<?php
/**
 * Who may open Reports. The admin decides, per person, on Reports > Access.
 *
 *   none : no Reports menu, every /reports URL is 403
 *   own  : sees reports about their own time only
 *   all  : sees everyone's time (team reports included)
 *
 * Admins always have full access. A person with no row in report_access has no
 * access. If the report_access table has not been created yet (SQL step 7 not run),
 * the old role-permission rules apply so the app keeps working.
 */

declare(strict_types=1);

final class ReportAccessHelper
{
    public const NONE = 'none';
    public const OWN  = 'own';
    public const ALL  = 'all';

    /** @var array<int, array{level:string,export:bool,billing:bool}> */
    private static array $cache = [];

    public static function tableReady(): bool
    {
        return SchemaHelper::tableExists('report_access');
    }

    /** @return array{level:string,export:bool,billing:bool} */
    public static function forCurrentUser(): array
    {
        $userId = (int) AuthHelper::id();
        if ($userId < 1) {
            return ['level' => self::NONE, 'export' => false, 'billing' => false];
        }

        if (isset(self::$cache[$userId])) {
            return self::$cache[$userId];
        }

        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            return self::$cache[$userId] = ['level' => self::ALL, 'export' => true, 'billing' => true];
        }

        if (!self::tableReady()) {
            $legacy = PermissionHelper::has('reports.view') && FeatureFlagsHelper::reportsVisible();

            return self::$cache[$userId] = [
                'level'   => !$legacy ? self::NONE : (PermissionHelper::has('time.view_all') ? self::ALL : self::OWN),
                'export'  => $legacy && PermissionHelper::has('reports.export'),
                'billing' => $legacy && PermissionHelper::has('reports.billing'),
            ];
        }

        $row = Database::fetchOne(
            'SELECT access_level, can_export, can_billing FROM report_access WHERE user_id = :id',
            ['id' => $userId]
        );

        if ($row === null) {
            return self::$cache[$userId] = ['level' => self::NONE, 'export' => false, 'billing' => false];
        }

        return self::$cache[$userId] = [
            'level'   => $row['access_level'] === self::ALL ? self::ALL : self::OWN,
            'export'  => (int) $row['can_export'] === 1,
            'billing' => (int) $row['can_billing'] === 1,
        ];
    }

    public static function canView(): bool
    {
        return self::forCurrentUser()['level'] !== self::NONE;
    }

    /** Sees other people's time. Clients never do: their view is limited to their own clients' projects. */
    public static function canViewAll(): bool
    {
        return self::forCurrentUser()['level'] === self::ALL && !AuthHelper::hasRole(AuthHelper::ROLE_CLIENT);
    }

    public static function canExport(): bool
    {
        return self::canView() && self::forCurrentUser()['export'];
    }

    public static function canBilling(): bool
    {
        return self::canView() && self::forCurrentUser()['billing'];
    }

    public static function requireView(): void
    {
        if (!self::canView()) {
            LoggerHelper::warning('Reports access denied', ['user_id' => AuthHelper::id()]);
            throw new HttpException(403);
        }
    }

    public static function requireAdmin(): void
    {
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            throw new HttpException(403);
        }
    }
}
