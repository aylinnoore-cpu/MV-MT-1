<?php require __DIR__.'/../includes/lib.php';allow(['support','ed','finance']);$s=$_GET['s']??'pending';
$w=['pending'=>'status IN("requested","ed_approved","finance_approved")','approved'=>'status="po_issued"','rejected'=>'status="rejected"'][$s]??die('?');
head('Approvals');foreach(['pending','approved','rejected'] as $t)echo "<a class='btn ".($t==$s?'':'g')."' href='?s=$t'>".ucfirst($t).'</a> ';
$us=array_column(q('SELECT id,name FROM users')->fetchAll(),'name','id');
echo '<div class=card><table><tr><th>#<th>Request<th>Type<th>Amount<th>Status<th>Requested by<th>Quotes<th>Date<th>';
foreach(q("SELECT p.*,(SELECT COUNT(*) FROM documents d WHERE d.kind='quotation' AND d.ref_id=p.id) qn FROM procurement p WHERE $w ORDER BY id DESC") as $x)
 echo "<tr><td>$x[id]<td>".h($x['title']).'<td>'.pretty($x['type'])."<td>$x[amount]<td><span class=tag>".pretty($x['status']).'</span><td>'.h($us[$x['requested_by']]??'')."<td>$x[qn]<td>$x[created_at]<td><a href='records.php?m=procurement&a=view&id=$x[id]'>Details / Decide</a>";
echo '</table></div><div class=card><b>Approval history</b><table><tr><th>Date &amp; time<th>Request<th>Action<th>By<th>Remarks';
foreach(q('SELECT a.*,p.title FROM approvals a LEFT JOIN procurement p ON p.id=a.entity_id ORDER BY a.id DESC LIMIT 50') as $x)
 echo "<tr><td>$x[created_at]<td>#$x[entity_id] ".h($x['title']).'<td>'.pretty($x['action']).'<td>'.h($us[$x['approver_id']]??'').'<td>'.h($x['remarks']);
echo '</table></div>';foot();
