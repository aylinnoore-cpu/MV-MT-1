<?php
/**
 * Notifications page: full history with All / Unread tabs, a type filter and pagination.
 *
 * @var bool   $installed notifications table exists
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int} $result
 * @var array{total: int, unread: int} $counts
 * @var string $filter 'all' | 'unread'
 * @var string $type   '' or one of info|success|warning|danger
 */

$items  = $result['items'];
$unread = (int) $counts['unread'];

$typeIcon = [
    'success' => 'fa-circle-check',
    'warning' => 'fa-triangle-exclamation',
    'danger'  => 'fa-circle-exclamation',
    'info'    => 'fa-circle-info',
];
$typeLabel = [
    'info'    => 'Info',
    'success' => 'Success',
    'warning' => 'Warning',
    'danger'  => 'Alert',
];

/** Query string for this page, keeping the active filters. Defaults are left out of the URL. */
$query = static function (array $override = []) use ($filter, $type, $result): string {
    $merged = array_merge(['filter' => $filter, 'type' => $type, 'page' => $result['page']], $override);
    if ($merged['filter'] !== 'unread') {
        unset($merged['filter']);
    }
    if ($merged['type'] === '') {
        unset($merged['type']);
    }
    if ((int) $merged['page'] <= 1) {
        unset($merged['page']);
    }

    return $merged === [] ? '' : '?' . http_build_query($merged);
};

$basePath   = url('/notifications');
$returnPath = '/notifications' . $query();
$firstShown = $result['total'] === 0 ? 0 : ($result['page'] - 1) * $result['per_page'] + 1;
$lastShown  = min($result['total'], $result['page'] * $result['per_page']);
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Notifications</h2>
        <p class="page-lead">Updates about your tasks, timesheets, schedule and projects.</p>
    </div>
    <form method="post" action="<?= e(url('/notifications/read-all')) ?>" class="m-0" data-notification-form data-kind="all"<?= $unread > 0 ? '' : ' hidden' ?>>
        <?= csrf_field() ?>
        <input type="hidden" name="return" value="<?= e($returnPath) ?>">
        <button type="submit" class="btn btn-outline-secondary"><i class="fa-solid fa-check-double me-1" aria-hidden="true"></i>Mark all as read</button>
    </form>
</div>

<div class="notification-page" data-notifications-page>
    <div aria-live="polite">
        <div class="alert alert-danger mb-3" role="alert" data-notification-alert hidden>
            <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap">
                <span data-notification-alert-text></span>
                <button type="button" class="btn btn-sm btn-outline-danger" data-notification-retry>Try again</button>
            </div>
        </div>
    </div>

    <nav class="filter-tabs" aria-label="Notification status">
        <a class="filter-tab<?= $filter === 'all' ? ' is-active' : '' ?>" href="<?= e($basePath . $query(['filter' => 'all', 'page' => 1])) ?>"<?= $filter === 'all' ? ' aria-current="page"' : '' ?>>
            All <span class="count-pill"><?= (int) $counts['total'] ?></span>
        </a>
        <a class="filter-tab<?= $filter === 'unread' ? ' is-active' : '' ?>" href="<?= e($basePath . $query(['filter' => 'unread', 'page' => 1])) ?>"<?= $filter === 'unread' ? ' aria-current="page"' : '' ?>>
            Unread <span class="count-pill" data-unread-count><?= $unread ?></span>
        </a>
    </nav>

    <form method="get" action="<?= e($basePath) ?>" class="filter-bar">
        <?php if ($filter === 'unread'): ?><input type="hidden" name="filter" value="unread"><?php endif; ?>
        <div>
            <label for="notification-type" class="visually-hidden">Type</label>
            <select id="notification-type" name="type" class="form-select">
                <option value="">All types</option>
                <?php foreach ($typeLabel as $key => $label): ?>
                    <option value="<?= e($key) ?>"<?= $type === $key ? ' selected' : '' ?>><?= e($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-outline-secondary">Filter</button>
        <?php if ($type !== ''): ?>
            <a class="btn btn-link" href="<?= e($basePath . $query(['type' => '', 'page' => 1])) ?>">Clear</a>
        <?php endif; ?>
    </form>

    <section class="panel" aria-labelledby="notifications-title">
        <div class="panel-head">
            <h2 id="notifications-title" class="panel-title">
                <?= $filter === 'unread' ? 'Unread' : 'All notifications' ?>
                <span class="count-pill"><?= (int) $result['total'] ?></span>
            </h2>
        </div>

        <?php if (!$installed): ?>
            <div class="empty-state">
                <i class="fa-solid fa-database" aria-hidden="true"></i>
                <p>Notifications are not set up on this installation yet. Ask an administrator to run the database upgrade.</p>
            </div>
        <?php elseif ($items === []): ?>
            <div class="empty-state">
                <i class="fa-regular fa-bell-slash" aria-hidden="true"></i>
                <?php if ($filter === 'unread' || $type !== ''): ?>
                    <p>No notifications match these filters.</p>
                <?php else: ?>
                    <p>You are all caught up. New messages about your projects and time will show up here.</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <ul class="feed">
                <?php foreach ($items as $note): ?>
                    <?php
                    $id       = (int) $note['id'];
                    $isUnread = (int) $note['is_read'] === 0;
                    $kind     = isset($typeIcon[(string) $note['type']]) ? (string) $note['type'] : 'info';
                    $href     = Notification::href((string) ($note['link'] ?? ''));
                    $readUrl  = url('/notifications/' . $id . '/read');
                    ?>
                    <li class="feed-item<?= $isUnread ? ' is-unread' : '' ?>" data-notification-row data-id="<?= $id ?>">
                        <span class="feed-icon feed-<?= e($kind) ?>" aria-hidden="true"><i class="fa-solid <?= e($typeIcon[$kind]) ?>"></i></span>
                        <div class="feed-body">
                            <div class="feed-title">
                                <?php if ($href !== ''): ?>
                                    <a href="<?= e($href) ?>" data-notification-link data-read-url="<?= e($isUnread ? $readUrl : '') ?>"><?= e($note['title']) ?></a>
                                <?php else: ?>
                                    <?= e($note['title']) ?>
                                <?php endif; ?>
                                <?php if ($isUnread): ?><span class="visually-hidden" data-unread-label>(unread)</span><?php endif; ?>
                            </div>
                            <?php if (!empty($note['message'])): ?>
                                <div class="feed-text"><?= e($note['message']) ?></div>
                            <?php endif; ?>
                            <div class="feed-type"><?= e($typeLabel[$kind]) ?></div>
                        </div>
                        <div class="feed-aside">
                            <time class="feed-time" datetime="<?= e(str_replace(' ', 'T', (string) $note['created_at'])) ?>Z"><?= e(FormatHelper::datetime((string) $note['created_at'], 'M j, Y, H:i')) ?></time>
                            <?php if ($isUnread): ?>
                                <form method="post" action="<?= e($readUrl) ?>" class="m-0" data-notification-form data-kind="one">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="return" value="<?= e($returnPath) ?>">
                                    <button type="submit" class="btn btn-link btn-sm p-0">Mark as read</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>

            <div class="notification-pager">
                <span class="text-secondary small">Showing <?= (int) $firstShown ?>&ndash;<?= (int) $lastShown ?> of <?= (int) $result['total'] ?></span>
                <?php if ($result['pages'] > 1): ?>
                    <nav class="d-flex align-items-center gap-2" aria-label="Notification pages">
                        <?php if ($result['page'] > 1): ?>
                            <a class="btn btn-sm btn-outline-secondary" rel="prev" href="<?= e($basePath . $query(['page' => $result['page'] - 1])) ?>">Previous</a>
                        <?php endif; ?>
                        <span class="small">Page <?= (int) $result['page'] ?> of <?= (int) $result['pages'] ?></span>
                        <?php if ($result['page'] < $result['pages']): ?>
                            <a class="btn btn-sm btn-outline-secondary" rel="next" href="<?= e($basePath . $query(['page' => $result['page'] + 1])) ?>">Next</a>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>
</div>
