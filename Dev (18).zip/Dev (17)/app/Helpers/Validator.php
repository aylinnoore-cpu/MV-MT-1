<?php
/**
 * Declarative server-side validation.
 *
 *   $v = ValidatorHelper::make($request->all(), [
 *       'name'     => 'required|string|max:120',
 *       'email'    => 'required|email|max:190|unique:users,email',
 *       'role'     => 'required|in:admin,manager,employee,client',
 *       'budget'   => 'nullable|numeric|min:0',
 *       'due_date' => 'nullable|date',
 *   ]);
 *   if ($v->fails()) { ... $v->errors() ... }
 *   $clean = $v->validated();   // ONLY the fields that have rules (mass-assignment safe)
 *
 * Rules: required, nullable, string, int, numeric, boolean, email, url, date, datetime,
 *        min:n, max:n, between:a,b, in:a,b,c, regex:/pattern/, same:field, confirmed,
 *        strong_password, timezone, unique:table,column[,ignoreId], exists:table,column
 *
 * min/max/between mean: length for strings, value for int/numeric.
 */

declare(strict_types=1);

final class ValidatorHelper
{
    /** @var array<string, string> first error per field */
    private array $errors = [];

    /** @var array<string, mixed> */
    private array $validated = [];

    /**
     * @param array<string, mixed>                   $data
     * @param array<string, string|list<string>>     $rules
     * @param array<string, string>                  $labels Human field names for messages
     */
    private function __construct(
        private readonly array $data,
        private readonly array $rules,
        private readonly array $labels,
    ) {
    }

    /**
     * @param array<string, mixed>               $data
     * @param array<string, string|list<string>> $rules
     * @param array<string, string>              $labels
     */
    public static function make(array $data, array $rules, array $labels = []): self
    {
        $validator = new self($data, $rules, $labels);
        $validator->run();

        return $validator;
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }

    /** @return array<string, string> */
    public function errors(): array
    {
        return $this->errors;
    }

    /** @return array<string, mixed> Trimmed, typed values for fields that passed. */
    public function validated(): array
    {
        return $this->validated;
    }

    private function run(): void
    {
        foreach ($this->rules as $field => $ruleSet) {
            $rules    = is_array($ruleSet) ? $ruleSet : explode('|', $ruleSet);
            $value    = $this->normalize($this->data[$field] ?? null);
            $nullable = in_array('nullable', $rules, true);
            $blank    = $value === null || $value === '';

            if ($blank) {
                if (in_array('required', $rules, true)) {
                    $this->fail($field, ':field is required.');
                } else {
                    // Optional and empty: keep as null so callers can store NULL.
                    $this->validated[$field] = null;
                }
                continue;
            }

            $kind = $this->detectKind($rules);

            foreach ($rules as $rule) {
                if (in_array($rule, ['required', 'nullable'], true)) {
                    continue;
                }
                if (!$this->check($field, $value, $rule, $kind)) {
                    break; // first failing rule per field is enough
                }
            }

            if (!isset($this->errors[$field])) {
                $this->validated[$field] = $this->cast($value, $kind);
            }
        }
    }

    /** Trim strings; reject arrays/objects outright (they are never valid scalar input here). */
    private function normalize(mixed $value): mixed
    {
        if (is_string($value)) {
            return trim($value);
        }

        return is_scalar($value) || $value === null ? $value : '';
    }

    /** @param list<string> $rules */
    private function detectKind(array $rules): string
    {
        foreach (['int', 'numeric', 'boolean'] as $kind) {
            if (in_array($kind, $rules, true)) {
                return $kind;
            }
        }

        return 'string';
    }

    private function cast(mixed $value, string $kind): mixed
    {
        return match ($kind) {
            'int'     => (int) $value,
            'numeric' => (float) $value,
            'boolean' => filter_var($value, FILTER_VALIDATE_BOOLEAN) ? 1 : 0,
            default   => (string) $value,
        };
    }

    private function check(string $field, mixed $value, string $rule, string $kind): bool
    {
        [$name, $argument] = array_pad(explode(':', $rule, 2), 2, '');
        $args = $argument === '' ? [] : explode(',', $argument);

        $ok = match ($name) {
            'string'          => is_string($value) || is_numeric($value),
            'int'             => filter_var($value, FILTER_VALIDATE_INT) !== false,
            'numeric'         => is_numeric($value),
            'boolean'         => in_array(strtolower((string) $value), ['1', '0', 'true', 'false', 'on', 'off', 'yes', 'no'], true),
            'email'           => filter_var($value, FILTER_VALIDATE_EMAIL) !== false,
            'url'             => $this->isHttpUrl((string) $value),
            'date'            => $this->isDate((string) $value, 'Y-m-d'),
            'datetime'        => $this->isDate((string) $value, 'Y-m-d H:i:s') || $this->isDate((string) $value, 'Y-m-d H:i') || $this->isDate((string) $value, 'Y-m-d\TH:i'),
            'min'             => $this->measure($value, $kind) >= (float) ($args[0] ?? 0),
            'max'             => $this->measure($value, $kind) <= (float) ($args[0] ?? 0),
            'between'         => $this->measure($value, $kind) >= (float) ($args[0] ?? 0) && $this->measure($value, $kind) <= (float) ($args[1] ?? 0),
            'in'              => in_array((string) $value, $args, true),
            'regex'           => $this->matchesRegex((string) $value, $argument),
            'same'            => (string) $value === (string) ($this->data[$args[0] ?? ''] ?? ''),
            'confirmed'       => (string) $value === (string) ($this->data[$field . '_confirmation'] ?? ''),
            'strong_password' => $this->isStrongPassword((string) $value),
            'timezone'        => in_array((string) $value, DateTimeZone::listIdentifiers(), true),
            'unique'          => $this->isUnique((string) $value, $args),
            'exists'          => $this->exists((string) $value, $args),
            default           => throw new InvalidArgumentException("Unknown validation rule: {$name}"),
        };

        if (!$ok) {
            $this->fail($field, $this->message($name, $args, $kind));
        }

        return $ok;
    }

    /** Length for strings, numeric value for int/numeric fields. */
    private function measure(mixed $value, string $kind): float
    {
        return $kind === 'string' ? (float) mb_strlen((string) $value, 'UTF-8') : (float) $value;
    }

    private function isDate(string $value, string $format): bool
    {
        $parsed = DateTimeImmutable::createFromFormat('!' . $format, $value);
        $errors = DateTimeImmutable::getLastErrors();

        return $parsed !== false
            && $parsed->format($format) === $value
            && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0));
    }

    /** Only http/https URLs: blocks javascript:, data: and file: schemes that enable XSS or SSRF tricks. */
    private function isHttpUrl(string $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_URL) !== false
            && in_array(strtolower((string) parse_url($value, PHP_URL_SCHEME)), ['http', 'https'], true);
    }

    private function matchesRegex(string $value, string $pattern): bool
    {
        return $pattern !== '' && @preg_match($pattern, $value) === 1;
    }

    /** At least 10 characters with lower, upper and a digit. Length is capped for bcrypt (72 bytes). */
    private function isStrongPassword(string $value): bool
    {
        return strlen($value) >= 10
            && strlen($value) <= 72
            && preg_match('/[a-z]/', $value) === 1
            && preg_match('/[A-Z]/', $value) === 1
            && preg_match('/\d/', $value) === 1;
    }

    /** @param list<string> $args [table, column, ignoreId?] */
    private function isUnique(string $value, array $args): bool
    {
        [$table, $column] = $this->identifiers($args);
        $sql    = "SELECT COUNT(*) FROM `{$table}` WHERE `{$column}` = ?";
        $params = [$value];

        if (isset($args[2]) && $args[2] !== '') {
            $sql .= ' AND `id` <> ?';
            $params[] = (int) $args[2];
        }

        return (int) Database::fetchValue($sql, $params) === 0;
    }

    /** @param list<string> $args [table, column] */
    private function exists(string $value, array $args): bool
    {
        [$table, $column] = $this->identifiers($args);

        return (int) Database::fetchValue("SELECT COUNT(*) FROM `{$table}` WHERE `{$column}` = ?", [$value]) > 0;
    }

    /**
     * Identifiers are interpolated into SQL (they cannot be bound), so they must be
     * developer-supplied and strictly shaped. Never build rules from user input.
     *
     * @param list<string> $args
     * @return array{0: string, 1: string}
     */
    private function identifiers(array $args): array
    {
        $table  = $args[0] ?? '';
        $column = $args[1] ?? '';

        if (!preg_match('/^[a-z_][a-z0-9_]*$/', $table) || !preg_match('/^[a-z_][a-z0-9_]*$/', $column)) {
            throw new InvalidArgumentException('Invalid table or column in validation rule.');
        }

        return [$table, $column];
    }

    /** @param list<string> $args */
    private function message(string $rule, array $args, string $kind): string
    {
        $unit = $kind === 'string' ? ' characters' : '';

        return match ($rule) {
            'string'          => ':field must be text.',
            'int'             => ':field must be a whole number.',
            'numeric'         => ':field must be a number.',
            'boolean'         => ':field must be true or false.',
            'email'           => ':field must be a valid email address.',
            'url'             => ':field must be a valid http(s) URL.',
            'date'            => ':field must be a valid date (YYYY-MM-DD).',
            'datetime'        => ':field must be a valid date and time.',
            'min'             => ":field must be at least {$args[0]}{$unit}.",
            'max'             => ":field must not be more than {$args[0]}{$unit}.",
            'between'         => ":field must be between {$args[0]} and {$args[1]}{$unit}.",
            'in'              => ':field has an invalid selection.',
            'regex'           => ':field has an invalid format.',
            'same'            => ':field does not match.',
            'confirmed'       => ':field confirmation does not match.',
            'strong_password' => ':field must be 10 to 72 characters with upper-case, lower-case and a number.',
            'timezone'        => ':field must be a valid timezone.',
            'unique'          => ':field is already in use.',
            'exists'          => ':field does not exist.',
            default           => ':field is invalid.',
        };
    }

    private function fail(string $field, string $template): void
    {
        $label = $this->labels[$field] ?? ucfirst(str_replace('_', ' ', $field));
        $this->errors[$field] ??= str_replace(':field', $label, $template);
    }
}
