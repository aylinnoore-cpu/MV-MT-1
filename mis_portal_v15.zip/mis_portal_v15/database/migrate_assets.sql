USE mis_portal;
ALTER TABLE assets MODIFY status ENUM('active','under_repair','faulty','dead','working','out_for_repair','out_for_maintenance','in_storage','lost') DEFAULT 'working';
UPDATE assets SET status='working' WHERE status='active';
UPDATE assets SET status='out_for_repair' WHERE status='under_repair';
ALTER TABLE assets MODIFY status ENUM('working','out_for_repair','out_for_maintenance','in_storage','faulty','dead','lost') DEFAULT 'working';
ALTER TABLE assets ADD COLUMN IF NOT EXISTS mac_supported ENUM('No','Yes') DEFAULT 'No',
 ADD COLUMN IF NOT EXISTS mac_address VARCHAR(17) NULL, ADD COLUMN IF NOT EXISTS ip_address VARCHAR(45) NULL,
 ADD COLUMN IF NOT EXISTS ip_type ENUM('Static','DHCP reservation') NULL;
