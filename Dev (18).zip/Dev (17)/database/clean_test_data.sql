-- TimeTrack clean-test-data script.
-- INTENTIONALLY DESTRUCTIVE. Run only against a dedicated test database.
-- Keeps schema, roles and permissions; removes application/demo activity and
-- user-created business data. It does not delete the workspace row.
SET FOREIGN_KEY_CHECKS=0;
TRUNCATE TABLE timesheet_entries;
TRUNCATE TABLE timesheets;
TRUNCATE TABLE time_entries;
TRUNCATE TABLE active_timers;
TRUNCATE TABLE task_assignees;
TRUNCATE TABLE tasks;
TRUNCATE TABLE schedule_recurrences;
TRUNCATE TABLE schedules;
TRUNCATE TABLE project_favorites;
TRUNCATE TABLE project_members;
TRUNCATE TABLE projects;
TRUNCATE TABLE clients;
TRUNCATE TABLE notifications;
TRUNCATE TABLE activity_logs;
SET FOREIGN_KEY_CHECKS=1;
