<?php
/**
 * Brand identity that an administrator controls from System settings (no code edits):
 * primary colour, application logo, and the matching theme CSS.
 *
 * Design rules
 *  - Nothing is configured by default: with no brand colour saved, css() returns '' and the
 *    application keeps its built-in look exactly as shipped.
 *  - One colour in, a whole palette out. Hover, pressed, soft and pale shades are derived, and
 *    text colours are chosen for contrast so a very light or very dark pick stays readable.
 *  - The logo is validated, re-encoded with GD when available (strips metadata and any hidden
 *    payload) and stored under public/uploads/branding. Only a bare file name is kept in
 *    settings, and it is re-validated on every read, so a tampered row cannot point elsewhere.
 *  - SVG is deliberately not accepted: it can carry scripts.
 */

declare(strict_types=1);

final class BrandingHelper
{
    /** Colour emails fall back to when no brand colour has been chosen. */
    public const EMAIL_DEFAULT = '#0b7a75';

    public const LOGO_MAX_BYTES = 1048576; // 1 MiB
    public const LOGO_MIN_PX    = 32;
    public const LOGO_MAX_PX    = 4000;
    private const LOGO_STORE_PX = 512;     // larger images are scaled down on save

    private const LOGO_DIR  = '/uploads/branding';
    private const LOGO_NAME = '/^logo-[a-f0-9]{16}\.(png|jpg|webp)$/';

    public const FAVICON_MIN_PX    = 32;
    private const FAVICON_STORE_PX = 256;  // favicons never need more; larger images are scaled down
    private const FAVICON_NAME     = '/^favicon-[a-f0-9]{16}\.(png|jpg|webp)$/';

    /* ------------------------------------------------------------------ colour */

    /** Accepts "#0B7A75", "0b7a75" or "#0b7" and returns "#0b7a75", or null when invalid. */
    public static function normalizeHex(string $value): ?string
    {
        $value = strtolower(trim($value));
        $value = ltrim($value, '#');

        if (preg_match('/^[0-9a-f]{3}$/', $value) === 1) {
            $value = $value[0] . $value[0] . $value[1] . $value[1] . $value[2] . $value[2];
        }

        return preg_match('/^[0-9a-f]{6}$/', $value) === 1 ? '#' . $value : null;
    }

    /** The saved brand colour as "#rrggbb", or '' when none is set (built-in theme). */
    public static function color(): string
    {
        return self::normalizeHex(SettingsService::systemString('brand_color', '')) ?? '';
    }

    /** Brand colour for places that always need one (emails): saved colour or the default. */
    public static function colorOrDefault(): string
    {
        $color = self::color();

        return $color !== '' ? $color : self::EMAIL_DEFAULT;
    }

    /** Dark header colour for emails, derived from the brand colour. */
    public static function emailHeaderColor(): string
    {
        $color = self::color();

        return $color !== '' ? self::mix($color, '#000000', 0.72) : '#0f2a2b';
    }

    /** Readable text colour for use ON the given background: white or near-black. */
    public static function textOn(string $background): string
    {
        $dark = '#17232b';

        return self::contrast($background, '#ffffff') >= self::contrast($background, $dark) ? '#ffffff' : $dark;
    }

    /**
     * Theme overrides appended after the main stylesheets. Empty string = keep built-in colours.
     * Only values built from a validated hex colour are ever written, so nothing user-typed
     * reaches the stylesheet.
     */
    public static function css(): string
    {
        $b = self::color();
        if ($b === '') {
            return '';
        }

        $dark   = self::mix($b, '#000000', 0.18);   // hover
        $darker = self::mix($b, '#000000', 0.34);   // pressed
        $soft   = self::mix($b, '#ffffff', 0.35);
        $pale   = self::mix($b, '#ffffff', 0.88);   // avatar, selected rows
        $wash   = self::mix($b, '#ffffff', 0.92);   // active nav item
        $ink    = self::mix($b, '#000000', 0.72);   // login panel, mobile menu
        $ink2   = self::mix($b, '#000000', 0.62);
        $bar    = self::mix($b, '#000000', 0.45);   // decorative bars
        $on     = self::textOn($b);
        $link   = self::readableOn($b, '#ffffff', 4.5, false);       // links on white pages
        $linkH  = self::mix($link, '#000000', 0.18);
        $linkDk = self::readableOn($b, '#1b2024', 4.5, true);        // links in dark theme
        $linkDkH = self::mix($linkDk, '#ffffff', 0.18);

        $rgb    = self::rgbList($b);
        $linkRgb = self::rgbList($link);
        $linkHRgb = self::rgbList($linkH);
        $linkDkRgb = self::rgbList($linkDk);
        $linkDkHRgb = self::rgbList($linkDkH);

        return <<<CSS
:root{--tt-tide:{$b};--tt-tide-dark:{$dark};--tt-ink:{$ink};--tt-ink-2:{$ink2};--clock-blue:{$b};--clock-blue-dark:{$dark};--brand-on:{$on};--bs-primary:{$b};--bs-primary-rgb:{$rgb};--bs-link-color:{$link};--bs-link-color-rgb:{$linkRgb};--bs-link-hover-color:{$linkH};--bs-link-hover-color-rgb:{$linkHRgb};--bs-focus-ring-color:rgba({$rgb},.28)}
.cf-page,.cf-head,.cf-tabs{--cf-blue:{$b};--cf-blue-soft:{$soft};--cf-blue-pale:{$pale}}
.btn-primary{--bs-btn-color:{$on};--bs-btn-hover-color:{$on};--bs-btn-active-color:{$on};--bs-btn-disabled-color:{$on};--bs-btn-bg:{$b};--bs-btn-border-color:{$b};--bs-btn-hover-bg:{$dark};--bs-btn-hover-border-color:{$dark};--bs-btn-active-bg:{$darker};--bs-btn-active-border-color:{$darker};--bs-btn-disabled-bg:{$b};--bs-btn-disabled-border-color:{$b};--bs-btn-focus-shadow-rgb:{$rgb}}
.btn-outline-primary{--bs-btn-color:{$link};--bs-btn-border-color:{$b};--bs-btn-hover-color:{$on};--bs-btn-hover-bg:{$b};--bs-btn-hover-border-color:{$b};--bs-btn-active-color:{$on};--bs-btn-active-bg:{$dark};--bs-btn-active-border-color:{$dark};--bs-btn-focus-shadow-rgb:{$rgb}}
.brand-mark{background:{$b};color:{$on}}
.workspace-dot{background:{$b}}
.avatar{background:{$pale};color:{$link}}
.sidebar-link.active{background:{$wash}}
.sidebar-link.active i{color:{$dark}}
.form-control:focus,.form-select:focus{border-color:{$b};box-shadow:0 0 0 .22rem rgba({$rgb},.2)}
.cf-input:focus,.cf-select:focus{border-color:{$b};box-shadow:0 0 0 2px rgba({$rgb},.12)}
:focus-visible{outline-color:{$b}}
.ruler-bar{background:{$bar}}
html[data-bs-theme='dark']{--bs-link-color:{$linkDk};--bs-link-color-rgb:{$linkDkRgb};--bs-link-hover-color:{$linkDkH};--bs-link-hover-color-rgb:{$linkDkHRgb}}
CSS;
    }

    /* -------------------------------------------------------------------- logo */

    /** File name of the saved logo, or '' when none (or when the stored value is not a safe name). */
    public static function logoFile(): string
    {
        $file = SettingsService::systemString('brand_logo', '');

        return preg_match(self::LOGO_NAME, $file) === 1 && is_file(self::logoDir() . '/' . $file) ? $file : '';
    }

    public static function logoUrl(): string
    {
        $file = self::logoFile();

        return $file !== '' ? FormatHelper::url(self::LOGO_DIR . '/' . $file) : '';
    }

    /** File name of the saved favicon, or '' when none (or when the stored value is not a safe name). */
    public static function faviconFile(): string
    {
        $file = SettingsService::systemString('brand_favicon', '');

        return preg_match(self::FAVICON_NAME, $file) === 1 && is_file(self::logoDir() . '/' . $file) ? $file : '';
    }

    /** URL of the uploaded favicon, or '' when none (the built-in icon is used instead). */
    public static function faviconUrl(): string
    {
        $file = self::faviconFile();

        return $file !== '' ? FormatHelper::url(self::LOGO_DIR . '/' . $file) : '';
    }

    /**
     * The square brand tile: the uploaded logo when there is one, otherwise the stopwatch icon.
     * Returns ready-to-print HTML (every dynamic value is escaped).
     */
    public static function mark(): string
    {
        $url = self::logoUrl();
        if ($url === '') {
            return '<span class="brand-mark" aria-hidden="true"><i class="fa-solid fa-stopwatch"></i></span>';
        }

        return '<span class="brand-mark has-logo" aria-hidden="true"><img src="'
            . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" alt=""></span>';
    }

    /**
     * Validate and store an uploaded logo. Returns the new bare file name.
     *
     * @param array<string, mixed> $file one entry of $_FILES
     * @throws RuntimeException with a message that is safe to show to the administrator
     */
    public static function saveLogo(array $file): string
    {
        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            throw new RuntimeException('That image is larger than the server allows. Use one under 1 MB.');
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException('The logo could not be uploaded. Please try again.');
        }

        $tmp = (string) ($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            throw new RuntimeException('The logo could not be uploaded. Please try again.');
        }
        if ((int) ($file['size'] ?? 0) > self::LOGO_MAX_BYTES) {
            throw new RuntimeException('The logo must be 1 MB or smaller.');
        }

        return self::storeImage($tmp);
    }

    /**
     * Validate an image on disk and write it to the branding folder. Split from saveLogo() so the
     * checks can run without a real HTTP upload.
     */
    public static function storeImage(string $path): string
    {
        $info = @getimagesize($path);
        $types = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
        $mime = is_array($info) ? (string) ($info['mime'] ?? '') : '';

        if (!isset($types[$mime])) {
            throw new RuntimeException('The logo must be a PNG, JPG or WebP image.');
        }

        [$w, $h] = [(int) $info[0], (int) $info[1]];
        if ($w < self::LOGO_MIN_PX || $h < self::LOGO_MIN_PX) {
            throw new RuntimeException('The logo is too small. Use at least ' . self::LOGO_MIN_PX . ' x ' . self::LOGO_MIN_PX . ' pixels.');
        }
        if ($w > self::LOGO_MAX_PX || $h > self::LOGO_MAX_PX) {
            throw new RuntimeException('The logo is too large. Use at most ' . self::LOGO_MAX_PX . ' x ' . self::LOGO_MAX_PX . ' pixels.');
        }

        $dir = self::logoDir();
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new RuntimeException('The uploads folder is not writable. Check permissions on public/uploads.');
        }

        $token = bin2hex(random_bytes(8));

        // Preferred path: decode and re-encode, which drops EXIF/ICC data and any appended payload.
        if (function_exists('imagecreatefromstring') && function_exists('imagepng')) {
            $image = @imagecreatefromstring((string) file_get_contents($path));
            if ($image === false) {
                throw new RuntimeException('That image could not be read. Try exporting it again as PNG.');
            }

            $longest = max($w, $h);
            if ($longest > self::LOGO_STORE_PX) {
                $scale = self::LOGO_STORE_PX / $longest;
                $scaled = imagescale($image, max(1, (int) round($w * $scale)), max(1, (int) round($h * $scale)));
                if ($scaled !== false) {
                    $image = $scaled;
                }
            }

            imagealphablending($image, false);
            imagesavealpha($image, true);

            $name = 'logo-' . $token . '.png';
            $ok = imagepng($image, $dir . '/' . $name, 6);
            if (!$ok) {
                throw new RuntimeException('The logo could not be saved. Check permissions on public/uploads.');
            }

            return $name;
        }

        // GD is missing: keep the validated original bytes.
        $name = 'logo-' . $token . '.' . $types[$mime];
        if (!@copy($path, $dir . '/' . $name)) {
            throw new RuntimeException('The logo could not be saved. Check permissions on public/uploads.');
        }

        return $name;
    }

    /**
     * Validate and store an uploaded favicon. Returns the new bare file name.
     * A wide or tall image is centred on a transparent square so it is never stretched.
     *
     * @param array<string, mixed> $file one entry of $_FILES
     * @throws RuntimeException with a message that is safe to show to the administrator
     */
    public static function saveFavicon(array $file): string
    {
        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            throw new RuntimeException('That image is larger than the server allows. Use one under 1 MB.');
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException('The favicon could not be uploaded. Please try again.');
        }

        $tmp = (string) ($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            throw new RuntimeException('The favicon could not be uploaded. Please try again.');
        }
        if ((int) ($file['size'] ?? 0) > self::LOGO_MAX_BYTES) {
            throw new RuntimeException('The favicon must be 1 MB or smaller.');
        }

        return self::storeFaviconImage($tmp);
    }

    /** Validate an image on disk and write it, squared and scaled, to the branding folder. */
    public static function storeFaviconImage(string $path): string
    {
        $info = @getimagesize($path);
        $types = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
        $mime = is_array($info) ? (string) ($info['mime'] ?? '') : '';

        if (!isset($types[$mime])) {
            throw new RuntimeException('The favicon must be a PNG, JPG or WebP image.');
        }

        [$w, $h] = [(int) $info[0], (int) $info[1]];
        if ($w < self::FAVICON_MIN_PX || $h < self::FAVICON_MIN_PX) {
            throw new RuntimeException('The favicon is too small. Use at least ' . self::FAVICON_MIN_PX . ' x ' . self::FAVICON_MIN_PX . ' pixels.');
        }
        if ($w > self::LOGO_MAX_PX || $h > self::LOGO_MAX_PX) {
            throw new RuntimeException('The favicon is too large. Use at most ' . self::LOGO_MAX_PX . ' x ' . self::LOGO_MAX_PX . ' pixels.');
        }

        $dir = self::logoDir();
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new RuntimeException('The uploads folder is not writable. Check permissions on public/uploads.');
        }

        $token = bin2hex(random_bytes(8));

        // Preferred path: decode, centre on a transparent square, scale, re-encode as PNG
        // (drops EXIF/ICC data and any appended payload, like the logo).
        if (function_exists('imagecreatefromstring') && function_exists('imagepng')) {
            $image = @imagecreatefromstring((string) file_get_contents($path));
            if ($image === false) {
                throw new RuntimeException('That image could not be read. Try exporting it again as PNG.');
            }
            if (!imageistruecolor($image) && function_exists('imagepalettetotruecolor')) {
                imagepalettetotruecolor($image);
            }

            $side = max($w, $h);
            $square = imagecreatetruecolor($side, $side);
            imagealphablending($square, false);
            imagesavealpha($square, true);
            imagefill($square, 0, 0, imagecolorallocatealpha($square, 0, 0, 0, 127));
            imagecopy($square, $image, intdiv($side - $w, 2), intdiv($side - $h, 2), 0, 0, $w, $h);

            if ($side > self::FAVICON_STORE_PX) {
                $scaled = imagescale($square, self::FAVICON_STORE_PX, self::FAVICON_STORE_PX);
                if ($scaled !== false) {
                    $square = $scaled;
                    imagealphablending($square, false);
                    imagesavealpha($square, true);
                }
            }

            $name = 'favicon-' . $token . '.png';
            if (!imagepng($square, $dir . '/' . $name, 6)) {
                throw new RuntimeException('The favicon could not be saved. Check permissions on public/uploads.');
            }

            return $name;
        }

        // GD is missing: keep the validated original bytes.
        $name = 'favicon-' . $token . '.' . $types[$mime];
        if (!@copy($path, $dir . '/' . $name)) {
            throw new RuntimeException('The favicon could not be saved. Check permissions on public/uploads.');
        }

        return $name;
    }

    /** Remove a stored favicon file. Ignores anything that is not a bare, well-formed favicon name. */
    public static function deleteFavicon(string $file): void
    {
        if (preg_match(self::FAVICON_NAME, $file) !== 1) {
            return;
        }
        $path = self::logoDir() . '/' . $file;
        if (is_file($path)) {
            @unlink($path);
        }
    }

    /** Remove a stored logo file. Ignores anything that is not a bare, well-formed logo name. */
    public static function deleteLogo(string $file): void
    {
        if (preg_match(self::LOGO_NAME, $file) !== 1) {
            return;
        }
        $path = self::logoDir() . '/' . $file;
        if (is_file($path)) {
            @unlink($path);
        }
    }

    private static function logoDir(): string
    {
        return PUBLIC_PATH . self::LOGO_DIR;
    }

    /* ------------------------------------------------------------ colour maths */

    /** @return array{0:int,1:int,2:int} */
    private static function rgb(string $hex): array
    {
        $hex = ltrim($hex, '#');

        return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
    }

    private static function hex(int $r, int $g, int $b): string
    {
        return sprintf('#%02x%02x%02x', max(0, min(255, $r)), max(0, min(255, $g)), max(0, min(255, $b)));
    }

    private static function rgbList(string $hex): string
    {
        return implode(', ', self::rgb($hex));
    }

    /** Blend $a toward $b. $amount 0 = $a, 1 = $b. */
    private static function mix(string $a, string $b, float $amount): string
    {
        [$ar, $ag, $ab] = self::rgb($a);
        [$br, $bg, $bb] = self::rgb($b);

        return self::hex(
            (int) round($ar + ($br - $ar) * $amount),
            (int) round($ag + ($bg - $ag) * $amount),
            (int) round($ab + ($bb - $ab) * $amount)
        );
    }

    /** WCAG relative luminance. */
    private static function luminance(string $hex): float
    {
        $channels = array_map(static function (int $v): float {
            $c = $v / 255;

            return $c <= 0.03928 ? $c / 12.92 : (($c + 0.055) / 1.055) ** 2.4;
        }, self::rgb($hex));

        return 0.2126 * $channels[0] + 0.7152 * $channels[1] + 0.0722 * $channels[2];
    }

    /** WCAG contrast ratio between two colours (1 to 21). */
    public static function contrast(string $a, string $b): float
    {
        $la = self::luminance($a);
        $lb = self::luminance($b);

        return (max($la, $lb) + 0.05) / (min($la, $lb) + 0.05);
    }

    /**
     * Nudge $color until it reads on $background with at least $ratio contrast. Darkens for light
     * backgrounds, lightens for dark ones ($lighten). The brand colour itself is returned if it
     * already passes.
     */
    private static function readableOn(string $color, string $background, float $ratio, bool $lighten): string
    {
        $target = $lighten ? '#ffffff' : '#000000';
        for ($step = 0; $step <= 10; $step++) {
            $candidate = self::mix($color, $target, $step / 10);
            if (self::contrast($candidate, $background) >= $ratio) {
                return $candidate;
            }
        }

        return $target;
    }
}