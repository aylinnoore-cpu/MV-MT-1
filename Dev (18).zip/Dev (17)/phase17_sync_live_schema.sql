-- =====================================================================
-- TimeTrack Phase 17: bring a live database level with database/install.sql
--
-- Written against the live dump u897128490_timetrack.sql (2026-10-03,
-- MariaDB 11.8). Idempotent: safe to run more than once. Works in the
-- mysql CLI and in phpMyAdmin (no DELIMITER blocks, no stored programs).
--
-- What it does (and nothing else):
--   1. time_entries.auto_stopped            ADD (was missing)
--   2. users.role                           re-sync cache from roles.name
--   3. tasks.assigned_to -> task_assignees  copy any missing rows
--   4. activity_logs.entity_id              fill gaps from record_id
--   5. project_members.project_role         normalise + lowercase default
--   6. audit_logs view                      recreate WITHOUT record_id
--   7. DROP tasks.assigned_to (+FK, index), activity_logs.record_id,
--      redundant index timesheets.idx_timesheets_user
--   8. reports.view / reports.export / reports.billing permissions + roles
--
-- Deliberately NOT done here:
--   * tasks.status enum is left as the live enum
--     ('To Do','In Progress','On Hold','Review','Completed','Cancelled').
--     install.sql still has the old Open/In Progress/Done enum and must be
--     updated to match (code change, not a data change).
--   * No user, project, task or time-entry rows are modified or deleted.
--   * The billable_rate backfill from phase14_step19_reports.sql is skipped:
--     the columns already exist and every project rate is currently 0.00.
--
-- BEFORE RUNNING: take a full backup.
--   mysqldump --single-transaction --routines u897128490_timetrack > backup_before_phase17.sql
-- =====================================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------
-- 1. Timer auto-stop flag (code writes/reads it; column was missing)
-- ---------------------------------------------------------------------
ALTER TABLE `time_entries`
    ADD COLUMN IF NOT EXISTS `auto_stopped` TINYINT(1) NOT NULL DEFAULT 0 AFTER `approved_at`;

-- ---------------------------------------------------------------------
-- 2. users.role is a cache of roles.name; role_id is the source of truth
-- ---------------------------------------------------------------------
UPDATE `users` u
INNER JOIN `roles` r ON r.id = u.role_id
SET u.role = r.name
WHERE u.role <> r.name;

-- ---------------------------------------------------------------------
-- 3. Preserve legacy single-assignee data before the column is dropped
-- ---------------------------------------------------------------------
-- Guarded: on a re-run the column no longer exists, so the statement is skipped.
SET @sql := IF(
    EXISTS (SELECT 1 FROM information_schema.columns
            WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'assigned_to'),
    'INSERT IGNORE INTO `task_assignees` (`task_id`, `user_id`, `created_at`)
     SELECT t.id, t.assigned_to, UTC_TIMESTAMP()
     FROM `tasks` t
     WHERE t.assigned_to IS NOT NULL
       AND NOT EXISTS (SELECT 1 FROM `task_assignees` ta
                       WHERE ta.task_id = t.id AND ta.user_id = t.assigned_to)',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------------------
-- 4. Keep the audit trail intact: entity_id wins, fill gaps from record_id
-- ---------------------------------------------------------------------
SET @sql := IF(
    EXISTS (SELECT 1 FROM information_schema.columns
            WHERE table_schema = DATABASE() AND table_name = 'activity_logs' AND column_name = 'record_id'),
    'UPDATE `activity_logs` SET `entity_id` = `record_id`
     WHERE `entity_id` IS NULL AND `record_id` IS NOT NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------------------
-- 5. Canonical project roles are lowercase manager | member | viewer
-- ---------------------------------------------------------------------
-- Note: without BINARY, 'Member' = 'member' under utf8mb4_unicode_ci and would be skipped.
UPDATE `project_members`
SET `project_role` = CASE
        WHEN LOWER(`project_role`) = 'manager' THEN 'manager'
        WHEN LOWER(`project_role`) = 'viewer'  THEN 'viewer'
        ELSE 'member'
    END
WHERE BINARY `project_role` NOT IN ('manager', 'member', 'viewer');   -- BINARY: column collation is case-insensitive

ALTER TABLE `project_members`
    MODIFY `project_role` VARCHAR(60) NOT NULL DEFAULT 'member';

-- ---------------------------------------------------------------------
-- 6. Audit view must stop referencing record_id BEFORE the column is dropped.
--    SQL SECURITY INVOKER and no DEFINER, so it imports on any host/user.
-- ---------------------------------------------------------------------
CREATE OR REPLACE SQL SECURITY INVOKER VIEW `audit_logs` AS
    SELECT `id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`,
           `ip_address`, `user_agent`, `meta`, `old_value`, `new_value`, `created_at`
    FROM `activity_logs`;

-- ---------------------------------------------------------------------
-- 7. Drop the duplicates (FK first, then index, then column)
-- ---------------------------------------------------------------------
ALTER TABLE `tasks` DROP FOREIGN KEY IF EXISTS `fk_tasks_assigned`;
ALTER TABLE `tasks` DROP INDEX IF EXISTS `idx_tasks_assigned`;
ALTER TABLE `tasks` DROP COLUMN IF EXISTS `assigned_to`;

ALTER TABLE `activity_logs` DROP COLUMN IF EXISTS `record_id`;

-- (user_id) is already covered by the left-most column of idx_timesheets_user_period
ALTER TABLE `timesheets` DROP INDEX IF EXISTS `idx_timesheets_user`;

CREATE TABLE IF NOT EXISTS `agent_pair_attempts` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `ip` VARCHAR(45) NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_agent_pair_attempts_ip_created` (`ip`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 8. Reports permissions (without these /reports returns 403 for everyone)
-- ---------------------------------------------------------------------
INSERT INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
    ('reports.view',    'View reports',         'reports', 'Open reports.'),
    ('reports.export',  'Export reports',       'reports', 'Download reports as CSV.'),
    ('reports.billing', 'View billing figures', 'reports', 'See rates and billable amounts.')
ON DUPLICATE KEY UPDATE
    `display_name` = VALUES(`display_name`),
    `module`       = VALUES(`module`),
    `description`  = VALUES(`description`);

-- admin + manager: all three; employee + client: view only (Report.php scopes
-- their rows to their own entries / their own client record).
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id
FROM `roles` r
CROSS JOIN `permissions` p
WHERE r.name IN ('admin', 'manager')
  AND p.name IN ('reports.view', 'reports.export', 'reports.billing');

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT r.id, p.id
FROM `roles` r
CROSS JOIN `permissions` p
WHERE r.name IN ('employee', 'client')
  AND p.name = 'reports.view';

-- ---------------------------------------------------------------------
-- Verification: every row should say OK
-- ---------------------------------------------------------------------
SELECT 'time_entries.auto_stopped exists' AS `check`,
       IF((SELECT COUNT(*) FROM information_schema.columns
           WHERE table_schema = DATABASE() AND table_name = 'time_entries'
             AND column_name = 'auto_stopped') = 1, 'OK', 'FAIL') AS `result`
UNION ALL
SELECT 'tasks.assigned_to dropped',
       IF((SELECT COUNT(*) FROM information_schema.columns
           WHERE table_schema = DATABASE() AND table_name = 'tasks'
             AND column_name = 'assigned_to') = 0, 'OK', 'FAIL')
UNION ALL
SELECT 'activity_logs.record_id dropped',
       IF((SELECT COUNT(*) FROM information_schema.columns
           WHERE table_schema = DATABASE() AND table_name = 'activity_logs'
             AND column_name = 'record_id') = 0, 'OK', 'FAIL')
UNION ALL
SELECT 'audit_logs view has no record_id',
       IF((SELECT COUNT(*) FROM information_schema.columns
           WHERE table_schema = DATABASE() AND table_name = 'audit_logs'
             AND column_name = 'record_id') = 0, 'OK', 'FAIL')
UNION ALL
SELECT '3 reports.* permissions exist',
       IF((SELECT COUNT(*) FROM `permissions` WHERE `name` LIKE 'reports.%') = 3, 'OK', 'FAIL')
UNION ALL
SELECT 'admin has all 3 reports.* permissions',
       IF((SELECT COUNT(*) FROM `role_permissions` rp
           JOIN `roles` r ON r.id = rp.role_id
           JOIN `permissions` p ON p.id = rp.permission_id
           WHERE r.name = 'admin' AND p.name LIKE 'reports.%') = 3, 'OK', 'FAIL')
UNION ALL
SELECT 'no user role/role_id mismatch',
       IF((SELECT COUNT(*) FROM `users` u JOIN `roles` r ON r.id = u.role_id
           WHERE u.role <> r.name) = 0, 'OK', 'FAIL');
