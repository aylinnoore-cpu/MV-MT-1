/*
 * System settings > Branding: keeps the colour picker, the hex box and the swatches in sync,
 * shows a live preview, and previews a chosen logo before it is saved.
 * Preview only: the server validates and stores everything.
 */
(function () {
  'use strict';

  var HEX = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i;

  function normalize(value) {
    var v = String(value || '').trim();
    if (!HEX.test(v)) return null;
    v = v.replace('#', '').toLowerCase();
    if (v.length === 3) v = v[0] + v[0] + v[1] + v[1] + v[2] + v[2];
    return '#' + v;
  }

  function luminance(hex) {
    var c = [1, 3, 5].map(function (i) {
      var v = parseInt(hex.substr(i, 2), 16) / 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }

  // Same rule as the server (white or near-black, whichever contrasts more).
  function textOn(hex) {
    var l = luminance(hex);
    var vsWhite = 1.05 / (l + 0.05);
    var vsDark = (l + 0.05) / (luminance('#17232b') + 0.05);
    return vsWhite >= vsDark ? '#ffffff' : '#17232b';
  }

  document.addEventListener('DOMContentLoaded', function () {
    var form = document.querySelector('[data-branding-form]');
    if (!form) return;

    var picker = form.querySelector('[data-brand-picker]');
    var hex = form.querySelector('[data-brand-hex]');
    var preview = form.querySelector('[data-brand-preview]');
    var tile = form.querySelector('[data-brand-tile]');
    var btn = form.querySelector('[data-brand-btn]');
    var link = form.querySelector('[data-brand-link]');
    var swatches = form.querySelectorAll('[data-brand-swatch]');
    var file = form.querySelector('[data-brand-logo]');
    var box = form.querySelector('[data-brand-logo-box]');
    var remove = form.querySelector('[data-brand-remove]');
    var fallback = (preview && preview.getAttribute('data-default')) || '#0b7a75';

    function paint() {
      var color = normalize(hex.value) || fallback;
      var on = textOn(color);
      if (tile) { tile.style.background = color; tile.style.color = on; }
      if (btn) { btn.style.background = color; btn.style.color = on; }
      if (link) { link.style.color = color; }
      Array.prototype.forEach.call(swatches, function (s) {
        s.classList.toggle('is-active', normalize(hex.value) === s.getAttribute('data-brand-swatch'));
      });
    }

    picker.addEventListener('input', function () {
      hex.value = picker.value;
      paint();
    });

    hex.addEventListener('input', function () {
      var n = normalize(hex.value);
      if (n) picker.value = n;
      paint();
    });

    Array.prototype.forEach.call(swatches, function (s) {
      s.addEventListener('click', function () {
        var c = s.getAttribute('data-brand-swatch');
        hex.value = c;
        picker.value = c;
        paint();
      });
    });

    if (file && box) {
      file.addEventListener('change', function () {
        var f = file.files && file.files[0];
        if (!f) return;
        if (f.size > 1048576) {
          box.textContent = 'That file is over 1 MB.';
          return;
        }
        if (remove) remove.checked = false;
        var reader = new FileReader(); // data: URL; blob: URLs are blocked by the page policy
        reader.onload = function () {
          box.textContent = '';
          var img = document.createElement('img');
          img.alt = 'Selected logo preview';
          img.src = String(reader.result);
          box.appendChild(img);
        };
        reader.readAsDataURL(f);
      });
    }

    var favFile = form.querySelector('[data-brand-favicon]');
    var favBox = form.querySelector('[data-brand-favicon-box]');
    var favRemove = form.querySelector('[data-brand-favicon-remove]');

    if (favFile && favBox) {
      favFile.addEventListener('change', function () {
        var f = favFile.files && favFile.files[0];
        if (!f) return;
        if (f.size > 1048576) {
          favBox.textContent = 'That file is over 1 MB.';
          return;
        }
        if (favRemove) favRemove.checked = false;
        var reader = new FileReader(); // data: URL; blob: URLs are blocked by the page policy
        reader.onload = function () {
          favBox.textContent = '';
          var img = document.createElement('img');
          img.alt = 'Selected favicon preview';
          img.src = String(reader.result);
          favBox.appendChild(img);
        };
        reader.readAsDataURL(f);
      });
    }

    paint();
  });
})();