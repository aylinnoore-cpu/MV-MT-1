<?php
/**
 * Global/system settings: identity, formats, billing defaults, timezone, timer cap.
 * Workspace identity and workspace policies are managed separately under /workspace.
 *
 * Settings live in the key/value `settings` table. Only SYSTEM_DEFAULTS keys can be
 * written from this screen, so a crafted POST cannot create arbitrary configuration rows.
 */

declare(strict_types=1);

final class SettingsController extends Controller
{
    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN]);
    }

    /** GET /settings */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $this->render('settings/index', [
            'pageTitle' => 'System settings',
            'settings'  => SettingsService::system(),
            'smtp'      => SmtpSettings::public(),
            'smtpEncryptions' => SmtpSettings::ENCRYPTIONS,
            'timezones' => DateTimeZone::listIdentifiers(),
            'currencies' => SettingsService::CURRENCIES,
            'dateFormats' => SettingsService::DATE_FORMATS,
            'timeFormats' => SettingsService::TIME_FORMATS,
            'appKeyOk'  => DesktopAgent::keyConfigured(),
            'smtpHints' => SmtpSettings::deliveryHints(),
        ]);
    }

    /** GET /settings/audit-logs : searchable, filterable audit trail. */
    public function auditLogs(Request $request, array $params): void
    {
        PermissionHelper::require('activity.view');

        $filters = [
            'q'       => trim((string) $request->input('q', '')),
            'module'  => (string) $request->input('module', 'all'),
            'action'  => trim((string) $request->input('action', '')),
            'user_id' => (int) $request->input('user_id', 0),
        ];

        $model = new ActivityLog();
        $result = $model->search($filters, (int) $request->input('page', 1), 25);

        $this->render('settings/audit_logs', [
            'pageTitle' => 'Activity log',
            'result'    => $result,
            'filters'   => $filters,
            'modules'   => $model->modules(),
        ]);
    }

    /** POST /settings */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'app_name'            => 'required|string|max:80',
            'company_email'       => 'required|email|max:190',
            'date_format'         => 'required|string|max:20',
            'time_format'         => 'required|in:' . implode(',', SettingsService::TIME_FORMATS),
            'currency_symbol'     => 'required|string|max:6',
            'currency'            => 'required|in:' . implode(',', SettingsService::CURRENCIES),
            'default_hourly_rate' => 'required|numeric|min:0|max:100000',
            'default_timezone'    => 'required|timezone',
            'timer_max_hours'     => 'required|numeric|min:1|max:24',
            'timer_reminder_minutes' => 'required|numeric|min:0|max:240',
        ], '/settings', [
            'app_name'            => 'Application name',
            'company_email'       => 'Company email',
            'date_format'         => 'Date format',
            'time_format'         => 'Time format',
            'currency_symbol'     => 'Currency symbol',
            'currency'            => 'Currency code',
            'default_hourly_rate' => 'Default hourly rate',
            'default_timezone'    => 'Timezone',
            'timer_max_hours'     => 'Timer maximum hours',
            'timer_reminder_minutes' => 'Still-working reminder',
        ]);

        if (!in_array((string) $data['date_format'], SettingsService::DATE_FORMATS, true)) {
            $this->backWithErrors('/settings', ['date_format' => 'Date format is invalid.']);
        }

        $before = SettingsService::system();
        $after  = [];

        Database::transaction(function () use ($data, $request, &$after): void {
            $writes = [
                'app_name' => trim((string) $data['app_name']),
                'company_email' => strtolower(trim((string) $data['company_email'])),
                'date_format' => (string) $data['date_format'],
                'time_format' => (string) $data['time_format'],
                'currency_symbol' => (string) $data['currency_symbol'],
                'currency' => (string) $data['currency'],
                'default_hourly_rate' => (string) $data['default_hourly_rate'],
                'default_timezone' => (string) $data['default_timezone'],
                'timer_max_hours' => (string) max(1, min(24, (int) $data['timer_max_hours'])),
                'timer_reminder_minutes' => (string) max(0, min(240, (int) $data['timer_reminder_minutes'])),
                'allow_manual_time_entries' => $request->input('allow_manual_time_entries') ? '1' : '0',
                'notifications_enabled' => $request->input('notifications_enabled') ? '1' : '0',
                'maintenance_mode' => $request->input('maintenance_mode') ? '1' : '0',
            ];
            foreach ($writes as $key => $value) {
                SettingsService::setSystem($key, $value);
                $after[$key] = $value;
            }
        });

        LoggerHelper::logEvent('settings.updated', LoggerHelper::MODULE_SETTINGS, null, $before, $after);

        $this->flash('success', 'System settings were saved.');
        $this->redirect('/settings');
    }

    /** POST /settings/branding : brand colour, application logo, favicon and sign-in page text. */
    public function updateBranding(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'brand_color'    => 'nullable|string|max:7',
            'login_headline' => 'nullable|string|max:120',
            'login_subtext'  => 'nullable|string|max:300',
        ], '/settings#branding', [
            'brand_color'    => 'Brand colour',
            'login_headline' => 'Sign-in headline',
            'login_subtext'  => 'Sign-in description',
        ]);

        $rawColor = trim((string) ($data['brand_color'] ?? ''));
        $color = '';
        if ($rawColor !== '') {
            $color = BrandingHelper::normalizeHex($rawColor) ?? '';
            if ($color === '') {
                $this->backWithErrors('/settings#branding', ['brand_color' => 'Enter a colour such as #0b7a75.']);
            }
        }

        $headline = trim((string) ($data['login_headline'] ?? ''));
        if ($headline === '') {
            $headline = SettingsService::SYSTEM_DEFAULTS['login_headline'];
        }
        $subtext = trim((string) ($data['login_subtext'] ?? ''));

        $before  = SettingsService::system();
        $oldLogo = (string) $before['brand_logo'];
        $newLogo = $oldLogo;
        $oldFavicon = (string) ($before['brand_favicon'] ?? '');
        $newFavicon = $oldFavicon;

        $hasUpload = isset($_FILES['logo']) && is_array($_FILES['logo'])
            && (int) ($_FILES['logo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;

        if ($hasUpload) {
            try {
                $newLogo = BrandingHelper::saveLogo($_FILES['logo']);
            } catch (RuntimeException $e) {
                $this->backWithErrors('/settings#branding', ['logo' => $e->getMessage()]);
            }
        } elseif ($request->input('remove_logo')) {
            $newLogo = '';
        }

        $hasFavicon = isset($_FILES['favicon']) && is_array($_FILES['favicon'])
            && (int) ($_FILES['favicon']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;

        if ($hasFavicon) {
            try {
                $newFavicon = BrandingHelper::saveFavicon($_FILES['favicon']);
            } catch (RuntimeException $e) {
                if ($newLogo !== $oldLogo) {
                    BrandingHelper::deleteLogo($newLogo); // the logo was already written; do not orphan it
                }
                $this->backWithErrors('/settings#branding', ['favicon' => $e->getMessage()]);
            }
        } elseif ($request->input('remove_favicon')) {
            $newFavicon = '';
        }

        $writes = [
            'brand_color'    => $color,
            'brand_logo'     => $newLogo,
            'brand_favicon'  => $newFavicon,
            'login_headline' => $headline,
            'login_subtext'  => $subtext,
        ];

        try {
            Database::transaction(static function () use ($writes): void {
                foreach ($writes as $key => $value) {
                    SettingsService::setSystem($key, $value);
                }
            });
        } catch (Throwable $e) {
            if ($newLogo !== $oldLogo) {
                BrandingHelper::deleteLogo($newLogo); // do not leave an orphan file behind
            }
            if ($newFavicon !== $oldFavicon) {
                BrandingHelper::deleteFavicon($newFavicon);
            }
            throw $e;
        }

        if ($newLogo !== $oldLogo && $oldLogo !== '') {
            BrandingHelper::deleteLogo($oldLogo);
        }
        if ($newFavicon !== $oldFavicon && $oldFavicon !== '') {
            BrandingHelper::deleteFavicon($oldFavicon);
        }

        LoggerHelper::logEvent('settings.branding_updated', LoggerHelper::MODULE_SETTINGS, null, [
            'brand_color' => $before['brand_color'],
            'brand_logo'  => $oldLogo,
            'brand_favicon' => $oldFavicon,
        ], [
            'brand_color' => $color,
            'brand_logo'  => $newLogo,
            'brand_favicon' => $newFavicon,
        ]);

        $this->flash('success', 'Branding was saved.');
        $this->redirect('/settings#branding');
    }

    /** POST /settings/branding/reset : back to the built-in colours, icon and sign-in text. */
    public function resetBranding(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $oldLogo = SettingsService::systemString('brand_logo', '');
        $oldFavicon = SettingsService::systemString('brand_favicon', '');
        $defaults = SettingsService::SYSTEM_DEFAULTS;

        Database::transaction(static function () use ($defaults): void {
            foreach (['brand_color', 'brand_logo', 'brand_favicon', 'login_headline', 'login_subtext'] as $key) {
                SettingsService::setSystem($key, $defaults[$key]);
            }
        });

        if ($oldLogo !== '') {
            BrandingHelper::deleteLogo($oldLogo);
        }
        if ($oldFavicon !== '') {
            BrandingHelper::deleteFavicon($oldFavicon);
        }

        LoggerHelper::logEvent('settings.branding_reset', LoggerHelper::MODULE_SETTINGS, null, null, null);

        $this->flash('success', 'Branding was reset to the defaults.');
        $this->redirect('/settings#branding');
    }

    /** POST /settings/smtp */
    public function updateSmtp(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'smtp_host' => 'nullable|string|max:190',
            'smtp_port' => 'required|int|min:1|max:65535',
            'smtp_username' => 'nullable|string|max:190',
            'smtp_password' => 'nullable|string|max:255',
            'smtp_encryption' => 'required|in:' . implode(',', SmtpSettings::ENCRYPTIONS),
            'smtp_from_name' => 'nullable|string|max:120',
            'smtp_from_email' => 'nullable|email|max:190',
            'smtp_reply_to' => 'nullable|email|max:190',
            'invite_expiry_days' => 'required|int|min:1|max:90',
        ], '/settings#smtp', [
            'smtp_host' => 'SMTP host',
            'smtp_port' => 'SMTP port',
            'smtp_username' => 'SMTP username',
            'smtp_password' => 'SMTP password',
            'smtp_encryption' => 'Encryption',
            'smtp_from_name' => 'From name',
            'smtp_from_email' => 'From email',
            'smtp_reply_to' => 'Reply-To',
            'invite_expiry_days' => 'Invitation expiry',
        ]);

        $password = (string) ($data['smtp_password'] ?? '');
        $replacePassword = $password !== '';

        try {
            SmtpSettings::save([
                'smtp_enabled' => $request->input('smtp_enabled') ? '1' : '0',
                'smtp_host' => trim((string) ($data['smtp_host'] ?? '')),
                'smtp_port' => (string) max(1, min(65535, (int) $data['smtp_port'])),
                'smtp_username' => trim((string) ($data['smtp_username'] ?? '')),
                'smtp_password' => $password,
                'smtp_encryption' => (string) $data['smtp_encryption'],
                'smtp_from_name' => trim((string) ($data['smtp_from_name'] ?? '')),
                'smtp_from_email' => strtolower(trim((string) ($data['smtp_from_email'] ?? ''))),
                'smtp_reply_to' => strtolower(trim((string) ($data['smtp_reply_to'] ?? ''))),
                'invite_expiry_days' => (string) max(1, min(90, (int) $data['invite_expiry_days'])),
            ], $replacePassword);
        } catch (RuntimeException $e) {
            $this->flash('danger', $e->getMessage());
            $this->redirect('/settings#smtp');
        }

        LoggerHelper::logEvent('settings.smtp_updated', LoggerHelper::MODULE_SETTINGS, null, null, [
            'host' => trim((string) ($data['smtp_host'] ?? '')),
            'port' => (int) $data['smtp_port'],
            'encryption' => (string) $data['smtp_encryption'],
            'enabled' => $request->input('smtp_enabled') ? '1' : '0',
            'password_changed' => $replacePassword ? '1' : '0',
        ]);

        $hints = SmtpSettings::deliveryHints();
        if ($hints !== []) {
            $this->flash('warning', $hints[0]);
        }
        $this->flash('success', 'Mail settings were saved.');
        $this->redirect('/settings#smtp');
    }

    /** POST /settings/smtp/test */
    public function testSmtp(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'test_email' => 'required|email|max:190',
        ], '/settings#smtp', ['test_email' => 'Test email']);

        if (RateLimitHelper::tooMany('mail.test_sent', $request->ip(), 8, 15)) {
            $this->flash('danger', 'Too many test emails from this address. Wait a few minutes and try again.');
            $this->redirect('/settings#smtp');
        }

        if (!SmtpSettings::isConfigured()) {
            $this->flash('danger', 'Save SMTP host and From email first, then send a test.');
            $this->redirect('/settings#smtp');
        }

        $to = strtolower((string) $data['test_email']);
        $app = SettingsService::appName();
        $code = strtoupper(bin2hex(random_bytes(3)));
        $safeApp = htmlspecialchars($app, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $result = Mailer::send(
            $to,
            $app . ' test email ' . $code,
            '<p>This is a test message from ' . $safeApp . '.</p>'
            . '<p>Search Gmail for <strong>' . htmlspecialchars($code, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</strong>.</p>'
            . '<p>Also check Spam and Promotions. The mail server accepted this message; Gmail may still delay or file it.</p>',
            'This is a test message from ' . $app . ".\nSearch for " . $code . ".\nAlso check Spam and Promotions."
        );

        LoggerHelper::logEvent(
            $result['ok'] ? 'mail.test_sent' : 'mail.test_failed',
            LoggerHelper::MODULE_MAIL,
            null,
            null,
            ['ok' => $result['ok'] ? '1' : '0', 'to_domain' => substr(strrchr($to, '@') ?: '', 1)]
        );

        if ($result['ok']) {
            $this->flash(
                'success',
                'The mail server accepted the test. Search Gmail for ' . $code
                . ' (Inbox, Spam, Promotions). If nothing arrives in a few minutes, Gmail is filtering it — use smtp.gmail.com, port 587, TLS, an App Password, and the same Gmail address as From.'
            );
            foreach (SmtpSettings::deliveryHints() as $hint) {
                $this->flash('warning', $hint);
            }
        } else {
            $this->flash('danger', $result['error'] !== '' ? $result['error'] : 'The test email could not be sent.');
        }
        $this->redirect('/settings#smtp');
    }
}