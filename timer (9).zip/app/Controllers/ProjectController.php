<?php
/**
 * Projects: index with All/Active/Completed tabs, create, view, edit, archive, delete, sync members.
 *
 * Employees only see projects they are assigned to (or manage/created).
 * Managers can manage projects they are the manager of.
 * Admins have full access.
 */

declare(strict_types=1);

final class ProjectController extends Controller
{
    private Project $projects;
    private Client $clients;
    private ProjectMember $members;

    public function __construct()
    {
        parent::__construct(true);
        FeatureFlagsHelper::requireProjects();
        $this->projects = new Project();
        $this->clients  = new Client();
        $this->members  = new ProjectMember();
    }

    /** GET /projects */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('projects.view');

        $tab = (string) $request->input('tab', 'active');
        if (!in_array($tab, ['all', 'active', 'completed', 'archived'], true)) {
            $tab = 'active';
        }

        $sort = (string) $request->input('sort', 'name');
        if (!in_array($sort, ['name', 'client', 'tracked', 'progress'], true)) {
            $sort = 'name';
        }
        $dir    = strtolower((string) $request->input('dir', 'asc')) === 'desc' ? 'desc' : 'asc';
        $memberIds = $this->postedIds('members');

        $userId  = (int) AuthHelper::id();
        $viewAll = PermissionHelper::has('projects.view_all');

        $result = $this->projects->listFiltered([
            'tab'        => $tab,
            'status'     => (string) $request->input('status', ''),
            'client_id'  => (int) $request->input('client_id', 0),
            'manager_id' => (int) $request->input('manager_id', 0),
            'q'          => (string) $request->input('q', ''),
            'member_ids' => $memberIds,
            'sort'       => $sort,
            'dir'        => $dir,
        ], (int) $request->input('page', 1), 25, $userId, $viewAll);

        $this->render('projects/index', [
            'pageTitle'   => 'Projects',
            'tab'         => $tab,
            'result'      => $result,
            'clients'     => $this->clients->activeOptions(),
            'managers'    => $this->managerOptions(),
            'filters'     => [
                'status'     => (string) $request->input('status', ''),
                'client_id'  => (int) $request->input('client_id', 0),
                'manager_id' => (int) $request->input('manager_id', 0),
                'q'          => (string) $request->input('q', ''),
                'members'    => $memberIds,
                'sort'       => $sort,
                'dir'        => $dir,
            ],
            'memberOptions' => $this->assignableUsers(),
            'canCreate'   => WorkspacePolicy::canCreateProject(),
            'canEdit'     => PermissionHelper::has('projects.edit'),
            'canArchive'  => PermissionHelper::has('projects.archive'),
            'canDelete'   => PermissionHelper::has('projects.delete'),
            'isAdmin'     => AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
            'userId'      => $userId,
        ]);
    }

    /** GET /projects/create */
    public function create(Request $request, array $params): void
    {
        PermissionHelper::require('projects.create');
        WorkspacePolicy::requireCanCreateProject();

        $this->render('projects/create', $this->formData([
            'pageTitle'    => 'New project',
            'project'      => $this->blankProject(),
            'selectedIds'  => [],
            'memberRoles'  => [],
            'formAction'   => url('/projects'),
            'submitLabel'  => 'Create project',
        ]));
    }

    /** POST /projects */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('projects.create');
        // project_creation_policy is a second gate so a crafted POST cannot skip the workspace rule.
        WorkspacePolicy::requireCanCreateProject();

        $data = $this->validatedProject('/projects/create');
        $data['created_by'] = (int) AuthHelper::id();
        // Create form cannot set visibility; only the Access tab may change it later.
        if (Project::extrasReady()) {
            $data['is_public'] = WorkspacePolicy::defaultProjectIsPublic() ? 1 : 0;
        }

        if ($data['project_code'] === null || $data['project_code'] === '') {
            $data['project_code'] = $this->projects->nextCode();
        }

        $id = $this->projects->create($data);

        $memberIds = $this->postedMemberIds();
        if ($data['manager_id'] !== null) {
            $memberIds[] = (int) $data['manager_id'];
        }
        $memberIds[] = (int) AuthHelper::id();
        $this->members->sync($id, $memberIds, $this->postedMemberRoles($data['manager_id']));
        $this->assertOnlyPmIsManager($id, $data['manager_id']);

        LoggerHelper::projectCreated($id, [
            'name' => (string) $data['name'],
            'code' => (string) $data['project_code'],
        ]);
        $this->flash('success', 'Project "' . $data['name'] . '" was created.');
        $this->redirect('/projects/' . $id);
    }

    /** GET /projects/{id}  (tabs: tasks, access, status, forecast, note, settings) */
    public function show(Request $request, array $params): void
    {
        PermissionHelper::require('projects.view');

        $project   = $this->loadVisible((int) ($params['id'] ?? 0));
        $projectId = (int) $project['id'];
        $userId    = (int) AuthHelper::id();
        $members   = $this->members->forProject($projectId);
        $canManage = $this->projects->userCanManage($project, $userId, AuthHelper::hasRole(AuthHelper::ROLE_ADMIN));
        $canEdit   = $canManage && PermissionHelper::has('projects.edit');
        $archived  = (string) $project['status'] === Project::STATUS_ARCHIVED;

        $tasksReady = Task::installed();
        $allowed    = ['tasks', 'access', 'status', 'forecast', 'note'];
        if ($canEdit) {
            $allowed[] = 'settings';
        }

        $tab = (string) $request->input('tab', $tasksReady ? 'tasks' : 'status');
        if ($tab === 'overview') {
            $tab = 'status';
        }
        if (!in_array($tab, $allowed, true) || ($tab === 'tasks' && !$tasksReady)) {
            $tab = 'status';
        }

        $taskModel  = new Task();
        $taskCounts = $tasksReady ? $taskModel->counts($projectId) : ['all' => 0, 'active' => 0, 'done' => 0];

        $data = [
            'pageTitle'        => (string) $project['name'],
            'project'          => $project,
            'members'          => $members,
            'tab'              => $tab,
            'activeProjectTab' => $tab,
            'tasksReady'       => $tasksReady,
            'taskCounts'       => $taskCounts,
            'taskStatuses'     => Task::STATUSES,
            'isFavorite'       => $this->projects->isFavorite($projectId, $userId),
            'extrasReady'      => Project::extrasReady(),
            'currency'         => AnalyticsHelper::currency(),
            'projectAssets'    => true,
            'canEdit'          => $canEdit,
            'canArchive'       => $canManage && PermissionHelper::has('projects.archive'),
            'canDelete'        => $canManage && PermissionHelper::has('projects.delete'),
            'canManageMembers' => $canManage && PermissionHelper::has('projects.manage_members'),
            'canCreateTask'    => TaskPolicy::canCreateOnProject($project) && !$archived,
            'canEditTask'      => TaskPolicy::isLegacy() ? PermissionHelper::has('tasks.edit') : TaskPolicy::hasCapability('tasks.edit'),
            'canDeleteTask'    => TaskPolicy::isLegacy() ? PermissionHelper::has('tasks.delete') : TaskPolicy::hasCapability('tasks.delete'),
            'canAssignTask'    => TaskPolicy::isLegacy() ? PermissionHelper::has('tasks.assign') : TaskPolicy::hasCapability('tasks.assign'),
            'canTrack'         => PermissionHelper::has('time.track') && Timer::installed() && !$archived && FeatureFlagsHelper::trackerVisible(),
        ];

        switch ($tab) {
            case 'tasks':
                $filter = (string) $request->input('task_status', 'active');
                if (!in_array($filter, ['active', 'done', 'all'], true)) {
                    $filter = 'active';
                }
                $search = trim((string) $request->input('task_q', ''));
                $dir    = (string) $request->input('task_dir', 'asc') === 'desc' ? 'desc' : 'asc';

                $teamFilter = (int) $request->input('task_team', 0);
                if ($teamFilter < 1) {
                    $teamFilter = 0;
                }

                $tasks = $taskModel->forProject($projectId, $filter, $search, $dir);
                if (TaskPolicy::isStrict()) {
                    $tasks = array_values(array_filter(
                        $tasks,
                        static fn (array $row): bool => TaskPolicy::isVisibleTo($row, $project, $userId)
                    ));
                }
                if ($teamFilter > 0) {
                    $tasks = array_values(array_filter(
                        $tasks,
                        static fn (array $row): bool => (int) ($row['team_id'] ?? 0) === $teamFilter
                    ));
                }
                foreach ($tasks as $i => $row) {
                    $tasks[$i]['flags'] = TaskPolicy::flagsFor($row, $project);
                    $tasks[$i]['allowed_statuses'] = TaskPolicy::allowedTransitions($row, $project);
                }

                $data['taskFilter']     = $filter;
                $data['taskSearch']     = $search;
                $data['taskDir']        = $dir;
                $data['taskTeam']       = $teamFilter;
                $data['tasks']          = $tasks;
                $data['creatableTeams'] = TaskPolicy::creatableTeams($project);
                $data['projectTeams']   = self::projectTeamOptions($projectId);
                break;

            case 'access':
                $memberIds = array_map(static fn (array $row): int => (int) $row['user_id'], $members);
                $data['candidates'] = array_values(array_filter(
                    $this->assignableUsers(),
                    static fn (array $user): bool => !in_array((int) $user['id'], $memberIds, true)
                ));
                break;

            case 'status':
                $filter = (string) $request->input('task_status', 'all');
                if (!in_array($filter, ['all', 'active', 'done'], true)) {
                    $filter = 'all';
                }
                $sort = (string) $request->input('s', 'name') === 'tracked' ? 'tracked' : 'name';
                $dir  = (string) $request->input('d', 'asc') === 'desc' ? 'desc' : 'asc';

                $data['statusFilter']   = $filter;
                $data['statusSort']     = $sort;
                $data['statusDir']      = $dir;
                $data['statusRows']     = $tasksReady ? $taskModel->statusRows($projectId, $filter, $sort, $dir) : [];
                $data['trackedSeconds'] = $taskModel->projectTrackedSeconds($projectId);
                $data['totals']         = $this->projects->totals($projectId);
                break;

            case 'forecast':
                $data['forecast']    = $this->forecast($projectId, $request);
                $data['chartAssets'] = true;
                break;

            case 'settings':
                $data['clients']    = $this->clients->activeOptions();
                $data['managers']   = $this->managerOptions();
                $data['statuses']   = Project::STATUSES;
                $data['priorities'] = Project::PRIORITIES;
                break;
        }

        $this->render('projects/view', $data);
    }

    /**
     * Planned hours (schedules) of one project, bucketed per day, week or month and split by person.
     *
     * @return array<string, mixed>
     */
    private function forecast(int $projectId, Request $request): array
    {
        $zone = new DateTimeZone(FormatHelper::displayTimezone());
        $now  = new DateTimeImmutable('now', $zone);

        $gran = (string) $request->input('g', 'week');
        if (!in_array($gran, ['day', 'week', 'month'], true)) {
            $gran = 'week';
        }

        $parse = static function (mixed $value, DateTimeZone $zone): ?DateTimeImmutable {
            $value = is_string($value) ? trim($value) : '';
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) !== 1) {
                return null;
            }
            $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, $zone);

            return $date === false ? null : $date;
        };

        $from = $parse($request->input('from'), $zone) ?? $now->modify('first day of this month')->setTime(0, 0);
        $to   = $parse($request->input('to'), $zone) ?? $from->modify('first day of next month')->modify('last day of this month');
        if ($to < $from) {
            [$from, $to] = [$to, $from];
        }
        if ($from->diff($to)->days > 730) {
            $to = $from->modify('+730 days');
        }

        $weekMod = WorkspacePolicy::weekModifier();
        $keyOf = static function (DateTimeImmutable $d) use ($gran, $weekMod): string {
            return match ($gran) {
                'day'   => $d->format('Y-m-d'),
                'month' => $d->format('Y-m-01'),
                default => $d->modify($weekMod)->format('Y-m-d'),
            };
        };
        $labelOf = static function (string $key) use ($gran): string {
            $d = new DateTimeImmutable($key);

            return $gran === 'month' ? $d->format('M Y') : $d->format('M d');
        };

        $buckets = [];
        $cursor  = new DateTimeImmutable($keyOf($from), $zone);
        while ($cursor <= $to && count($buckets) < 800) {
            $buckets[$cursor->format('Y-m-d')] = 0.0;
            $cursor = match ($gran) {
                'day'   => $cursor->modify('+1 day'),
                'month' => $cursor->modify('+1 month'),
                default => $cursor->modify('+7 days'),
            };
        }
        $keys = array_keys($buckets);

        $people = [];
        try {
            $rows = Database::fetchAll(
                "SELECT s.start_datetime, s.end_datetime, s.estimated_hours, u.id AS user_id, u.name
                 FROM schedules s
                 INNER JOIN users u ON u.id = s.user_id
                 WHERE s.project_id = :project_id
                   AND s.status <> 'Cancelled'
                   AND s.start_datetime >= :from_utc AND s.start_datetime <= :to_utc",
                [
                    'project_id' => $projectId,
                    'from_utc'   => $from->modify('-1 day')->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
                    'to_utc'     => $to->modify('+2 days')->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
                ]
            );
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $rows = [];
        }

        $utc = new DateTimeZone('UTC');
        foreach ($rows as $row) {
            $start = new DateTimeImmutable((string) $row['start_datetime'], $utc);
            $start = $start->setTimezone($zone);
            if ($start < $from || $start >= $to->modify('+1 day')) {
                continue;
            }

            $hours = (float) $row['estimated_hours'];
            if ($hours <= 0) {
                $end   = new DateTimeImmutable((string) $row['end_datetime'], $utc);
                $hours = max(0.0, ($end->getTimestamp() - $start->getTimestamp()) / 3600);
            }

            $key = $keyOf($start);
            $uid = (int) $row['user_id'];
            if (!isset($people[$uid])) {
                $people[$uid] = ['label' => (string) $row['name'], 'data' => array_fill(0, count($keys), 0.0)];
            }
            $index = array_search($key, $keys, true);
            if ($index !== false) {
                $people[$uid]['data'][$index] = round($people[$uid]['data'][$index] + $hours, 2);
            }
        }

        $span = (int) $from->diff($to)->days + 1;

        return [
            'gran'      => $gran,
            'from'      => $from->format('Y-m-d'),
            'to'        => $to->format('Y-m-d'),
            'prevFrom'  => $from->modify('-' . $span . ' days')->format('Y-m-d'),
            'prevTo'    => $to->modify('-' . $span . ' days')->format('Y-m-d'),
            'nextFrom'  => $from->modify('+' . $span . ' days')->format('Y-m-d'),
            'nextTo'    => $to->modify('+' . $span . ' days')->format('Y-m-d'),
            'rangeText' => $from->format('M d, Y') . ' - ' . $to->format('M d, Y'),
            'chart'     => [
                'labels'      => array_map($labelOf, $keys),
                'datasets'    => array_values($people),
                'startLabel'  => $from->format('M d'),
                'endLabel'    => $to->format('M d'),
                'empty'       => $people === [],
            ],
        ];
    }

    /** GET /projects/{id}/dashboard */
    public function dashboard(Request $request, array $params): void
    {
        PermissionHelper::require('projects.view');
        FeatureFlagsHelper::requireReports();

        $project = $this->loadVisible((int) ($params['id'] ?? 0));
        $canManage = $this->projects->userCanManage(
            $project,
            (int) AuthHelper::id(),
            AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)
        );
        $analytics = AnalyticsHelper::projectDashboard((int) $project['id']);

        $this->render('projects/dashboard', [
            'pageTitle'    => $project['name'] . ' dashboard',
            'project'      => $project,
            'totals'       => $analytics['totals'],
            'taskRows'     => $analytics['tasks'],
            'people'       => $analytics['people'],
            'gantt'        => $analytics['gantt'],
            'currency'     => AnalyticsHelper::currency(),
            'canEdit'      => $canManage && PermissionHelper::has('projects.edit'),
            'canTrack'     => PermissionHelper::has('time.track') && Timer::installed()
                && (string) $project['status'] !== Project::STATUS_ARCHIVED
                && FeatureFlagsHelper::trackerVisible(),
            'chartAssets'  => true,
            'projectAssets' => true,
            'isFavorite'   => $this->projects->isFavorite((int) $project['id'], (int) AuthHelper::id()),
            'canArchive'   => $canManage && PermissionHelper::has('projects.archive'),
            'canDelete'    => $canManage && PermissionHelper::has('projects.delete'),
        ]);
    }

    /** GET /projects/{id}/edit  (kept for old links: the form now lives on the Settings tab) */
    public function edit(Request $request, array $params): void
    {
        PermissionHelper::require('projects.edit');

        $project = $this->loadVisible((int) ($params['id'] ?? 0));
        $this->assertCanManage($project);

        $this->redirect('/projects/' . (int) $project['id'] . '?tab=settings');
    }

    /** POST /projects/{id} */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('projects.edit');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        $data = $this->validatedProject('/projects/' . $id . '/edit', $id);
        unset($data['created_by']);
        $this->projects->update($id, $data);

        if (PermissionHelper::has('projects.manage_members')) {
            $memberIds = $this->postedMemberIds();
            if ($data['manager_id'] !== null) {
                $memberIds[] = (int) $data['manager_id'];
            }
            $this->members->sync($id, $memberIds, $this->postedMemberRoles($data['manager_id']));
        }

        LoggerHelper::projectEdited(
            $id,
            ['name' => (string) ($project['name'] ?? ''), 'status' => (string) ($project['status'] ?? '')],
            ['name' => (string) $data['name'], 'status' => (string) ($data['status'] ?? '')]
        );
        $this->flash('success', 'Project "' . $data['name'] . '" was updated.');
        $this->redirect('/projects/' . $id);
    }

    /** POST /projects/{id}/archive */
    public function archive(Request $request, array $params): void
    {
        PermissionHelper::require('projects.archive');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        if ((string) $project['status'] === Project::STATUS_ARCHIVED) {
            $this->flash('info', 'This project is already archived.');
            $this->redirect('/projects/' . $id);
        }

        $this->projects->archive($id);
        LoggerHelper::audit('project.archived', 'project', $id, ['name' => $project['name']]);
        $this->flash('success', 'Project "' . $project['name'] . '" was archived.');
        $this->redirect('/projects?tab=archived');
    }

    /** POST /projects/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        PermissionHelper::require('projects.delete');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        $snapshot = [
            'name'         => (string) ($project['name'] ?? ''),
            'status'       => (string) ($project['status'] ?? ''),
            'project_code' => (string) ($project['project_code'] ?? ''),
            'client_id'    => (int) ($project['client_id'] ?? 0),
        ];

        $result = $this->projects->deleteIfEmpty($id);
        $name   = (string) $project['name'];

        if ($result === 'not_archived') {
            $this->flash('warning', 'Archive "' . $name . '" before deleting it.');
            $this->redirect('/projects/' . $id);
        }
        if ($result === 'has_time') {
            $this->flash('danger', 'Cannot delete "' . $name . '": it still has time entries or a running timer. Archive it and keep the hours.');
            $this->redirect('/projects/' . $id);
        }
        if ($result === 'missing') {
            $this->flash('info', 'That project is already gone.');
            $this->redirect('/projects?tab=archived');
        }

        LoggerHelper::audit('project.deleted', 'project', $id, [
            'module'    => LoggerHelper::MODULE_PROJECT,
            'entity_id' => $id,
            'old'       => $snapshot,
            'name'      => $snapshot['name'],
        ]);
        $this->flash('success', 'Project "' . $name . '" was deleted.');
        $this->redirect('/projects?tab=archived');
    }

    /** POST /projects/{id}/members */
    public function syncMembers(Request $request, array $params): void
    {
        PermissionHelper::require('projects.manage_members');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        $memberIds = $this->postedMemberIds();
        if (!empty($project['manager_id'])) {
            $memberIds[] = (int) $project['manager_id'];
        }
        $this->members->sync($id, $memberIds, $this->postedMemberRoles($project['manager_id'] ?? null));
        $this->assertOnlyPmIsManager($id, $project['manager_id'] ?? null);

        LoggerHelper::audit('project.members_synced', 'project', $id, ['count' => count(array_unique($memberIds))]);
        $this->flash('success', 'Project members were updated.');
        $this->redirect('/projects/' . $id . '?tab=access');
    }

    /** POST /projects/{id}/settings  (Settings tab) */
    public function updateSettings(Request $request, array $params): void
    {
        PermissionHelper::require('projects.edit');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        $back  = '/projects/' . $id . '?tab=settings';
        $input = $request->all();
        $has   = static fn (string $key): bool => array_key_exists($key, $input);
        $extras = Project::extrasReady();

        $rules  = [
            'name'      => 'required|string|max:160',
            'client_id' => 'required|int|exists:clients,id',
        ];
        $labels = ['name' => 'Name', 'client_id' => 'Client'];

        $optional = [
            'status'          => ['required|in:' . implode(',', Project::STATUSES), 'Status'],
            'priority'        => ['required|in:' . implode(',', Project::PRIORITIES), 'Priority'],
            'start_date'      => ['nullable|date', 'Start date'],
            'due_date'        => ['nullable|date', 'Due date'],
            'manager_id'      => ['nullable|int|exists:users,id', 'Manager'],
            'hourly_rate'     => ['nullable|numeric|min:0|max:99999', 'Hourly rate'],
            'estimated_hours' => ['nullable|numeric|min:0|max:999999', 'Estimated hours'],
            'budget'          => ['nullable|numeric|min:0|max:99999999', 'Budget'],
        ];
        foreach ($optional as $key => [$rule, $label]) {
            if ($has($key)) {
                $rules[$key]  = $rule;
                $labels[$key] = $label;
            }
        }
        if ($has('project_code') && trim((string) $input['project_code']) !== '') {
            $rules['project_code']  = 'string|max:40|unique:projects,project_code,' . $id;
            $labels['project_code'] = 'Project code';
        }

        $validator = ValidatorHelper::make($input, $rules, $labels);
        if ($validator->fails()) {
            $errors = array_values($validator->errors());
            $this->flash('danger', (string) ($errors[0] ?? 'Please check the project settings.'));
            $this->redirect($back);
        }
        $valid = $validator->validated();

        $data = [
            'name'      => (string) $valid['name'],
            'client_id' => (int) $valid['client_id'],
        ];

        foreach (['status', 'priority'] as $key) {
            if ($has($key)) {
                $data[$key] = (string) $valid[$key];
            }
        }
        if (isset($rules['project_code'])) {
            $data['project_code'] = (string) $valid['project_code'];
        }
        foreach (['start_date', 'due_date'] as $key) {
            if ($has($key)) {
                $data[$key] = ($valid[$key] ?? '') !== '' ? $valid[$key] : null;
            }
        }
        $start = array_key_exists('start_date', $data) ? $data['start_date'] : ($project['start_date'] ?? null);
        $due   = array_key_exists('due_date', $data) ? $data['due_date'] : ($project['due_date'] ?? null);
        if ($start !== null && $due !== null && (string) $due < (string) $start) {
            $this->flash('danger', 'Due date must be on or after the start date.');
            $this->redirect($back);
        }

        if ($has('hourly_rate')) {
            $data['hourly_rate'] = (float) ($valid['hourly_rate'] ?? 0);
        }
        if ($has('is_billable')) {
            $data['is_billable'] = (string) $input['is_billable'] === '1' ? 1 : 0;
        }

        if ($has('manager_id')) {
            $managerId = ($valid['manager_id'] ?? '') !== '' ? (int) $valid['manager_id'] : null;
            if ($managerId !== null) {
                $manager = Database::fetchOne(
                    'SELECT u.id, r.name AS role, u.status
                     FROM users u
                     INNER JOIN roles r ON r.id = u.role_id
                     WHERE u.id = :id LIMIT 1',
                    ['id' => $managerId]
                );
                if ($manager === null || $manager['status'] !== 'active'
                    || !in_array((string) $manager['role'], [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER], true)) {
                    $this->flash('danger', 'Manager must be an active admin or manager.');
                    $this->redirect($back);
                }
            }
            $data['manager_id'] = $managerId;
        }

        // Project estimate: none | time | budget.
        $type = (string) ($input['estimate_type'] ?? '');
        if (in_array($type, ['none', 'time', 'budget'], true)) {
            if ($type === 'none') {
                $data['estimated_hours'] = 0;
                $data['budget']          = 0;
            } elseif ($type === 'time') {
                $data['estimated_hours'] = (float) ($valid['estimated_hours'] ?? 0);
            } else {
                $data['budget'] = (float) ($valid['budget'] ?? 0);
            }
            if ($extras) {
                $data['estimate_type'] = $type;
            }
        }

        if ($extras && $has('color')) {
            $color = strtoupper(trim((string) $input['color']));
            if (preg_match('/^#[0-9A-F]{6}$/', $color) === 1) {
                $data['color'] = $color;
            }
        }

        $this->projects->update($id, $data);

        if (array_key_exists('manager_id', $data)) {
            $oldPm = (int) ($project['manager_id'] ?? 0);
            $newPm = (int) ($data['manager_id'] ?? 0);
            if ($oldPm > 0 && $oldPm !== $newPm) {
                $this->members->setRole($id, $oldPm, ProjectMember::ROLE_MEMBER);
            }
            $this->assertOnlyPmIsManager($id, $data['manager_id']);
        }

        LoggerHelper::projectEdited(
            $id,
            ['name' => (string) ($project['name'] ?? ''), 'status' => (string) ($project['status'] ?? '')],
            ['name' => (string) $data['name'], 'status' => (string) ($data['status'] ?? $project['status'] ?? '')]
        );
        $this->flash('success', 'Project settings were saved.');
        $this->redirect($back);
    }

    /** POST /projects/{id}/visibility  (Access tab, JSON) */
    public function visibility(Request $request, array $params): void
    {
        PermissionHelper::require('projects.manage_members');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        if (!Project::extrasReady()) {
            $this->json(['ok' => false, 'message' => 'Run database/UPGRADE_LIVE.sql to enable project visibility.'], 409);
        }

        $public = (string) $request->input('visibility', '') === 'public' ? 1 : 0;
        $this->projects->update($id, ['is_public' => $public]);
        LoggerHelper::audit('project.visibility_changed', 'project', $id, ['public' => $public]);

        $this->json(['ok' => true, 'visibility' => $public === 1 ? 'public' : 'private']);
    }

    /** POST /projects/{id}/note  (Note tab, JSON autosave) */
    public function saveNote(Request $request, array $params): void
    {
        PermissionHelper::require('projects.edit');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        $note = str_replace("\r\n", "\n", (string) $request->input('note', ''));
        if (mb_strlen($note) > 5000) {
            $this->json(['ok' => false, 'message' => 'A note can have at most 5000 characters.'], 422);
        }

        $this->projects->update($id, ['description' => trim($note) === '' ? null : $note]);
        LoggerHelper::audit('project.note_saved', 'project', $id, ['length' => mb_strlen($note)]);

        $this->json(['ok' => true]);
    }

    /** POST /projects/{id}/favorite */
    public function favorite(Request $request, array $params): void
    {
        PermissionHelper::require('projects.view');

        $project = $this->loadVisible((int) ($params['id'] ?? 0));
        $this->projects->toggleFavorite((int) $project['id'], (int) AuthHelper::id());

        // The star on the project list posts a `back` path so the user stays on the list.
        $back = (string) $request->input('back', '');
        if ($back !== '' && preg_match('#^/projects(\?[A-Za-z0-9_=&%.+\-]*)?$#', $back) === 1) {
            $this->redirect($back);
        }

        $tab = (string) $request->input('tab', '');
        if (!in_array($tab, ['tasks', 'access', 'status', 'forecast', 'note', 'settings'], true)) {
            $this->redirect('/projects/' . (int) $project['id']);
        }
        $this->redirect('/projects/' . (int) $project['id'] . '?tab=' . $tab);
    }

    /** POST /projects/{id}/members/add  (Access tab, "Add members" modal) */
    public function addMembers(Request $request, array $params): void
    {
        PermissionHelper::require('projects.manage_members');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);
        $back = '/projects/' . $id . '?tab=access';

        $role = (string) $request->input('role', ProjectMember::ROLE_MEMBER);
        if (!in_array($role, ProjectMember::ROLES, true) || $role === ProjectMember::ROLE_MANAGER) {
            $role = ProjectMember::ROLE_MEMBER;
        }

        $allowed = array_map(static fn (array $user): int => (int) $user['id'], $this->assignableUsers());
        $added   = 0;
        foreach ($this->postedIds('user_ids') as $userId) {
            if (in_array($userId, $allowed, true) && !$this->members->isMember($id, $userId)) {
                $this->members->assign($id, $userId, $role);
                $added++;
            }
        }

        if ($added === 0) {
            $this->flash('warning', 'Select at least one person to add.');
            $this->redirect($back);
        }

        LoggerHelper::audit('project.members_added', 'project', $id, ['count' => $added]);
        $this->flash('success', $added === 1 ? '1 member was added.' : $added . ' members were added.');
        $this->redirect($back);
    }

    /** POST /projects/{id}/members/{uid}/role */
    public function memberRole(Request $request, array $params): void
    {
        PermissionHelper::require('projects.manage_members');

        $id      = (int) ($params['id'] ?? 0);
        $userId  = (int) ($params['uid'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);
        $back = '/projects/' . $id . '?tab=access';

        $role = (string) $request->input('role', '');
        if (!in_array($role, ProjectMember::ROLES, true) || !$this->members->isMember($id, $userId)) {
            $this->redirect($back);
        }
        $pmId = (int) ($project['manager_id'] ?? 0);
        if ($userId === $pmId && $role !== ProjectMember::ROLE_MANAGER) {
            $this->flash('warning', 'The project manager keeps the manager role. Change the manager in Settings first.');
            $this->redirect($back);
        }
        if ($role === ProjectMember::ROLE_MANAGER && $userId !== $pmId) {
            $this->flash('warning', 'Only the project manager can have the manager role. Change the manager in Settings first.');
            $this->redirect($back);
        }

        $this->members->setRole($id, $userId, $role);
        LoggerHelper::audit('project.member_role_changed', 'project', $id, ['user_id' => $userId, 'role' => $role]);
        $this->flash('success', 'Role updated.');
        $this->redirect($back);
    }

    /** POST /projects/{id}/members/{uid}/remove */
    public function memberRemove(Request $request, array $params): void
    {
        PermissionHelper::require('projects.manage_members');

        $id      = (int) ($params['id'] ?? 0);
        $userId  = (int) ($params['uid'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);
        $back = '/projects/' . $id . '?tab=access';

        if ($userId === (int) ($project['manager_id'] ?? 0)) {
            $this->flash('warning', 'The project manager cannot be removed. Change the manager in Settings first.');
            $this->redirect($back);
        }

        $held = $this->teamPositionsOnProject($id, $userId);
        if ($held !== []) {
            $this->flash('warning', 'This person is ' . implode(' and ', $held) . ' of a team on this project. Change the team first.');
            $this->redirect($back);
        }

        if ($this->members->remove($id, $userId)) {
            $this->removeFromProjectTeams($id, $userId);
            ApprovalChainHelper::reset();
            LoggerHelper::audit('project.member_removed', 'project', $id, ['user_id' => $userId]);
            $this->flash('success', 'Member removed from the project.');
        }
        $this->redirect($back);
    }

    /** @return list<int> */
    private function postedIds(string $key): array
    {
        $raw = $this->request->input($key, []);
        if (!is_array($raw)) {
            $raw = $raw === null || $raw === '' ? [] : [$raw];
        }

        $ids = [];
        foreach ($raw as $value) {
            if ((int) $value > 0) {
                $ids[] = (int) $value;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * Team manager titles this person holds on the project.
     *
     * @return list<string>
     */
    private function teamPositionsOnProject(int $projectId, int $userId): array
    {
        if ($projectId < 1 || $userId < 1 || !TeamGroup::installed()) {
            return [];
        }

        $held = [];
        if (Department::installed()) {
            $asDept = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM departments WHERE project_id = :p AND manager_id = :u',
                ['p' => $projectId, 'u' => $userId]
            );
            if ($asDept > 0) {
                $held[] = 'department manager';
            }
        }
        $asManager = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM teams WHERE project_id = :p AND manager_id = :u',
            ['p' => $projectId, 'u' => $userId]
        );
        if ($asManager > 0) {
            $held[] = 'team manager';
        }

        return $held;
    }

    private function removeFromProjectTeams(int $projectId, int $userId): void
    {
        if ($projectId < 1 || $userId < 1 || !TeamGroup::installed()) {
            return;
        }

        Database::execute(
            'DELETE tm FROM team_members tm
             INNER JOIN teams t ON t.id = tm.team_id
             WHERE t.project_id = :p AND tm.user_id = :u',
            ['p' => $projectId, 'u' => $userId]
        );
    }

    /** @return array<string, mixed> */
    private function loadVisible(int $id): array
    {
        if ($id < 1) {
            $this->notFound();
        }

        $project = $this->projects->findWithRelations($id);
        if ($project === null) {
            $this->notFound();
        }

        $viewAll = PermissionHelper::has('projects.view_all');
        if (!$this->projects->userCanView($project, (int) AuthHelper::id(), $viewAll)) {
            $this->forbidden();
        }
        ClientScope::assertCanSeeProject($project);

        return $project;
    }

    /** @param array<string, mixed> $project */
    private function assertCanManage(array $project): void
    {
        if (!$this->projects->userCanManage(
            $project,
            (int) AuthHelper::id(),
            AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)
        )) {
            $this->forbidden();
        }
    }

    /** @return array<string, mixed> */
    private function validatedProject(string $failPath, ?int $ignoreId = null): array
    {
        $codeRule = $ignoreId !== null
            ? 'nullable|string|max:40|unique:projects,project_code,' . $ignoreId
            : 'nullable|string|max:40|unique:projects,project_code';

        $data = $this->validate([
            'client_id'       => 'required|int|exists:clients,id',
            'project_code'    => $codeRule,
            'name'            => 'required|string|max:160',
            'description'     => 'nullable|string|max:5000',
            'start_date'      => 'nullable|date',
            'due_date'        => 'nullable|date',
            'status'          => 'required|in:' . implode(',', Project::STATUSES),
            'priority'        => 'required|in:' . implode(',', Project::PRIORITIES),
            'estimated_hours' => 'nullable|numeric|min:0|max:999999',
            'budget'          => 'nullable|numeric|min:0|max:99999999',
            'hourly_rate'     => 'nullable|numeric|min:0|max:99999',
            'is_billable'     => 'nullable|boolean',
            'manager_id'      => 'nullable|int|exists:users,id',
        ], $failPath, [
            'client_id'       => 'Client',
            'project_code'    => 'Project code',
            'name'            => 'Name',
            'description'     => 'Description',
            'start_date'      => 'Start date',
            'due_date'        => 'Due date',
            'status'          => 'Status',
            'priority'        => 'Priority',
            'estimated_hours' => 'Estimated hours',
            'budget'          => 'Budget',
            'hourly_rate'     => 'Hourly rate',
            'is_billable'     => 'Billable',
            'manager_id'      => 'Manager',
        ]);

        if ($data['start_date'] !== null && $data['due_date'] !== null && $data['due_date'] < $data['start_date']) {
            $this->backWithErrors($failPath, ['due_date' => 'Due date must be on or after the start date.']);
        }

        $data['estimated_hours'] = $data['estimated_hours'] ?? 0;
        $data['budget']          = $data['budget'] ?? 0;
        $data['hourly_rate']     = $data['hourly_rate'] ?? 0;
        $data['is_billable']     = (int) ($data['is_billable'] ?? 0);

        if ($data['manager_id'] !== null) {
            $manager = Database::fetchOne(
                "SELECT u.id, r.name AS role, u.status
                 FROM users u
                 INNER JOIN roles r ON r.id = u.role_id
                 WHERE u.id = :id LIMIT 1",
                ['id' => (int) $data['manager_id']]
            );
            if ($manager === null || $manager['status'] !== 'active') {
                $this->backWithErrors($failPath, ['manager_id' => 'Manager does not exist.']);
            }
            if (!in_array((string) $manager['role'], [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER], true)) {
                $this->backWithErrors($failPath, ['manager_id' => 'Manager must be an admin or a manager.']);
            }
        }

        return $data;
    }

    /** @return list<int> */
    private function postedMemberIds(): array
    {
        $raw = $this->request->input('member_ids', []);
        if (!is_array($raw)) {
            $raw = $raw === null || $raw === '' ? [] : [$raw];
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @return array<int, string>
     */
    private function postedMemberRoles(mixed $managerId): array
    {
        $raw = $this->request->input('member_roles', []);
        $roles = [];

        if (is_array($raw)) {
            foreach ($raw as $userId => $role) {
                $uid = (int) $userId;
                $role = strtolower((string) $role);
                if ($uid > 0 && in_array($role, ProjectMember::ROLES, true)) {
                    $roles[$uid] = $role;
                }
            }
        }

        if ($managerId !== null && (int) $managerId > 0) {
            $roles[(int) $managerId] = ProjectMember::ROLE_MANAGER;
        }

        $pmId = $managerId !== null ? (int) $managerId : 0;
        foreach ($roles as $uid => $role) {
            if ($role === ProjectMember::ROLE_MANAGER && (int) $uid !== $pmId) {
                $roles[$uid] = ProjectMember::ROLE_MEMBER;
            }
        }

        return $roles;
    }

    private function assertOnlyPmIsManager(int $projectId, mixed $managerId): void
    {
        $pmId = $managerId !== null ? (int) $managerId : 0;
        try {
            Database::execute(
                "UPDATE project_members SET project_role = :member
                 WHERE project_id = :project_id AND project_role = :manager AND user_id <> :pm",
                [
                    'member'     => ProjectMember::ROLE_MEMBER,
                    'project_id' => $projectId,
                    'manager'    => ProjectMember::ROLE_MANAGER,
                    'pm'         => $pmId,
                ]
            );
            if ($pmId > 0) {
                $this->members->assign($projectId, $pmId, ProjectMember::ROLE_MANAGER);
            }
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }
    }

    /**
     * @param array<string, mixed> $extra
     * @return array<string, mixed>
     */
    private function formData(array $extra): array
    {
        return array_merge([
            'clients'     => $this->clients->activeOptions(),
            'managers'    => $this->managerOptions(),
            'users'       => $this->assignableUsers(),
            'statuses'    => Project::STATUSES,
            'priorities'  => Project::PRIORITIES,
            'memberRoles' => $extra['memberRoles'] ?? [],
        ], $extra);
    }

    /** @return array<string, mixed> */
    private function blankProject(): array
    {
        return [
            'id'              => 0,
            'client_id'       => (int) ($this->request->input('client_id', 0)),
            'project_code'    => $this->projects->nextCode(),
            'name'            => '',
            'description'     => '',
            'start_date'      => '',
            'due_date'        => '',
            'status'          => Project::STATUS_PLANNING,
            'priority'        => Project::PRIORITY_MEDIUM,
            'estimated_hours' => '',
            'budget'          => '',
            'hourly_rate'     => '',
            'is_billable'     => 1,
            'manager_id'      => AuthHelper::hasRole(AuthHelper::ROLE_MANAGER) ? AuthHelper::id() : null,
        ];
    }

    /** @return list<array<string, mixed>> */
    private function managerOptions(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name, u.email, r.name AS role
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager')
             ORDER BY u.name ASC"
        );
    }

    /** @return list<array<string, mixed>> */
    private function assignableUsers(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name, u.email, r.name AS role, u.job_title
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
              WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
              ORDER BY u.name ASC"
        );
    }

    /**
     * @return list<array{id: int, name: string}>
     */
    private static function projectTeamOptions(int $projectId): array
    {
        $snap = ApprovalChainHelper::snapshot();
        $out  = [];
        foreach ($snap['teams'] as $teamId => $team) {
            if ((int) $team['project_id'] !== $projectId) {
                continue;
            }
            $out[] = [
                'id'   => (int) $teamId,
                'name' => (string) ($snap['teamNames'][(int) $teamId] ?? ('Team #' . $teamId)),
            ];
        }
        usort($out, static fn (array $a, array $b): int => strcasecmp($a['name'], $b['name']));

        return $out;
    }
}
