<?php
declare(strict_types=1);

$me = AuthHelper::user() ?? ['name' => '', 'email' => '', 'role' => ''];
$current = Request::current()->path();
$appName = (string) Config::get('app.name', 'TimeTrack');

$groups = [
    'TRACK' => [
        ['label' => 'Dashboard', 'icon' => 'fa-gauge-high', 'path' => '/dashboard', 'permission' => 'dashboard.view'],
        ['label' => 'Time Tracker', 'icon' => 'fa-clock', 'path' => '/time', 'permission' => 'time.view_own', 'controller' => 'TimerController'],
        ['label' => 'Timesheet', 'icon' => 'fa-file-lines', 'path' => '/timesheets', 'permission' => 'time.view_own', 'controller' => 'TimesheetController'],
        ['label' => 'Calendar', 'icon' => 'fa-calendar-days', 'path' => '/schedule/my', 'permission' => 'schedule.view', 'controller' => 'ScheduleController'],
    ],
    'MANAGE' => [
        ['label' => 'Approvals', 'icon' => 'fa-circle-check', 'path' => '/timesheets/team', 'permission' => 'time.approve', 'controller' => 'TimesheetController', 'badge' => true],
        ['label' => 'Projects', 'icon' => 'fa-diagram-project', 'path' => '/projects', 'permission' => 'projects.view', 'controller' => 'ProjectController'],
        ['label' => 'Team', 'icon' => 'fa-users', 'path' => '/projects', 'permission' => 'projects.view', 'controller' => 'ProjectController'],
        ['label' => 'Clients', 'icon' => 'fa-building', 'path' => '/clients', 'permission' => 'clients.view', 'controller' => 'ClientController'],
        ['label' => 'Schedule', 'icon' => 'fa-calendar-week', 'path' => '/schedule', 'permission' => 'schedule.view', 'controller' => 'ScheduleController'],
    ],
];

$isActive = static fn (string $path): bool => $current === $path || str_starts_with($current, $path . '/');
$initials = '';
foreach (array_slice(preg_split('/\s+/', trim((string) $me['name'])) ?: [], 0, 2) as $part) {
    $initials .= mb_strtoupper(mb_substr($part, 0, 1, 'UTF-8'), 'UTF-8');
}
$initials = $initials !== '' ? $initials : '?';
try {
    $unreadCount = (int) Database::fetchValue('SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0', ['id' => (int) AuthHelper::id()]);
} catch (Throwable) { $unreadCount = 0; }
try {
    $pendingCount = PermissionHelper::has('time.approve') ? (int) Database::fetchValue("SELECT COUNT(*) FROM timesheets WHERE status = 'Submitted'") : 0;
} catch (Throwable) { $pendingCount = 0; }
?>
<aside class="app-sidebar offcanvas-lg offcanvas-start" tabindex="-1" id="appSidebar" aria-label="Main navigation">
    <div class="sidebar-brand">
        <a href="<?= e(url('/dashboard')) ?>" class="brand-link">
            <span class="brand-mark" aria-hidden="true"><i class="fa-solid fa-stopwatch"></i></span>
            <span class="brand-name"><?= e($appName) ?></span>
        </a>
        <button type="button" class="btn-close d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#appSidebar" aria-label="Close menu"></button>
    </div>
    <div class="workspace-switcher"><span class="workspace-dot"></span><span class="workspace-name">My Workspace</span><i class="fa-solid fa-ellipsis ms-auto" aria-hidden="true"></i></div>
    <nav class="sidebar-nav">
        <?php foreach ($groups as $heading => $items): ?>
            <div class="sidebar-heading"><?= e($heading) ?></div>
            <ul class="nav flex-column">
            <?php foreach ($items as $item): ?>
                <?php if (isset($item['controller']) && !is_file(APP_PATH . '/Controllers/' . $item['controller'] . '.php')) continue; if (!PermissionHelper::has($item['permission'])) continue; $active = $isActive($item['path']); ?>
                <li class="nav-item"><a class="sidebar-link<?= $active ? ' active' : '' ?>" href="<?= e(url($item['path'])) ?>" <?= $active ? 'aria-current="page"' : '' ?>><i class="fa-solid <?= e($item['icon']) ?> fa-fw" aria-hidden="true"></i><span><?= e($item['label']) ?></span><?php if (!empty($item['badge']) && $pendingCount > 0): ?><span class="sidebar-badge">!</span><?php endif; ?></a></li>
            <?php endforeach; ?>
            </ul>
        <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
        <a class="sidebar-link<?= $isActive('/profile') ? ' active' : '' ?>" href="<?= e(url('/profile')) ?>"><i class="fa-solid fa-gear fa-fw" aria-hidden="true"></i><span>Settings</span></a>
        <div class="sidebar-user"><span class="avatar" aria-hidden="true"><?= e($initials) ?></span><span class="sidebar-user-text"><span class="sidebar-user-name"><?= e($me['name']) ?></span><span class="sidebar-user-role"><?= e(ucfirst((string) $me['role'])) ?></span></span></div>
    </div>
</aside>
<div class="app-main">
    <header class="app-topbar">
        <button class="btn btn-icon d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#appSidebar" aria-controls="appSidebar" aria-label="Open menu"><i class="fa-solid fa-bars" aria-hidden="true"></i></button>
        <div class="topbar-workspace"><strong><?= e($appName) ?></strong><span>Time &amp; project management</span></div>
        <div class="topbar-actions">
            <a class="btn btn-icon position-relative" href="<?= e(url('/dashboard')) ?>#notifications" aria-label="Notifications"><i class="fa-regular fa-bell" aria-hidden="true"></i><?php if ($unreadCount > 0): ?><span class="badge-dot"><?= $unreadCount > 9 ? '9+' : $unreadCount ?></span><?php endif; ?></a>
            <div class="dropdown"><button class="btn btn-user dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><span class="avatar avatar-sm" aria-hidden="true"><?= e($initials) ?></span><span class="d-none d-md-inline"><?= e($me['name']) ?></span></button><ul class="dropdown-menu dropdown-menu-end"><li class="dropdown-header"><?= e($me['email']) ?></li><li><a class="dropdown-item" href="<?= e(url('/profile')) ?>"><i class="fa-solid fa-user-gear fa-fw me-2" aria-hidden="true"></i>Settings</a></li><li><hr class="dropdown-divider"></li><li><form method="post" action="<?= e(url('/logout')) ?>" class="m-0"><?= csrf_field() ?><button type="submit" class="dropdown-item"><i class="fa-solid fa-arrow-right-from-bracket fa-fw me-2" aria-hidden="true"></i>Sign out</button></form></li></ul></div>
        </div>
    </header>
    <main class="app-content" id="main-content">
