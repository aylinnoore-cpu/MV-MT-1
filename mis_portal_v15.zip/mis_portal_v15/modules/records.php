<?php require __DIR__.'/../includes/lib.php';need();
$k=$_GET['m']??'assets';$M=mods()[$k]??die('Unknown module');$r=role();
if(!in_array($r,$M['view']))die('Access denied');
$id=(int)($_GET['id']??0);$a=$_GET['a']??'list';$t=$k;$own=isset($M['own'])&&!in_array($r,$M['full']??['support','ed','finance'])?$M['own']:null;
$hid=$r=='staff'?($M['hide']??[]):[];
$users=array_column(q('SELECT id,name FROM users')->fetchAll(),'name','id');
$assets=array_column(q('SELECT id,name FROM assets')->fetchAll(),'name','id');
$vendors=array_column(q('SELECT id,CONCAT(name,IF(status="inactive"," (inactive)","")) n FROM vendors ORDER BY name')->fetchAll(),'n','id');
$arows=q('SELECT id,warranty_end,vendor_id FROM assets')->fetchAll();$wend=array_column($arows,'warranty_end','id');$avend=array_column($arows,'vendor_id','id');
$Wm=[];foreach($wend as $i=>$e){[$wtx,$wcl]=warr($e);if(!empty($avend[$i])&&isset($vendors[$avend[$i]]))$wtx.=' | Vendor: '.$vendors[$avend[$i]];$Wm[$i]=[$wtx,$wcl];}
function mw($x){global $wend;[$wtx,$wcl]=warr($wend[$x['asset_id']]??null,$x['work_date']?:null);return '<span class="pill '.$wcl.'">'.h($wtx).'</span>';}
function row($t,$id,$own){$s="SELECT * FROM $t WHERE id=?";$p=[$id];if($own){$s.=" AND $own=?";$p[]=me()['id'];}return q($s,$p)->fetch();}
function cell($c,$v,$M,$users,$assets){global $vendors;$ty=$M['f'][$c][1]??'';if($c=='vendor_id')return h($vendors[$v]??'');if($c=='warranty')return $v;
 if($c=='warranty_end')return $v?'<span class="pill '.warr($v)[1].'">'.h(warr($v)[0]).'</span>':'<span class=pill>No warranty info</span>';
 if(in_array($c,['assigned_to','created_by','requested_by','user_id'])||$ty=='user')return h($users[$v]??'');
 if($c=='asset_id')return h($assets[$v]??'');
 if($c=='status'||$c=='priority')return '<span class=tag>'.h(pretty($v)).'</span>';
 return h(in_array($c,['role','type','category'])?pretty($v):$v);}
if($_SERVER['REQUEST_METHOD']=='POST'){chk();
 if($a=='delete'&&in_array($r,$M['del']??[])){$x=row($t,$id,$own);if($x){$why=trim($_POST['reason']??'');if($why===''){$_SESSION['err']='A reason is required for deletion.';header("Location: records.php?m=$k");exit;}if($k=='vendors'){if(q('SELECT (SELECT COUNT(*) FROM assets WHERE vendor_id=?)+(SELECT COUNT(*) FROM procurement WHERE vendor_id=?) c',[$id,$id])->fetch()['c']){$_SESSION['err']='This vendor is linked to assets or procurement requests. Set it to Inactive instead of deleting.';header("Location: records.php?m=vendors");exit;}
   $dl=[];foreach(q('SELECT * FROM documents WHERE kind="vendor_doc" AND ref_id=?',[$id])->fetchAll() as $o){$dl[]=['file'=>$o['orig_name'],'sha256'=>@hash_file('sha256',ST.$o['stored'])];@unlink(ST.$o['stored']);}log_delete('Vendor',$id,$x['name'],$x+['documents_removed'=>$dl],$why);q('DELETE FROM documents WHERE kind="vendor_doc" AND ref_id=?',[$id]);}
  if($k=='assets'){$why=trim($_POST['reason']??'');if($why===''){$_SESSION['err']='A reason is required to delete an asset.';header("Location: records.php?m=assets");exit;}
   $GLOBALS['pdo']->beginTransaction();$mc=q('SELECT COUNT(*) c FROM maintenance WHERE asset_id=?',[$id])->fetch()['c'];
   log_delete('Asset',$id,$x['asset_tag'].' - '.$x['name'],$x+['assigned_to_name'=>$users[$x['assigned_to']]??null,'vendor_name'=>$vendors[$x['vendor_id']]??$x['vendor'],'maintenance_records_removed'=>$mc],$why);
   q('DELETE FROM maintenance WHERE asset_id=?',[$id]);}q("DELETE FROM $t WHERE id=?",[$id]);if($k=='assets')$GLOBALS['pdo']->commit();logit("Deleted $k #$id (".($x['name']??'').")".($k=='assets'?' - reason: '.mb_substr($why,0,120):''));}header("Location: records.php?m=$k");exit;}
if($k=='vendors'&&$a=='vdoc'&&in_array($r,$M['edit'])){
  if(isset($_POST['del'])){$o=q('SELECT * FROM documents WHERE id=? AND kind="vendor_doc" AND ref_id=?',[(int)$_POST['del'],$id])->fetch();$rs=trim($_POST['reason']??'');if($o&&$rs===''){$_SESSION['err']='A reason is required to delete a document.';}elseif($o){log_delete('Vendor document',$o['id'],$o['orig_name'],$o+['file_sha256'=>@hash_file('sha256',ST.$o['stored']),'vendor_id'=>$id],$rs);@unlink(ST.$o['stored']);q('DELETE FROM documents WHERE id=?',[$o['id']]);logit("Deleted vendor document {$o['orig_name']} - reason: ".mb_substr($rs,0,120));}}
  else foreach($_FILES['files']['name']??[] as $i=>$n){if($n==='')continue;$f=['name'=>$n,'tmp_name'=>$_FILES['files']['tmp_name'][$i],'size'=>$_FILES['files']['size'][$i]];$s=store($f,['pdf','jpg','jpeg','png']);
   if($s){adddoc('vendor_doc',$id,$n,$s[0],$s[1]);logit("Uploaded vendor document $n (vendor #$id)");}else $_SESSION['err']="Rejected $n: only PDF/JPG/PNG up to 8MB.";}
  header("Location: records.php?m=vendors&a=view&id=$id");exit;}
 if($a=='flow'&&isset(flow()[$k])){ // status workflow
  $x=row($t,$id,$own)?:die('Not found');
  foreach(flow()[$k][$x['status']]??[] as [$to,$roles,$l])if($to==$_POST['to']&&in_array($r,$roles)){
   q("UPDATE $t SET status=? WHERE id=?",[$to,$id]);if($k=="item_requests"&&trim($_POST["remarks"]??"")!=="")q("UPDATE item_requests SET remarks=? WHERE id=?",[trim($_POST["remarks"]),$id]);if($k=="procurement")q("INSERT INTO approvals(entity,entity_id,action,approver_id,remarks)VALUES(?,?,?,?,?)",["procurement",$id,$to,me()["id"],trim($_POST["remarks"]??"")]);
   if($to=='po_issued')q('UPDATE procurement SET po_number=? WHERE id=?',['PO-'.date('Y').'-'.$id,$id]);
   logit(ucfirst(rtrim($k,'s'))." #$id: $l");}
  header("Location: records.php?m=$k&a=view&id=$id");exit;}
 if($a=='comment'&&$k=='tickets'&&row($t,$id,$own)){q('INSERT INTO ticket_comments(ticket_id,user_id,body)VALUES(?,?,?)',[$id,me()['id'],$_POST['body']]);header("Location: records.php?m=$k&a=view&id=$id");exit;}
 if($a=='form'){ // save
  if(!in_array($r,$M[$id?'edit':'add']))die('Access denied');
  $d=[];foreach($M['f'] as $c=>$f){$v=trim($_POST[$c]??'');
   if($f[1]=='password'){if($v==='')continue;$v=password_hash($v,PASSWORD_DEFAULT);}
   $d[$c]=($v===''&&in_array($f[1],['date','user','asset','number','opt','vendor']))?null:$v;}
  if($k=='assets'){$er='';$ws=$d['warranty_start']?:$d['purchase_date'];$d['warranty_end']=($ws&&(int)$d['warranty_months']>0)?(new DateTime($ws))->modify('+'.(int)$d['warranty_months'].' months')->format('Y-m-d'):null;if(($d['mac_supported']??'No')!='Yes')$d['mac_address']=$d['ip_address']=$d['ip_type']=null;
   else{if($d['mac_address']!==null){$m=preg_replace('/[^0-9A-F]/','',strtoupper($d['mac_address']));if(strlen($m)!=12)$er='Invalid MAC address (needs 12 hex digits, e.g. AA:BB:CC:DD:EE:FF).';else{$d['mac_address']=implode(':',str_split($m,2));if(q('SELECT 1 FROM assets WHERE mac_address=? AND id<>?',[$d['mac_address'],$id])->fetch())$er='This MAC address is already registered to another asset.';}}
    if(!$er&&$d['ip_address']!==null){if(!filter_var($d['ip_address'],FILTER_VALIDATE_IP))$er='Invalid IP address.';elseif($o=q('SELECT name FROM assets WHERE ip_address=? AND id<>?',[$d['ip_address'],$id])->fetch())$er='IP '.$d['ip_address'].' is already in use by: '.$o['name'];}}
   if(!$er&&$d['asset_tag']!==null&&q('SELECT 1 FROM assets WHERE asset_tag=? AND id<>?',[$d['asset_tag'],$id])->fetch())$er='Asset tag already exists.';
   if($er){$_SESSION['err']=$er;$_SESSION['old']=$_POST;header("Location: records.php?m=assets&a=form".($id?"&id=$id":''));exit;}}
  if($id){q("UPDATE $t SET ".implode(',',array_map(fn($c)=>"$c=?",array_keys($d)))." WHERE id=?",[...array_values($d),$id]);logit("Updated $k #$id");}
  else{if(isset($M['auto']))$d[$M['auto']]=me()['id'];
   q("INSERT INTO $t(".implode(',',array_keys($d)).")VALUES(".implode(',',array_fill(0,count($d),'?')).")",array_values($d));$id=$GLOBALS['pdo']->lastInsertId();
   if($k=='tickets')q('UPDATE tickets SET ticket_no=? WHERE id=?',['T'.(1000+$id),$id]);if($k=="assets")q("UPDATE assets SET barcode=? WHERE id=?",["AST-".str_pad($id,6,"0",STR_PAD_LEFT),$id]);logit("Created $k #$id");}
  if($k=="users"&&!empty($_FILES["photo"]["name"]))set_photo($id,$_FILES["photo"]);
  header("Location: records.php?m=$k&a=view&id=$id");exit;}}
head($M['title']);if(!empty($_SESSION['err'])){echo '<p class=err style="font-weight:600">'.h($_SESSION['err']).'</p>';unset($_SESSION['err']);}
if($a=='form'){$x=$id?row($t,$id,$own):[];if(!empty($_SESSION['old'])){$x=array_merge($x,$_SESSION['old']);unset($_SESSION['old']);}if($id&&!in_array($r,$M['edit']))die('Access denied');if(!$id&&!in_array($r,$M['add']))die('Access denied');
 echo '<div class=card><form method=post enctype=multipart/form-data><input type=hidden name=c value="'.csrf().'">';
 foreach($M['f'] as $c=>$f){if(in_array($c,$hid))continue;$v=$x[$c]??'';echo (($f[3]??'')=='net'?'<div class=net>':'<div>').'<label>'.h($f[0]).'</label>';
  if($f[1]=='textarea')echo "<textarea name=$c rows=3>".h($v)."</textarea>";
  elseif($f[1]=='select'){echo "<select name=$c>";foreach($f[2] as $o)echo '<option value="'.$o.'"'.($o==$v?' selected':'').'>'.pretty($o).'</option>';echo '</select>';}
  elseif(in_array($f[1],['user','asset','vendor'])){echo "<select name=$c><option value=''>-- none --</option>";foreach($f[1]=='user'?$users:($f[1]=='vendor'?$vendors:$assets) as $i=>$n)echo "<option value=$i".($i==$v?' selected':'').'>'.h($n).'</option>';echo '</select>';}
  else echo "<input name=$c type=".($f[1]=='password'?'password':$f[1])." step=0.01 value='".($f[1]=='password'?'':h($v))."'".($f[1]=='text'&&$c!='serial_no'&&$c!='vendor'&&$c!='category'&&$c!='location'&&$c!='phone'?' required':'').">";echo '</div>';}
 if($k=='users')echo '<label>Profile photo (JPG/PNG, max 3MB)</label><input type=file name=photo accept=image/png,image/jpeg>';echo '<p><button>Save</button> <a class="btn g" href="records.php?m='.$k.'">Cancel</a></p></form></div>'.($k=='assets'?'<script>var s=document.querySelector("[name=mac_supported]");function tg(){document.querySelectorAll(".net").forEach(function(d){d.style.display=s.value=="Yes"?"":"none"})}s.onchange=tg;tg()</script>':'').($k=='maintenance'?'<script>var W='.json_encode($Wm,JSON_HEX_TAG).',s=document.querySelector("[name=asset_id]"),d=document.createElement("div");d.style.cssText="margin-top:6px;padding:8px 12px;border-radius:6px;max-width:480px;font-weight:600";s.after(d);function wu(){var w=W[s.value];if(!w){d.style.display="none";return}d.style.display="";d.textContent="Warranty: "+w[0];var c={g:["#dff5e6","#1d7a3c"],o:["#ffe9dc","#c24a00"],r:["#fde4e4","#b42323"]}[w[1]]||["#e8eaee","#333"];d.style.background=c[0];d.style.color=c[1]}s.onchange=wu;wu()</script>':'');}
elseif($a=='view'){$x=row($t,$id,$own)?:die('Not found');if($k=='maintenance')$x['warranty']=mw($x);
 echo '<div class=card>'.($k=='users'?'<img src="file.php?photo='.$id.'" onerror="this.style.display=\'none\'" style="float:right;width:110px;height:130px;object-fit:cover;border:1px solid #ccc">':'').'<table>';foreach($x as $c=>$v)if($c!='password'&&!in_array($c,$hid))echo '<tr><th>'.h(pretty($c)).'</th><td>'.cell($c,$v,$M,$users,$assets).'</td></tr>';echo '</table><p class=noprint>';
 foreach(flow()[$k][$x['status']??'']??[] as [$to,$roles,$l])if(in_array($r,$roles))
  echo '<form method=post action="records.php?m='.$k.'&a=flow&id='.$id.'" style="display:inline"><input type=hidden name=c value="'.csrf().'"><input type=hidden name=to value='.$to.'><input name=remarks placeholder=Remarks style="width:150px"> <button class="'.($to=='rejected'?'btn r':'').'">'.$l.'</button></form> ';
 if(in_array($r,$M['edit']))echo "<a class=btn href='records.php?m=$k&a=form&id=$id'>Edit</a> ";
 if($k=='assets'&&in_array($r,['support','ed'])){if(in_array($x['status'],['out_for_repair','out_for_maintenance']))echo "<a class=btn href='asset_out.php?id=$id&a=return'>Mark returned</a> ";elseif(in_array($x['status'],['working','in_storage','faulty']))echo "<a class=btn href='asset_out.php?id=$id'>Send out for repair / maintenance</a> ";}
 if(in_array($r,$M['del']??[]))echo '<form method=post action="records.php?m='.$k.'&a=delete&id='.$id.'" style="display:inline" onsubmit="return dl(this)"><input type=hidden name=reason><input type=hidden name=c value="'.csrf().'"><button class="btn r">Delete</button></form> ';
 echo '<button class=g onclick="print()" style="background:#e8eaee;color:#1d2433">Print record</button> '.($k=='procurement'?"<a class='btn g' href='quotes.php?p=$id'>Quotations</a> <a class='btn g' href='gen.php?k=cs&p=$id'>Comparative statement</a> <a class='btn g' href='gen.php?k=po&p=$id'>Purchase order</a>":'').($k=='assets'?" <a class='btn g' href='barcode.php?ids=$id'>Print barcode</a>":'').'</p></div>';
 if($k=='assets'){echo '<div class=card><b>Maintenance &amp; repair history</b><table><tr><th>Date<th>Type<th>Technician'.($hid?'':'<th>Cost').'<th>Next due<th>Expected return<th>Returned';
  foreach(q('SELECT * FROM maintenance WHERE asset_id=? ORDER BY work_date DESC',[$id]) as $m)echo "<tr><td>$m[work_date]<td>".pretty($m['type'])."<td>".h($m['technician']).($hid?'':"<td>$m[cost]")."<td>$m[next_due]<td>$m[expected_return]<td>$m[returned_on]";echo '</table></div>';}
if($k=='vendors'){$ed=in_array($r,$M['edit']);echo '<div class=card><b>Documents</b> <small>(registration, contract, tax certificate, etc.)</small><table><tr><th>File<th>Uploaded<th>';
  foreach(q('SELECT * FROM documents WHERE kind="vendor_doc" AND ref_id=? ORDER BY id DESC',[$id]) as $m)echo '<tr><td>'.h($m['orig_name']).'<td>'.$m['created_at'].'<td><a href="file.php?id='.$m['id'].'" target=_blank>Preview</a> | <a href="file.php?id='.$m['id'].'&dl=1">Download</a>'
   .($ed?' | <form method=post action="records.php?m=vendors&a=vdoc&id='.$id.'" style="display:inline" onsubmit="return dl(this)"><input type=hidden name=reason><input type=hidden name=c value="'.csrf().'"><button name=del value='.$m['id'].' class="btn r" style="padding:1px 8px">Delete</button></form>':'');
  echo '</table>'.($ed?'<form method=post enctype=multipart/form-data action="records.php?m=vendors&a=vdoc&id='.$id.'"><input type=hidden name=c value="'.csrf().'"><label>Attach documents (PDF, JPG, PNG - multiple allowed)</label><input type=file name=files[] multiple required accept=.pdf,.jpg,.jpeg,.png> <button>Upload</button></form>':'').'</div>';
  echo '<div class=card><b>Assets supplied</b><table><tr><th>Barcode<th>Asset<th>Warranty';foreach(q('SELECT * FROM assets WHERE vendor_id=?',[$id]) as $m){[$wt,$wc]=warr($m['warranty_end']);echo '<tr><td>'.h($m['barcode']).'<td><a href="records.php?m=assets&a=view&id='.$m['id'].'">'.h($m['name']).'</a><td><span class="pill '.$wc.'">'.h($wt).'</span>';}
  echo '</table></div><div class=card><b>Procurement requests</b><table><tr><th>#<th>Title<th>Amount<th>Status';foreach(q('SELECT * FROM procurement WHERE vendor_id=? ORDER BY id DESC',[$id]) as $m)echo '<tr><td>'.$m['id'].'<td><a href="records.php?m=procurement&a=view&id='.$m['id'].'">'.h($m['title']).'</a><td>'.$m['amount'].'<td>'.pretty($m['status']);echo '</table></div>';}
 if($k=='procurement'){echo '<div class=card><b>Approval history</b><table><tr><th>Date<th>Action<th>By<th>Remarks';
  foreach(q('SELECT * FROM approvals WHERE entity="procurement" AND entity_id=? ORDER BY id',[$id]) as $m)echo '<tr><td>'.$m['created_at'].'<td>'.pretty($m['action']).'<td>'.h($users[$m['approver_id']]??'').'<td>'.h($m['remarks']);echo '</table></div>';}
 if($k=='users'){echo '<div class=card><b>Assigned assets</b><table><tr><th>Barcode<th>Asset<th>Since';
  foreach(q('SELECT * FROM assets WHERE assigned_to=?',[$id]) as $m)echo '<tr><td>'.h($m['barcode']).'<td>'.h($m['name']).'<td>'.$m['assigned_date'];echo '</table></div>';}
 if($k=='tickets'){echo '<div class=card><b>Comments</b><table>';
  foreach(q('SELECT * FROM ticket_comments WHERE ticket_id=? ORDER BY id',[$id]) as $m)echo '<tr><td>'.h($users[$m['user_id']]??'').'<td>'.h($m['body']).'<td>'.$m['created_at'];
  echo '</table><form method=post action="records.php?m=tickets&a=comment&id='.$id.'"><input type=hidden name=c value="'.csrf().'"><textarea name=body rows=2 required></textarea><p><button>Add comment</button></p></form></div>';}}
else{$s="SELECT * FROM $t";$p=[];if($own){$s.=" WHERE $own=?";$p[]=me()['id'];}
 if($k=='assets'&&in_array($_GET['status']??'',$M['f']['status'][2])){$s.=($own?' AND':' WHERE').' status=?';$p[]=$_GET['status'];}
 echo '<p class=noprint>'.(in_array($r,$M['add'])?"<a class=btn href='records.php?m=$k&a=form'>+ Add new</a> ":'').($k=='assets'&&in_array($r,['support','ed'])?"<a class='btn g' href='asset_import.php'>Import assets</a> <a class='btn g' href='deletion_log.php?entity=Asset'>Deletion log</a>":'').'</p>'.($k=='assets'?'<p class=noprint><a class=pill style="text-decoration:none" href="records.php?m=assets">All</a> '.implode(' ',array_map(fn($o)=>"<a class='pill ".(($_GET['status']??'')==$o?'o':'')."' style='text-decoration:none' href='records.php?m=assets&status=$o'>".pretty($o).'</a>',$M['f']['status'][2])).'</p>':'').'<div class=card><table><tr>';
 $cols=array_values(array_diff($M['cols'],$hid));foreach($cols as $c)echo '<th>'.h(pretty($c));echo '<th class=noprint>';
 foreach(q($s.' ORDER BY id DESC',$p) as $x){if($k=='maintenance')$x['warranty']=mw($x);echo '<tr>';foreach($cols as $c)echo '<td>'.cell($c,$x[$c],$M,$users,$assets);echo "<td class=noprint style='white-space:nowrap'><a href='records.php?m=$k&a=view&id=$x[id]'>Open</a>".(in_array($r,$M['edit'])?" | <a href='records.php?m=$k&a=form&id=$x[id]'>Edit</a>":'').($k=='assets'&&in_array($r,['support','ed'])?" | <a href='barcode.php?ids=$x[id]'>Barcode</a>".(in_array($x['status'],['out_for_repair','out_for_maintenance'])?" | <a href='asset_out.php?id=$x[id]&a=return'>Return</a>":(in_array($x['status'],['working','in_storage','faulty'])?" | <a href='asset_out.php?id=$x[id]'>Send out</a>":'')):'').(in_array($r,$M['del']??[])?" | <form method=post action='records.php?m=$k&a=delete&id=$x[id]' style=display:inline onsubmit=\"return dl(this)\"><input type=hidden name=reason><input type=hidden name=c value='".csrf()."'><button class='btn r' style='padding:1px 8px'>Delete</button></form>":'');}
 echo '</table></div>';}
foot();
