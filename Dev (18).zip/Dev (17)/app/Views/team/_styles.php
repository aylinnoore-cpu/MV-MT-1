<?php
/**
 * Styles scoped to the Team pages (Phase 14). Kept here, not in app.css, so nothing else
 * in the app can be affected. Colours use Bootstrap theme variables so dark mode follows.
 */
?>
<style>
.tm-week { display:flex; align-items:center; gap:.5rem; flex-wrap:wrap; }
.tm-week-label { font-weight:600; min-width:11rem; text-align:center; }
.tm-person { display:flex; align-items:center; gap:.7rem; min-width:13rem; }
.tm-person a.tm-name { font-weight:600; color:inherit; text-decoration:none; }
.tm-person a.tm-name:hover { text-decoration:underline; }
.tm-sub { display:block; font-size:.8rem; color:var(--bs-secondary-color); }
.tm-chips { display:flex; flex-wrap:wrap; gap:.3rem; }
.tm-chip { display:inline-flex; align-items:center; gap:.35rem; max-width:13rem; padding:.12rem .55rem; font-size:.78rem; border:1px solid var(--bs-border-color); border-radius:999px; color:inherit; text-decoration:none; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.tm-chip:hover { background:var(--bs-tertiary-bg); }
.tm-dot { width:.5rem; height:.5rem; border-radius:50%; flex:0 0 auto; background:var(--tt-tide, #0b7a75); }
.tm-chip.is-manager { border-color:var(--tt-tide, #0b7a75); }
.tm-chip-more { font-size:.78rem; color:var(--bs-secondary-color); align-self:center; }
.tm-load { min-width:12rem; }
.tm-load-top { display:flex; justify-content:space-between; font-size:.82rem; margin-bottom:.25rem; gap:.5rem; }
.tm-bar { height:.5rem; border-radius:999px; background:var(--bs-tertiary-bg); overflow:hidden; }
.tm-bar > span { display:block; height:100%; border-radius:999px; background:var(--tt-tide, #0b7a75); }
.tm-bar.is-available > span { background:#3b82c4; }
.tm-bar.is-over > span { background:#b42318; }
.tm-bar.is-none > span { background:transparent; }
.tm-state { display:inline-block; padding:.1rem .55rem; font-size:.75rem; font-weight:600; border-radius:999px; }
.tm-state.is-available { color:#1d4f87; background:#e3effb; }
.tm-state.is-balanced { color:#2f6f45; background:#e8f5ec; }
.tm-state.is-over { color:#912018; background:#fde8e6; }
.tm-state.is-none { color:var(--bs-secondary-color); background:var(--bs-tertiary-bg); }
.tm-muted { color:var(--bs-secondary-color); }
.tm-tasks b.is-overdue { color:#b42318; }
.tm-trend { display:grid; grid-template-columns:repeat(6, 1fr); gap:.75rem; align-items:end; height:11rem; padding:1rem 1rem .25rem; }
.tm-trend-col { display:flex; flex-direction:column; align-items:center; justify-content:flex-end; height:100%; gap:.35rem; min-width:0; }
.tm-trend-bars { display:flex; align-items:flex-end; gap:.25rem; height:100%; width:100%; justify-content:center; }
.tm-trend-bar { width:42%; max-width:1.6rem; min-height:2px; border-radius:.3rem .3rem 0 0; background:var(--tt-tide, #0b7a75); }
.tm-trend-bar.is-tracked { background:var(--tt-amber, #e8a317); }
.tm-trend-label { font-size:.72rem; color:var(--bs-secondary-color); white-space:nowrap; }
.tm-trend-col.is-current .tm-trend-label { font-weight:700; color:inherit; }
.tm-legend { display:flex; gap:1rem; padding:0 1rem .9rem; font-size:.78rem; color:var(--bs-secondary-color); }
.tm-legend i { display:inline-block; width:.6rem; height:.6rem; border-radius:2px; margin-right:.3rem; background:var(--tt-tide, #0b7a75); }
.tm-legend i.is-tracked { background:var(--tt-amber, #e8a317); }
.tm-head { display:flex; align-items:center; gap:1rem; flex-wrap:wrap; padding:1.25rem; }
.tm-head .avatar { width:3.2rem; height:3.2rem; font-size:1.2rem; }
@media (max-width: 767.98px) { .tm-week-label { min-width:0; } .tm-load, .tm-person { min-width:0; } }
</style>
