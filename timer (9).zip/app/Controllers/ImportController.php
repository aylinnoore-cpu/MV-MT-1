<?php
declare(strict_types=1);

/** CSV importer for initial migration from another time/project system. */
final class ImportController extends Controller
{
    private const TYPES = [
        'users' => 'Users / team members',
        'clients' => 'Clients',
        'projects' => 'Projects',
        'project_members' => 'Project members',
        'tasks' => 'Tasks',
        'task_assignees' => 'Task assignees',
        'time_entries' => 'Historical time entries',
        'schedules' => 'Schedules',
    ];

    private const MAX_ROWS = 5000;

    private const UNASSIGNED_CLIENT = 'Unassigned';

    private const UPSERT_TABLES = [
        'users', 'clients', 'projects', 'project_members', 'tasks', 'task_assignees', 'time_entries', 'schedules',
    ];

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER]);
        // The parent constructor already limits this area to Admin/Manager (same gate the sidebar uses).
        // Only enforce the DB permission for roles that are not Admin, because 'imports.manage' is not
        // seeded in role_permissions on every install and would otherwise 403 admins.
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            PermissionHelper::require('imports.manage');
        }
    }

    public function index(Request $request, array $params): void
    {
        $this->render('imports/index', [
            'pageTitle' => 'Import data',
            'types' => self::TYPES,
            'selected' => (string) $request->input('type', 'users'),
            'result' => null,
        ]);
    }

    public function import(Request $request, array $params): void
    {
        $type = (string) $request->input('type', '');
        if (!isset(self::TYPES[$type])) {
            $this->flash('danger', 'Choose a valid import type.');
            $this->redirect('/import');
        }
        if (!isset($_FILES['csv']) || !is_array($_FILES['csv']) || (int) ($_FILES['csv']['error'] ?? 99) !== UPLOAD_ERR_OK) {
            $this->flash('danger', 'Please select a CSV file.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        $tmp = (string) $_FILES['csv']['tmp_name'];
        if ((int) ($_FILES['csv']['size'] ?? 0) > 10 * 1024 * 1024) {
            $this->flash('danger', 'CSV is too large. Maximum size is 10 MB.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        $rows = $this->readCsv($tmp);
        if ($rows === []) {
            $this->flash('danger', 'The CSV is empty or its header row could not be read.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        if (count($rows) > self::MAX_ROWS) {
            $this->flash('danger', 'CSV has more than ' . self::MAX_ROWS . ' data rows. Split the file and import in batches.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }

        $dryRun = $request->input('preview') === '1' || $request->input('preview') === 'on';
        $allOrNothing = $request->input('all_or_nothing') === '1' || $request->input('all_or_nothing') === 'on';

        $result = $this->runImport($type, $rows, $dryRun, $allOrNothing);
        LoggerHelper::audit('import.completed', 'import', null, [
            'type' => $type,
            'rows' => count($rows),
            'created' => $result['created'],
            'updated' => $result['updated'],
            'skipped' => $result['skipped'],
            'preview' => $dryRun,
            'all_or_nothing' => $allOrNothing,
            'passwords_generated' => $result['passwords_generated'] ?? 0,
        ]);
        $this->render('imports/index', [
            'pageTitle' => 'Import data',
            'types' => self::TYPES,
            'selected' => $type,
            'result' => $result,
        ]);
    }

    /** @return list<array<string,string>> */
    private function readCsv(string $path): array
    {
        $fh = fopen($path, 'rb');
        if ($fh === false) {
            return [];
        }
        $header = fgetcsv($fh);
        if ($header === false) {
            fclose($fh);
            return [];
        }
        if (isset($header[0])) {
            $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $header[0]) ?? (string) $header[0];
        }
        $header = array_map(fn ($v): string => strtolower($this->clean((string) $v)), $header);
        $rows = [];
        while (($line = fgetcsv($fh)) !== false) {
            if (count(array_filter($line, static fn ($v): bool => trim((string) $v) !== '')) === 0) {
                continue;
            }
            $row = [];
            foreach ($header as $i => $key) {
                if ($key !== '') {
                    $row[$key] = $this->clean((string) ($line[$i] ?? ''));
                }
            }
            $rows[] = $row;
        }
        fclose($fh);
        return $rows;
    }

    /** @param list<array<string,string>> $rows */
    private function runImport(string $type, array $rows, bool $dryRun, bool $allOrNothing): array
    {
        $result = [
            'created' => 0,
            'updated' => 0,
            'skipped' => 0,
            'errors' => [],
            'passwords_generated' => 0,
            'preview' => $dryRun,
        ];

        $runner = function () use ($type, $rows, &$result): void {
            foreach ($rows as $n => $row) {
                try {
                    $changed = match ($type) {
                        'users' => $this->user($row, $result),
                        'clients' => $this->client($row),
                        'projects' => $this->project($row),
                        'project_members' => $this->projectMember($row),
                        'tasks' => $this->task($row),
                        'task_assignees' => $this->taskAssignee($row),
                        'time_entries' => $this->timeEntry($row),
                        'schedules' => $this->schedule($row),
                    };
                    if ($changed === 'created') {
                        $result['created']++;
                    } elseif ($changed === 'updated') {
                        $result['updated']++;
                    } else {
                        $result['skipped']++;
                    }
                } catch (Throwable $e) {
                    $result['skipped']++;
                    if (count($result['errors']) < 100) {
                        $result['errors'][] = 'CSV row ' . ($n + 2) . ': ' . $e->getMessage();
                    }
                    LoggerHelper::exception($e);
                    if (!empty($result['strict_txn'])) {
                        throw $e;
                    }
                }
            }
        };

        $result['all_or_nothing'] = $allOrNothing;
        $result['strict_txn'] = $allOrNothing && !$dryRun;

        try {
            if ($dryRun || $allOrNothing) {
                Database::transaction(function () use ($runner, $dryRun): void {
                    $runner();
                    if ($dryRun) {
                        throw new RuntimeException('__import_preview_rollback__');
                    }
                });
            } else {
                $runner();
            }
        } catch (RuntimeException $e) {
            if ($e->getMessage() !== '__import_preview_rollback__') {
                if ($allOrNothing && !$dryRun) {
                    $result['created'] = 0;
                    $result['updated'] = 0;
                }
            }
        } catch (Throwable $e) {
            if ($allOrNothing && !$dryRun) {
                $result['created'] = 0;
                $result['updated'] = 0;
            }
            LoggerHelper::exception($e);
        }

        if ($dryRun) {
            array_unshift($result['errors'], 'Preview only: no rows were written.');
        }

        return $result;
    }

    /** @param array<string,string> $r */
    private function user(array $r, array &$result): string
    {
        foreach (['name', 'email', 'role'] as $k) {
            $this->required($r, $k);
        }

        $actorIsAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);
        $actorId = (int) AuthHelper::id();

        $role = strtolower($r['role']);
        if (!in_array($role, AuthHelper::ROLES, true)) {
            throw new RuntimeException('Invalid role: ' . $role);
        }
        if (!$actorIsAdmin && $role === AuthHelper::ROLE_ADMIN) {
            throw new RuntimeException('Only admins can import admin users.');
        }

        $roleId = (int) Database::fetchValue('SELECT id FROM roles WHERE name = :r', ['r' => $role]);
        if (!$roleId) {
            throw new RuntimeException('Role not found: ' . $role);
        }

        $email = strtolower($r['email']);
        $existing = Database::fetchOne(
            'SELECT u.id, r.name AS role_name
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.email = :e',
            ['e' => $email]
        );

        $status = in_array($r['status'] ?? 'active', ['active', 'inactive', 'suspended'], true)
            ? (string) $r['status']
            : 'active';

        if ($existing) {
            $existingId = (int) $existing['id'];
            $existingRole = (string) $existing['role_name'];
            if (!$actorIsAdmin && $existingRole === AuthHelper::ROLE_ADMIN) {
                throw new RuntimeException('Cannot modify an admin account.');
            }
            if ($existingId === $actorId && ($role !== $existingRole || $status !== 'active')) {
                throw new RuntimeException('Cannot change the role or status of the currently logged-in user.');
            }
        }

        $timezone = $r['timezone'] !== '' ? $r['timezone'] : SettingsService::systemTimezone();
        if (!FormatHelper::isValidZone($timezone)) {
            $timezone = SettingsService::systemTimezone();
        }

        $data = [
            'role_id' => $roleId,
            'role' => $role,
            'name' => $r['name'],
            'email' => $email,
            'phone' => ($r['phone'] ?? '') !== '' ? $r['phone'] : null,
            'job_title' => ($r['job_title'] ?? '') !== '' ? $r['job_title'] : null,
            'hourly_rate' => $this->num($r['hourly_rate'] ?? '0'),
            'timezone' => $timezone,
            'status' => $status,
        ];

        if ($existing) {
            $id = (int) $existing['id'];
            Database::execute(
                'UPDATE users SET role_id = :role_id, role = :role, name = :name, phone = :phone,
                 job_title = :job_title, hourly_rate = :hourly_rate, timezone = :timezone,
                 status = :status, updated_at = UTC_TIMESTAMP()
                 WHERE id = :id',
                $data + ['id' => $id]
            );
            LoggerHelper::audit('import.user_updated', 'user', $id, ['email' => $email, 'role' => $role]);
            return 'updated';
        }

        $generated = false;
        if (($r['password'] ?? '') !== '') {
            $password = $r['password'];
        } else {
            $password = bin2hex(random_bytes(12));
            $generated = true;
        }

        Database::execute(
            'INSERT INTO users (role_id, role, name, email, password, phone, job_title, hourly_rate, timezone, status, password_changed_at)
             VALUES (:role_id, :role, :name, :email, :password, :phone, :job_title, :hourly_rate, :timezone, :status, NULL)',
            $data + ['password' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12])]
        );
        $id = Database::lastInsertId();
        if ($generated) {
            $result['passwords_generated']++;
        }
        LoggerHelper::audit('import.user_created', 'user', $id, [
            'email' => $email,
            'role' => $role,
            'password_generated' => $generated,
        ]);
        return 'created';
    }

    /** @param array<string,string> $r */
    private function client(array $r): string
    {
        $this->required($r, 'name');
        $email = ($r['email'] ?? '') !== '' ? strtolower($r['email']) : null;
        $existingId = $this->lookupClient($email ?? '', $r['name']);
        $lookup = $existingId !== null
            ? ['id' => $existingId]
            : ($email !== null ? ['email' => $email] : ['name' => $r['name']]);
        $data = [
            'name' => $r['name'],
            'email' => $email,
            'phone' => ($r['phone'] ?? '') !== '' ? $r['phone'] : null,
            'address' => ($r['address'] ?? '') !== '' ? $r['address'] : null,
            'status' => in_array($r['status'] ?? 'active', ['active', 'inactive'], true) ? $r['status'] : 'active',
        ];
        return $this->upsert('clients', $lookup, $data);
    }

    /** @param array<string,string> $r */
    private function project(array $r): string
    {
        foreach (['name', 'status'] as $k) {
            $this->required($r, $k);
        }
        $lookup = ($r['project_code'] ?? '') !== ''
            ? ['project_code' => $r['project_code']]
            : ['name' => $r['name']];
        $clientName = trim((string) ($r['client_name'] ?? ''));
        if ($clientName === '') {
            // Projects require a client in this app; park client-less rows under a placeholder.
            $clientName = self::UNASSIGNED_CLIENT;
            if ($this->lookupClient('', $clientName) === null) {
                Database::execute(
                    'INSERT INTO clients (name, status) VALUES (:n, :s)',
                    ['n' => $clientName, 's' => 'active']
                );
            }
        }
        $clientId = $this->lookupClient('', $clientName);
        if (!$clientId) {
            throw new RuntimeException('Client not found: ' . $clientName . ' (import clients first, or fix the spelling)');
        }
        $managerId = $this->lookupUser($r['manager_email'] ?? '');
        $allowed = ['Planning', 'Active', 'On Hold', 'Completed', 'Archived'];
        $statusKey = strtolower(str_replace(['_', '-'], ' ', $r['status']));
        $statusMap = [
            'planning' => 'Planning', 'active' => 'Active', 'on hold' => 'On Hold', 'hold' => 'On Hold',
            'completed' => 'Completed', 'complete' => 'Completed', 'done' => 'Completed',
            'archived' => 'Archived', 'inactive' => 'Archived',
        ];
        $status = $statusMap[$statusKey] ?? 'Planning';
        $createdBy = $this->lookupUser($r['created_by_email'] ?? '') ?: (int) AuthHelper::id();
        $data = [
            'client_id' => $clientId,
            'name' => $r['name'],
            'project_code' => ($r['project_code'] ?? '') !== '' ? $r['project_code'] : null,
            'description' => ($r['description'] ?? '') !== '' ? $r['description'] : null,
            'status' => $status,
            'priority' => (($priority = trim((string) ($r['priority'] ?? ''))) !== '' && in_array($priority, ['Low', 'Medium', 'High', 'Urgent'], true)) ? $priority : 'Medium',
            'start_date' => ($r['start_date'] ?? '') !== '' ? $r['start_date'] : null,
            'due_date' => ($r['due_date'] ?? '') !== '' ? $r['due_date'] : null,
            'manager_id' => $managerId ?: null,
            'hourly_rate' => $this->num($r['hourly_rate'] ?? '0'),
            'is_billable' => $this->bool($r['is_billable'] ?? '1'),
        ];
        return $this->upsert('projects', $lookup, $data, ['created_by' => $createdBy]);
    }

    /** @param array<string,string> $r */
    private function projectMember(array $r): string
    {
        foreach (['project_code', 'user_email'] as $k) {
            $this->required($r, $k);
        }
        $pid = $this->lookupProject($r['project_code']);
        $uid = $this->lookupUser($r['user_email']);
        if (!$pid || !$uid) {
            throw new RuntimeException('Project or user not found');
        }
        $role = in_array($r['project_role'] ?? 'member', ['manager', 'member', 'viewer'], true)
            ? $r['project_role']
            : 'member';
        $pmId = (int) Database::fetchValue('SELECT manager_id FROM projects WHERE id = :id LIMIT 1', ['id' => $pid]);
        if ($role === 'manager' && $uid !== $pmId) {
            $role = 'member';
        }
        if ($uid === $pmId) {
            $role = 'manager';
        }
        $ex = Database::fetchOne(
            'SELECT 1 FROM project_members WHERE project_id = :p AND user_id = :u',
            ['p' => $pid, 'u' => $uid]
        );
        if ($ex) {
            Database::execute(
                'UPDATE project_members SET project_role = :r WHERE project_id = :p AND user_id = :u',
                ['r' => $role, 'p' => $pid, 'u' => $uid]
            );
            return 'updated';
        }
        Database::execute(
            'INSERT INTO project_members (project_id, user_id, project_role) VALUES (:p, :u, :r)',
            ['p' => $pid, 'u' => $uid, 'r' => $role]
        );
        return 'created';
    }

    /** @param array<string,string> $r */
    private function task(array $r): string
    {
        foreach (['project_code', 'name'] as $k) {
            $this->required($r, $k);
        }
        $pid = $this->lookupProject($r['project_code']);
        if (!$pid) {
            throw new RuntimeException('Project not found');
        }
        $rawStatus = ($r['status'] ?? '') !== '' ? $r['status'] : Task::STATUS_TODO;
        $status = Task::persistStatus(Task::normalizeStatus($rawStatus));
        if (!in_array($status, Task::STATUSES, true) && !Task::statusEnumAllows($status)) {
            $status = Task::persistStatus(Task::STATUS_TODO);
        }
        $data = [
            'project_id' => $pid,
            'name' => $r['name'],
            'description' => ($r['description'] ?? '') !== '' ? $r['description'] : null,
            'status' => $status,
            'priority' => in_array($r['priority'] ?? 'Medium', Task::PRIORITIES, true) ? $r['priority'] : Task::PRIORITY_MEDIUM,
            'estimated_hours' => $this->num($r['estimated_hours'] ?? '0'),
            'is_billable' => $this->bool($r['is_billable'] ?? '0'),
        ];
        $teamName = trim((string) ($r['team'] ?? $r['team_name'] ?? ''));
        if ($teamName !== '' && SchemaHelper::columnExists('tasks', 'team_id') && TeamGroup::installed()) {
            $team = Database::fetchOne(
                'SELECT id FROM teams WHERE project_id = :p AND name = :n LIMIT 1',
                ['p' => $pid, 'n' => $teamName]
            );
            if ($team === null) {
                throw new RuntimeException('Team "' . $teamName . '" was not found in this project.');
            }
            $data['team_id'] = (int) $team['id'];
        }
        return $this->upsert(
            'tasks',
            ['project_id' => $pid, 'name' => $r['name']],
            $data,
            ['created_by' => (int) AuthHelper::id()]
        );
    }

    /** @param array<string,string> $r */
    private function taskAssignee(array $r): string
    {
        foreach (['project_code', 'task_name', 'user_email'] as $k) {
            $this->required($r, $k);
        }
        $pid = $this->lookupProject($r['project_code']);
        $uid = $this->lookupUser($r['user_email']);
        $task = Database::fetchOne(
            SchemaHelper::columnExists('tasks', 'team_id')
                ? 'SELECT id, team_id FROM tasks WHERE project_id = :p AND name = :n'
                : 'SELECT id FROM tasks WHERE project_id = :p AND name = :n',
            ['p' => $pid, 'n' => $r['task_name']]
        );
        if (!$task || !$uid) {
            throw new RuntimeException('Task or user not found');
        }
        $project = (new Project())->find($pid);
        if ($project === null) {
            throw new RuntimeException('Project not found');
        }
        $teamId = null;
        if (isset($task['team_id']) && $task['team_id'] !== null && $task['team_id'] !== '') {
            $teamId = (int) $task['team_id'];
            if ($teamId < 1) {
                $teamId = null;
            }
        }
        try {
            TaskPolicy::assertAssignable((int) AuthHelper::id(), $project, $teamId, [$uid]);
        } catch (HttpException $e) {
            throw new RuntimeException($e->getMessage());
        }
        $ex = Database::fetchOne(
            'SELECT 1 FROM task_assignees WHERE task_id = :t AND user_id = :u',
            ['t' => (int) $task['id'], 'u' => $uid]
        );
        if ($ex) {
            return 'skipped';
        }
        Database::execute(
            'INSERT INTO task_assignees (task_id, user_id) VALUES (:t, :u)',
            ['t' => (int) $task['id'], 'u' => $uid]
        );
        return 'created';
    }

    /** @param array<string,string> $r */
    private function timeEntry(array $r): string
    {
        foreach (['user_email', 'project_code', 'start_time', 'end_time'] as $k) {
            $this->required($r, $k);
        }
        $uid = $this->lookupUser($r['user_email']);
        $pid = $this->lookupProject($r['project_code']);
        if (!$uid || !$pid) {
            throw new RuntimeException('User or project not found');
        }
        $taskId = null;
        if (($r['task_name'] ?? '') !== '') {
            $t = Database::fetchOne(
                'SELECT id FROM tasks WHERE project_id = :p AND name = :n',
                ['p' => $pid, 'n' => $r['task_name']]
            );
            $taskId = $t ? (int) $t['id'] : null;
            if ($taskId === null) {
                throw new RuntimeException('Task not found');
            }
        }
        $start = $this->datetime($r['start_time']);
        $end = $this->datetime($r['end_time']);
        $startTs = strtotime($start . ' UTC');
        $endTs = strtotime($end . ' UTC');
        if ($startTs === false || $endTs === false || $endTs <= $startTs) {
            throw new RuntimeException('End must be after start');
        }

        try {
            TimeTrackingRules::assertCanTrack(
                $uid,
                $pid,
                $taskId,
                $start,
                TimeTrackingRules::CONTEXT_IMPORT
            );
        } catch (HttpException $e) {
            throw new RuntimeException($e->getMessage());
        }

        $bill = $this->bool($r['is_billable'] ?? '1');
        $rate = $this->num($r['billable_rate'] ?? '0');
        if ($rate <= 0) {
            $rate = (float) (Database::fetchValue('SELECT hourly_rate FROM projects WHERE id = :id', ['id' => $pid]) ?? 0);
        }

        $payload = [
            'user_id' => $uid,
            'project_id' => $pid,
            'task_id' => $taskId,
            'start_time' => $start,
            'end_time' => $end,
            'break_minutes' => (int) ($r['break_minutes'] ?? 0),
            'description' => ($r['description'] ?? '') !== '' ? $r['description'] : null,
            'is_billable' => $bill,
            'billable_rate' => $rate,
            'auto_stopped' => $this->bool($r['auto_stopped'] ?? '0'),
            '_context' => TimeTrackingRules::CONTEXT_IMPORT,
        ];

        $startCol = TimeEntry::column('start_time') ?? 'started_at';
        $endCol = TimeEntry::column('end_time') ?? 'ended_at';
        $ex = Database::fetchOne(
            "SELECT id FROM time_entries WHERE user_id = :u AND `{$startCol}` = :s AND `{$endCol}` = :e LIMIT 1",
            ['u' => $uid, 's' => $start, 'e' => $end]
        );

        $model = new TimeEntry();
        if ($ex) {
            $model->updateEntry((int) $ex['id'], $payload);
            return 'updated';
        }
        $model->createEntry($payload, false);
        return 'created';
    }

    /** @param array<string,string> $r */
    private function schedule(array $r): string
    {
        foreach (['user_email', 'start_datetime', 'end_datetime'] as $k) {
            $this->required($r, $k);
        }
        $uid = $this->lookupUser($r['user_email']);
        if (!$uid) {
            throw new RuntimeException('User not found');
        }
        $pid = $this->lookupProject($r['project_code'] ?? '');
        if (!$pid) {
            throw new RuntimeException('Project not found');
        }
        $start = $this->datetime($r['start_datetime']);
        $end = $this->datetime($r['end_datetime']);
        $startTs = strtotime($start . ' UTC');
        $endTs = strtotime($end . ' UTC');
        if ($startTs === false || $endTs === false || $endTs <= $startTs) {
            throw new RuntimeException('End must be after start');
        }
        $data = [
            'user_id' => $uid,
            'project_id' => $pid,
            'task_id' => null,
            'start_datetime' => $start,
            'end_datetime' => $end,
            'status' => in_array($r['status'] ?? 'Scheduled', ['Scheduled', 'In Progress', 'Completed', 'Missed', 'Cancelled', 'Rescheduled'], true)
                ? $r['status']
                : 'Scheduled',
            'notes' => ($r['notes'] ?? '') !== '' ? $r['notes'] : null,
        ];
        Database::execute(
            'INSERT INTO schedules (user_id, project_id, task_id, start_datetime, end_datetime, status, notes, created_by)
             VALUES (:user_id, :project_id, :task_id, :start_datetime, :end_datetime, :status, :notes, :created_by)',
            $data + ['created_by' => (int) AuthHelper::id()]
        );
        return 'created';
    }

    /**
     * @param array<string, mixed> $lookup
     * @param array<string, mixed> $data
     * @param array<string, mixed> $insertOnly
     */
    private function upsert(string $table, array $lookup, array $data, array $insertOnly = []): string
    {
        if (!in_array($table, self::UPSERT_TABLES, true)) {
            throw new InvalidArgumentException('Unsupported import table.');
        }
        foreach (array_keys($lookup + $data + $insertOnly) as $col) {
            if (!preg_match('/^[a-z_][a-z0-9_]*$/', (string) $col)) {
                throw new InvalidArgumentException('Invalid column name.');
            }
        }

        $where = [];
        $params = [];
        $i = 0;
        foreach ($lookup as $col => $val) {
            $key = 'lk' . $i++;
            $where[] = '`' . $col . '` = :' . $key;
            $params[$key] = $val;
        }
        $existing = Database::fetchOne(
            'SELECT id FROM `' . $table . '` WHERE ' . implode(' AND ', $where) . ' LIMIT 1',
            $params
        );

        if ($existing) {
            $sets = [];
            $update = [];
            $j = 0;
            foreach ($data as $col => $val) {
                $key = 'u' . $j++;
                $sets[] = '`' . $col . '` = :' . $key;
                $update[$key] = $val;
            }
            $update['id'] = (int) $existing['id'];
            Database::execute(
                'UPDATE `' . $table . '` SET ' . implode(', ', $sets) . ', updated_at = UTC_TIMESTAMP() WHERE id = :id',
                $update
            );
            return 'updated';
        }

        $insert = $data + $insertOnly;
        $cols = array_keys($insert);
        $placeholders = [];
        $bound = [];
        $k = 0;
        foreach ($insert as $val) {
            $key = 'i' . $k++;
            $placeholders[] = ':' . $key;
            $bound[$key] = $val;
        }
        Database::execute(
            'INSERT INTO `' . $table . '` (`' . implode('`, `', $cols) . '`) VALUES (' . implode(', ', $placeholders) . ')',
            $bound
        );
        return 'created';
    }

    private function lookupUser(string $email): int
    {
        if ($email === '') {
            return 0;
        }
        return (int) (Database::fetchValue('SELECT id FROM users WHERE email = :e', ['e' => strtolower($email)]) ?? 0);
    }

    private function lookupClient(string $email, string $name): ?int
    {
        if ($email !== '') {
            $v = Database::fetchValue('SELECT id FROM clients WHERE email = :e', ['e' => strtolower($email)]);
            if ($v) {
                return (int) $v;
            }
        }
        $key = $this->nameKey($name);
        if ($key === '') {
            return null;
        }
        foreach (Database::fetchAll('SELECT id, name FROM clients') as $c) {
            if ($this->nameKey((string) $c['name']) === $key) {
                return (int) $c['id'];
            }
        }
        return null;
    }

    /** Whitespace/NBSP/zero-width cleanup. */
    private function clean(string $v): string
    {
        $v = preg_replace('/[\x{00A0}\x{200B}\x{200C}\x{200D}\x{FEFF}\x{202F}\x{2007}]/u', ' ', $v) ?? $v;
        $v = preg_replace('/\s+/u', ' ', $v) ?? $v;
        return trim($v);
    }

    /** Comparison key: "AFIC - NIHD", "afic-nihd" and " AFIC  NIHD " all match. */
    private function nameKey(string $v): string
    {
        return preg_replace('/[^\p{L}\p{N}]+/u', '', mb_strtolower($this->clean($v))) ?? '';
    }

    private function lookupProject(string $code): int
    {
        return $code === '' ? 0 : (int) (Database::fetchValue('SELECT id FROM projects WHERE project_code = :c', ['c' => $code]) ?? 0);
    }

    /** @param array<string,string> $r */
    private function required(array $r, string $k): void
    {
        if (trim((string) ($r[$k] ?? '')) === '') {
            throw new RuntimeException('Missing ' . $k);
        }
    }

    private function num(string $v): float
    {
        return max(0, (float) str_replace(',', '', trim($v)));
    }

    private function bool(string $v): int
    {
        return in_array(strtolower(trim($v)), ['1', 'true', 'yes', 'y'], true) ? 1 : 0;
    }

    private function datetime(string $v): string
    {
        $v = trim($v);
        if ($v === '' || !preg_match('/^\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)?$/', $v)) {
            throw new RuntimeException('Invalid date/time: ' . $v);
        }

        if (str_ends_with($v, 'Z') || preg_match('/[+-]\d{2}:?\d{2}$/', $v)) {
            try {
                return (new DateTimeImmutable($v))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
            } catch (Exception) {
                throw new RuntimeException('Invalid date/time: ' . $v);
            }
        }

        $user = AuthHelper::user();
        $tz = is_array($user) ? (string) ($user['timezone'] ?? '') : '';
        $utc = FormatHelper::toUtc($v, $tz !== '' ? $tz : null);
        if ($utc === null) {
            throw new RuntimeException('Invalid date/time: ' . $v);
        }
        return $utc;
    }
}