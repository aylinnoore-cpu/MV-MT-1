# MIS Portal
index.php, login.php, logout.php   entry pages
config/config.php                  DB settings + paths
includes/  lib.php (helpers, auth, uploads) | modules.php (fields, roles, workflows) | layout.php (sidebar, header)
modules/   records.php (assets, procurement, tickets, maintenance, staff) | approvals | quotes | gen (comparative statement & PO)
           barcode | reports | settings | file (secure downloads)
assets/css/style.css               styles
database/  schema.sql (new install) | migrate.sql (upgrade)
storage/   private uploads (web access denied)
(no Composer / vendor folder needed)
verify.php public signature verification
