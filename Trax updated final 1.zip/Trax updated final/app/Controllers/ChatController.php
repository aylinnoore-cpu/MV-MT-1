<?php
/**
 * Internal chat. Membership, role and client-scope are re-checked on every action.
 * Client-role users never reach these methods (ClientScopeMiddleware + constructor).
 */

declare(strict_types=1);

final class ChatController extends Controller
{
    private Conversation $conversations;
    private ChatMessage $messages;

    public function __construct()
    {
        parent::__construct(true);
        if (ClientScope::isClient()) {
            throw new HttpException(403, 'Client accounts cannot access chat.');
        }
        $this->conversations = new Conversation();
        $this->messages = new ChatMessage();
    }

    /** GET /chat */
    public function index(Request $request, array $params): void
    {
        $userId = (int) AuthHelper::id();
        $installed = Conversation::installed();
        $openId = (int) $request->input('c', 0);
        $sidebar = $installed ? $this->conversations->sidebarFor($userId) : [
            'teams' => [], 'projects' => [], 'dms' => [], 'custom' => [], 'unread_total' => 0,
        ];

        $conversation = null;
        $members = [];
        $history = [];
        $maxId = 0;
        $adminPeek = false;
        if ($installed && $openId > 0) {
            [$conversation, $adminPeek] = $this->loadAccessible($openId, $userId, true);
            if ($conversation !== null) {
                $members = $this->conversations->liveMembers($conversation);
                $history = $this->messages->latest((int) $conversation['id'], 50);
                $maxId = $this->messages->maxId((int) $conversation['id']);
                if ($history !== []) {
                    $this->conversations->markRead((int) $conversation['id'], $userId, $maxId);
                }
                if ($adminPeek) {
                    LoggerHelper::logEvent('chat.admin_dm_access', LoggerHelper::MODULE_CHAT, (int) $conversation['id'], null, [
                        'admin_id' => $userId,
                    ]);
                }
            }
        }

        $this->render('chat/index', [
            'pageTitle'        => 'Messages',
            'chatAssets'       => true,
            'installed'        => $installed,
            'sidebar'          => $sidebar,
            'conversation'     => $conversation,
            'conversationName' => $conversation !== null ? $this->conversations->displayName($conversation, $userId) : '',
            'members'          => $members,
            'history'          => array_map([$this, 'publicMessage'], $history),
            'maxId'            => $maxId,
            'adminPeek'        => $adminPeek,
            'noticeEnabled'    => ChatHelper::noticeEnabled(),
            'noticeText'       => ChatHelper::noticeText(),
            'canCreateChannel' => ChatHelper::canCreateChannel(),
            'canCreateTask'    => ChatHelper::canCreateTaskFromMessage(),
            'canManage'        => AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
            'dmCandidates'     => $installed ? $this->conversations->dmCandidates($userId) : [],
            'staffDirectory'   => $installed && (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER) || ChatHelper::canCreateChannel())
                ? $this->conversations->staffDirectory() : [],
            'createProjects'   => ChatHelper::canCreateTaskFromMessage() ? $this->createTaskProjects() : [],
            'maxFileBytes'     => ChatHelper::effectiveMaxBytes(),
            'maxFileLabel'     => ChatHelper::formatBytes(ChatHelper::effectiveMaxBytes()),
            'allowedTypes'     => ChatHelper::allowedExtensions(),
            'bodyMax'          => ChatHelper::BODY_MAX,
            'filesPerMessage'  => ChatHelper::FILES_PER_MESSAGE,
            'userId'           => $userId,
        ]);
    }

    /** GET /chat/poll */
    public function poll(Request $request, array $params): void
    {
        $this->requireInstalledJson();
        $userId = (int) AuthHelper::id();
        $conversationId = (int) $request->input('c', 0);
        $sinceId = (int) $request->input('since_id', 0);
        $badgeSince = (int) $request->input('badge_since', 0);

        AuthHelper::releaseSession();

        if ($conversationId < 1) {
            $unread = $this->conversations->unreadConversationCount($userId);
            $this->json(['ok' => true, 'messages' => [], 'unread' => $unread, 'max_id' => 0]);
        }

        $conversation = $this->requireAccess($conversationId, $userId, true, false);
        $new = $this->messages->since((int) $conversation['id'], max(0, $sinceId));
        $maxId = $this->messages->maxId((int) $conversation['id']);
        if ($new !== []) {
            $this->conversations->markRead((int) $conversation['id'], $userId, $maxId);
        }
        $unread = $this->conversations->unreadConversationCount($userId);
        unset($badgeSince);

        $this->json([
            'ok'       => true,
            'messages' => array_map([$this, 'publicMessage'], $new),
            'unread'   => $unread,
            'max_id'   => $maxId,
        ]);
    }

    /** GET /chat/conversations/{id}/messages */
    public function messages(Request $request, array $params): void
    {
        $this->requireInstalledJson();
        $userId = (int) AuthHelper::id();
        $conversation = $this->requireAccess((int) ($params['id'] ?? 0), $userId, true, false);
        $before = (int) $request->input('before_id', 0);
        $rows = $this->messages->latest((int) $conversation['id'], 40, $before > 0 ? $before : null);

        $this->json([
            'ok'       => true,
            'messages' => array_map([$this, 'publicMessage'], $rows),
            'has_more' => count($rows) >= 40,
        ]);
    }

    /** POST /chat/conversations/{id}/messages */
    public function send(Request $request, array $params): void
    {
        $this->requireInstalledJson();
        $userId = (int) AuthHelper::id();
        if (ChatHelper::tooManySends($userId) || RateLimitHelper::tooMany('chat.message_sent', $request->ip(), 60, 1)) {
            throw new HttpException(429, 'You are sending messages too quickly. Please wait a moment.');
        }

        $conversation = $this->requireAccess((int) ($params['id'] ?? 0), $userId, false);
        if ($this->conversations->isArchived($conversation)) {
            $this->json(['ok' => false, 'error' => ['message' => 'This conversation is archived.']], 403);
        }

        $body = trim((string) $request->input('body', ''));
        if (mb_strlen($body, 'UTF-8') > ChatHelper::BODY_MAX) {
            $this->json(['ok' => false, 'error' => ['message' => 'Messages can be at most ' . ChatHelper::BODY_MAX . ' characters.']], 422);
        }

        $taskId = (int) $request->input('task_id', 0);
        $taskId = $taskId > 0 ? $this->validateTaskLink($taskId, $conversation) : null;

        $uploads = $this->collectUploads();
        if ($body === '' && $uploads === []) {
            $this->json(['ok' => false, 'error' => ['message' => 'Write a message or attach a file.']], 422);
        }
        if (count($uploads) > ChatHelper::FILES_PER_MESSAGE) {
            $this->json(['ok' => false, 'error' => ['message' => 'You can attach up to ' . ChatHelper::FILES_PER_MESSAGE . ' files per message.']], 422);
        }

        $stored = [];
        if ($uploads !== []) {
            if (ChatHelper::tooManyUploads($userId)) {
                throw new HttpException(429, 'You have uploaded too many files recently. Please wait and try again.');
            }
            foreach ($uploads as $file) {
                $check = ChatHelper::inspectUpload($file);
                if (!$check['ok']) {
                    $this->json(['ok' => false, 'error' => ['message' => $check['error']]], 422);
                }
                try {
                    $stored[] = ChatHelper::storeUpload($file, $check['ext'], $check['mime']);
                } catch (Throwable $e) {
                    LoggerHelper::exception($e);
                    $this->json(['ok' => false, 'error' => ['message' => 'The file could not be saved. Please try again.']], 500);
                }
            }
        }

        $members = $this->conversations->liveMembers($conversation);
        $parsed = ChatHelper::parseMentions($body, $members);
        $groupNote = null;
        $groupMention = false;
        $mentionIds = $parsed['user_ids'];

        if ($parsed['group']) {
            if (!ChatHelper::canUseGroupMentions()) {
                $groupNote = 'Group mentions (@all / @everyone / @team / @members) are not enabled for your role, so they were sent as plain text.';
            } elseif (ChatHelper::tooManyGroupMentions($userId) || RateLimitHelper::tooMany('chat.group_mention', $request->ip(), ChatHelper::GROUP_MENTION_LIMIT, ChatHelper::GROUP_MENTION_WINDOW_MINUTES)) {
                $groupNote = 'Group mentions are limited to ' . ChatHelper::GROUP_MENTION_LIMIT . ' per hour. Your message was sent without notifying everyone.';
                $individual = ChatHelper::parseMentions(
                    preg_replace('/@(all|everyone|team|members)\b/i', '', $body) ?? $body,
                    $members
                );
                $mentionIds = $individual['user_ids'];
                $groupMention = false;
            } else {
                $groupMention = true;
                $mentionIds = array_map(static fn (array $m): int => (int) $m['id'], $members);
            }
        }

        $mentionIds = array_values(array_unique(array_filter(
            array_map('intval', $mentionIds),
            static fn (int $id): bool => $id > 0 && $id !== $userId
        )));

        $isDm = (string) $conversation['type'] === Conversation::TYPE_DM;
        if ($isDm) {
            foreach ($members as $member) {
                $mid = (int) $member['id'];
                if ($mid !== $userId) {
                    $mentionIds[] = $mid;
                }
            }
            $mentionIds = array_values(array_unique($mentionIds));
        }

        $message = $this->messages->post(
            (int) $conversation['id'],
            $userId,
            $body,
            $stored,
            $mentionIds,
            $groupMention,
            $taskId
        );

        LoggerHelper::audit('chat.message_sent', 'chat', (int) $message['id'], [
            'conversation_id' => (int) $conversation['id'],
            'files'           => count($stored),
            'mentions'        => count($mentionIds),
        ]);

        $preview = $body !== '' ? mb_substr($body, 0, 120, 'UTF-8') : (count($stored) > 0 ? 'Sent a file' : 'New message');
        $actor = (string) (AuthHelper::user()['name'] ?? 'Someone');
        $link = '/chat?c=' . (int) $conversation['id'];
        foreach (array_unique($mentionIds) as $nid) {
            if ((int) $nid === $userId) {
                continue;
            }
            NotificationHelper::chatMention((int) $nid, $actor, $preview, $link, $isDm);
        }

        $this->conversations->markRead((int) $conversation['id'], $userId, (int) $message['id']);

        $payload = ['ok' => true, 'message' => $this->publicMessage($message)];
        if ($groupNote !== null) {
            $payload['notice'] = $groupNote;
        }
        $this->json($payload);
    }

    /** POST /chat/conversations/{id}/messages/{mid}/edit */
    public function edit(Request $request, array $params): void
    {
        $this->requireInstalledJson();
        $userId = (int) AuthHelper::id();
        $conversation = $this->requireAccess((int) ($params['id'] ?? 0), $userId, false);
        $messageId = (int) ($params['mid'] ?? 0);
        $row = $this->messages->find($messageId);
        if ($row === null || (int) $row['conversation_id'] !== (int) $conversation['id']) {
            $this->notFound();
        }
        if ((int) $row['user_id'] !== $userId) {
            $this->forbidden();
        }
        if ((string) ($row['deleted_at'] ?? '') !== '') {
            $this->json(['ok' => false, 'error' => ['message' => 'Deleted messages cannot be edited.']], 422);
        }
        $body = trim((string) $request->input('body', ''));
        if ($body === '' || mb_strlen($body, 'UTF-8') > ChatHelper::BODY_MAX) {
            $this->json(['ok' => false, 'error' => ['message' => 'Enter a message of at most ' . ChatHelper::BODY_MAX . ' characters.']], 422);
        }
        $this->messages->editBody($messageId, $userId, $body);
        $fresh = $this->messages->since((int) $conversation['id'], $messageId - 1, 1);
        $this->json(['ok' => true, 'message' => $this->publicMessage($fresh[0] ?? ['id' => $messageId, 'body' => $body, 'edited_at' => gmdate('Y-m-d H:i:s')])]);
    }

    /** POST /chat/conversations/{id}/messages/{mid}/delete */
    public function destroyMessage(Request $request, array $params): void
    {
        $this->requireInstalledJson();
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            $this->forbidden();
        }
        $userId = (int) AuthHelper::id();
        $conversation = $this->requireAccess((int) ($params['id'] ?? 0), $userId, true);
        $messageId = (int) ($params['mid'] ?? 0);
        $row = $this->messages->find($messageId);
        if ($row === null || (int) $row['conversation_id'] !== (int) $conversation['id']) {
            $this->notFound();
        }
        $this->messages->softDelete($messageId, $userId);
        $this->json(['ok' => true]);
    }

    /** GET /chat/files/{id} */
    public function file(Request $request, array $params): void
    {
        if (!Conversation::installed()) {
            throw new HttpException(404);
        }
        $userId = (int) AuthHelper::id();
        $attachment = $this->messages->findAttachment((int) ($params['id'] ?? 0));
        if ($attachment === null || (string) ($attachment['deleted_at'] ?? '') !== '') {
            throw new HttpException(404);
        }
        $conversation = $this->conversations->findAlive((int) $attachment['conversation_id']);
        if ($conversation === null) {
            throw new HttpException(404);
        }
        $adminPeek = false;
        if (!$this->conversations->userCanAccess($conversation, $userId, false)) {
            if ($this->conversations->userCanAccess($conversation, $userId, true)) {
                $adminPeek = true;
                LoggerHelper::logEvent('chat.admin_dm_access', LoggerHelper::MODULE_CHAT, (int) $conversation['id'], null, [
                    'admin_id' => $userId,
                    'file_id'  => (int) $attachment['id'],
                ]);
            } else {
                throw new HttpException(403);
            }
        }
        unset($adminPeek);

        $path = ChatHelper::absoluteFile((string) $attachment['stored_name']);
        if ($path === null) {
            throw new HttpException(404);
        }

        AuthHelper::releaseSession();

        $ext = strtolower((string) $attachment['extension']);
        $mime = (string) $attachment['mime'];
        $inline = in_array($ext, ChatHelper::INLINE_IMAGE_EXTENSIONS, true)
            && in_array(strtolower($mime), ChatHelper::PREVIEW_IMAGE_MIMES, true);
        $downloadName = str_replace(["\r", "\n", '"'], '', (string) $attachment['original_name']);
        $disposition = ($inline ? 'inline' : 'attachment') . '; filename="' . $downloadName . '"';

        header('X-Content-Type-Options: nosniff');
        header('Content-Type: ' . $mime);
        header('Content-Disposition: ' . $disposition);
        header('Content-Length: ' . (string) filesize($path));
        header('Cache-Control: private, no-store');
        readfile($path);
        exit;
    }

    /** POST /chat/dm */
    public function startDm(Request $request, array $params): void
    {
        $this->requireInstalledJson();
        $userId = (int) AuthHelper::id();
        $otherId = (int) $request->input('user_id', 0);
        if ($otherId < 1 || $otherId === $userId) {
            $this->json(['ok' => false, 'error' => ['message' => 'Choose a colleague to message.']], 422);
        }
        if (ClientScope::isClient($otherId) || !ChatHelper::shareTeamOrProject($userId, $otherId)) {
            $this->json(['ok' => false, 'error' => ['message' => 'You can only message people who share a team or project with you.']], 403);
        }
        $conversation = $this->conversations->findOrCreateDm($userId, $otherId);
        $this->json(['ok' => true, 'id' => (int) $conversation['id'], 'url' => FormatHelper::url('/chat?c=' . (int) $conversation['id'])]);
    }

    /** POST /chat/channels */
    public function storeChannel(Request $request, array $params): void
    {
        $this->requireInstalledJson();
        if (!ChatHelper::canCreateChannel()) {
            $this->forbidden();
        }
        $userId = (int) AuthHelper::id();
        $name = trim((string) $request->input('name', ''));
        if ($name === '' || mb_strlen($name, 'UTF-8') > ChatHelper::NAME_MAX) {
            $this->json(['ok' => false, 'error' => ['message' => 'Enter a channel name of at most ' . ChatHelper::NAME_MAX . ' characters.']], 422);
        }
        $memberIds = $this->intList($request->input('member_ids', []));
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            $allowed = array_map(static fn (array $p): int => (int) $p['id'], $this->conversations->dmCandidates($userId));
            $allowed[] = $userId;
            $memberIds = array_values(array_intersect($memberIds, $allowed));
        }
        $conversation = $this->conversations->createCustom($name, $userId, $memberIds);
        $this->json(['ok' => true, 'id' => (int) $conversation['id'], 'url' => FormatHelper::url('/chat?c=' . (int) $conversation['id'])]);
    }

    /** POST /chat/channels/{id}/archive */
    public function archive(Request $request, array $params): void
    {
        $this->requireAdminChannel((int) ($params['id'] ?? 0));
        $id = (int) ($params['id'] ?? 0);
        $this->conversations->archive($id, (int) AuthHelper::id());
        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }
        $this->flash('success', 'Channel archived.');
        $this->redirect('/chat');
    }

    /** POST /chat/channels/{id}/unarchive */
    public function unarchive(Request $request, array $params): void
    {
        $this->requireAdminChannel((int) ($params['id'] ?? 0));
        $this->conversations->unarchive((int) ($params['id'] ?? 0), (int) AuthHelper::id());
        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }
        $this->flash('success', 'Channel restored.');
        $this->redirect('/chat?c=' . (int) ($params['id'] ?? 0));
    }

    /** POST /chat/channels/{id}/delete */
    public function destroyChannel(Request $request, array $params): void
    {
        $this->requireAdminChannel((int) ($params['id'] ?? 0));
        $this->conversations->softDelete((int) ($params['id'] ?? 0), (int) AuthHelper::id());
        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }
        $this->flash('success', 'Channel deleted.');
        $this->redirect('/chat');
    }

    /** POST /chat/channels/{id}/members */
    public function updateMembers(Request $request, array $params): void
    {
        $conversation = $this->requireAdminChannel((int) ($params['id'] ?? 0));
        if ((string) $conversation['type'] !== Conversation::TYPE_CUSTOM) {
            $this->json(['ok' => false, 'error' => ['message' => 'Team and project channel members come from team or project membership.']], 422);
        }
        $memberIds = $this->intList($request->input('member_ids', []));
        if ($memberIds === []) {
            $this->json(['ok' => false, 'error' => ['message' => 'A channel needs at least one member.']], 422);
        }
        $this->conversations->replaceCustomMembers((int) $conversation['id'], $memberIds, (int) AuthHelper::id());
        $this->json(['ok' => true]);
    }

    /** POST /projects/{id}/chat */
    public function startProject(Request $request, array $params): void
    {
        if (!Conversation::installed()) {
            $this->flash('warning', 'Chat is not installed yet. Run the Phase 21 migration first.');
            $this->redirect('/projects/' . (int) ($params['id'] ?? 0));
        }
        $userId = (int) AuthHelper::id();
        $projectId = (int) ($params['id'] ?? 0);
        $project = Database::fetchOne('SELECT * FROM projects WHERE id = :id LIMIT 1', ['id' => $projectId]);
        if ($project === null) {
            $this->notFound();
        }
        FeatureFlagsHelper::requireProjects();
        PermissionHelper::require('projects.view');
        ClientScope::assertCanSeeProject($project);

        $fake = ['id' => 0, 'type' => Conversation::TYPE_PROJECT, 'project_id' => $projectId, 'deleted_at' => null];
        if (!$this->conversations->userCanAccess($fake, $userId, false)
            && !PermissionHelper::has('projects.view_all')
            && !AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            $this->forbidden();
        }
        $conversation = $this->conversations->ensureProjectChannel($projectId, $userId);
        $this->redirect('/chat?c=' . (int) $conversation['id']);
    }

    /** POST /chat/files/{id}/delete */
    public function destroyFile(Request $request, array $params): void
    {
        $this->requireInstalledJson();
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            $this->forbidden();
        }
        $attachment = $this->messages->findAttachment((int) ($params['id'] ?? 0));
        if ($attachment === null) {
            $this->notFound();
        }
        $this->requireAccess((int) $attachment['conversation_id'], (int) AuthHelper::id(), true);
        $this->messages->softDeleteAttachment((int) $attachment['id'], (int) AuthHelper::id());
        $this->json(['ok' => true]);
    }

    /* ------------------------------------------------------------------ helpers */

    private function requireInstalledJson(): void
    {
        if (!Conversation::installed()) {
            $this->json(['ok' => false, 'error' => ['message' => 'Chat is not installed yet.']], 503);
        }
    }

    /**
     * @return array{0: array<string, mixed>|null, 1: bool}
     */
    private function loadAccessible(int $id, int $userId, bool $allowAdminPeek): array
    {
        $conversation = $this->conversations->findAlive($id);
        if ($conversation === null) {
            return [null, false];
        }
        if ($this->conversations->userCanAccess($conversation, $userId, false)) {
            return [$conversation, false];
        }
        if ($allowAdminPeek && $this->conversations->userCanAccess($conversation, $userId, true)) {
            return [$conversation, true];
        }

        return [null, false];
    }

    /** @return array<string, mixed> */
    private function requireAccess(int $id, int $userId, bool $allowAdminPeek, bool $logPeek = true): array
    {
        [$conversation, $peek] = $this->loadAccessible($id, $userId, $allowAdminPeek);
        if ($conversation === null) {
            throw new HttpException(404);
        }
        if ($peek && $allowAdminPeek && $logPeek) {
            LoggerHelper::logEvent('chat.admin_dm_access', LoggerHelper::MODULE_CHAT, (int) $conversation['id'], null, [
                'admin_id' => $userId,
            ]);
        }

        return $conversation;
    }

    /** @return array<string, mixed> */
    private function requireAdminChannel(int $id): array
    {
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            $this->forbidden();
        }
        $conversation = $this->conversations->findAlive($id);
        if ($conversation === null) {
            $this->notFound();
        }

        return $conversation;
    }

    private function validateTaskLink(int $taskId, array $conversation): ?int
    {
        if ($taskId < 1 || !SchemaHelper::tableExists('tasks')) {
            return null;
        }
        $task = Database::fetchOne('SELECT id, project_id FROM tasks WHERE id = :id LIMIT 1', ['id' => $taskId]);
        if ($task === null) {
            return null;
        }
        $projectId = (int) ($conversation['project_id'] ?? 0);
        if ((string) $conversation['type'] === Conversation::TYPE_PROJECT && $projectId > 0) {
            return (int) $task['project_id'] === $projectId ? $taskId : null;
        }

        return $taskId;
    }

    /** @return list<array<string, mixed>> */
    private function collectUploads(): array
    {
        if (!isset($_FILES['files']) || !is_array($_FILES['files'])) {
            return [];
        }
        $bag = $_FILES['files'];
        if (!isset($bag['name']) || !is_array($bag['name'])) {
            $error = (int) ($bag['error'] ?? UPLOAD_ERR_NO_FILE);
            return $error === UPLOAD_ERR_NO_FILE ? [] : [$bag];
        }
        $out = [];
        foreach ($bag['name'] as $i => $name) {
            $out[] = [
                'name'     => (string) $name,
                'type'     => (string) ($bag['type'][$i] ?? ''),
                'tmp_name' => (string) ($bag['tmp_name'][$i] ?? ''),
                'error'    => (int) ($bag['error'][$i] ?? UPLOAD_ERR_NO_FILE),
                'size'     => (int) ($bag['size'][$i] ?? 0),
            ];
        }

        return array_values(array_filter($out, static fn (array $f): bool => (int) $f['error'] !== UPLOAD_ERR_NO_FILE));
    }

    /** @return list<array{id: int, name: string}> */
    private function createTaskProjects(): array
    {
        if (!SchemaHelper::tableExists('projects')) {
            return [];
        }
        $archived = SchemaHelper::columnExists('projects', 'status')
            ? " AND (p.status IS NULL OR p.status <> 'Archived')"
            : '';
        try {
            if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN) || PermissionHelper::has('projects.view_all')) {
                return Database::fetchAll(
                    "SELECT p.id, p.name FROM projects p WHERE 1 = 1{$archived} ORDER BY p.name ASC LIMIT 200"
                );
            }
            $userId = (int) AuthHelper::id();
            if (SchemaHelper::tableExists('project_members')) {
                return Database::fetchAll(
                    "SELECT p.id, p.name FROM projects p
                     INNER JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = :u
                     WHERE 1 = 1{$archived}
                     ORDER BY p.name ASC LIMIT 200",
                    ['u' => $userId]
                );
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat create-task projects failed', ['error' => $e->getMessage()]);
        }

        return [];
    }

    /**
     * @param mixed $value
     * @return list<int>
     */
    private function intList(mixed $value): array
    {
        if (!is_array($value)) {
            $value = $value === null || $value === '' ? [] : [$value];
        }
        $ids = [];
        foreach ($value as $item) {
            $id = (int) $item;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @param array<string, mixed> $message
     * @return array<string, mixed>
     */
    private function publicMessage(array $message): array
    {
        $created = (string) ($message['created_at'] ?? '');

        return [
            'id'          => (int) ($message['id'] ?? 0),
            'user_id'     => (int) ($message['user_id'] ?? 0),
            'user_name'   => (string) ($message['user_name'] ?? ''),
            'avatar_html' => UserAvatarHelper::html((string) ($message['avatar_path'] ?? ''), (string) ($message['user_name'] ?? ''), 'avatar avatar-sm'),
            'body'        => (string) ($message['body'] ?? ''),
            'body_html'   => $this->formatBody((string) ($message['body'] ?? ''), $message['mentions'] ?? []),
            'task_id'     => $message['task_id'] ?? null,
            'task_name'   => $message['task_name'] ?? null,
            'task_url'    => !empty($message['task_project_id'])
                ? FormatHelper::url('/projects/' . (int) $message['task_project_id'] . '?tab=tasks')
                : null,
            'edited'      => (string) ($message['edited_at'] ?? '') !== '',
            'deleted'     => !empty($message['deleted']),
            'created_at'  => $created,
            'created'     => $created !== '' ? FormatHelper::datetime($created, 'M j, H:i') : '',
            'attachments' => array_map(static function (array $a): array {
                $a['url'] = FormatHelper::url((string) $a['url']);

                return $a;
            }, $message['attachments'] ?? []),
        ];
    }

    /**
     * @param list<array<string, mixed>> $mentions
     */
    private function formatBody(string $body, array $mentions): string
    {
        unset($mentions);
        $escaped = e($body);
        $escaped = preg_replace(
            '/(^|\\s)@(all|everyone|team|members)\\b/i',
            '$1<span class="chat-mention">@$2</span>',
            $escaped
        ) ?? $escaped;
        $escaped = preg_replace(
            '/(^|\\s)@([A-Za-z0-9_]+)/',
            '$1<span class="chat-mention">@$2</span>',
            $escaped
        ) ?? $escaped;

        return nl2br($escaped, false);
    }
}
