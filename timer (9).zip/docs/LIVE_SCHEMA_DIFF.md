# Live schema diff

Maintained against `database/install.sql` (the release source of truth). The raw
live dump is **not** shipped in the release zip; keep it in `_dev/` when you need
to re-diff. Last reviewed: 2026-10-04 (MariaDB 11.8).

## Already present on live (do not treat as missing)

- `time_entries.auto_stopped` — present (migration `03_timer_auto_stopped.sql` is idempotent)
- `time_entries.status`, `approved_by`, `approved_at` — still present on live;
  dropped by `04_drop_entry_status.sql` after copying leftover Approved rows into the timesheet model
- `users.role` — present as a denormalized cache of `roles.name`; `role_id` is
  authoritative (`07_remove_role_schema_duplicates.sql` re-syncs the cache)
- `activity_logs.record_id` — dropped by `07_remove_role_schema_duplicates.sql`
  after backfilling `entity_id`; `audit_logs` view selects `entity_id` only
- `tasks.assigned_to` — copied into `task_assignees`, then dropped by
  `07_remove_role_schema_duplicates.sql`
- `agent_pair_attempts` — added by phase 16 / `install.sql`

## Missing on live vs install.sql (apply Phase 13)

- `time_entries` indexes `idx_time_entries_user_started`, `idx_time_entries_project_started` (`01_base.sql`)
- CHECK `chk_time_entries_ended_after_started` (`01_base.sql`)
- `users.must_change_password` (`02_must_change_password.sql`)
- `timesheets.uq_timesheets_user_period` — live has only `idx_timesheets_user_period`
  after the superseded 05 file dropped the unique key (`06_restore_timesheet_period_unique.sql`)
- `client_users` table (`08_client_users.sql`)
- `schedules.recurrence_parent_id` + index + FK (`09_schedule_recurrence_parent.sql`)
- `workspace_settings.scheduling_enabled = '1'` where missing (`10_enable_scheduling.sql`)
- `tasks.team_id`, `tasks.reviewed_by`, `tasks.reviewed_at`, `tasks.review_note` plus FKs (`UPGRADE_LIVE.sql` STEP 11)
- workspace settings `task_scope_mode`, `other_team_tasks_visibility`, `members_can_create_subtasks`, `task_review_required` (`UPGRADE_LIVE.sql` STEP 11)

## Live data notes for the data-fix scripts

- timesheets 1, 4, 5, 6 overlap user 1 period 2026-09-28..2026-10-04; sheet 3 is a
  Rejected 2026-10-01..2026-10-02 fragment. Preview then merge with
  `phase13/data_fixes/timesheets_1_and_3.*.sql` **before** `06_restore_timesheet_period_unique.sql`.
- `timesheet_entries` does not include time_entries 8 and 11 on a weekly sheet for user 1.
- Schedules 3-16 for user "Test" are multi-day recurrence corruption. Preview then
  clean with `phase13/data_fixes/schedule_bad_rows.*.sql`.

## Verify after applying Phase 13

```sql
SHOW INDEX FROM time_entries WHERE Key_name IN ('idx_time_entries_user_started','idx_time_entries_project_started');
SHOW COLUMNS FROM time_entries LIKE 'status';
SHOW COLUMNS FROM users LIKE 'must_change_password';
SHOW INDEX FROM timesheets WHERE Key_name = 'uq_timesheets_user_period';
SHOW TABLES LIKE 'client_users';
SHOW COLUMNS FROM schedules LIKE 'recurrence_parent_id';
```
