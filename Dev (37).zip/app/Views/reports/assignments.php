<?php
/**
 * Team report > Assignments (Clockify layout).
 *
 * @var array<int,array<string,mixed>> $users
 */
require APP_PATH . '/Views/reports/_header.php';
$hmsH = static fn(int $s): string => $hms($s) . 'h';
$status = static function (int $scheduled, int $tracked): string {
    if ($scheduled < 1) { return '<span class="rk-dash">-</span>'; }
    $pct = $tracked / $scheduled * 100;
    return '<div class="rk-status">' . e(number_format($pct, 2)) . '%</div><div class="rk-progress' . ($pct > 100 ? ' is-over' : '') . '"><span style="width:' . min(100, max(0, $pct)) . '%"></span></div>';
};
$other = $by === 'project' ? 'User' : 'Project';
?>
<div class="rk-groupby">
    <form method="get" action="<?= e(url('/reports/assignments')) ?>" class="d-flex align-items-center gap-2 m-0">
        <?php foreach (['from', 'to'] as $k): ?><input type="hidden" name="<?= $k ?>" value="<?= e($filters[$k]) ?>"><?php endforeach; ?>
        <?php foreach (['user_id', 'project_id'] as $k): if ((int) $filters[$k] > 0): ?><input type="hidden" name="<?= $k ?>" value="<?= (int) $filters[$k] ?>"><?php endif; endforeach; ?>
        <span class="rk-gl">Group by:</span>
        <select name="group" aria-label="Group by" data-autosubmit><option value="user"<?= $by === 'user' ? ' selected' : '' ?>>User</option><option value="project"<?= $by === 'project' ? ' selected' : '' ?>>Project</option></select>
        <span class="rk-static"><?= e($other) ?></span>
    </form>
    <span class="rk-sums"><span>Scheduled:<b><?= e($hms((int) $scheduledTotal)) ?></b></span><span>Tracked:<b><?= e($hms((int) $trackedTotal)) ?></b></span></span>
</div>
<div class="rk-box" style="border-top:0">
    <div class="rk-scroll">
    <table class="rk-table">
        <thead><tr><th class="rk-l"><span class="rk-chev" data-collapse-all title="Expand / collapse all"><i class="fa-solid fa-chevron-down"></i></span> &nbsp; Title <i class="fa-solid fa-sort"></i></th><th class="rk-r">Scheduled <i class="fa-solid fa-sort"></i></th><th class="rk-r">Tracked <i class="fa-solid fa-sort"></i></th><th class="rk-r">Difference <i class="fa-solid fa-sort"></i></th><th class="rk-l" style="min-width:12rem">Status <i class="fa-solid fa-sort"></i></th></tr></thead>
        <tbody>
        <?php if ($users === []): ?><tr><td colspan="5" class="rk-empty">Nothing is scheduled or tracked in this range.</td></tr><?php endif; ?>
        <?php foreach ($users as $uid => $u): $diff = (int) $u['scheduled'] - (int) $u['tracked']; ?>
            <tr<?= $u['projects'] !== [] ? ' class="rk-click" data-bs-toggle="collapse" data-bs-target=".rk-u' . (int) $uid . '" role="button"' : '' ?>>
                <td><span class="rk-num"><?= count($u['projects']) ?></span><span class="rk-dot" style="background:<?= e($u['color']) ?>"></span><?= e($u['name']) ?></td>
                <td class="rk-r"><?= e($hmsH((int) $u['scheduled'])) ?><span class="rk-sub">of <?= e($hmsH((int) $capacity)) ?></span></td>
                <td class="rk-r"><?= e($hmsH((int) $u['tracked'])) ?></td>
                <td class="rk-r"><?= e($hmsH($diff)) ?></td>
                <td><?= $status((int) $u['scheduled'], (int) $u['tracked']) ?></td>
            </tr>
            <?php foreach ($u['projects'] as $p): $pd = (int) $p['scheduled'] - (int) $p['tracked']; ?>
            <tr class="collapse rk-child rk-u<?= (int) $uid ?>">
                <td class="ps-5"><?= e($p['name']) ?></td>
                <td class="rk-r"><?= e($hmsH((int) $p['scheduled'])) ?></td>
                <td class="rk-r"><?= e($hmsH((int) $p['tracked'])) ?></td>
                <td class="rk-r"><?= e($hmsH($pd)) ?></td>
                <td><?= $status((int) $p['scheduled'], (int) $p['tracked']) ?></td>
            </tr>
            <?php endforeach; ?>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php if ($canViewAll && $by === 'user'): ?>
<div class="rk-more"><a href="<?= e($tabUrl('assignments', ['all' => $showAll ? '' : '1'])) ?>"><?= $showAll ? 'Hide users without time' : 'Show users without time' ?></a></div>
<?php endif; ?>
</div>
