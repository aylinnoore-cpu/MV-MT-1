# TimeTrack hierarchy, dashboard stats and workflow notifications

## Hierarchy

Admin > Project Manager > Department Manager > Team Manager > Team members

A department belongs to one project. It has one department manager and any number of
team managers. Each team manager has their own members.

Example:

```
ADMIN
└── Project Manager
    └── Department 1
        ├── Department Manager
        ├── Team Manager A
        │   ├── Member 1
        │   └── Member 2
        └── Team Manager B
            └── Member 3
```

A Team Manager is assigned on `teams.manager_id`. A Department Manager is assigned on
`departments.manager_id`. The same person may manage more than one team, but not as both
department manager and team manager in the same department.

## Dashboard stats (filtered date range)

Stats follow the person's place in the hierarchy, not their global role:

- Admin: everyone, with breakdowns by project, department, client and team
- Project manager: only projects they manage
- Department manager: only their departments and the teams inside them
- Team manager: only their teams
- Member: only their own time

The date picker on the dashboard still limits every view to the selected period.

## Workflow access and notifications

Workspace > Features controls who can open Approvals and who is notified on submission.
There is no automatic email to every manager in the chain.

Defaults:

- Access: team manager, department manager, project manager, admin
- In-app notice: all of those positions
- Email: team manager and admin only (department and project managers are skipped)

Change these switches to grant or revoke access, in-app notices or email per position.

Admins submitting their own time are routed only to other active admins who still have
access and notification enabled.

## Time locking

A submission creates a timesheet batch and links only the selected time entries. Existing
submitted/approved entries stay locked; new unsubmitted entries in the same week/month remain
recordable. This allows one task to remain active across multiple weeks with many time chunks.
