<?php
/**
 * Client directory. List, create, edit, delete with CSRF and validation.
 *
 * Employees cannot see this module (clients.view is admin/manager only).
 */

declare(strict_types=1);

final class ClientController extends Controller
{
    private Client $clients;

    public function __construct()
    {
        parent::__construct(true);
        $this->clients = new Client();
    }

    /** GET /clients */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('clients.view');

        $status = (string) $request->input('status', '');
        $status = in_array($status, Client::STATUSES, true) ? $status : null;
        $search = (string) $request->input('q', '');
        $page   = (int) $request->input('page', 1);

        $result = $this->clients->listFiltered($page, 20, $status, $search);

        $this->view('clients/index', [
            'pageTitle' => 'Clients',
            'result'    => $result,
            'status'    => $status ?? '',
            'search'    => $search,
            'canCreate' => PermissionHelper::has('clients.create'),
            'canEdit'   => PermissionHelper::has('clients.edit'),
            'canDelete' => PermissionHelper::has('clients.delete'),
        ]);
    }

    /** POST /clients */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('clients.create');

        $data = $this->validatedClient('/clients');
        $id   = $this->clients->create($data);

        LoggerHelper::audit('client.created', 'client', $id, ['name' => $data['name']]);
        $this->flash('success', 'Client "' . $data['name'] . '" was added.');
        $this->redirect('/clients');
    }

    /** POST /clients/{id} */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('clients.edit');

        $id     = (int) ($params['id'] ?? 0);
        $client = $this->clients->find($id);
        if ($client === null) {
            $this->notFound();
        }

        $data = $this->validatedClient('/clients');
        $this->clients->update($id, $data);

        LoggerHelper::audit('client.updated', 'client', $id, ['name' => $data['name']]);
        $this->flash('success', 'Client "' . $data['name'] . '" was updated.');
        $this->redirect('/clients');
    }

    /** POST /clients/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        PermissionHelper::require('clients.delete');

        $id     = (int) ($params['id'] ?? 0);
        $client = $this->clients->find($id);
        if ($client === null) {
            $this->notFound();
        }

        $count = $this->clients->projectCount($id);
        if ($count > 0) {
            $this->flash('danger', 'Cannot delete "' . $client['name'] . '": ' . $count . ' project' . ($count === 1 ? '' : 's') . ' still belong to this client.');
            $this->redirect('/clients');
        }

        $this->clients->delete($id);
        LoggerHelper::audit('client.deleted', 'client', $id, ['name' => $client['name']]);
        $this->flash('success', 'Client "' . $client['name'] . '" was deleted.');
        $this->redirect('/clients');
    }

    /** @return array<string, mixed> */
    private function validatedClient(string $failPath): array
    {
        $data = $this->validate([
            'name'    => 'required|string|max:160',
            'email'   => 'nullable|email|max:190',
            'phone'   => 'nullable|string|max:30',
            'company' => 'nullable|string|max:160',
            'address' => 'nullable|string|max:255',
            'status'  => 'required|in:active,inactive',
        ], $failPath, [
            'name'    => 'Name',
            'email'   => 'Email',
            'phone'   => 'Phone',
            'company' => 'Company',
            'address' => 'Address',
            'status'  => 'Status',
        ]);

        $data['status'] = in_array((string) $data['status'], Client::STATUSES, true)
            ? (string) $data['status']
            : Client::STATUS_ACTIVE;

        return $data;
    }
}
