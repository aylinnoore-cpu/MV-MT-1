/*
 * Planned schedule calendar, conflict prompts, drag-and-drop.
 * CSP forbids inline scripts: every interaction is wired here.
 */
(function () {
    'use strict';

    var root = document.getElementById('scheduleCalendar');
    if (!root) { return; }

    var cfg = {
        view: root.getAttribute('data-view') || 'week',
        // 'all' = everyone (team viewers only), otherwise a user id. Empty lets the server default to "me".
        userId: root.getAttribute('data-user-id') || '',
        eventsUrl: root.getAttribute('data-events-url') || '',
        storeUrl: root.getAttribute('data-store-url') || '',
        tasksUrl: root.getAttribute('data-tasks-url') || '',
        assigneesUrl: root.getAttribute('data-assignees-url') || '',
        timezone: root.getAttribute('data-timezone') || 'UTC',
        canCreate: root.getAttribute('data-can-create') === '1',
        canEdit: root.getAttribute('data-can-edit') === '1',
        canDelete: root.getAttribute('data-can-delete') === '1',
        hasTasks: root.getAttribute('data-has-tasks') === '1'
    };

    var cursor = startOfView(new Date(), cfg.view);
    var events = [];
    var pendingPayload = null;
    var dragState = null;

    var form = document.getElementById('scheduleForm');
    var modalEl = document.getElementById('scheduleModal');
    var conflictEl = document.getElementById('conflictModal');
    var modal = modalEl && window.bootstrap ? window.bootstrap.Modal.getOrCreateInstance(modalEl) : null;
    var conflictModal = conflictEl && window.bootstrap ? window.bootstrap.Modal.getOrCreateInstance(conflictEl) : null;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSchedule);
    } else {
        initSchedule();
    }

    function initSchedule() {
        bindChrome();
        document.addEventListener('mousemove', onDragMove);
        document.addEventListener('mouseup', onDragEnd);
        if (!root.hasAttribute('hidden')) {
            render();
            loadEvents();
        }
        openPrefilled();
    }

    /** Task page "Schedule" button: open the Plan work modal with project and task chosen. */
    function openPrefilled() {
        var projectId = parseInt(root.getAttribute('data-prefill-project') || '0', 10) || 0;
        var taskId = parseInt(root.getAttribute('data-prefill-task') || '0', 10) || 0;
        if (!projectId || !cfg.canCreate) { return; }
        openForm(null, roundToHalf(new Date()));
        setValue('schedule_project_id', String(projectId));
        loadTasks(projectId, taskId || '');
        loadAssignees(projectId);
    }

    function bindChrome() {
        document.querySelectorAll('.cal-view-btn').forEach(function (btn) {
            btn.addEventListener('click', function () {
                cfg.view = btn.getAttribute('data-cal-view') || 'week';
                document.querySelectorAll('.cal-view-btn').forEach(function (b) { b.classList.toggle('active', b === btn); });
                cursor = startOfView(cursor, cfg.view);
                render();
                loadEvents();
            });
        });

        var prev = document.getElementById('calPrev');
        var next = document.getElementById('calNext');
        var today = document.getElementById('calToday');
        if (prev) { prev.addEventListener('click', function () { cursor = shift(cursor, cfg.view, -1); render(); loadEvents(); }); }
        if (next) { next.addEventListener('click', function () { cursor = shift(cursor, cfg.view, 1); render(); loadEvents(); }); }
        if (today) { today.addEventListener('click', function () { cursor = startOfView(new Date(), cfg.view); render(); loadEvents(); }); }

        var filter = document.getElementById('calUserFilter');
        if (filter) {
            filter.addEventListener('change', function () {
                cfg.userId = filter.value === 'all' ? 'all' : String(parseInt(filter.value, 10) || '');
                loadEvents();
            });
        }

        var newBtn = document.getElementById('scheduleNewBtn');
        if (newBtn) {
            newBtn.addEventListener('click', function () { openForm(null, roundToHalf(new Date())); });
        }

        var rec = document.getElementById('schedule_recurrence');
        var daysWrap = document.getElementById('scheduleDaysWrap');
        if (rec && daysWrap) {
            rec.addEventListener('change', function () {
                daysWrap.hidden = rec.value !== 'custom' && rec.value !== 'weekly';
            });
        }

        var projectSel = document.getElementById('schedule_project_id');
        if (projectSel) {
            projectSel.addEventListener('change', function () {
                loadTasks(projectSel.value);
                loadAssignees(projectSel.value);
            });
        }

        var startInp = document.getElementById('schedule_start');
        var endInp = document.getElementById('schedule_end');
        var hoursInp = document.getElementById('schedule_hours');
        function syncHours() {
            if (!startInp || !endInp || !hoursInp || !startInp.value || !endInp.value) { return; }
            var a = new Date(startInp.value);
            var b = new Date(endInp.value);
            if (isNaN(a) || isNaN(b) || b <= a) { return; }
            hoursInp.value = ((b.getTime() - a.getTime()) / 3600000).toFixed(2);
        }
        if (startInp) { startInp.addEventListener('change', syncHours); }
        if (endInp) { endInp.addEventListener('change', syncHours); }

        if (form) {
            form.addEventListener('submit', function (event) {
                event.preventDefault();
                submitForm(false);
            });
        }

        var overrideBtn = document.getElementById('conflictOverrideBtn');
        if (overrideBtn) {
            overrideBtn.addEventListener('click', function () {
                if (conflictModal) { conflictModal.hide(); }
                if (pendingPayload) {
                    pendingPayload.body.override_conflict = 1;
                    postJson(pendingPayload.url, pendingPayload.body).then(handleSaveResponse);
                    return;
                }
                submitForm(true);
            });
        }

        var deleteBtn = document.getElementById('scheduleDeleteBtn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function () {
                var id = document.getElementById('scheduleId').value;
                if (!id || !window.confirm('Cancel this planned block?')) { return; }
                postJson(cfg.storeUrl.replace(/\/$/, '') + '/' + id + '/delete', {}).then(function () {
                    if (modal) { modal.hide(); }
                    loadEvents();
                    window.location.reload();
                });
            });
        }
    }

    function range() {
        var start = startOfView(cursor, cfg.view);
        var end;
        if (cfg.view === 'month') {
            end = new Date(start);
            end.setMonth(end.getMonth() + 1);
        } else if (cfg.view === 'day') {
            end = new Date(start);
            end.setDate(end.getDate() + 1);
        } else {
            end = new Date(start);
            end.setDate(end.getDate() + 7);
        }
        return { start: start, end: end };
    }

    function loadEvents() {
        if (root.hasAttribute('hidden') || !cfg.eventsUrl) { return; }
        var r = range();
        var url = cfg.eventsUrl + '?start=' + encodeURIComponent(toLocalInput(r.start)) + '&end=' + encodeURIComponent(toLocalInput(r.end));
        if (cfg.userId) { url += '&user_id=' + encodeURIComponent(cfg.userId); }

        fetch(url, { headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                events = (data && data.events) ? data.events : [];
                render();
            })
            .catch(function () { events = []; render(); });
    }

    function render() {
        if (root.hasAttribute('hidden')) { return; }
        var title = document.getElementById('calTitle');
        if (title) { title.textContent = titleFor(cursor, cfg.view); }
        root.innerHTML = '';
        if (cfg.view === 'month') {
            renderMonth();
        } else {
            renderTimeGrid(cfg.view === 'day' ? 1 : 7);
        }
    }

    function renderMonth() {
        var start = startOfView(cursor, 'month');
        var grid = document.createElement('div');
        grid.className = 'cal-month';
        ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].forEach(function (d) {
            var h = document.createElement('div');
            h.className = 'cal-dow';
            h.textContent = d;
            grid.appendChild(h);
        });

        var first = new Date(start);
        var pad = (first.getDay() + 6) % 7;
        var cellDate = new Date(first);
        cellDate.setDate(cellDate.getDate() - pad);
        var todayKey = ymd(new Date());

        for (var i = 0; i < 42; i++) {
            var cell = document.createElement('button');
            cell.type = 'button';
            cell.className = 'cal-cell';
            if (ymd(cellDate) === todayKey) { cell.classList.add('is-today'); }
            if (cellDate.getMonth() !== start.getMonth()) { cell.classList.add('is-muted'); }
            cell.setAttribute('data-date', ymd(cellDate));
            var num = document.createElement('span');
            num.className = 'cal-cell-num';
            num.textContent = String(cellDate.getDate());
            cell.appendChild(num);

            var dayEvents = eventsOnDay(cellDate);
            dayEvents.slice(0, 3).forEach(function (ev) {
                var chip = document.createElement('span');
                chip.className = 'cal-chip';
                chip.style.background = ev.color || '#12426f';
                chip.textContent = ev.title;
                cell.appendChild(chip);
            });
            if (dayEvents.length > 3) {
                var more = document.createElement('span');
                more.className = 'cal-more';
                more.textContent = '+' + (dayEvents.length - 3);
                cell.appendChild(more);
            }

            cell.addEventListener('click', onMonthCellClick);
            grid.appendChild(cell);
            cellDate = addDays(cellDate, 1);
        }

        root.appendChild(grid);
    }

    function renderTimeGrid(dayCount) {
        var start = startOfView(cursor, dayCount === 1 ? 'day' : 'week');
        var wrap = document.createElement('div');
        wrap.className = 'cal-week';

        var gutter = document.createElement('div');
        gutter.className = 'cal-gutter';
        gutter.appendChild(document.createElement('div'));
        for (var h = 0; h < 24; h++) {
            var lab = document.createElement('div');
            lab.className = 'cal-hour-label';
            lab.textContent = (h < 10 ? '0' : '') + h + ':00';
            gutter.appendChild(lab);
        }
        wrap.appendChild(gutter);

        var todayKey = ymd(new Date());
        for (var d = 0; d < dayCount; d++) {
            var day = addDays(start, d);
            var col = document.createElement('div');
            col.className = 'cal-day';
            if (ymd(day) === todayKey) { col.classList.add('is-today'); }

            var head = document.createElement('div');
            head.className = 'cal-day-head';
            head.textContent = weekday(day) + ' ' + day.getDate();
            col.appendChild(head);

            var body = document.createElement('div');
            body.className = 'cal-day-body';
            body.setAttribute('data-date', ymd(day));
            for (var hour = 0; hour < 24; hour++) {
                var slot = document.createElement('div');
                slot.className = 'cal-slot';
                slot.setAttribute('data-hour', String(hour));
                body.appendChild(slot);
            }

            eventsOnDay(day).forEach(function (ev) { body.appendChild(eventEl(ev, day)); });
            body.addEventListener('click', onGridClick);
            col.appendChild(body);
            wrap.appendChild(col);
        }

        root.appendChild(wrap);
        bindEventDrag();
    }

    function eventEl(ev, day) {
        var el = document.createElement('button');
        el.type = 'button';
        el.className = 'cal-event';
        el.style.background = ev.color || '#12426f';
        el.setAttribute('data-id', String(ev.id));
        el.setAttribute('data-editable', ev.editable ? '1' : '0');

        var start = parseIso(ev.start);
        var end = parseIso(ev.end);
        var dayStart = new Date(day.getFullYear(), day.getMonth(), day.getDate());
        var dayEnd = addDays(dayStart, 1);
        var visStart = start < dayStart ? dayStart : start;
        var visEnd = end > dayEnd ? dayEnd : end;
        var top = ((visStart.getHours() * 60 + visStart.getMinutes()) / (24 * 60)) * 100;
        var height = Math.max(3, ((visEnd - visStart) / 86400000) * 100);
        el.style.top = top + '%';
        el.style.height = height + '%';

        var time = document.createElement('span');
        time.className = 'cal-event-time';
        time.textContent = pad(start.getHours()) + ':' + pad(start.getMinutes());
        var name = document.createElement('span');
        name.className = 'cal-event-title';
        name.textContent = ev.title;
        el.appendChild(time);
        el.appendChild(name);

        if (ev.editable && cfg.canEdit) {
            var handle = document.createElement('span');
            handle.className = 'cal-resize';
            handle.setAttribute('data-resize', '1');
            el.appendChild(handle);
        }

        el.addEventListener('click', function (event) {
            event.stopPropagation();
            openForm(ev);
        });

        return el;
    }

    function bindEventDrag() {
        root.querySelectorAll('.cal-event[data-editable="1"]').forEach(function (el) {
            el.addEventListener('mousedown', function (event) {
                if (event.button !== 0) { return; }
                event.preventDefault();
                var id = parseInt(el.getAttribute('data-id'), 10);
                var ev = events.find(function (item) { return item.id === id; });
                if (!ev) { return; }
                var body = el.closest('.cal-day-body');
                if (!body) { return; }
                dragState = {
                    id: id,
                    event: ev,
                    el: el,
                    body: body,
                    resize: event.target && event.target.getAttribute('data-resize') === '1',
                    startY: event.clientY,
                    originStart: parseIso(ev.start),
                    originEnd: parseIso(ev.end),
                    height: body.clientHeight || 1
                };
            });
        });
    }

    function onDragMove(event) {
        if (!dragState) { return; }
        var minutes = Math.round(((event.clientY - dragState.startY) / dragState.height) * 24 * 60 / 15) * 15;
        var start = new Date(dragState.originStart.getTime());
        var end = new Date(dragState.originEnd.getTime());
        if (dragState.resize) {
            end = new Date(end.getTime() + minutes * 60000);
            if (end - start < 15 * 60000) { end = new Date(start.getTime() + 15 * 60000); }
        } else {
            start = new Date(start.getTime() + minutes * 60000);
            end = new Date(end.getTime() + minutes * 60000);
        }
        dragState.nextStart = start;
        dragState.nextEnd = end;

        var day = parseYmd(dragState.body.getAttribute('data-date'));
        var dayStart = new Date(day.getFullYear(), day.getMonth(), day.getDate());
        var visStart = start < dayStart ? dayStart : start;
        var visEnd = end;
        var top = ((visStart.getHours() * 60 + visStart.getMinutes()) / (24 * 60)) * 100;
        var height = Math.max(3, ((visEnd - visStart) / 86400000) * 100);
        dragState.el.style.top = top + '%';
        dragState.el.style.height = height + '%';
    }

    function onDragEnd() {
        if (!dragState) { return; }
        var state = dragState;
        dragState = null;
        if (!state.nextStart || !state.nextEnd) { return; }
        if (state.nextStart.getTime() === state.originStart.getTime() && state.nextEnd.getTime() === state.originEnd.getTime()) {
            return;
        }
        pendingPayload = {
            url: cfg.storeUrl.replace(/\/$/, '') + '/' + state.id + '/time',
            body: {
                start_datetime: toLocalInput(state.nextStart),
                end_datetime: toLocalInput(state.nextEnd),
                override_conflict: 0
            }
        };
        postJson(pendingPayload.url, pendingPayload.body).then(handleSaveResponse);
    }

    function onMonthCellClick(event) {
        var btn = event.currentTarget;
        var date = parseYmd(btn.getAttribute('data-date'));
        var dayEvents = eventsOnDay(date);
        if (dayEvents.length === 1) {
            openForm(dayEvents[0]);
            return;
        }
        if (cfg.canCreate) {
            var start = new Date(date);
            start.setHours(9, 0, 0, 0);
            openForm(null, start);
        }
    }

    function onGridClick(event) {
        if (!cfg.canCreate) { return; }
        var body = event.currentTarget;
        var rect = body.getBoundingClientRect();
        var y = event.clientY - rect.top;
        var minutes = Math.round((y / rect.height) * 24 * 60 / 30) * 30;
        minutes = Math.max(0, Math.min(23 * 60 + 30, minutes));
        var date = parseYmd(body.getAttribute('data-date'));
        date.setHours(Math.floor(minutes / 60), minutes % 60, 0, 0);
        openForm(null, date);
    }

    function openForm(ev, startDate) {
        if (!form || !modal) { return; }
        form.reset();
        document.getElementById('scheduleOverride').value = '0';
        var idField = document.getElementById('scheduleId');
        var title = document.getElementById('scheduleModalTitle');
        var deleteBtn = document.getElementById('scheduleDeleteBtn');
        var userSel = document.getElementById('schedule_user_id');
        var defaultUser = userSel ? userSel.getAttribute('data-default-user') : '';

        if (ev) {
            if (title) { title.textContent = 'Edit planned work'; }
            idField.value = String(ev.id);
            form.setAttribute('action', cfg.storeUrl.replace(/\/$/, '') + '/' + ev.id);
            setValue('schedule_project_id', String(ev.project_id));
            setValue('schedule_task_id', ev.task_id ? String(ev.task_id) : '');
            setValue('schedule_user_id', String(ev.user_id));
            setValue('schedule_status', ev.status || 'Scheduled');
            setValue('schedule_start', toLocalInput(parseIso(ev.start)));
            setValue('schedule_end', toLocalInput(parseIso(ev.end)));
            setValue('schedule_hours', String(ev.estimated_hours || ''));
            setValue('schedule_notes', ev.notes || '');
            if (deleteBtn) { deleteBtn.hidden = !cfg.canDelete; }
            loadTasks(ev.project_id, ev.task_id);
            loadAssignees(ev.project_id, ev.user_id);
        } else {
            if (title) { title.textContent = 'Plan work'; }
            idField.value = '';
            form.setAttribute('action', cfg.storeUrl);
            var start = startDate || roundToHalf(new Date());
            var end = new Date(start.getTime() + 60 * 60 * 1000);
            setValue('schedule_status', 'Scheduled');
            setValue('schedule_start', toLocalInput(start));
            setValue('schedule_end', toLocalInput(end));
            setValue('schedule_hours', '1');
            if (defaultUser) { setValue('schedule_user_id', defaultUser); }
            if (deleteBtn) { deleteBtn.hidden = true; }
        }

        var rec = document.getElementById('schedule_recurrence');
        var daysWrap = document.getElementById('scheduleDaysWrap');
        if (rec) { rec.value = 'none'; }
        if (daysWrap) { daysWrap.hidden = true; }

        modal.show();
    }

    function submitForm(override) {
        if (!form) { return; }
        document.getElementById('scheduleOverride').value = override ? '1' : '0';
        var data = new FormData(form);
        var body = {};
        data.forEach(function (value, key) {
            if (key.slice(-2) === '[]') {
                var k = key.slice(0, -2);
                if (!Array.isArray(body[k])) { body[k] = []; }
                body[k].push(value);
            } else if (Object.prototype.hasOwnProperty.call(body, key)) {
                if (!Array.isArray(body[key])) { body[key] = [body[key]]; }
                body[key].push(value);
            } else {
                body[key] = value;
            }
        });
        if (Array.isArray(body.days_of_week)) {
            body.days_of_week = body.days_of_week;
        }

        var action = form.getAttribute('action') || cfg.storeUrl;
        pendingPayload = { url: action, body: body };
        if (override) { body.override_conflict = 1; }
        postJson(action, body).then(handleSaveResponse);
    }

    function handleSaveResponse(data) {
        if (!data) { return; }
        if (data.ok) {
            if (modal) { modal.hide(); }
            if (root.hasAttribute('hidden')) {
                window.location.reload();
                return;
            }
            loadEvents();
            return;
        }
        if (data.conflict && data.conflicts) {
            showConflicts(data.conflicts);
            return;
        }
        if (data.errors) {
            var first = data.errors[Object.keys(data.errors)[0]];
            window.alert(first || 'Please check the form.');
        }
    }

    function showConflicts(list) {
        var ul = document.getElementById('conflictList');
        if (ul) {
            ul.innerHTML = '';
            list.forEach(function (item) {
                var li = document.createElement('li');
                li.textContent = (item.task_name || 'No task') + ' · ' + item.project_name + ' · ' + item.time_range;
                ul.appendChild(li);
            });
        }
        if (conflictModal) { conflictModal.show(); }
    }

    function loadTasks(projectId, selected) {
        var sel = document.getElementById('schedule_task_id');
        if (!sel || !cfg.hasTasks || !projectId) { return; }
        fetch(cfg.tasksUrl + '?project_id=' + encodeURIComponent(projectId), {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (res) { return res.json(); }).then(function (data) {
            sel.innerHTML = '<option value="">No task</option>';
            (data.tasks || []).forEach(function (task) {
                var opt = document.createElement('option');
                opt.value = String(task.id);
                opt.textContent = task.name;
                if (String(selected) === String(task.id)) { opt.selected = true; }
                sel.appendChild(opt);
            });
        }).catch(function () {});
    }

    function loadAssignees(projectId, selected) {
        var sel = document.getElementById('schedule_user_id');
        if (!sel || !cfg.assigneesUrl || !projectId) { return; }
        if (sel.options.length <= 1 && !cfg.canCreate) { return; }
        fetch(cfg.assigneesUrl + '?project_id=' + encodeURIComponent(projectId), {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (res) { return res.json(); }).then(function (data) {
            if (!data.users || !data.users.length) { return; }
            var current = selected || sel.value;
            if (sel.options.length > 1) {
                sel.innerHTML = '<option value="">Select a person</option>';
                data.users.forEach(function (user) {
                    var opt = document.createElement('option');
                    opt.value = String(user.id);
                    opt.textContent = user.name;
                    if (String(current) === String(user.id)) { opt.selected = true; }
                    sel.appendChild(opt);
                });
            }
        }).catch(function () {});
    }

    function postJson(url, body) {
        return fetch(url, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(body)
        }).then(function (res) { return res.json().catch(function () { return { ok: false }; }); });
    }

    function eventsOnDay(date) {
        var dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        var dayEnd = addDays(dayStart, 1);
        return events.filter(function (ev) {
            return parseIso(ev.start) < dayEnd && parseIso(ev.end) > dayStart;
        });
    }

    function startOfView(date, view) {
        var d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        if (view === 'month') {
            return new Date(d.getFullYear(), d.getMonth(), 1);
        }
        if (view === 'day') { return d; }
        var pad = (d.getDay() + 6) % 7;
        d.setDate(d.getDate() - pad);
        return d;
    }

    function shift(date, view, dir) {
        var d = new Date(date);
        if (view === 'month') { d.setMonth(d.getMonth() + dir); }
        else if (view === 'day') { d.setDate(d.getDate() + dir); }
        else { d.setDate(d.getDate() + (7 * dir)); }
        return startOfView(d, view);
    }

    function titleFor(date, view) {
        var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        if (view === 'month') { return months[date.getMonth()] + ' ' + date.getFullYear(); }
        if (view === 'day') { return weekday(date) + ', ' + months[date.getMonth()] + ' ' + date.getDate(); }
        var end = addDays(date, 6);
        return months[date.getMonth()] + ' ' + date.getDate() + ' – ' + months[end.getMonth()] + ' ' + end.getDate();
    }

    function weekday(date) {
        return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][date.getDay()];
    }

    function ymd(date) {
        return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate());
    }

    function parseYmd(value) {
        var p = String(value || '').split('-');
        return new Date(parseInt(p[0], 10), parseInt(p[1], 10) - 1, parseInt(p[2], 10));
    }

    function addDays(date, n) {
        var d = new Date(date);
        d.setDate(d.getDate() + n);
        return d;
    }

    function parseIso(value) {
        var d = new Date(value);
        return isNaN(d) ? new Date() : d;
    }

    function toLocalInput(date) {
        return ymd(date) + 'T' + pad(date.getHours()) + ':' + pad(date.getMinutes());
    }

    function roundToHalf(date) {
        var d = new Date(date);
        var m = d.getMinutes() < 30 ? 0 : 30;
        d.setMinutes(m, 0, 0);
        return d;
    }

    function pad(n) { return n < 10 ? '0' + n : String(n); }

    function setValue(id, value) {
        var el = document.getElementById(id);
        if (el) { el.value = value; }
    }
})();
