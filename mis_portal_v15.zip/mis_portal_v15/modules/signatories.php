<?php require __DIR__.'/../includes/lib.php';allow(['ed']);
if($_SERVER['REQUEST_METHOD']=='POST'){chk();
 if(isset($_POST['revoke'])){q('UPDATE signatories SET active=0 WHERE id=?',[(int)$_POST['revoke']]);logit('Revoked signing authority #'.(int)$_POST['revoke']);}
 elseif(isset(slots()[$_POST['slot']])){$r=store($_FILES['sig'],['png','jpg','jpeg'],1000000);
  if(!$r)$_SESSION['err']='Signature must be a PNG/JPG up to 1MB.';
  else{$d=adddoc('signature',0,$_FILES['sig']['name'],$r[0],$r[1]);
   q('INSERT INTO signatories(user_id,slot,doc_id,created_by)VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE doc_id=VALUES(doc_id),active=1',[(int)$_POST['user'],$_POST['slot'],$d,me()['id']]);logit('Authorized signatory (user #'.(int)$_POST['user'].', '.$_POST['slot'].')');}}
 header('Location: signatories.php');exit;}
head('Authorized Signatures');if(!empty($_SESSION['err'])){echo '<p class=err>'.h($_SESSION['err']).'</p>';unset($_SESSION['err']);}
echo '<div class=card><form method=post enctype=multipart/form-data><input type=hidden name=c value="'.csrf().'"><label>Person</label><select name=user>';
foreach(q('SELECT id,name,role FROM users WHERE status="active" ORDER BY name') as $u)echo "<option value=$u[id]>".h($u['name']).' ('.$u['role'].')</option>';
echo '</select><label>Signs for</label><select name=slot>';foreach(slots() as $k=>$v)echo "<option value=$k>".h($v).'</option>';
echo '</select><label>Signature image (PNG with transparent background is best)</label><input type=file name=sig accept=image/png,image/jpeg required><p><button>Authorize / replace signature</button></p></form></div>
<div class=card><table><tr><th>Person<th>Signs for<th>Signature<th>Status<th>';
foreach(q('SELECT a.*,u.name FROM signatories a JOIN users u ON u.id=a.user_id ORDER BY a.id DESC') as $a)
 echo '<tr><td>'.h($a['name']).'<td>'.h(slots()[$a['slot']]).'<td><img src="file.php?id='.$a['doc_id'].'" style="height:40px"><td>'.($a['active']?'Authorized':'Revoked').'<td>'
 .($a['active']?'<form method=post style=display:inline><input type=hidden name=c value="'.csrf().'"><button name=revoke value='.$a['id'].' class="btn r" style="padding:2px 8px">Revoke</button></form>':'');
echo '</table></div>';foot();
