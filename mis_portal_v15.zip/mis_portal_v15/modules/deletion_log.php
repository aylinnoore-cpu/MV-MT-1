<?php require __DIR__.'/../includes/lib.php';allow(['support','ed']);
$E=['Asset','Vendor','Vendor document','Quotation','Logo','Document signatures'];$ent=in_array($_GET['entity']??'',$E)?$_GET['entity']:'';$q=trim($_GET['q']??'');$f=$_GET['from']??'';$t=$_GET['to']??'';
$w=['1'];$p=[];$lw=['1'];$lp=[];
if($ent!==''){$w[]='entity=?';$p[]=$ent;}if($q!==''){$w[]='(label LIKE ? OR reason LIKE ? OR deleted_by_name LIKE ? OR entity LIKE ?)';$lw[]='(asset_tag LIKE ? OR name LIKE ? OR reason LIKE ? OR deleted_by_name LIKE ?)';for($i=0;$i<4;$i++){$p[]="%$q%";$lp[]="%$q%";}}
if($f!==''){$w[]='deleted_at>=?';$lw[]='deleted_at>=?';$p[]=$lp[]=$f.' 00:00:00';}if($t!==''){$w[]='deleted_at<=?';$lw[]='deleted_at<=?';$p[]=$lp[]=$t.' 23:59:59';}
$rows=q('SELECT *,0 legacy FROM deletion_log WHERE '.implode(' AND ',$w).' ORDER BY id DESC LIMIT 500',$p)->fetchAll();
if($ent===''||$ent=='Asset')$rows=array_merge($rows,q('SELECT id,"Asset" entity,asset_id entity_id,CONCAT(asset_tag," - ",name) label,snapshot,reason,deleted_by_name,client_ip,deleted_at,NULL row_hash,1 legacy FROM asset_deletions WHERE '.implode(' AND ',$lw).' ORDER BY id DESC LIMIT 500',$lp)->fetchAll());
usort($rows,fn($a,$b)=>strcmp($b['deleted_at'],$a['deleted_at']));$rows=array_slice($rows,0,500);
if(isset($_GET['csv'])){header('Content-Type:text/csv');header('Content-Disposition:attachment;filename=deletion_log.csv');$o=fopen('php://output','w');csvput($o,['Deleted at','Type','Item','Deleted by','From IP','Reason','Entry hash']);
 foreach($rows as $x)csvput($o,[$x['deleted_at'],$x['entity'],$x['label'],$x['deleted_by_name'],$x['client_ip'],$x['reason'],$x['row_hash']]);exit;}
head('Deletion Log','Permanent record of everything deleted from the portal. Entries cannot be edited or removed.');
if(isset($_GET['verify'])){$prev='';$n=0;$bad=0;foreach(q('SELECT * FROM deletion_log ORDER BY id')->fetchAll() as $r){$n++;
  $h=hash('sha256',implode('|',[$prev,$r['entity'],$r['entity_id'],$r['label'],$r['snapshot'],$r['reason'],$r['deleted_by'],$r['deleted_by_name'],$r['deleted_at']]));
  if($r['prev_hash']!==$prev||$r['row_hash']!==$h){$bad=$r['id'];break;}$prev=$r['row_hash'];}
 echo $bad?'<p class=err style="font-weight:700">&#10006; Integrity check FAILED: entry #'.$bad.' (or one before it) was altered or removed.</p>':'<p style="color:#1d7a3c;font-weight:700">&#10004; Integrity check passed: all '.$n.' chained entries are intact.</p>';}
echo '<div class="card noprint"><form method=get style="display:flex;gap:10px;flex-wrap:wrap;align-items:end"><div><label>Type</label><select name=entity><option value="">All</option>';foreach($E as $o)echo '<option'.($o==$ent?' selected':'').'>'.h($o).'</option>';
echo '</select></div><div><label>Search</label><input name=q value="'.h($q).'" placeholder="Item, user, reason"></div><div><label>From</label><input type=date name=from value="'.h($f).'"></div><div><label>To</label><input type=date name=to value="'.h($t).'"></div>
 <button>Filter</button> <a class="btn g" href="deletion_log.php">Reset</a> <a class="btn g" href="?'.h(http_build_query(['entity'=>$ent,'q'=>$q,'from'=>$f,'to'=>$t,'csv'=>1])).'">Export CSV</a> <button type=button class="btn g" onclick=print()>Print</button> <a class="btn g" href="?verify=1">Verify log integrity</a></form></div>
<div class=card><table><tr><th>Deleted at<th>Type<th>Item<th>Deleted by<th>Reason<th>Details';
foreach($rows as $x){$s=json_decode((string)$x['snapshot'],true)?:[];$d='';foreach($s as $k=>$v){if($v===null||$v==='')continue;$d.=pretty($k).': '.(is_array($v)?json_encode($v,JSON_UNESCAPED_UNICODE):$v)."\n";}
 echo '<tr><td style="white-space:nowrap">'.h($x['deleted_at']).'<td><span class=tag>'.h($x['entity']).'</span><td><b>'.h($x['label']).'</b><td>'.h($x['deleted_by_name']).'<br><small>'.h($x['client_ip']).'</small><td>'.nl2br(h($x['reason']))
 .'<td><details><summary>View</summary><pre style="white-space:pre-wrap;font-size:12px;max-width:360px">'.h($d).'</pre><small>'.($x['legacy']?'Earlier asset log entry':'Entry hash: '.h(substr($x['row_hash'],0,16)).'...').'</small></details>';}
if(!$rows)echo '<tr><td colspan=6>No deletions recorded.';echo '</table></div>';foot();
