<?php require __DIR__.'/includes/lib.php';$c=strtoupper(trim($_GET['code']??''));$r=null;
if($c)$r=q('SELECT s.*,u.name uname,u.designation,g.kind,g.po_no,g.data,a.active FROM doc_signatures s JOIN users u ON u.id=s.user_id JOIN generated g ON g.id=s.gen_id JOIN signatories a ON a.id=s.signatory_id WHERE s.code=?',[$c])->fetch();
?><!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Verify signature</title>
<body style="font:15px system-ui;background:#f3f4f1;max-width:560px;margin:30px auto;padding:0 14px"><h2>Signature verification</h2>
<form><input name=code value="<?=h($c)?>" placeholder="SIG-XXXXXXXXXXXX" style="padding:8px;width:70%"> <button style="padding:8px">Verify</button></form>
<?php if($c&&!$r)echo '<p style="color:#a33"><b>No signature found with this code.</b></p>';
if($r){$ok=hash_equals($r['doc_hash'],hash('sha256',$r['data']));$d=json_decode($r['data'],true);
 echo '<div style="background:#fff;border:1px solid #dcdfe4;padding:16px;margin-top:14px"><p style="color:'.($ok?'#186a3b':'#a33').'"><b>'.($ok?'VALID - document unchanged since signing':'WARNING - document was modified after this signature').'</b></p>
 <p>Document: '.($r['kind']=='po'?'Purchase Order '.h($r['po_no']):'Comparative Statement '.h($d['h']['ref_no']??'')).'<br>Signed for: '.h(slots()[$r['slot']]??$r['slot']).'<br>Signed by: '.h($r['uname']).' '.h($r['designation']).'<br>Date &amp; time: '.h($r['signed_at']).'<br>Code: '.h($r['code']).'</p>'
 .($r['active']?'':'<p style="color:#a33">Note: this person\'s signing authority has since been revoked; the signature was valid when applied.</p>').'</div>';}
