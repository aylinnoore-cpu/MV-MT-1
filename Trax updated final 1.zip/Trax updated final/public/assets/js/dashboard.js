/*
 * Dashboard charts (Chart.js) and time-entry edit modal.
 * Wired through data- attributes; no inline scripts.
 */
(function () {
    'use strict';
    var chartColors = window.ttChartPalette ? window.ttChartPalette() : { tick: '#8a96a0', grid: '#edf0f1', slice: '#ffffff' };

    function parseJsonAttr(el, name) {
        if (!el) { return []; }
        var raw = el.getAttribute(name);
        if (!raw) { return []; }
        try { return JSON.parse(raw); } catch (e) { return []; }
    }

    function barChart(canvas, labels, datasets) {
        if (!canvas || !window.Chart || labels.length === 0) { return; }
        new window.Chart(canvas, {
            type: 'bar',
            data: { labels: labels, datasets: datasets },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: { legend: { position: 'bottom' } },
                scales: {
                    x: { ticks: { autoSkip: true, maxRotation: 0 } },
                    y: { beginAtZero: true }
                }
            }
        });
    }

    var health = document.getElementById('projectHealthChart');
    if (health) {
        barChart(health, parseJsonAttr(health, 'data-chart-labels'), [
            { label: 'Estimated hours', data: parseJsonAttr(health, 'data-chart-planned'), backgroundColor: '#12426f' },
            { label: 'Tracked hours', data: parseJsonAttr(health, 'data-chart-actual'), backgroundColor: '#0b7a75' }
        ]);
    }

    var people = document.getElementById('peopleTimeChart');
    if (people) {
        barChart(people, parseJsonAttr(people, 'data-chart-labels'), [
            { label: 'Hours', data: parseJsonAttr(people, 'data-chart-hours'), backgroundColor: '#0b7a75' },
            { label: 'Billable amount', data: parseJsonAttr(people, 'data-chart-amounts'), backgroundColor: '#e8a317' }
        ]);
    }

    /* ---- Weekly team dashboard: stacked day chart + project donut ---- */
    function pad2(n) { return n < 10 ? '0' + n : String(n); }
    function hms(totalSeconds) {
        var s = Math.max(0, Math.round(totalSeconds));
        return pad2(Math.floor(s / 3600)) + ':' + pad2(Math.floor((s % 3600) / 60)) + ':' + pad2(s % 60);
    }

    // Pin a chart's box to a fixed size with inline styles. A responsive Chart.js canvas whose
    // container is sized by its own content grows on every resize; this makes that impossible
    // no matter which stylesheet is (or is not) loaded.
    function lockBox(canvas, width, height) {
        var box = canvas.parentElement;
        if (!box) { return; }
        box.style.position = 'relative';
        box.style.height = height;
        box.style.minHeight = '0';
        box.style.maxHeight = height;
        box.style.overflow = 'hidden';
        if (width) { box.style.width = width; box.style.maxWidth = '100%'; }
        canvas.style.position = 'absolute';
        canvas.style.top = '0';
        canvas.style.left = '0';
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.maxWidth = '100%';
        canvas.style.maxHeight = '100%';
    }

    function shortHours(totalSeconds) {
        var h = (totalSeconds || 0) / 3600;
        return (h >= 100 ? Math.round(h) : Math.round(h * 10) / 10) + 'h';
    }

    var weekStack = document.getElementById('weekStackChart');
    if (weekStack && window.Chart) {
        var wkSmall = window.matchMedia && window.matchMedia('(max-width: 700px)').matches;
        lockBox(weekStack, '', wkSmall ? '18rem' : '27rem');
        var wkLabels = parseJsonAttr(weekStack, 'data-labels');
        var wkSets = parseJsonAttr(weekStack, 'data-datasets');
        var wkTotals = parseJsonAttr(weekStack, 'data-totals');
        var maxHours = 0;
        wkTotals.forEach(function (t) { maxHours = Math.max(maxHours, t / 3600); });

        // Draws "hh:mm:ss" above each stacked column (and on the baseline for empty days).
        var totalsPlugin = {
            id: 'weekTotals',
            afterDatasetsDraw: function (chart) {
                var ctx = chart.ctx;
                var yScale = chart.scales.y;
                ctx.save();
                ctx.font = '12px "IBM Plex Sans", system-ui, sans-serif';
                ctx.fillStyle = '#5b6d6c';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'bottom';
                // Many bars (month / last 30 days): short rotated labels, and none on empty days.
                var dense = wkLabels.length > 16;
                wkLabels.forEach(function (_, i) {
                    if (dense && !(wkTotals[i] > 0)) { return; }
                    var top = yScale.getPixelForValue(0);
                    var x = null;
                    chart.data.datasets.forEach(function (ds, di) {
                        var el = chart.getDatasetMeta(di).data[i];
                        if (!el) { return; }
                        if (x === null) { x = el.x; }
                        if ((ds.data[i] || 0) > 0) { top = Math.min(top, el.y); }
                    });
                    if (x === null) { x = chart.scales.x.getPixelForValue(i); }
                    if (dense) {
                        ctx.save();
                        ctx.translate(x, top - 4);
                        ctx.rotate(-Math.PI / 2);
                        ctx.textAlign = 'left';
                        ctx.textBaseline = 'middle';
                        ctx.font = '11px "IBM Plex Sans", system-ui, sans-serif';
                        ctx.fillText(shortHours(wkTotals[i]), 0, 0);
                        ctx.restore();
                    } else {
                        ctx.fillText(hms(wkTotals[i] || 0), x, top - 5);
                    }
                });
                ctx.restore();
            }
        };


    function ensureChartDrilldownModal() {
        var existing = document.getElementById('ttChartDrilldownModal');
        if (existing) { return existing; }

        var style = document.createElement('style');
        style.id = 'ttChartDrilldownStyles';
        style.textContent = [
            '.tt-chart-modal-backdrop{position:fixed;inset:0;z-index:1080;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(15,23,42,.42);backdrop-filter:blur(3px)}',
            '.tt-chart-modal{width:min(680px,calc(100vw - 36px));max-height:min(78vh,620px);overflow:hidden;background:#fff;border:1px solid #e8ecef;border-radius:14px;box-shadow:0 20px 55px rgba(15,23,42,.22);font-family:"IBM Plex Sans",system-ui,sans-serif}',
            '.tt-chart-modal-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:16px 18px 12px}',
            '.tt-chart-modal-title{margin:0;font-size:16px;font-weight:600;color:#2b3a42}',
            '.tt-chart-modal-total{display:block;margin:0;font-size:15px;color:#2b3a42;font-weight:500;font-variant-numeric:tabular-nums;white-space:nowrap}',
            '.tt-chart-modal-close{width:34px;height:34px;flex:0 0 34px;border:0;border-radius:50%;background:#f4f6f6;color:#566563;font-size:20px;line-height:1;cursor:pointer}',
            '.tt-chart-modal-close:hover{background:#e9eeee;color:#172b2a}',
            '.tt-chart-modal-body{padding:0 18px 14px;overflow:auto;max-height:calc(min(78vh,620px) - 72px)}',
            '.tt-chart-modal-table{width:100%;border-collapse:collapse;font-size:13px;border-top:1px solid #dfe4e5}',
            '.tt-chart-modal-table th{padding:0;height:0;font-size:0;line-height:0;border:0}',
            '.tt-chart-modal-table td{padding:7px 4px;color:#263836;vertical-align:middle;border:0}',
            '.tt-chart-modal-table td:first-child{position:relative;padding-left:4px}',
            '.tt-chart-modal-project{font-weight:500}.tt-chart-modal-dot{display:inline-block;width:7px;height:7px;min-width:7px;height:7px;border-radius:50%;margin-right:9px;vertical-align:1px;flex:0 0 7px}',
            '.tt-chart-modal-client{display:block;margin:1px 0 0 15px;color:#8a9695;font-size:11px}',
            '.tt-chart-modal-time{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap;font-weight:600}',
            '.tt-chart-modal-pct{text-align:right;color:#748180;white-space:nowrap}',
            '.tt-person-minibar{display:flex;align-items:center;gap:0;min-height:22px;padding:2px 0;cursor:pointer}',
            
            '.tt-chart-modal-empty{padding:28px 4px;text-align:center;color:#7b8988;font-size:13px}',
            '@media (max-width:520px){.tt-chart-modal-backdrop{padding:10px}.tt-chart-modal{width:calc(100vw - 20px);border-radius:12px}.tt-chart-modal-head{padding:15px 16px 12px}.tt-chart-modal-body{padding:6px 16px 14px}.tt-chart-modal-table{font-size:12px}}'
        ].join('');
        document.head.appendChild(style);

        var backdrop = document.createElement('div');
        backdrop.id = 'ttChartDrilldownModal';
        backdrop.className = 'tt-chart-modal-backdrop';
        backdrop.hidden = true;
        backdrop.innerHTML = [
            '<div class="tt-chart-modal" role="dialog" aria-modal="true" aria-labelledby="ttChartModalTitle">',
            '  <div class="tt-chart-modal-head">',
            '    <div><h3 id="ttChartModalTitle" class="tt-chart-modal-title"></h3><span id="ttChartModalTotal" class="tt-chart-modal-total"></span></div>',
            '    <button type="button" class="tt-chart-modal-close" aria-label="Close">×</button>',
            '  </div>',
            '  <div id="ttChartModalBody" class="tt-chart-modal-body"></div>',
            '</div>'
        ].join('');
        document.body.appendChild(backdrop);

        var close = function () {
            backdrop.hidden = true;
            document.body.style.overflow = '';
        };
        backdrop.querySelector('.tt-chart-modal-close').addEventListener('click', close);
        backdrop.addEventListener('click', function (event) {
            if (event.target === backdrop) { close(); }
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !backdrop.hidden) { close(); }
        });

        backdrop._open = function (detail) {
            var total = detail.total || 0;
            backdrop.querySelector('#ttChartModalTitle').textContent = 'Projects';
            backdrop.querySelector('#ttChartModalTotal').textContent = hms(total);

            var body = backdrop.querySelector('#ttChartModalBody');
            var projects = Array.isArray(detail.projects) ? detail.projects : [];
            if (!projects.length) {
                body.innerHTML = '<div class="tt-chart-modal-empty">No tracked time for this period.</div>';
            } else {
                var rows = projects.map(function (item) {
                    var client = item.client ? '<span class="tt-chart-modal-client">' + escapeHtml(item.client) + '</span>' : '';
                    var dot = item.color ? '<span class="tt-chart-modal-dot" style="background:' + escapeHtml(item.color) + '"></span>' : '';
                    return '<tr>' +
                        '<td>' + dot + '<span class="tt-chart-modal-project">' + escapeHtml(item.project || 'Project') + '</span>' + client + '</td>' +
                        '<td class="tt-chart-modal-time">' + hms(item.seconds || 0) + '</td>' +
                        '<td class="tt-chart-modal-pct">' + Number(item.percent || 0).toFixed(2) + '%</td>' +
                        '</tr>';
                }).join('');
                body.innerHTML = '<table class="tt-chart-modal-table"><thead><tr><th>Project</th><th style="text-align:right">Time</th><th style="text-align:right">Share</th></tr></thead><tbody>' + rows + '</tbody></table>';
            }
            backdrop.hidden = false;
            document.body.style.overflow = 'hidden';
        };

        return backdrop;
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function openPersonBreakdown(bar) {
        var detail = parseJsonAttr(bar, 'data-person-details');
        if (!detail || !Array.isArray(detail.projects)) { return; }
        ensureChartDrilldownModal()._open({
            label: detail.label || 'Team member',
            date: detail.date || '',
            total: Number(detail.total || 0),
            projects: detail.projects
        });
    }

    document.addEventListener('click', function (event) {
        var bar = event.target.closest ? event.target.closest('.tt-person-minibar') : null;
        if (!bar) { return; }
        event.preventDefault();
        openPersonBreakdown(bar);
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Enter' && event.key !== ' ') { return; }
        var bar = event.target.closest ? event.target.closest('.tt-person-minibar') : null;
        if (!bar) { return; }
        event.preventDefault();
        openPersonBreakdown(bar);
    });

        var wkDetails = parseJsonAttr(weekStack, 'data-details');
        var weekStackInstance = new window.Chart(weekStack, {
            type: 'bar',
            data: {
                labels: wkLabels,
                datasets: wkSets.map(function (s) {
                    return {
                        label: s.label,
                        data: s.data,
                        backgroundColor: s.color,
                        borderWidth: 0,
                        barPercentage: 0.72,
                        categoryPercentage: 0.9
                    };
                })
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                layout: { padding: { top: wkLabels.length > 16 ? 44 : 18 } },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        filter: function (item) { return item.parsed.y > 0; },
                        callbacks: {
                            label: function (ctx) { return ' ' + ctx.dataset.label + ': ' + hms(ctx.parsed.y * 3600); }
                        }
                    }
                },
                onClick: function (event, activeElements, chart) {
                    var points = chart.getElementsAtEventForMode(event, 'index', { intersect: false }, true);
                    var point = points && points.length ? points[0] : (activeElements && activeElements.length ? activeElements[0] : null);
                    if (!point) { return; }
                    var index = point.index;
                    var detail = wkDetails[index];
                    if (!detail) { return; }
                    ensureChartDrilldownModal()._open(detail);
                },
                scales: {
                    x: { stacked: true, grid: { display: false }, ticks: { color: chartColors.tick, maxRotation: 0, autoSkip: true, maxTicksLimit: 16 } },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        suggestedMax: Math.max(5, Math.ceil(maxHours * 1.12 / 5) * 5),
                        grid: { color: chartColors.grid },
                        border: { display: false },
                        ticks: {
                            color: chartColors.tick,
                            callback: function (v) { return Number(v).toFixed(1) + 'h'; }
                        }
                    }
                }
            },
            plugins: [totalsPlugin]
        });
        weekStack.style.cursor = 'pointer';
    }

    var weekDonut = document.getElementById('weekDonutChart');
    if (weekDonut && window.Chart) {
        var wkDonutSize = window.matchMedia && window.matchMedia('(max-width: 700px)').matches ? '17rem' : '23rem';
        lockBox(weekDonut, wkDonutSize, wkDonutSize);
        var dn = {};
        try { dn = JSON.parse(weekDonut.getAttribute('data-donut') || '{}'); } catch (e) { dn = {}; }
        new window.Chart(weekDonut, {
            type: 'doughnut',
            data: {
                labels: dn.labels || [],
                datasets: [{ data: dn.data || [], backgroundColor: dn.colors || [], borderColor: chartColors.slice, borderWidth: 1 }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '52%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function (ctx) { return ' ' + ctx.label + ': ' + hms(ctx.parsed); }
                        }
                    }
                }
            }
        });
    }

    /* ---- Team activities: running timers count up live ----
       The server renders the elapsed seconds at page load; the browser adds the time passed
       since then (Date.now based, so it stays correct even if the tab was in the background). */
    var teamBody = document.querySelector('[data-team-activities]');
    var liveEls = [];
    var liveLoadedAt = Date.now();
    var fmtClock = function (total) {
        var s = Math.max(0, Math.floor(total));
        return Math.floor(s / 3600) + ':' + pad2(Math.floor((s % 3600) / 60)) + ':' + pad2(s % 60);
    };
    var tickLive = function () {
        var passed = (Date.now() - liveLoadedAt) / 1000;
        Array.prototype.forEach.call(liveEls, function (el) {
            var base = parseInt(el.getAttribute('data-live-seconds') || '0', 10) || 0;
            el.textContent = fmtClock(base + passed);
        });
    };
    var bindLive = function () {
        liveEls = document.querySelectorAll('[data-live-seconds]');
        liveLoadedAt = Date.now();
        tickLive();
    };
    bindLive();
    window.setInterval(tickLive, 1000);

    /* Keep Team activities in sync without a page reload: re-fetch the dashboard and swap
       only the table body. Runs right after any pause/resume/stop/start (tt:timer-changed
       from timer.js) and every 10 seconds while the tab is visible, so changes made in
       another tab or by another team member also show up. */
    if (teamBody) {
        var refreshing = false;
        var refreshQueued = null;
        var refreshTeam = function () {
            if (refreshing || document.hidden) { return; }
            refreshing = true;
            fetch(window.location.href, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                cache: 'no-store',
                credentials: 'same-origin'
            }).then(function (r) { return r.ok ? r.text() : ''; }).then(function (html) {
                if (!html) { return; }
                var doc = new DOMParser().parseFromString(html, 'text/html');
                var fresh = doc.querySelector('[data-team-activities]');
                if (fresh) {
                    teamBody.innerHTML = fresh.innerHTML;
                    bindLive();
                }
            }).catch(function () { /* keep current rows */ })
              .finally(function () { refreshing = false; });
        };
        window.addEventListener('tt:timer-changed', function () {
            if (refreshQueued) { window.clearTimeout(refreshQueued); }
            refreshQueued = window.setTimeout(refreshTeam, 400);
        });
        window.setInterval(refreshTeam, 10000);
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) { refreshTeam(); }
        });
    }

    var editModalEl = document.getElementById('editEntryModal');
    var editForm = document.getElementById('editEntryForm');
    if (!editModalEl || !editForm || !window.bootstrap) { return; }

    var modal = window.bootstrap.Modal.getOrCreateInstance(editModalEl);
    var baseUrl = (document.body && document.body.getAttribute('data-base-url')) || '/';
    if (baseUrl.slice(-1) !== '/') { baseUrl += '/'; }

    function fillEditTasks(projectId, selectedId) {
        var taskSelect = editForm.querySelector('[data-timer-task-select]');
        if (!taskSelect) { return; }
        taskSelect.innerHTML = '<option value="">No task</option>';
        if (!projectId) { return; }

        fetch(baseUrl + 'time/tasks?project_id=' + encodeURIComponent(projectId), {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (response) { return response.json(); }).then(function (data) {
            if (!data || !data.ok || !data.tasks) { return; }
            data.tasks.forEach(function (task) {
                var opt = document.createElement('option');
                opt.value = String(task.id);
                opt.textContent = task.name;
                if (selectedId && String(selectedId) === String(task.id)) {
                    opt.selected = true;
                }
                taskSelect.appendChild(opt);
            });
        }).catch(function () { /* keep empty */ });
    }

    document.addEventListener('click', function (event) {
        var btn = event.target.closest ? event.target.closest('[data-entry-edit]') : null;
        if (!btn) { return; }
        event.preventDefault();

        var id = btn.getAttribute('data-id') || '0';
        editForm.setAttribute('action', baseUrl + 'time/' + id);

        var project = editForm.querySelector('[name="project_id"]');
        var start = editForm.querySelector('[name="start_time"]');
        var end = editForm.querySelector('[name="end_time"]');
        var brk = editForm.querySelector('[name="break_minutes"]');
        var desc = editForm.querySelector('[name="description"]');
        var billable = editForm.querySelector('[name="is_billable"]');
        var projectId = btn.getAttribute('data-project-id') || '';
        var taskId = btn.getAttribute('data-task-id') || '';

        if (project) { project.value = projectId; }
        if (start) { start.value = btn.getAttribute('data-start') || ''; }
        if (end) { end.value = btn.getAttribute('data-end') || ''; }
        if (brk) { brk.value = btn.getAttribute('data-break') || '0'; }
        if (desc) { desc.value = btn.getAttribute('data-description') || ''; }
        if (billable) { billable.checked = btn.getAttribute('data-billable') === '1'; }
        fillEditTasks(projectId, taskId);

        modal.show();
    });
})();
/* Clockify-style dashboard date picker. */
(function () {
    'use strict';

    function closeAll(except) {
        document.querySelectorAll('[data-dashboard-date-picker].is-open').forEach(function (picker) {
            if (picker === except) { return; }
            picker.classList.remove('is-open');
            var trigger = picker.querySelector('[data-date-picker-trigger]');
            var popover = picker.querySelector('[data-date-picker-popover]');
            if (trigger) { trigger.setAttribute('aria-expanded', 'false'); }
            if (popover) { popover.hidden = true; }
        });
    }

    document.addEventListener('click', function (event) {
        var trigger = event.target.closest('[data-date-picker-trigger]');
        if (trigger) {
            var picker = trigger.closest('[data-dashboard-date-picker]');
            var popover = picker ? picker.querySelector('[data-date-picker-popover]') : null;
            if (!picker || !popover) { return; }
            var open = !picker.classList.contains('is-open');
            closeAll(picker);
            picker.classList.toggle('is-open', open);
            trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
            popover.hidden = !open;
            event.preventDefault();
            return;
        }

        if (!event.target.closest('[data-dashboard-date-picker]')) {
            closeAll(null);
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') { return; }
        closeAll(null);
    });
}());
