# Self-hosted front-end assets (FIX 5)

These files are already in the tree under the paths below. The app never loads jsDelivr at runtime. Re-download only if a binary is missing.

## Bootstrap 5.3.3

- https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css
  -> `public/assets/vendor/bootstrap/bootstrap.min.css`
- https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js
  -> `public/assets/vendor/bootstrap/bootstrap.bundle.min.js`

## Font Awesome 6.5.2

- https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css
  -> `public/assets/vendor/fontawesome/css/all.min.css`
- https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/webfonts/fa-solid-900.woff2
  -> `public/assets/vendor/fontawesome/webfonts/fa-solid-900.woff2`
- https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/webfonts/fa-regular-400.woff2
  -> `public/assets/vendor/fontawesome/webfonts/fa-regular-400.woff2`
- https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/webfonts/fa-brands-400.woff2
  -> `public/assets/vendor/fontawesome/webfonts/fa-brands-400.woff2`

`all.min.css` already references `../webfonts/*.woff2`.

## Chart.js 4.4.4

- https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js
  -> `public/assets/vendor/chartjs/chart.umd.min.js`

## Fonts (woff2 only)

- https://cdn.jsdelivr.net/fontsource/fonts/ibm-plex-sans@5.0.18/latin-400-normal.woff2
  -> `public/assets/fonts/ibm-plex-sans-400.woff2`
- https://cdn.jsdelivr.net/fontsource/fonts/ibm-plex-sans@5.0.18/latin-500-normal.woff2
  -> `public/assets/fonts/ibm-plex-sans-500.woff2`
- https://cdn.jsdelivr.net/fontsource/fonts/ibm-plex-sans@5.0.18/latin-600-normal.woff2
  -> `public/assets/fonts/ibm-plex-sans-600.woff2`
- https://cdn.jsdelivr.net/fontsource/fonts/roboto@5.0.8/latin-400-normal.woff2
  -> `public/assets/fonts/roboto-400.woff2`
- https://cdn.jsdelivr.net/fontsource/fonts/roboto@5.0.8/latin-500-normal.woff2
  -> `public/assets/fonts/roboto-500.woff2`

`public/assets/css/fonts.css` maps those files via `@font-face`.
