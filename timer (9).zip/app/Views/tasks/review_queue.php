<?php
/**
 * Tasks in Review that the current user may approve or return.
 *
 * @var list<array<string, mixed>> $items
 */

$backPath = '/tasks/review';
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Task review</h2>
        <p class="page-lead">Approve completed work or send it back with a note. You never review your own tasks.</p>
    </div>
</div>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Queue <span class="count-pill"><?= count($items) ?></span></h2>
    </div>
    <?php if ($items === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-folder-open" aria-hidden="true"></i>
            <p>No tasks are waiting for your review.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <th>Task</th>
                        <th>Project</th>
                        <th>Team</th>
                        <th>Assignees</th>
                        <th>Updated</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $task): ?>
                        <?php
                        $id    = (int) $task['id'];
                        $names = array_map(static fn (array $a): string => (string) $a['name'], $task['assignees'] ?? []);
                        $label = $names === [] ? 'Anyone' : implode(', ', $names);
                        ?>
                        <tr>
                            <td>
                                <div class="fw-medium"><?= e($task['name']) ?></div>
                                <div class="small text-secondary"><?= e($task['status']) ?></div>
                            </td>
                            <td>
                                <a href="<?= e(url('/projects/' . (int) $task['project_id'] . '?tab=tasks')) ?>"><?= e((string) ($task['project_name'] ?? '')) ?></a>
                            </td>
                            <td><?= e((string) ($task['team_name'] ?? 'Project-level')) ?></td>
                            <td><?= e($label) ?></td>
                            <td><?= e(FormatHelper::datetime((string) ($task['updated_at'] ?? ''), 'M j, H:i')) ?></td>
                            <td class="text-end text-nowrap">
                                <form method="post" action="<?= e(url('/tasks/' . $id . '/review')) ?>" class="d-inline"
                                      data-confirm="Complete <?= e($task['name']) ?>?" data-single-submit>
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="back" value="<?= e($backPath) ?>">
                                    <button type="submit" class="btn btn-sm btn-primary">Approve</button>
                                </form>
                                <button type="button"
                                        class="btn btn-sm btn-outline-danger"
                                        data-bs-toggle="modal"
                                        data-bs-target="#returnTaskModal"
                                        data-return-id="<?= $id ?>"
                                        data-return-name="<?= e($task['name']) ?>">
                                    Return
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<div class="modal fade" id="returnTaskModal" tabindex="-1" aria-labelledby="returnTaskTitle" aria-hidden="true">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('/tasks/0/return')) ?>" id="returnTaskForm" data-single-submit>
            <?= csrf_field() ?>
            <input type="hidden" name="back" value="<?= e($backPath) ?>">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title fs-5" id="returnTaskTitle">Return task</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="text-secondary" id="returnTaskLead">Send this task back to In Progress with a note.</p>
                    <label for="review_note" class="form-label">Reason</label>
                    <textarea id="review_note" name="review_note" class="form-control" rows="4" required maxlength="500"
                              placeholder="What needs to change?"></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Return task</button>
                </div>
            </div>
        </form>
    </div>
</div>
