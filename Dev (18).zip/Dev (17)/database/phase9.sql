-- =====================================================================
--  TimeTrack: Phase 9 schema, activity logging, notifications and settings
--  Run AFTER Phase 1..8 on an existing database:
--
--      mysql -u USER -p DATABASE < database/phase9.sql
--
--  Safe to re-run on MariaDB versions that support ADD COLUMN IF NOT EXISTS
--  (XAMPP ships MariaDB). On MySQL 8 run it once.
-- =====================================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------
-- activity_logs: richer audit trail
--   module      = logical area, e.g. "project", "task", "schedule", "time"
--   record_id   = id of the affected row (entity_id is kept for compatibility)
--   old_value   = JSON snapshot before the change
--   new_value   = JSON snapshot after the change
-- ---------------------------------------------------------------------
ALTER TABLE `activity_logs`
    ADD COLUMN IF NOT EXISTS `module`    VARCHAR(60)  NULL AFTER `action`,
    ADD COLUMN IF NOT EXISTS `record_id` INT UNSIGNED NULL AFTER `entity_id`,
    ADD COLUMN IF NOT EXISTS `old_value` LONGTEXT     NULL AFTER `user_agent`,
    ADD COLUMN IF NOT EXISTS `new_value` LONGTEXT     NULL AFTER `old_value`;

-- Keep the legacy read-alias in sync with the new columns.
CREATE OR REPLACE VIEW `audit_logs` AS
    SELECT `id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `record_id`,
           `ip_address`, `user_agent`, `meta`, `old_value`, `new_value`, `created_at`
    FROM `activity_logs`;

-- ---------------------------------------------------------------------
-- users: per-person billing rate (Phase 9 user management)
-- ---------------------------------------------------------------------
ALTER TABLE `users`
    ADD COLUMN IF NOT EXISTS `hourly_rate` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `job_title`;

-- ---------------------------------------------------------------------
-- Extra system settings used by SettingsController
-- ---------------------------------------------------------------------
INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`) VALUES
    ('currency_symbol',     '$',  'string', 'billing', 'Symbol shown next to money amounts.'),
    ('working_hours_per_day','8', 'string', 'general', 'Standard billable hours in one working day.');

-- ---------------------------------------------------------------------
-- New permission for the audit log screen (admins and managers already
-- receive it through the role mappings below; admins get everything).
-- ---------------------------------------------------------------------
INSERT IGNORE INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
    ('activity.view', 'View activity log', 'system', 'Read the audit trail.');

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, `id` FROM `permissions` WHERE `name` = 'activity.view';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, `id` FROM `permissions` WHERE `name` = 'activity.view';
