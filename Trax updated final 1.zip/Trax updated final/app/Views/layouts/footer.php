<?php
/**
 * Closing markup and scripts. Shared by the "app" and "auth" layouts.
 */

$isShell = AuthHelper::check();
?>
<?php if ($isShell): ?>
        </main>

        <footer class="app-footer">
            <span>&copy; <?= e(gmdate('Y')) ?> <?= e(SettingsService::appName()) ?></span>
            <span class="text-secondary">Times are shown in <?= e(str_replace('_', ' ', FormatHelper::displayTimezone())) ?></span>
        </footer>
    </div><!-- /.app-main -->
</div><!-- /.app-shell -->
<?php endif; ?>

<script src="<?= e(asset('vendor/bootstrap/bootstrap.bundle.min.js')) ?>"></script>
<?php if (!empty($chartAssets)): ?>
<script src="<?= e(asset('vendor/chartjs/chart.umd.min.js')) ?>"></script>
<?php endif; ?>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<?php if (!empty($reportAssets)): ?>
<script src="<?= e(asset('js/reports.js')) ?>"></script>
<?php endif; ?>
<?php if (!empty($projectAssets)): ?>
<script src="<?= e(asset('js/project.js')) ?>"></script>
<?php endif; ?>
<?php if ($isShell && PermissionHelper::hasAny('time.track', 'time.edit_own')): ?>
<script src="<?= e(asset('js/timer.js')) ?>"></script>
<?php endif; ?>
<?php if (!empty($scheduleAssets)): ?>
<script src="<?= e(asset('js/schedule.js')) ?>"></script>
<?php endif; ?>
<?php if ($isShell && !empty($notificationAssets)): ?>
<script src="<?= e(asset('js/notifications.js')) ?>"></script>
<?php endif; ?>
<?php if ($isShell): ?>
<script src="<?= e(asset('js/dashboard.js')) ?>"></script>
<?php endif; ?>
<?php if ($isShell && !empty($chatAssets)): ?>
<script src="<?= e(asset('js/chat.js')) ?>"></script>
<?php endif; ?>
</body>
</html>
