/*
 * Theme bootstrapping.
 *
 * Loaded synchronously in <head> (before the body paints) so the remembered colour
 * theme is applied without a flash of the wrong theme. The Content-Security-Policy
 * forbids inline scripts, which is why this lives in its own file.
 *
 * The header control carrying data-theme-toggle is wired up on DOMContentLoaded.
 * Preference order: saved choice -> OS preference.
 */
(function () {
    'use strict';

    var STORAGE_KEY = 'tt-theme';
    var root = document.documentElement;

    function saved() {
        try {
            var value = window.localStorage.getItem(STORAGE_KEY);
            return value === 'dark' || value === 'light' ? value : null;
        } catch (e) {
            return null;
        }
    }

    function system() {
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    function apply(theme) {
        root.setAttribute('data-bs-theme', theme);
        syncButtons(theme);
    }

    function syncButtons(theme) {
        document.querySelectorAll('[data-theme-toggle]').forEach(function (button) {
            var icon = button.querySelector('i');
            var dark = theme === 'dark';

            button.setAttribute('aria-pressed', dark ? 'true' : 'false');
            button.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
            button.setAttribute('title', dark ? 'Switch to light mode' : 'Switch to dark mode');

            if (icon) {
                // Light theme = lit bulb (solid, glowing); dark theme = unlit bulb (outline).
                icon.className = dark ? 'fa-regular fa-lightbulb' : 'fa-solid fa-lightbulb theme-bulb-on';
            }
        });
    }

    apply(saved() || system());

    if (window.matchMedia) {
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function (event) {
            if (!saved()) {
                apply(event.matches ? 'dark' : 'light');
            }
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        syncButtons(root.getAttribute('data-bs-theme') || system());

        document.querySelectorAll('[data-theme-toggle]').forEach(function (button) {
            button.addEventListener('click', function () {
                var next = (root.getAttribute('data-bs-theme') === 'dark') ? 'light' : 'dark';

                try {
                    window.localStorage.setItem(STORAGE_KEY, next);
                } catch (e) { /* private mode: keep the in-page choice only */ }

                apply(next);
            });
        });
    });
})();
