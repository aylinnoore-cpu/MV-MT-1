<?php
/**
 * Weekly timesheet matrix (Project | Task | Mon–Sun | Total) and monthly overview.
 *
 * @var string $activeTab
 * @var DateTimeImmutable $weekStart
 * @var string $prevWeek
 * @var string $nextWeek
 * @var string $thisWeek
 * @var array<string, mixed>|null $matrix
 * @var array<string, mixed>|null $month
 * @var array<string, mixed>|null $timesheet
 * @var string $status
 * @var bool $locked
 * @var bool $canSubmit
 * @var bool $canApprove
 * @var string $view
 */

$view       = $view ?? 'week';
$matrix     = $matrix ?? null;
$month      = $month ?? null;
$timesheet  = $timesheet ?? null;
$canSubmit  = $canSubmit ?? false;
$canApprove = $canApprove ?? false;
$locked     = $locked ?? false;
$status     = $status ?? Timesheet::STATUS_DRAFT;
$weekStart  = $weekStart ?? new DateTimeImmutable('Monday this week');

$statusClass = static fn (string $s): string => match ($s) {
    Timesheet::STATUS_APPROVED  => 'completed',
    Timesheet::STATUS_REJECTED  => 'cancelled',
    Timesheet::STATUS_SUBMITTED => 'hold',
    default                     => 'planning',
};

$cellHours = static function (int $seconds): string {
    if ($seconds <= 0) {
        return '';
    }

    return FormatHelper::hours($seconds);
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Timesheet</h2>
        <p class="page-lead">
            <?php if ($view === 'month' && is_array($month)): ?>
                Hours for <?= e($month['month_label']) ?>.
            <?php else: ?>
                Week of <?= e($weekStart->format('M j, Y')) ?>
                <?php if (is_array($matrix)): ?>
                    &ndash; <?= e((new DateTimeImmutable($matrix['week_end']))->format('M j, Y')) ?>.
                <?php endif; ?>
            <?php endif; ?>
        </p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if ($view === 'month'): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets/month?month=' . $prevWeek)) ?>">Previous</a>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets/month')) ?>">This month</a>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets/month?month=' . $nextWeek)) ?>">Next</a>
        <?php else: ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets?week=' . $prevWeek)) ?>">Previous</a>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets')) ?>">This week</a>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets?week=' . $nextWeek)) ?>">Next</a>
        <?php endif; ?>
        <?php if ($canSubmit): ?>
            <form method="post" action="<?= e(url('/timesheets/submit')) ?>" class="m-0"
                  data-confirm="Submit this week for approval? Time entries will be locked until a manager reviews them."
                  data-single-submit>
                <?= csrf_field() ?>
                <input type="hidden" name="week" value="<?= e($weekStart->format('Y-m-d')) ?>">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-paper-plane me-1" aria-hidden="true"></i>Submit timesheet
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>

<nav class="filter-tabs" aria-label="Timesheet views">
    <a class="filter-tab<?= $view === 'week' ? ' is-active' : '' ?>" href="<?= e(url('/timesheets?week=' . $weekStart->format('Y-m-d'))) ?>">Week</a>
    <a class="filter-tab<?= $view === 'month' ? ' is-active' : '' ?>" href="<?= e(url('/timesheets/month')) ?>">Month</a>
    <?php if ($canApprove): ?>
        <a class="filter-tab" href="<?= e(url('/timesheets/team')) ?>">Team approval</a>
    <?php endif; ?>
</nav>

<?php if ($view === 'week' && is_array($matrix)): ?>
    <?php
    $days   = $matrix['days'];
    $rows   = $matrix['rows'];
    $status = (string) (($matrix['timesheet']['status'] ?? '') ?: $status);
    ?>

    <?php if ($status === Timesheet::STATUS_REJECTED && !empty($timesheet['rejection_reason'])): ?>
        <div class="alert alert-warning timesheet-reject-alert" role="alert">
            <div class="fw-semibold mb-1"><i class="fa-solid fa-triangle-exclamation me-1" aria-hidden="true"></i>This week was sent back</div>
            <p class="mb-1"><?= e((string) $timesheet['rejection_reason']) ?></p>
            <p class="mb-0 small">
                <?php if (!empty($timesheet['approved_by_name'])): ?>
                    <?= e((string) $timesheet['approved_by_name']) ?>
                    &middot;
                <?php endif; ?>
                <?= e(FormatHelper::datetime((string) ($timesheet['approved_at'] ?? ''), 'M j, Y H:i')) ?>
            </p>
        </div>
    <?php endif; ?>

    <div class="kpi-grid mb-4">
        <article class="kpi-card">
            <p class="kpi-label">Status</p>
            <p class="kpi-value"><span class="status-badge status-<?= e($statusClass($status)) ?>"><?= e($status) ?></span></p>
            <p class="kpi-sub">
                <?php if ($status === Timesheet::STATUS_SUBMITTED && !empty($timesheet['submitted_at'])): ?>
                    Sent <?= e(FormatHelper::datetime((string) $timesheet['submitted_at'], 'M j, H:i')) ?>
                <?php elseif ($status === Timesheet::STATUS_APPROVED && !empty($timesheet['approved_at'])): ?>
                    Approved <?= e(FormatHelper::datetime((string) $timesheet['approved_at'], 'M j, H:i')) ?>
                <?php elseif ($locked): ?>
                    Entries are locked
                <?php else: ?>
                    Not submitted
                <?php endif; ?>
            </p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Tracked</p>
            <p class="kpi-value"><?= e(FormatHelper::hours((int) $matrix['grand_total'])) ?>h</p>
            <p class="kpi-sub"><?= e(FormatHelper::duration((int) $matrix['grand_total'])) ?> &middot; <?= (int) $matrix['entry_count'] ?> entries</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Billable</p>
            <p class="kpi-value"><?= e(FormatHelper::hours((int) $matrix['billable_total'])) ?>h</p>
            <p class="kpi-sub"><?= e(FormatHelper::duration((int) $matrix['billable_total'])) ?></p>
        </article>
    </div>

    <section class="panel timesheet-panel">
        <div class="panel-head">
            <h2 class="panel-title">Weekly grid</h2>
            <?php if ($locked): ?>
                <span class="count-pill">Locked</span>
            <?php endif; ?>
        </div>
        <?php if ($rows === []): ?>
            <div class="empty-state">
                <i class="fa-regular fa-clock" aria-hidden="true"></i>
                <p>No time entries this week. Track time or add an entry, then submit.</p>
                <p class="mt-3 mb-0"><a class="btn btn-outline-primary" href="<?= e(url('/time')) ?>">Open time tracker</a></p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table data-table timesheet-matrix mb-0">
                    <thead>
                        <tr>
                            <th>Project</th>
                            <th>Task</th>
                            <?php foreach ($days as $day): ?>
                                <th class="text-end<?= $day['is_today'] ? ' is-today' : '' ?><?= $day['is_weekend'] ? ' is-weekend' : '' ?>">
                                    <?= e($day['label']) ?>
                                    <span class="d-block fw-normal"><?= e($day['short']) ?></span>
                                </th>
                            <?php endforeach; ?>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <td>
                                    <a href="<?= e(url('/projects/' . (int) $row['project_id'])) ?>" class="fw-medium"><?= e($row['project_name']) ?></a>
                                    <?php if (!empty($row['project_code'])): ?>
                                        <div class="small text-secondary"><?= e($row['project_code']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><?= $row['task_name'] !== '' ? e($row['task_name']) : '—' ?></td>
                                <?php foreach ($days as $day): ?>
                                    <?php $secs = (int) ($row['days'][$day['key']] ?? 0); ?>
                                    <td class="text-end mono<?= $day['is_today'] ? ' is-today' : '' ?><?= $day['is_weekend'] ? ' is-weekend' : '' ?><?= $secs > 0 ? ' has-time' : '' ?>">
                                        <?= e($cellHours($secs)) ?>
                                    </td>
                                <?php endforeach; ?>
                                <td class="text-end mono fw-semibold"><?= e(FormatHelper::hours((int) $row['total_seconds'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="2">Daily total</th>
                            <?php foreach ($days as $day): ?>
                                <?php $secs = (int) ($matrix['column_totals'][$day['key']] ?? 0); ?>
                                <th class="text-end mono<?= $day['is_today'] ? ' is-today' : '' ?>">
                                    <?= e($cellHours($secs)) ?>
                                </th>
                            <?php endforeach; ?>
                            <th class="text-end mono"><?= e(FormatHelper::hours((int) $matrix['grand_total'])) ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </section>

<?php elseif ($view === 'month' && is_array($month)): ?>
    <div class="kpi-grid mb-4">
        <article class="kpi-card">
            <p class="kpi-label">Month</p>
            <p class="kpi-value"><?= e($month['month_label']) ?></p>
            <p class="kpi-sub"><?= count($month['weeks']) ?> weeks</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Tracked</p>
            <p class="kpi-value"><?= e(FormatHelper::hours((int) $month['grand_total'])) ?>h</p>
            <p class="kpi-sub"><?= e(FormatHelper::duration((int) $month['grand_total'])) ?></p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Billable</p>
            <p class="kpi-value"><?= e(FormatHelper::hours((int) $month['billable_total'])) ?>h</p>
            <p class="kpi-sub"><?= e(FormatHelper::duration((int) $month['billable_total'])) ?></p>
        </article>
    </div>

    <section class="panel">
        <div class="panel-head">
            <h2 class="panel-title">Weeks</h2>
        </div>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <th>Week</th>
                        <th>Entries</th>
                        <th>Tracked</th>
                        <th>Billable</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($month['weeks'] as $weekRow): ?>
                        <tr>
                            <td>
                                <?php
                                $ws = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $weekRow['week_start']);
                                $we = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $weekRow['week_end']);
                                ?>
                                <?= e($ws ? $ws->format('M j') : $weekRow['week_start']) ?>
                                &ndash;
                                <?= e($we ? $we->format('M j') : $weekRow['week_end']) ?>
                            </td>
                            <td><?= (int) $weekRow['entry_count'] ?></td>
                            <td class="mono"><?= e(FormatHelper::hours((int) $weekRow['total_seconds'])) ?>h</td>
                            <td class="mono"><?= e(FormatHelper::hours((int) $weekRow['billable_seconds'])) ?>h</td>
                            <td><span class="status-badge status-<?= e($statusClass((string) $weekRow['status'])) ?>"><?= e($weekRow['status']) ?></span></td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/timesheets?week=' . $weekRow['week_start'])) ?>">Open</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php endif; ?>
