<?php
/**
 * Sign in, sign out, own profile and password change.
 *
 * Login pages must be reachable without a session, while the profile pages need one,
 * so this controller is public at construction time and the profile actions call
 * requireLogin() themselves (same AuthMiddleware every other controller uses).
 *
 * SECURITY decisions:
 *  - One generic message for unknown e-mail and wrong password (no account enumeration),
 *    and password_verify() always runs so response time does not reveal which one failed.
 *  - Per-account lockout (security.login_max_attempts / login_lockout_minutes) plus a
 *    per-IP failure ceiling, so guessing across many accounts is slowed down too.
 *  - The session id is regenerated on login (AuthHelper::login) and on password change.
 *  - Passwords are bcrypt (cost 12) and are transparently re-hashed when the cost changes.
 */

declare(strict_types=1);

final class AuthController extends Controller
{
    private const HASH_OPTIONS = ['cost' => 12];

    /** Verified when the e-mail is unknown, so both paths cost the same time. Matches no real password. */
    private const DUMMY_HASH = '$2y$12$p.7X0qLnAWjRnqT2VII6ZONXReZ4OcoroAl43p63vN1oea.mnNk9y';

    private const BAD_CREDENTIALS = 'These credentials do not match our records.';

    public function __construct()
    {
        parent::__construct(false); // public by default; see requireLogin()
    }

    /* ------------------------------------------------------------------ login */

    /** GET /login */
    public function login(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            $this->redirect('/dashboard');
        }

        $this->render('auth/login', ['pageTitle' => 'Sign in'], 'auth');
    }

    /** POST /login */
    public function authenticate(Request $request, array $params): void
    {
        $data = $this->validate([
            'email'    => 'required|email|max:190',
            'password' => 'required|string|max:200',
        ], '/login', ['email' => 'Email', 'password' => 'Password']);

        $email = strtolower((string) $data['email']);
        $ip    = $request->ip();

        if ($this->tooManyFailuresFromIp($ip)) {
            LoggerHelper::warning('Login blocked: too many failures from IP', ['ip' => $ip]);
            $this->backWithErrors('/login', ['email' => 'Too many failed sign-in attempts. Please wait a few minutes and try again.']);
        }

        $user = Database::fetchOne(
            'SELECT u.id, u.name, u.email, u.password, r.name AS role, u.status, u.timezone, u.locked_until
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.email = :email LIMIT 1',
            ['email' => $email]
        );

        // Locked accounts are refused before the password is checked, even if it is correct.
        if ($user !== null && $user['locked_until'] !== null) {
            $remaining = strtotime($user['locked_until'] . ' UTC') - time();

            if ($remaining > 0) {
                $minutes = (int) ceil($remaining / 60);
                $this->recordFailure($user, $email, 'locked');
                $this->backWithErrors('/login', [
                    'email' => 'Too many failed attempts. Try again in ' . $minutes . ($minutes === 1 ? ' minute.' : ' minutes.'),
                ]);
            }
        }

        // Always run a bcrypt comparison, against a dummy hash when the account does not exist.
        $passwordOk = password_verify((string) $data['password'], $user['password'] ?? self::DUMMY_HASH);

        if ($user === null || !$passwordOk) {
            $this->recordFailure($user, $email, 'bad_credentials');
            $this->backWithErrors('/login', ['email' => self::BAD_CREDENTIALS]);
        }

        if ($user['status'] !== 'active') {
            LoggerHelper::audit('auth.login_blocked', 'user', (int) $user['id'], ['status' => $user['status']]);
            $this->backWithErrors('/login', ['email' => 'This account is not active. Please contact your administrator.']);
        }

        if ($user['role'] !== AuthHelper::ROLE_ADMIN && $this->maintenanceModeOn()) {
            $this->backWithErrors('/login', ['email' => 'The system is in maintenance mode. Please try again later.']);
        }

        Database::execute(
            'UPDATE users
             SET failed_login_attempts = 0, locked_until = NULL,
                 last_login_at = UTC_TIMESTAMP(), last_login_ip = :ip
             WHERE id = :id',
            ['ip' => $ip, 'id' => (int) $user['id']]
        );

        if (password_needs_rehash($user['password'], PASSWORD_BCRYPT, self::HASH_OPTIONS)) {
            Database::execute(
                'UPDATE users SET password = :password WHERE id = :id',
                ['password' => password_hash((string) $data['password'], PASSWORD_BCRYPT, self::HASH_OPTIONS), 'id' => (int) $user['id']]
            );
        }

        AuthHelper::login($user); // regenerates the session id and the CSRF token
        LoggerHelper::audit('auth.login', 'user', (int) $user['id']);

        $this->redirect(AuthHelper::pullIntended('/dashboard'));
    }

    /** POST /logout */
    public function logout(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            LoggerHelper::audit('auth.logout', 'user', AuthHelper::id());
        }

        AuthHelper::logout();

        // logout() destroys the session; open a clean one so the flash message and CSRF token work.
        session_start();
        session_regenerate_id(true);
        $_SESSION['_created'] = time();
        $_SESSION['_last']    = time();
        // Do NOT set '_ua' here. AuthHelper::enforceLifetimes() stores it on the next request
        // using the same browser-family hash it later compares against. Storing a hash of the
        // FULL user agent here made every sign-in right after a sign-out look like a different
        // browser and ended the session immediately.
        $this->flash('info', 'You have been signed out.');

        $this->redirect('/login');
    }

    /* ---------------------------------------------------------------- profile */

    /** GET /profile */
    public function profile(Request $request, array $params): void
    {
        $this->requireLogin();

        $account = Database::fetchOne(
            'SELECT u.id, u.name, u.email, u.phone, u.job_title, u.timezone, u.last_login_at,
                    u.password_changed_at, u.created_at, r.display_name AS role_name
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.id = :id LIMIT 1',
            ['id' => (int) AuthHelper::id()]
        );

        if ($account === null) {
            $this->notFound();
        }

        $this->render('auth/profile', [
            'pageTitle' => 'My profile',
            'account'   => $account,
            'timezones' => DateTimeZone::listIdentifiers(),
        ]);
    }

    /** POST /profile  (name, phone, job title, timezone) */
    public function updateProfile(Request $request, array $params): void
    {
        $this->requireLogin();

        $data = $this->validate([
            'name'      => 'required|string|max:120',
            'phone'     => ['nullable', 'string', 'max:30', 'regex:/^[0-9+().\-\s]+$/'],
            'job_title' => 'nullable|string|max:100',
            'timezone'  => 'required|timezone',
        ], '/profile', ['name' => 'Name', 'phone' => 'Phone', 'job_title' => 'Job title', 'timezone' => 'Timezone']);

        Database::execute(
            'UPDATE users SET name = :name, phone = :phone, job_title = :job_title, timezone = :timezone WHERE id = :id',
            [
                'name'      => $data['name'],
                'phone'     => $data['phone'],
                'job_title' => $data['job_title'],
                'timezone'  => $data['timezone'],
                'id'        => (int) AuthHelper::id(),
            ]
        );

        // Refresh the cached display fields so the new name and timezone show immediately.
        $row = Database::fetchOne(
            'SELECT u.id, u.name, u.email, r.name AS role, u.timezone
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.id = :id LIMIT 1',
            ['id' => (int) AuthHelper::id()]
        );
        if ($row !== null) {
            AuthHelper::syncFromDatabase($row);
        }

        LoggerHelper::audit('profile.updated', 'user', AuthHelper::id());
        $this->flash('success', 'Your profile has been updated.');
        $this->redirect('/profile');
    }

    /** POST /profile/password */
    public function updatePassword(Request $request, array $params): void
    {
        $this->requireLogin();

        $data = $this->validate([
            'current_password' => 'required|string|max:200',
            'password'         => 'required|string|strong_password|confirmed',
        ], '/profile', [
            'current_password' => 'Current password',
            'password'         => 'New password',
        ]);

        $userId  = (int) AuthHelper::id();
        $current = (string) Database::fetchValue('SELECT password FROM users WHERE id = :id LIMIT 1', ['id' => $userId]);

        if (!password_verify((string) $data['current_password'], $current)) {
            LoggerHelper::audit('auth.password_change_failed', 'user', $userId);
            $this->backWithErrors('/profile', ['current_password' => 'The current password is not correct.']);
        }

        if (password_verify((string) $data['password'], $current)) {
            $this->backWithErrors('/profile', ['password' => 'Choose a password you have not used for this account before.']);
        }

        $sql = 'UPDATE users SET password = :password, password_changed_at = UTC_TIMESTAMP()';
        if (SchemaHelper::columnExists('users', 'must_change_password')) {
            $sql .= ', must_change_password = 0';
        }
        $sql .= ' WHERE id = :id';
        Database::execute($sql, [
            'password' => password_hash((string) $data['password'], PASSWORD_BCRYPT, self::HASH_OPTIONS),
            'id'       => $userId,
        ]);

        // A privilege-sensitive change: rotate the session id and CSRF token.
        session_regenerate_id(true);
        CsrfHelper::regenerate();

        LoggerHelper::audit('auth.password_changed', 'user', $userId);
        $this->flash('success', 'Your password has been changed.');
        $this->redirect('/profile');
    }

    /* ---------------------------------------------------------- invitation */

    /** GET /accept-invitation */
    public function acceptInvitation(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            $this->flash('info', 'You are already signed in.');
            $this->redirect('/dashboard');
        }

        $token = trim((string) $request->input('token', ''));
        $invitation = $this->invitationFromToken($token);
        $error = null;
        if ($invitation === null) {
            $error = 'This invitation link is not valid.';
        } elseif (!(new UserInvitation())->isAcceptable($invitation)) {
            $status = (new UserInvitation())->effectiveStatus($invitation);
            $error = match ($status) {
                UserInvitation::STATUS_ACCEPTED => 'This invitation has already been used. Sign in instead.',
                UserInvitation::STATUS_CANCELLED => 'This invitation was cancelled. Ask your administrator for a new one.',
                UserInvitation::STATUS_EXPIRED => 'This invitation has expired. Ask your administrator to resend it.',
                default => 'This invitation cannot be accepted.',
            };
        }

        $this->render('auth/accept_invitation', [
            'pageTitle' => 'Accept invitation',
            'invitation' => $invitation,
            'token' => $token,
            'inviteError' => $error,
        ], 'auth');
    }

    /** POST /accept-invitation */
    public function completeInvitation(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            $this->redirect('/dashboard');
        }

        $token = trim((string) $request->input('token', ''));
        if (RateLimitHelper::tooMany('invitation.accept_failed', $request->ip(), 20, 15)) {
            $this->backWithErrors('/accept-invitation?token=' . rawurlencode($token), [
                'password' => 'Too many attempts. Please wait a few minutes.',
            ]);
        }

        $data = $this->validate([
            'token' => 'required|string|max:128',
            'password' => 'required|string|strong_password|confirmed',
        ], '/accept-invitation?token=' . rawurlencode($token), [
            'password' => 'Password',
        ]);

        $accepted = $request->input('accept_terms') === '1' || $request->input('accept_terms') === 'on';
        $result = (new InvitationService())->accept((string) $data['token'], (string) $data['password'], $accepted);
        if (!$result['ok']) {
            LoggerHelper::audit('invitation.accept_failed', 'invite', null, ['reason' => 'rejected']);
            $this->backWithErrors('/accept-invitation?token=' . rawurlencode((string) $data['token']), [
                'password' => $result['error'],
            ]);
        }

        $this->flash('success', 'Your account is ready. Sign in with your email and the password you just created.');
        $this->redirect('/login');
    }

    /* ------------------------------------------------------- password reset */

    /** GET /forgot-password */
    public function forgotPassword(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            $this->redirect('/dashboard');
        }

        $this->render('auth/forgot_password', ['pageTitle' => 'Reset password'], 'auth');
    }

    /** POST /forgot-password */
    public function sendPasswordReset(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            $this->redirect('/dashboard');
        }

        $data = $this->validate([
            'email' => 'required|email|max:190',
        ], '/forgot-password', ['email' => 'Email']);

        $email = strtolower((string) $data['email']);
        if (RateLimitHelper::tooMany('auth.password_reset_requested', $request->ip(), 5, 15)) {
            $this->flash('danger', 'Too many reset emails from this address. Please wait a few minutes.');
            $this->redirect('/forgot-password');
        }

        $user = Database::fetchOne(
            'SELECT id, name, email, status FROM users WHERE email = :email LIMIT 1',
            ['email' => $email]
        );

        LoggerHelper::audit('auth.password_reset_requested', 'user', $user !== null ? (int) $user['id'] : null, [
            'email_domain' => substr(strrchr($email, '@') ?: '', 1),
        ]);

        if ($user !== null && (string) $user['status'] === 'active' && SchemaHelper::tableExists('password_reset_tokens') && SmtpSettings::enabled()) {
            $token = bin2hex(random_bytes(32));
            Database::execute(
                'UPDATE password_reset_tokens SET used_at = UTC_TIMESTAMP() WHERE user_id = :id AND used_at IS NULL',
                ['id' => (int) $user['id']]
            );
            Database::execute(
                'INSERT INTO password_reset_tokens (user_id, token_hash, expires_at, created_at)
                 VALUES (:user_id, :hash, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 2 HOUR), UTC_TIMESTAMP())',
                ['user_id' => (int) $user['id'], 'hash' => hash('sha256', $token)]
            );
            Mailer::sendTemplate($email, MailTemplate::PASSWORD_RESET, [
                'user_name' => (string) $user['name'],
                'email' => $email,
                'reset_url' => FormatHelper::absoluteUrl('/reset-password?token=' . rawurlencode($token)),
                'expiry_date' => FormatHelper::datetime(gmdate('Y-m-d H:i:s', time() + 7200), 'M j, Y H:i T'),
                'company_name' => SettingsService::appName(),
            ]);
        }

        $this->flash('success', 'If that email is on an account, a reset link has been sent.');
        $this->redirect('/login');
    }

    /** GET /reset-password */
    public function resetPasswordForm(Request $request, array $params): void
    {
        if (AuthHelper::check()) {
            $this->redirect('/dashboard');
        }

        $token = trim((string) $request->input('token', ''));
        $row = $this->passwordResetFromToken($token);

        $this->render('auth/reset_password', [
            'pageTitle' => 'Choose a new password',
            'token' => $token,
            'valid' => $row !== null,
        ], 'auth');
    }

    /** POST /reset-password */
    public function resetPassword(Request $request, array $params): void
    {
        $token = trim((string) $request->input('token', ''));
        $data = $this->validate([
            'token' => 'required|string|max:128',
            'password' => 'required|string|strong_password|confirmed',
        ], '/reset-password?token=' . rawurlencode($token), ['password' => 'Password']);

        $row = $this->passwordResetFromToken((string) $data['token']);
        if ($row === null) {
            $this->flash('danger', 'This reset link is not valid or has expired.');
            $this->redirect('/forgot-password');
        }

        $userId = (int) $row['user_id'];
        $sql = 'UPDATE users SET password = :password, password_changed_at = UTC_TIMESTAMP(), failed_login_attempts = 0, locked_until = NULL';
        if (SchemaHelper::columnExists('users', 'must_change_password')) {
            $sql .= ', must_change_password = 0';
        }
        $sql .= ' WHERE id = :id';
        Database::execute($sql, [
            'password' => password_hash((string) $data['password'], PASSWORD_BCRYPT, self::HASH_OPTIONS),
            'id' => $userId,
        ]);
        Database::execute(
            'UPDATE password_reset_tokens SET used_at = UTC_TIMESTAMP() WHERE id = :id',
            ['id' => (int) $row['id']]
        );

        LoggerHelper::audit('auth.password_reset', 'user', $userId);
        $this->flash('success', 'Your password has been changed. Sign in with the new password.');
        $this->redirect('/login');
    }

    /* ---------------------------------------------------------------- helpers */

    /** @return array<string, mixed>|null */
    private function invitationFromToken(string $token): ?array
    {
        if ($token === '' || !UserInvitation::installed()) {
            return null;
        }

        $row = (new UserInvitation())->findByToken($token);

        return $row === null ? null : (new UserInvitation())->attachAssignments($row);
    }

    /** @return array<string, mixed>|null */
    private function passwordResetFromToken(string $token): ?array
    {
        if ($token === '' || !SchemaHelper::tableExists('password_reset_tokens')) {
            return null;
        }

        return Database::fetchOne(
            'SELECT id, user_id, expires_at, used_at
             FROM password_reset_tokens
             WHERE token_hash = :hash AND used_at IS NULL AND expires_at >= UTC_TIMESTAMP()
             LIMIT 1',
            ['hash' => hash('sha256', $token)]
        );
    }


    private function requireLogin(): void
    {
        (new AuthMiddleware())->handle();
        (new PasswordChangeMiddleware())->handle($this->request);
    }

    /**
     * Count a failed attempt. For a real account this feeds the lockout counter:
     * reaching the limit sets locked_until and resets the counter.
     *
     * @param array<string, mixed>|null $user
     */
    private function recordFailure(?array $user, string $email, string $reason): void
    {
        if ($user !== null && $reason === 'bad_credentials') {
            $max     = max(1, (int) Config::get('security.login_max_attempts', 5));
            $minutes = max(1, (int) Config::get('security.login_lockout_minutes', 15));

            // locked_until is assigned first: MySQL evaluates SET left to right, and it must
            // still see the old attempt counter. Each placeholder is used once (native prepares).
            Database::execute(
                'UPDATE users
                 SET locked_until = IF(failed_login_attempts + 1 >= ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? MINUTE), locked_until),
                     failed_login_attempts = IF(failed_login_attempts + 1 >= ?, 0, failed_login_attempts + 1)
                 WHERE id = ?',
                [$max, $minutes, $max, (int) $user['id']]
            );
        }

        LoggerHelper::audit('auth.login_failed', 'user', $user !== null ? (int) $user['id'] : null, [
            'email'  => substr($email, 0, 190),
            'reason' => $reason,
        ]);
    }

    /** More failures from one address than several legitimate users could cause in the lockout window. */
    private function tooManyFailuresFromIp(string $ip): bool
    {
        $limit   = max(1, (int) Config::get('security.login_max_attempts', 5)) * 4;
        $minutes = max(1, (int) Config::get('security.login_lockout_minutes', 15));

        $count = (int) Database::fetchValue(
            "SELECT COUNT(*) FROM activity_logs
             WHERE action = 'auth.login_failed' AND ip_address = ?
               AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL ? MINUTE)",
            [$ip, $minutes]
        );

        return $count >= $limit;
    }

    private function maintenanceModeOn(): bool
    {
        return SettingsService::systemBool('maintenance_mode', false);
    }
}