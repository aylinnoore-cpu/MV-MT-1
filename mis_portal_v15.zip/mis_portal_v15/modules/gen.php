<?php require __DIR__.'/../includes/lib.php';allow(['support','ed','finance']);
$k=($_GET['k']??'cs')=='po'?'po':'cs';$mis=role()=='support';$title=$k=='po'?'Purchase Orders':'Comparative Statements';
function nextpo(){$m=176;foreach(q('SELECT po_no FROM generated WHERE kind="po"') as $r)if(preg_match('/(\d+)\s*$/',(string)$r['po_no'],$x))$m=max($m,(int)$x[1]);return 'MAVEN/PO/'.($m+1);}
function dflt($k){return $k=='po'?['title'=>'PURCHASE ORDER','po_no'=>nextpo(),'start_date'=>date('d-m-Y'),'first_name'=>'Maven Projects','first_address'=>'11th Floor AJ Tower, Gulberg Greens, Islamabad.','second_name'=>'','quote_ref'=>'','ntn'=>'','contact'=>'',
 'intro1'=>'Maven Projects LLP, referred to as the FIRST PARTY, intends to procure the items listed below for its operational and project requirements.',
 'intro2'=>'WHEREAS, under this WORK ORDER, the SECOND PARTY shall supply the goods and related equipment of reliable quality in a timely and efficient manner. The SECOND PARTY shall be responsible for ensuring the technical specifications, performance, and warranty support of the supplied products and shall abide by the Terms and Conditions of this contract.',
 'intro3'=>'M/S Maven Projects LLP hereby awards you this PURCHASE ORDER to proceed in accordance with the agreed Terms and Conditions.',
 'terms'=>"Maven Projects LLP shall have a reasonable time to inspect and test the products provided under this Agreement and reject any or all items that are nonconforming or defective.\nPrices are exclusive of GST.\nThe Freight charges are included & shall not be subject to any increase for any reason whatsoever.\n100% payment on Delivery; Delivery Time: ___ working days.\nAny handwritten changes on the face of this document shall be ignored and have no legal effect unless initiated by both parties."]
 :['title'=>'Comparative Statement','company'=>'Maven Project LLP','date'=>date('d-F-Y'),'ref_no'=>'','note'=>'NOTE: All prices are exclusive of applicable taxes.','recommendation'=>''];}
function build($k,$f){$g=($f['h']??[])+dflt($k);$items=[];
 foreach($f['rows'] as $r){if(trim($r['name'])==='')continue;$q=(float)$r['qty'];$it=['item.no'=>count($items)+1,'item.name'=>$r['name'],'item.unit'=>$r['unit'],'item.qty'=>$q];
  for($j=0;$j<3;$j++){$p=(float)($r['p'][$j]??0);$it['item.v'.($j+1)]=$p?:'N/A';}
  $it['item.unit_price']=$it['item.v1']==='N/A'?'':$it['item.v1'];$it['item.total']=$it['item.unit_price']!==''?$it['item.unit_price']*$q:'';$items[]=$it;}
 for($j=0;$j<3;$j++){$g['v'.($j+1).'.name']=$f['vendors'][$j]??'';$g['v'.($j+1).'.cond']=$f['cond'][$j]??'';}
 if($k=='po'){$ls=array_values(array_filter(array_map('trim',explode("\n",$g['terms']))));foreach($ls as $i=>$l)$ls[$i]=($i+1).'. '.$l;$g['terms']=implode("\n",$ls);}
 $sub=array_sum(array_map('floatval',array_column($items,'item.total')));$d=(float)($f['discount']??0);return [$g+['subtotal'=>$sub,'discount'=>$d,'grand_total'=>$sub-$d],$items];}
function css(){return '.doc{border-collapse:collapse;width:100%;max-width:900px;margin:0 auto;background:#fff;font:13px Arial,sans-serif;table-layout:fixed;color:#000}.doc td,.doc th{border:1px solid #000;padding:5px 6px;vertical-align:top;word-wrap:break-word}
.doc input,.doc textarea{width:100%;max-width:none;border:0;background:#fffbe6;font:inherit;padding:2px;box-sizing:border-box;resize:vertical}.c{text-align:center}.r{text-align:right}.b{font-weight:bold}.big{font-size:20px}.band{background:#e7e6e6;font-weight:bold}
.fl{display:flex;gap:6px;align-items:center}.fl input{flex:1}.sigt{width:100%;border-collapse:collapse;table-layout:fixed}.sigt td{border:1px solid #000;padding:4px}.sg{height:95px;vertical-align:bottom;text-align:center}.sg img{height:55px;display:block;margin:0 auto 3px}
.sm{font-size:10px}.x{background:#a33;color:#fff;border:0;border-radius:3px;float:right;cursor:pointer;margin-left:4px}.nb{border:0!important}';}
function E($ed,$n,$v,$o=[]){if(!$ed)return nl2br(h($v));$al=$o['al']??'';$ph=h($o['ph']??'');
 return !empty($o['ta'])?'<textarea name="'.$n.'" rows='.($o['rows']??2).' placeholder="'.$ph.'" style="text-align:'.$al.'">'.h($v).'</textarea>':'<input name="'.$n.'" value="'.h($v).'" placeholder="'.$ph.'" style="text-align:'.$al.'"'.(empty($o['num'])?'':' type=number step=any').'>';}
function N($v){return is_numeric($v)?rtrim(rtrim(number_format((float)$v,2),'0'),'.'):h($v);}
function irow($k,$i,$r){$o='<tr class=ir><td class="c sn"></td><td><button type=button class="x" onclick="rm(this)" title="Remove row">&times;</button>'.E(1,'name[]',$r['name'],['ta'=>1,'rows'=>3,'ph'=>'Item description']).'</td><td>'.E(1,'unit[]',$r['unit'],['al'=>'center']).($k=='po'?'':'<input type=hidden name="qty[]" value=1>').'</td>';
 if($k=='po')$o.='<td>'.E(1,"p[$i][0]",$r['p'][0]??'',['num'=>1,'al'=>'right']).'</td><td>'.E(1,'qty[]',$r['qty'],['num'=>1,'al'=>'center']).'</td><td class="r am"></td>';
 else for($j=0;$j<3;$j++)$o.='<td>'.E(1,"p[$i][$j]",$r['p'][$j]??'',['num'=>1,'al'=>'right','ph'=>'N/A']).'</td>';return $o.'</tr>';}
function sigs($gid){$S=[];foreach(q('SELECT s.*,u.name,a.doc_id sigdoc FROM doc_signatures s JOIN users u ON u.id=s.user_id JOIN signatories a ON a.id=s.signatory_id WHERE s.gen_id=?',[$gid]) as $s)$S[$s['slot']]=$s;return $S;}
function doc($k,$f,$ed,$sg=[],$xls=false){[$g,$items]=build($k,$f);$h=$g;$H=fn($n,$o=[])=>E($ed,"h[$n]",$h[$n]??'',$o);$o='<table class=doc>';
 if($k=='cs'){$o.='<tr><td colspan=6 class="c b big">'.$H('title',['al'=>'center']).'</td></tr><tr><td colspan=6 class="c b">'.$H('company',['al'=>'center']).'</td></tr>'
  .'<tr><td colspan=6 class=b><div class=fl>DATE: '.$H('date').'</div></td></tr><tr><td colspan=6 class=b><div class=fl>REF NO: '.$H('ref_no').'</div></td></tr>'
  .'<tr class="band c"><td rowspan=3 style="width:6%">SNo</td><td rowspan=3 style="width:40%">Item</td><td rowspan=3 style="width:8%">Unit</td><td>Vendor #1</td><td>Vendor #2</td><td>Vendor #3</td></tr><tr class=c>';
  for($j=0;$j<3;$j++)$o.='<td class=b>'.E($ed,'vendor[]',$f['vendors'][$j]??'',['al'=>'center','ph'=>'Vendor name']).'</td>';$o.='</tr><tr class="band c"><td>Unit Rate</td><td>Unit Rate</td><td>Unit Rate</td></tr>';}
 else{$o.='<colgroup><col style="width:10%"><col style="width:42%"><col style="width:8%"><col style="width:14%"><col style="width:8%"><col style="width:18%"></colgroup><tr><td colspan=6 class="c b big">'.$H('title',['al'=>'center']).'</td></tr>'
  .'<tr><td colspan=6 class=band>FIRST PARTY</td></tr><tr><td class=b>Name</td><td colspan=2>'.$H('first_name').'</td><td colspan=2 class=b>Purchase Order #</td><td class=b>'.$H('po_no').'</td></tr>'
  .'<tr><td class=b>Address</td><td colspan=2>'.$H('first_address',['ta'=>1]).'</td><td colspan=2 class=b>Start Date</td><td>'.$H('start_date').'</td></tr><tr><td colspan=6 class=band>SECOND PARTY</td></tr>'
  .'<tr><td class=b>Name</td><td colspan=2>'.$H('second_name',['ph'=>'Vendor name']).'</td><td colspan=2 class=b>Quotation Ref #:</td><td>'.$H('quote_ref').'</td></tr>'
  .'<tr><td class=b>NTN/Sales Tax Reg</td><td colspan=2>'.$H('ntn').'</td><td colspan=3></td></tr><tr><td class=b>Contact #</td><td colspan=2>'.$H('contact').'</td><td colspan=3></td></tr>';
  foreach(['intro1','intro2','intro3'] as $n)$o.='<tr><td colspan=6>'.$H($n,['ta'=>1,'rows'=>3]).'</td></tr>';
  $o.='<tr class="band c"><td>Sr No.</td><td>Description</td><td>Unit</td><td>Unit Rate (PKR)</td><td>Qty</td><td>Amount (PKR)</td></tr>';}
 if($ed){foreach($f['rows'] as $i=>$r)$o.=irow($k,$i,$r);}
 else foreach($items as $it){$o.='<tr><td class=c>'.$it['item.no'].'</td><td>'.nl2br(h($it['item.name'])).'</td><td class=c>'.h($it['item.unit']).'</td>';
  $o.=$k=='po'?'<td class=r>'.N($it['item.unit_price']).'</td><td class=c>'.N($it['item.qty']).'</td><td class=r>'.N($it['item.total']).'</td>':'<td class=r>'.N($it['item.v1']).'</td><td class=r>'.N($it['item.v2']).'</td><td class=r>'.N($it['item.v3']).'</td>';$o.='</tr>';}
 if($k=='cs'){$o.='<tr><td colspan=3 class=b>Condition</td>';for($j=0;$j<3;$j++)$o.='<td class=c>'.E($ed,'cond[]',$f['cond'][$j]??'New',['al'=>'center']).'</td>';
  $o.='</tr><tr><td colspan=6 class=b>'.$H('note').'</td></tr><tr><td colspan=6 class=b>'.$H('recommendation',['ta'=>1,'ph'=>'We recommend ____, as they offer ____.']).'</td></tr>';}
 else{$o.='<tr><td colspan=5 class="b r">Total</td><td class="r b" id=sub>'.($ed?'':N($g['subtotal'])).'</td></tr><tr><td colspan=5 class="b r">Discount</td><td class=r>'.($ed?'<input name=discount id=disc type=number step=any value="'.h($f['discount']??0).'" style="text-align:right">':N($g['discount'])).'</td></tr>'
  .'<tr><td colspan=5 class="b r">Grand Total</td><td class="r b" id=gt>'.($ed?'':N($g['grand_total'])).'</td></tr><tr><td colspan=6 class=band>TERMS AND CONDITIONS</td></tr><tr><td colspan=6>'.($ed?E(1,'h[terms]',$h['terms'],['ta'=>1,'rows'=>7,'ph'=>'One term per line - numbered automatically']):nl2br(h($g['terms']))).'</td></tr>';}
 $sl=slots();$o.='<tr><td colspan=6 style="padding:0;border:0"><table class=sigt><tr>'.($k=='po'?'<td class=sg></td>':'');
 foreach($sl as $s=>$lb){$x=$sg[$s]??null;$o.='<td class=sg>';if($x){if(!$xls&&$x['sigdoc'])$o.='<img src="file.php?id='.$x['sigdoc'].'">';$o.='<div class=sm>Sig ID: '.h($x['code']).'<br>'.h($x['name']).' | '.h(substr($x['signed_at'],0,16)).'</div>';}
  elseif($ed)$o.='<div class=sm style="color:#999">digital signature applied on approval</div>';$o.='</td>';}
 $o.='</tr><tr>'.($k=='po'?'<td class="c b">Second Party</td>':'');foreach($sl as $lb)$o.='<td class="c b">'.h($lb).'</td>';$o.='</tr></table></td></tr>';
 if(!$ed)$o.='<tr><td colspan=6 class="sm nb"><i>Signatures can be verified at '.h((isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].BASE.'/verify.php').' using the Sig ID.</i></td></tr>';
 return $o.'</table>';}
if(in_array($_GET['a']??'',['view','xls'])){$r=q('SELECT * FROM generated WHERE id=? AND kind=?',[(int)$_GET['id'],$k])->fetch()?:die('Not found');$f=json_decode($r['data'],true);$nm=$r['po_no']?preg_replace('/[^\w-]/','-',$r['po_no']):'Comparative-'.$r['id'];
 if($_GET['a']=='xls'){header('Content-Type: application/vnd.ms-excel; charset=utf-8');header("Content-Disposition: attachment; filename=\"$nm.xls\"");echo '<meta charset=utf-8><style>'.css().'</style>'.doc($k,$f,0,sigs($r['id']),true);exit;}
 echo '<!doctype html><meta charset=utf-8><title>'.h($nm).'</title><style>body{background:#eee;margin:0;padding:10px}@media print{.noprint{display:none}body{background:#fff;padding:0}}'.css().'</style>
 <div class=noprint style="max-width:900px;margin:0 auto 10px;font:14px sans-serif"><a href="gen.php?k='.$k.'">&larr; Back</a> &nbsp; <button onclick=print()>Print / Save as PDF</button> &nbsp; <a href="gen.php?k='.$k.'&a=xls&id='.$r['id'].'">Download Excel</a>'.($mis?' &nbsp; <a href="gen.php?k='.$k.'&edit='.$r['id'].'">Edit</a>':'').'</div>'.doc($k,$f,0,sigs($r['id']));exit;}
if($_SERVER['REQUEST_METHOD']=='POST'){chk();$bk="Location: gen.php?k=$k";
 if(isset($_POST['sign'])){$gid=(int)$_POST['sign'];$slot=$_POST['slot'];$a=q('SELECT * FROM signatories WHERE user_id=? AND slot=? AND active=1',[me()['id'],$slot])->fetch();$g=q('SELECT * FROM generated WHERE id=?',[$gid])->fetch();
  if(!$a||!$g||q('SELECT 1 FROM doc_signatures WHERE gen_id=? AND slot=?',[$gid,$slot])->fetch())die('Not allowed or already signed');
  do{$code='SIG-'.strtoupper(bin2hex(random_bytes(6)));}while(q('SELECT 1 FROM doc_signatures WHERE code=?',[$code])->fetch());
  q('INSERT INTO doc_signatures(gen_id,slot,signatory_id,user_id,code,doc_hash)VALUES(?,?,?,?,?,?)',[$gid,$slot,$a['id'],me()['id'],$code,hash('sha256',$g['data'])]);logit("Signed document #$gid as ".slots()[$slot]." ($code)");header($bk);exit;}
 if(!$mis)die('Access denied');
 $rows=[];foreach($_POST['name']??[] as $i=>$n)$rows[]=['name'=>$n,'unit'=>$_POST['unit'][$i]??'No','qty'=>$_POST['qty'][$i]??1,'p'=>$_POST['p'][$i]??[]];
 $f=['pid'=>(int)$_POST['pid'],'cid'=>$_POST['cid']??'','h'=>array_map(fn($v)=>trim((string)$v),$_POST['h']??[]),'vendors'=>$_POST['vendor']??[],'cond'=>$_POST['cond']??[],'rows'=>$rows,'discount'=>$_POST['discount']??0];
 if(!array_filter($rows,fn($r)=>trim($r['name'])!==''))die('Add at least one item');$gid=(int)($_POST['gid']??0);$po=$k=='po'?($f['h']['po_no']??''):null;
 if($po&&q('SELECT 1 FROM generated WHERE kind="po" AND po_no=? AND id<>?',[$po,$gid])->fetch()){$_SESSION['err']="PO number $po already exists.";header($bk.($gid?"&edit=$gid":'&new=1'));exit;}
 $js=json_encode($f);$pid=$f['pid']?:null;$cid=$f['cid']?:null;
 if($gid){q('UPDATE generated SET procurement_id=?,comparative_id=?,po_no=?,data=? WHERE id=? AND kind=?',[$pid,$cid,$po,$js,$gid,$k]);$cl=q('SELECT slot,code,user_id,signed_at FROM doc_signatures WHERE gen_id=?',[$gid])->fetchAll();if($cl)log_delete('Document signatures',$gid,($po?:'Comparative statement #'.$gid),['cleared'=>$cl],'Document edited - signatures cleared');q('DELETE FROM doc_signatures WHERE gen_id=?',[$gid]);}
 else{q('INSERT INTO generated(kind,procurement_id,comparative_id,po_no,data,created_by)VALUES(?,?,?,?,?,?)',[$k,$pid,$cid,$po,$js,me()['id']]);$gid=$GLOBALS['pdo']->lastInsertId();}
 logit("Saved ".($po?:'comparative statement')." (#$gid)");header($bk.'&a=view&id='.$gid);exit;}
head($title);if(!empty($_SESSION['err'])){echo '<p class=err>'.h($_SESSION['err']).'</p>';unset($_SESSION['err']);}
$edit=(int)($_GET['edit']??0);
if($mis&&($edit||isset($_GET['new']))){$ed=$edit?q('SELECT * FROM generated WHERE id=? AND kind=?',[$edit,$k])->fetch():null;
 $f=$ed?json_decode($ed['data'],true):['h'=>[],'vendors'=>[],'cond'=>['New','New','New'],'rows'=>[['name'=>'','unit'=>'No','qty'=>1,'p'=>[]]],'discount'=>0];
 echo '<style>'.css().'</style><form method=post class=noprint-x><input type=hidden name=c value="'.csrf().'"><input type=hidden name=gid value='.$edit.'><div class=card><label>Linked procurement request (optional)</label><select name=pid><option value=0>-- none --</option>';
 foreach(q('SELECT id,title FROM procurement ORDER BY id DESC') as $x)echo "<option value=$x[id]".($x['id']==($f['pid']??(int)($_GET['p']??0))?' selected':'').">#$x[id] ".h($x['title']).'</option>';echo '</select>';
 if($k=='po'){echo '<label>Linked comparative statement (optional)</label><select name=cid><option value="">-- none --</option>';foreach(q('SELECT id,procurement_id,created_at FROM generated WHERE kind="cs" ORDER BY id DESC') as $x)echo "<option value=$x[id]".($x['id']==($f['cid']??0)?' selected':'').">CS #$x[id] ($x[created_at])</option>";echo '</select>';}
 if($k=='po'){echo '<label>Fill second party details from a vendor</label><select id=vsel><option value="">-- choose vendor --</option>';foreach(q('SELECT id,name FROM vendors ORDER BY name') as $v)echo "<option value=$v[id]>".h($v['name']).'</option>';echo '</select>';}
 echo '<p style="color:#6b7385;margin-bottom:0">Type directly into the highlighted cells of the official format below. '.($ed?'Saving clears existing signatures.':'').'</p></div>'.doc($k,$f,1)
 .'<p style="text-align:center"><button type=button class="btn g" onclick="add()">+ Add item row</button> <button>'.($ed?'Save changes':'Save document').'</button> <a class="btn g" href="gen.php?k='.$k.'">Cancel</a></p></form>
 <script>var VJ='.json_encode(array_column(q('SELECT id,name,ntn,contact_person,phone FROM vendors')->fetchAll(),null,'id'),JSON_HEX_TAG).',T=document.querySelector(".doc"),PO='.($k=='po'?1:0).';function rows(){return T.querySelectorAll("tr.ir")}
 function rn(){rows().forEach(function(r,i){r.querySelector(".sn").textContent=i+1;r.querySelectorAll("input,textarea").forEach(function(e){e.name=e.name.replace(/p\[\d+\]/,"p["+i+"]")})});calc()}
 function add(){var l=rows(),c=l[l.length-1].cloneNode(true);c.querySelectorAll("input,textarea").forEach(function(e){if(e.type!="hidden"&&!/unit|qty/.test(e.name))e.value=""});l[l.length-1].after(c);rn()}
 function rm(b){if(rows().length>1){b.closest("tr").remove();rn()}}
 function calc(){if(!PO)return;var s=0;rows().forEach(function(r){var p=parseFloat(r.querySelector("[name^=\"p[\"]").value)||0,q=parseFloat(r.querySelector("[name=\"qty[]\"]").value)||0;r.querySelector(".am").textContent=p&&q?(p*q).toLocaleString():"";s+=p*q});
  document.getElementById("sub").textContent=s.toLocaleString();document.getElementById("gt").textContent=(s-(parseFloat(document.getElementById("disc").value)||0)).toLocaleString()}
 T.addEventListener("input",calc);rn();var vs=document.getElementById("vsel");if(vs)vs.onchange=function(){var v=VJ[vs.value];if(!v)return;[["second_name",v.name],["ntn",v.ntn||""],["contact",((v.contact_person||"")+" "+(v.phone||"")).trim()]].forEach(function(p){var e=document.querySelector("[name=\\"h["+p[0]+"]\\"]");if(e)e.value=p[1]})}</script>';foot();exit;}
$S=[];foreach(q('SELECT s.*,u.name FROM doc_signatures s JOIN users u ON u.id=s.user_id') as $s)$S[$s['gen_id']][$s['slot']]=$s;
$mine=array_column(q('SELECT slot FROM signatories WHERE user_id=? AND active=1',[me()['id']])->fetchAll(),'slot');
if($mis)echo '<p><a class=btn href="gen.php?k='.$k.'&new=1">+ New '.($k=='po'?'purchase order':'comparative statement').'</a></p>';
echo '<div class=card><table><tr><th>#<th>Request<th>'.($k=='po'?'PO no.<th>Vendor<th>':'').'Created<th>Signatures<th>';
foreach(q('SELECT g.*,p.title FROM generated g LEFT JOIN procurement p ON p.id=g.procurement_id WHERE g.kind=? ORDER BY g.id DESC',[$k]) as $x){$d=json_decode($x['data'],true);
 echo "<tr><td>$x[id]<td>".($x['procurement_id']?"#$x[procurement_id] ".h($x['title']):'-').($k=='po'?"<td>$x[po_no]<td>".h($d['h']['second_name']??''):'')."<td>$x[created_at]<td>";
 foreach(slots() as $sl=>$lb){$s=$S[$x['id']][$sl]??null;
  if($s)echo '&#10004; '.h($lb).': '.h($s['name']).' <small>('.h($s['code']).')</small><br>';
  elseif(in_array($sl,$mine))echo '<form method=post style=display:inline onsubmit="return confirm(\'Apply your signature as '.h($lb).'?\')"><input type=hidden name=c value="'.csrf().'"><input type=hidden name=sign value='.$x['id'].'><button name=slot value='.$sl.' class=btn style="padding:2px 8px;margin:1px">Sign as '.h($lb).'</button></form><br>';
  else echo h($lb).': pending<br>';}
 echo "<td><a href='gen.php?k=$k&a=view&id=$x[id]' target=_blank>View / Print</a> | <a href='gen.php?k=$k&a=xls&id=$x[id]'>Excel</a>".($mis?" | <a href='gen.php?k=$k&edit=$x[id]'>Edit</a>":'');}
echo '</table></div>';foot();
