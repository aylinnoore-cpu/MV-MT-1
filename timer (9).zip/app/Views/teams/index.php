<?php
/**
 * Department setup: departments grouped by project, with team managers and members.
 *
 * @var bool $ready
 * @var list<array<string, mixed>> $rows
 * @var array<int, list<array<string, mixed>>> $teams
 * @var array<int, list<array{id: int, name: string}>> $members
 * @var list<array<string, mixed>> $projects
 * @var int $projectId
 * @var string $search
 */

$byProject = [];
foreach ($rows as $row) {
    $byProject[(int) $row['project_id']][] = $row;
}
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Department setup</h2>
        <p class="page-lead">Build the approval hierarchy: project &rarr; department manager &rarr; team manager &rarr; members.</p>
    </div>
    <?php if ($ready): ?>
        <a class="btn btn-primary" href="<?= e(url('/teams/create' . ($projectId > 0 ? '?project_id=' . $projectId : ''))) ?>">
            <i class="fa-solid fa-plus me-1" aria-hidden="true"></i>New department
        </a>
    <?php endif; ?>
</div>

<?php if (!$ready): ?>
    <div class="alert alert-warning" role="alert">
        Department tables are not installed yet. Run <code>database/UPGRADE_LIVE.sql</code> on the live database, then reload this page.
    </div>
<?php else: ?>
    <div class="alert alert-info small" role="note">
        <div class="fw-semibold mb-1"><i class="fa-solid fa-sitemap me-1" aria-hidden="true"></i>Who approves a timesheet</div>
        Approvals follow this hierarchy: team manager, then department manager, then project manager, then admins.
        Who can open Approvals, and who is notified in-app or by email, is set under Workspace &rarr; Features &amp; policies.
        Department and project managers are not emailed on submission unless you turn that on.
    </div>

    <form method="get" action="<?= e(url('/teams')) ?>" class="filter-bar">
        <div class="filter-search">
            <label for="team-q" class="visually-hidden">Search departments</label>
            <input type="search" id="team-q" name="q" class="form-control" placeholder="Search department, team or project" value="<?= e($search) ?>">
        </div>
        <div>
            <label for="team-project" class="visually-hidden">Project</label>
            <select id="team-project" name="project_id" class="form-select">
                <option value="0">All projects</option>
                <?php foreach ($projects as $project): ?>
                    <option value="<?= (int) $project['id'] ?>"<?= $projectId === (int) $project['id'] ? ' selected' : '' ?>><?= e((string) $project['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-outline-secondary">Filter</button>
    </form>

    <?php if ($byProject === []): ?>
        <section class="panel">
            <div class="empty-state">
                <i class="fa-solid fa-sitemap" aria-hidden="true"></i>
                <p><?= $search !== '' || $projectId > 0 ? 'No departments match these filters.' : 'No departments yet. Create a department under a project to start routing approvals.' ?></p>
            </div>
        </section>
    <?php endif; ?>

    <?php foreach ($byProject as $pid => $departments): ?>
        <?php $first = $departments[0]; ?>
        <section class="panel mb-4">
            <div class="panel-head">
                <h2 class="panel-title">
                    <?= e((string) $first['project_name']) ?>
                    <span class="count-pill"><?= count($departments) ?></span>
                </h2>
                <div class="small">
                    <i class="fa-solid fa-user-tie me-1" aria-hidden="true"></i>Project manager:
                    <?php if (!empty($first['project_manager_name'])): ?>
                        <strong><?= e((string) $first['project_manager_name']) ?></strong>
                    <?php else: ?>
                        <span class="text-warning">not set</span>
                        <a href="<?= e(url('/projects/' . (int) $pid . '/edit')) ?>">set on project</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php foreach ($departments as $dept): ?>
                <?php $teamList = $teams[(int) $dept['id']] ?? []; ?>
                <div class="dept-card">
                    <div class="dept-card-head">
                        <div>
                            <h3 class="dept-card-title"><?= e((string) $dept['name']) ?></h3>
                            <div class="small text-muted">
                                Department manager:
                                <?php if (!empty($dept['manager_name'])): ?>
                                    <strong><?= e((string) $dept['manager_name']) ?></strong>
                                <?php else: ?>
                                    <span class="text-warning">not set</span>
                                <?php endif; ?>
                                <span class="status-badge status-<?= (string) $dept['status'] === 'active' ? 'completed' : 'planning' ?> ms-2"><?= e(ucfirst((string) $dept['status'])) ?></span>
                            </div>
                        </div>
                        <div class="d-flex gap-2">
                            <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/teams/' . (int) $dept['id'] . '/edit')) ?>">Edit</a>
                            <?php
                            $taskCount = (int) ($dept['task_count'] ?? 0);
                            $confirm = 'Delete department "' . (string) $dept['name'] . '"? Members keep their accounts and project access.';
                            if ($taskCount > 0) {
                                $confirm .= ' ' . $taskCount . ' open task' . ($taskCount === 1 ? '' : 's') . ' will become project-level.';
                            }
                            ?>
                            <form method="post" action="<?= e(url('/teams/' . (int) $dept['id'] . '/delete')) ?>" class="d-inline"
                                  data-confirm="<?= e($confirm) ?>">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </div>
                    </div>
                    <?php if ($teamList === []): ?>
                        <p class="small text-muted mb-0 px-3 pb-3">No team managers yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table data-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Team</th>
                                        <th>Team manager</th>
                                        <th>Members</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($teamList as $team): ?>
                                        <?php $list = $members[(int) $team['id']] ?? []; ?>
                                        <tr>
                                            <td class="fw-semibold"><?= e((string) $team['name']) ?></td>
                                            <td><?= !empty($team['manager_name']) ? e((string) $team['manager_name']) : '<span class="text-muted">—</span>' ?></td>
                                            <td>
                                                <?php if ($list === []): ?>
                                                    <span class="text-muted">No members</span>
                                                <?php else: ?>
                                                    <span class="count-pill"><?= count($list) ?></span>
                                                    <span class="small text-muted"><?= e(implode(', ', array_map(static fn (array $m): string => $m['name'], array_slice($list, 0, 4)))) ?><?= count($list) > 4 ? ' +' . (count($list) - 4) . ' more' : '' ?></span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endforeach; ?>
<?php endif; ?>
<style>
.dept-card { border-top: 1px solid var(--tt-line); }
.dept-card-head { display:flex; justify-content:space-between; align-items:flex-start; gap:1rem; padding:1rem 1.15rem .75rem; flex-wrap:wrap; }
.dept-card-title { font-size:1.05rem; margin:0 0 .2rem; }
</style>
