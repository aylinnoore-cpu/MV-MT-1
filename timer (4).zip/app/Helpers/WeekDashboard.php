<?php
/**
 * Data for the Clockify-style weekly team dashboard (workspace week start, viewer timezone).
 *
 * Returns: per-day totals stacked by project, per-project totals, top project/client,
 * and a "team activities" list (latest entry, running timer, week total per person).
 *
 * SECURITY: every value is bound as a parameter; column names come only from
 * TimeEntry::column() (a whitelist built from the live table), never from the request.
 * The only request value used here is the week date, which is validated as Y-m-d.
 * Project visibility follows the same rule as the rest of the app (view_all, or
 * manager / creator / member of the project).
 */

declare(strict_types=1);

final class WeekDashboardHelper
{
    /** Clockify-like palette, assigned to projects by rank (largest first). */
    public const PALETTE = [
        '#8d6e63', '#039be5', '#689f38', '#009688', '#f9a825',
        '#ab47bc', '#ef5350', '#5c6bc0', '#26a69a', '#ff7043',
    ];

    /**
     * @param list<int>|null $restrictUserIds Limit entries and people to these users. null = everyone in scope.
     * @return array<string, mixed>
     */
    public static function build(
        int $userId,
        bool $viewAll,
        ?string $weekDate = null,
        bool $onlyMe = false,
        string $range = 'week',
        ?string $anchorDate = null,
        ?array $restrictUserIds = null,
        bool $includeTeamOverview = false,
        bool $managedTeamsOnly = false
    ): array
    {
        $tz  = new DateTimeZone(FormatHelper::displayTimezone());
        $utc = new DateTimeZone('UTC');

        $weekMod = WorkspacePolicy::weekModifier();
        $range = strtolower(trim($range));
        if (!in_array($range, ['today', 'week', 'month', 'last30', 'past2weeks', 'year'], true)) {
            $range = 'week';
        }

        $rawAnchor = $anchorDate !== null && $anchorDate !== '' ? $anchorDate : $weekDate;
        $anchor = null;
        if ($rawAnchor !== null && preg_match('/^\d{4}-\d{2}-\d{2}$/', $rawAnchor) === 1) {
            $anchor = DateTimeImmutable::createFromFormat('!Y-m-d', $rawAnchor, $tz) ?: null;
        }
        $anchor ??= new DateTimeImmutable('today', $tz);
        $anchor = $anchor->setTime(0, 0, 0);

        if ($range === 'today') {
            $periodStart = $anchor;
            $periodEnd = $anchor->modify('+1 day');
            $prevAnchor = $anchor->modify('-1 day');
            $nextAnchor = $anchor->modify('+1 day');
        } elseif ($range === 'month') {
            $periodStart = $anchor->modify('first day of this month')->setTime(0, 0, 0);
            $periodEnd = $periodStart->modify('+1 month');
            $prevAnchor = $periodStart->modify('-1 month');
            $nextAnchor = $periodStart->modify('+1 month');
        } elseif ($range === 'last30') {
            $periodStart = $anchor->modify('-29 days');
            $periodEnd = $anchor->modify('+1 day');
            $prevAnchor = $anchor->modify('-30 days');
            $nextAnchor = $anchor->modify('+30 days');
        } elseif ($range === 'past2weeks') {
            $periodStart = $anchor->modify('-13 days');
            $periodEnd = $anchor->modify('+1 day');
            $prevAnchor = $anchor->modify('-14 days');
            $nextAnchor = $anchor->modify('+14 days');
        } elseif ($range === 'year') {
            $periodStart = $anchor->modify('first day of January')->setTime(0, 0, 0);
            $periodEnd = $periodStart->modify('+1 year');
            $prevAnchor = $periodStart->modify('-1 year');
            $nextAnchor = $periodStart->modify('+1 year');
        } else {
            $periodStart = $anchor->modify($weekMod)->setTime(0, 0, 0);
            $periodEnd = $periodStart->modify('+7 days');
            $prevAnchor = $periodStart->modify('-7 days');
            $nextAnchor = $periodStart->modify('+7 days');
        }

        $startUtc = $periodStart->setTimezone($utc)->format('Y-m-d H:i:s');
        $endUtc   = $periodEnd->setTimezone($utc)->format('Y-m-d H:i:s');

        $dayCount = max(1, (int) $periodStart->diff($periodEnd)->days);
        $days = [];
        for ($i = 0; $i < $dayCount; $i++) {
            $d = $periodStart->modify("+{$i} days");
            $days[$i] = [
                'date'     => $d->format('Y-m-d'),
                'label'    => in_array($range, ['month', 'year'], true) ? $d->format('M j') : $d->format('D, M j'),
                'seconds'  => 0,
                'projects' => [],
            ];
        }

        $today = new DateTimeImmutable('today', $tz);
        $currentWeekStart = $today->modify($weekMod)->setTime(0, 0, 0);
        $currentStart = $range === 'today'
            ? $today
            : ($range === 'month'
                ? $today->modify('first day of this month')->setTime(0, 0, 0)
                : ($range === 'last30'
                    ? $today->modify('-29 days')
                    : ($range === 'past2weeks'
                        ? $today->modify('-13 days')
                        : ($range === 'year' ? $today->modify('first day of January')->setTime(0, 0, 0) : $currentWeekStart))));
        $currentEnd = $range === 'today'
            ? $today->modify('+1 day')
            : ($range === 'month'
                ? $currentStart->modify('+1 month')
                : ($range === 'last30' || $range === 'past2weeks'
                    ? $today->modify('+1 day')
                    : ($range === 'year' ? $currentStart->modify('+1 year') : $currentStart->modify('+7 days'))));
        $labelEnd = $periodEnd->modify('-1 day');
        if ($range === 'today') {
            $rangeLabel = $periodStart->format('M j, Y');
        } elseif ($range === 'month') {
            $rangeLabel = $periodStart->format('F Y');
        } elseif ($range === 'last30' || $range === 'past2weeks') {
            $rangeLabel = $periodStart->format('M j') . ' - ' . $labelEnd->format('M j, Y');
        } elseif ($range === 'year') {
            $rangeLabel = $periodStart->format('Y');
        } else {
            $rangeLabel = $periodStart->format('M j') . ' - ' . $labelEnd->format('M j, Y');
        }

        $result = [
            'range'       => $range,
            'anchor_date' => $anchor->format('Y-m-d'),
            'week_start'  => $periodStart->format('Y-m-d'),
            'week_end'    => $labelEnd->format('Y-m-d'),
            'prev_week'   => $prevAnchor->format('Y-m-d'),
            'next_week'   => $nextAnchor->format('Y-m-d'),
            'prev_date'   => $prevAnchor->format('Y-m-d'),
            'next_date'   => $nextAnchor->format('Y-m-d'),
            'is_current'  => $periodStart->format('Y-m-d') === $currentStart->format('Y-m-d') && $periodEnd->format('Y-m-d') === $currentEnd->format('Y-m-d'),
            'range_label' => $rangeLabel,
            'only_me'     => $onlyMe,
            'total'       => 0,
            'days'        => $days,
            'projects'    => [],
            'top_project' => null,
            'top_client'  => null,
            'people'      => [],
            'teams'       => [],
            'managed_team_count' => 0,
            'ready'       => false,
        ];

        $startCol = self::column('start_time');
        $durCol   = self::column('duration_seconds');
        if ($startCol === null || $durCol === null || !self::tableExists('time_entries')) {
            return $result;
        }
        $result['ready'] = true;

        // Project visibility (alias p) shared by every query below.
        // "Only me" is already limited to the viewer's own rows, so project visibility must not hide them.
        if ($viewAll || $onlyMe) {
            $scopeSql = '1 = 1';
            $scopeParams = [];
        } else {
            $scopeSql = '(p.manager_id = :sc_manager OR p.created_by = :sc_creator OR EXISTS (
                SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = :sc_member
            ))';
            $scopeParams = ['sc_manager' => $userId, 'sc_creator' => $userId, 'sc_member' => $userId];
        }

        if ($onlyMe) {
            $restrictUserIds = [$userId];
        }
        $userFilter = self::userFilterSql($restrictUserIds, 'te.user_id', 'uidf');
        $meSql = $userFilter['sql'];
        $meParams = $userFilter['params'];

        // 1) Every entry of the week; bucketed into local days in PHP so no tz tables are needed.
        $rows = Database::fetchAll(
            "SELECT te.user_id, te.project_id, te.`{$startCol}` AS started, te.`{$durCol}` AS seconds
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             WHERE te.`{$startCol}` >= :s AND te.`{$startCol}` < :e AND {$scopeSql}{$meSql}",
            array_merge($scopeParams, $meParams, ['s' => $startUtc, 'e' => $endUtc])
        );

        $byProject = [];
        $byUser    = [];
        $total     = 0;

        foreach ($rows as $row) {
            $seconds = (int) $row['seconds'];
            $pid     = (int) $row['project_id'];
            $uid     = (int) $row['user_id'];

            try {
                $local = (new DateTimeImmutable((string) $row['started'], $utc))->setTimezone($tz);
            } catch (Exception) {
                continue;
            }
            $dayIndex = (int) $periodStart->diff($local->setTime(0, 0, 0))->format('%r%a');
            if ($dayIndex < 0 || $dayIndex >= $dayCount) {
                continue;
            }

            $days[$dayIndex]['seconds'] += $seconds;
            $days[$dayIndex]['projects'][$pid] = ($days[$dayIndex]['projects'][$pid] ?? 0) + $seconds;
            $byProject[$pid] = ($byProject[$pid] ?? 0) + $seconds;
            $byUser[$uid][$pid] = ($byUser[$uid][$pid] ?? 0) + $seconds;
            $total += $seconds;
        }

        // 2) Project names + clients, ranked by tracked time, colours by rank.
        arsort($byProject, SORT_NUMERIC);
        $projects = [];
        $colors   = [];
        if ($byProject !== []) {
            $ids = array_keys($byProject);
            $ph  = [];
            $pp  = [];
            foreach ($ids as $i => $id) {
                $ph[] = ':p' . $i;
                $pp['p' . $i] = $id;
            }
            $meta = [];
            foreach (Database::fetchAll(
                'SELECT p.id, p.name, c.name AS client_name
                 FROM projects p LEFT JOIN clients c ON c.id = p.client_id
                 WHERE p.id IN (' . implode(',', $ph) . ')',
                $pp
            ) as $m) {
                $meta[(int) $m['id']] = $m;
            }

            $rank = 0;
            foreach ($byProject as $pid => $seconds) {
                $color = self::PALETTE[$rank % count(self::PALETTE)];
                $colors[$pid] = $color;
                $projects[] = [
                    'id'      => $pid,
                    'name'    => (string) ($meta[$pid]['name'] ?? 'Project #' . $pid),
                    'client'  => (string) ($meta[$pid]['client_name'] ?? ''),
                    'seconds' => $seconds,
                    'percent' => $total > 0 ? round($seconds / $total * 100, 2) : 0.0,
                    'color'   => $color,
                ];
                $rank++;
            }
        }

        // 3) Top project / top client.
        $clientTotals = [];
        foreach ($projects as $p) {
            $name = $p['client'] !== '' ? $p['client'] : 'No client';
            $clientTotals[$name] = ($clientTotals[$name] ?? 0) + $p['seconds'];
        }
        arsort($clientTotals, SORT_NUMERIC);

        // 4) Team activities: latest entry + running timer + week total per person.
        $people = self::people($userId, $restrictUserIds, $scopeSql, $scopeParams, $startCol, $durCol, $byUser, $colors, $tz, $utc);

        $result['days']        = $days;
        $result['total']       = $total;
        $result['projects']    = $projects;
        $result['top_project'] = $projects[0] ?? null;
        $result['top_client']  = $clientTotals === [] ? null : [
            'name'    => (string) array_key_first($clientTotals),
            'seconds' => (int) reset($clientTotals),
        ];
        $result['people']      = $people;

        if ($includeTeamOverview) {
            $overview = self::teamOverview($userId, $managedTeamsOnly, $startUtc, $endUtc, $startCol, $durCol, $colors, $tz, $utc);
            $result['teams'] = $overview['teams'];
            $result['managed_team_count'] = $overview['managed_team_count'];
        }

        return $result;
    }

    /**
     * User ids on teams this person manages, plus themselves.
     *
     * @return list<int>
     */
    public static function managedTeamUserIds(int $userId): array
    {
        $ids = [$userId];
        if ($userId < 1 || !self::tableExists('teams') || !self::tableExists('team_members')) {
            return $ids;
        }

        $rows = Database::fetchAll(
            "SELECT tm.user_id
             FROM team_members tm
             INNER JOIN teams t ON t.id = tm.team_id
             WHERE t.manager_id = :m AND (t.status = 'active' OR t.status IS NULL)
             UNION
             SELECT t.manager_id
             FROM teams t
             WHERE t.manager_id = :m2 AND (t.status = 'active' OR t.status IS NULL)",
            ['m' => $userId, 'm2' => $userId]
        );
        foreach ($rows as $row) {
            $uid = (int) ($row['user_id'] ?? $row['manager_id'] ?? 0);
            if ($uid > 0) {
                $ids[] = $uid;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * How many active teams this person manages.
     */
    public static function managedTeamCount(int $userId): int
    {
        if ($userId < 1 || !self::tableExists('teams')) {
            return 0;
        }

        return (int) Database::fetchValue(
            "SELECT COUNT(*) FROM teams WHERE manager_id = :m AND (status = 'active' OR status IS NULL)",
            ['m' => $userId]
        );
    }

    /**
     * @param list<int>|null $restrictUserIds
     * @param array<int, array<int, int>> $byUser user => project => seconds
     * @param array<int, string> $colors project => colour
     * @return list<array<string, mixed>>
     */
    private static function people(
        int $userId,
        ?array $restrictUserIds,
        string $scopeSql,
        array $scopeParams,
        string $startCol,
        string $durCol,
        array $byUser,
        array $colors,
        DateTimeZone $tz,
        DateTimeZone $utc
    ): array {
        $userSql = "SELECT u.id, u.name FROM users u
                    INNER JOIN roles r ON r.id = u.role_id
                    WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')";
        $userParams = [];
        $userFilter = self::userFilterSql($restrictUserIds, 'u.id', 'uidp');
        $userSql .= $userFilter['sql'];
        $userParams = $userFilter['params'];
        $users = Database::fetchAll($userSql . ' ORDER BY u.name ASC', $userParams);

        $peopleFilter = self::userFilterSql($restrictUserIds, 'te.user_id', 'uidl');
        $runFilter = self::userFilterSql($restrictUserIds, 'a.user_id', 'uidr');

        // Latest entry per user (any week). Duplicate start times are collapsed in PHP.
        $latest = [];
        $latestRows = Database::fetchAll(
            "SELECT te.user_id, te.description, te.`{$startCol}` AS started, te.`{$durCol}` AS seconds,
                    p.name AS project_name, t.name AS task_name
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             LEFT JOIN tasks t ON t.id = te.task_id
             INNER JOIN (
                 SELECT user_id, MAX(`{$startCol}`) AS mx FROM time_entries GROUP BY user_id
             ) m ON m.user_id = te.user_id AND m.mx = te.`{$startCol}`
             WHERE {$scopeSql}{$peopleFilter['sql']}",
            array_merge($scopeParams, $peopleFilter['params'])
        );
        foreach ($latestRows as $r) {
            $latest[(int) $r['user_id']] ??= $r;
        }

        // Running timers.
        $running = [];
        if (self::tableExists('active_timers')) {
            foreach (Database::fetchAll(
                'SELECT a.user_id, a.started_at, a.paused_at, a.accumulated_seconds, a.description, p.name AS project_name, t.name AS task_name
                 FROM active_timers a
                 INNER JOIN projects p ON p.id = a.project_id
                 LEFT JOIN tasks t ON t.id = a.task_id
                 WHERE ' . $scopeSql . $runFilter['sql'],
                array_merge($scopeParams, $runFilter['params'])
            ) as $r) {
                $running[(int) $r['user_id']] = $r;
            }
        }

        $now = new DateTimeImmutable('now', $utc);
        $out = [];

        foreach ($users as $u) {
            $uid  = (int) $u['id'];
            $segs = $byUser[$uid] ?? [];
            arsort($segs, SORT_NUMERIC);
            $weekTotal = array_sum($segs);

            $activity = null;
            if (isset($running[$uid])) {
                $r = $running[$uid];
                $startedAt = new DateTimeImmutable((string) $r['started_at'], $utc);
                $isPaused  = !empty($r['paused_at']);
                $accum     = max(0, (int) ($r['accumulated_seconds'] ?? 0));
                $activity = [
                    'description' => (string) ($r['description'] ?? ''),
                    'project'     => (string) $r['project_name'],
                    'task'        => (string) ($r['task_name'] ?? ''),
                    // Paused timers show only the banked time and stop counting.
                    'seconds'     => $accum + ($isPaused ? 0 : max(0, $now->getTimestamp() - $startedAt->getTimestamp())),
                    'ago'         => $isPaused ? 'Paused' : 'In progress',
                    'running'     => !$isPaused,
                    'paused'      => $isPaused,
                    'live'        => true,
                ];
            } elseif (isset($latest[$uid])) {
                $r = $latest[$uid];
                $activity = [
                    'description' => (string) ($r['description'] ?? ''),
                    'project'     => (string) $r['project_name'],
                    'task'        => (string) ($r['task_name'] ?? ''),
                    'seconds'     => (int) $r['seconds'],
                    'ago'         => self::ago(new DateTimeImmutable((string) $r['started'], $utc), $now),
                    'running'     => false,
                ];
            }

            $firstProject = array_key_first($segs);
            $out[] = [
                'user_id'  => $uid,
                'name'     => (string) $u['name'],
                'initials' => self::initials((string) $u['name']),
                'color'    => $firstProject !== null ? ($colors[$firstProject] ?? self::PALETTE[$uid % count(self::PALETTE)]) : self::PALETTE[$uid % count(self::PALETTE)],
                'activity' => $activity,
                'total'    => $weekTotal,
                'segments' => array_map(
                    static fn (int $pid, int $sec): array => ['seconds' => $sec, 'color' => $colors[$pid] ?? '#b0bec5'],
                    array_keys($segs),
                    array_values($segs)
                ),
            ];
        }

        // Running first, then most recent activity, then name.
        usort($out, static function (array $a, array $b): int {
            $ra = (int) ($a['activity']['live'] ?? 0);
            $rb = (int) ($b['activity']['live'] ?? 0);
            if ($ra !== $rb) {
                return $rb <=> $ra;
            }
            $ha = $a['activity'] !== null ? 1 : 0;
            $hb = $b['activity'] !== null ? 1 : 0;
            if ($ha !== $hb) {
                return $hb <=> $ha;
            }

            return $b['total'] <=> $a['total'] ?: strcasecmp($a['name'], $b['name']);
        });

        return $out;
    }

    /**
     * Teams with the same name (e.g. Design Services under several projects) merge into one card.
     * Time is members' time on any project plus the team manager's time. Someone in two teams counts in both.
     *
     * @param array<int, string> $colors
     * @return array{teams: list<array<string, mixed>>, managed_team_count: int}
     */
    private static function teamOverview(
        int $userId,
        bool $managedTeamsOnly,
        string $startUtc,
        string $endUtc,
        string $startCol,
        string $durCol,
        array $colors,
        DateTimeZone $tz,
        DateTimeZone $utc
    ): array {
        $empty = ['teams' => [], 'managed_team_count' => 0];
        if (!self::tableExists('teams') || !self::tableExists('team_members')) {
            return $empty;
        }

        $teamSql = "SELECT t.id, t.name, t.manager_id, tmgr.name AS manager_name
                    FROM teams t
                    LEFT JOIN users tmgr ON tmgr.id = t.manager_id
                    WHERE (t.status = 'active' OR t.status IS NULL)";
        $teamParams = [];
        if ($managedTeamsOnly) {
            $teamSql .= ' AND t.manager_id = :mgr';
            $teamParams['mgr'] = $userId;
        }
        $teamSql .= ' ORDER BY t.name ASC, t.id ASC';
        $teamRows = Database::fetchAll($teamSql, $teamParams);
        if ($teamRows === []) {
            return ['teams' => [], 'managed_team_count' => 0];
        }

        $teamIds = array_map(static fn (array $row): int => (int) $row['id'], $teamRows);
        $memberMap = [];
        $ph = [];
        $pp = [];
        foreach ($teamIds as $i => $id) {
            $ph[] = ':tid' . $i;
            $pp['tid' . $i] = $id;
        }
        foreach (Database::fetchAll(
            'SELECT tm.team_id, u.id, u.name
             FROM team_members tm
             INNER JOIN users u ON u.id = tm.user_id
             WHERE tm.team_id IN (' . implode(',', $ph) . ') AND u.status = \'active\'
             ORDER BY u.name ASC',
            $pp
        ) as $row) {
            $memberMap[(int) $row['team_id']][] = ['id' => (int) $row['id'], 'name' => (string) $row['name']];
        }

        $peopleByTeam = [];
        foreach ($teamRows as $row) {
            $tid = (int) $row['id'];
            $people = $memberMap[$tid] ?? [];
            $mgrId = (int) ($row['manager_id'] ?? 0);
            if ($mgrId > 0) {
                $already = false;
                foreach ($people as $person) {
                    if ((int) $person['id'] === $mgrId) {
                        $already = true;
                        break;
                    }
                }
                if (!$already) {
                    $people[] = ['id' => $mgrId, 'name' => (string) ($row['manager_name'] ?? 'Manager')];
                }
            }
            $peopleByTeam[$tid] = $people;
        }

        $allUserIds = [];
        foreach ($peopleByTeam as $people) {
            foreach ($people as $person) {
                $allUserIds[] = (int) $person['id'];
            }
        }
        $allUserIds = array_values(array_unique(array_filter($allUserIds)));

        $secondsByUserProject = [];
        $projectNames = [];
        if ($allUserIds !== []) {
            $uf = self::userFilterSql($allUserIds, 'te.user_id', 'tov');
            $entryRows = Database::fetchAll(
                "SELECT te.user_id, te.project_id, te.`{$durCol}` AS seconds, p.name AS project_name
                 FROM time_entries te
                 INNER JOIN projects p ON p.id = te.project_id
                 WHERE te.`{$startCol}` >= :s AND te.`{$startCol}` < :e{$uf['sql']}",
                array_merge($uf['params'], ['s' => $startUtc, 'e' => $endUtc])
            );
            foreach ($entryRows as $row) {
                $uid = (int) $row['user_id'];
                $pid = (int) $row['project_id'];
                $secondsByUserProject[$uid][$pid] = ($secondsByUserProject[$uid][$pid] ?? 0) + (int) $row['seconds'];
                $projectNames[$pid] = (string) $row['project_name'];
            }
        }

        $runningUsers = [];
        if (self::tableExists('active_timers') && $allUserIds !== []) {
            $rf = self::userFilterSql($allUserIds, 'a.user_id', 'tovr');
            foreach (Database::fetchAll(
                'SELECT a.user_id, a.paused_at FROM active_timers a WHERE 1 = 1' . $rf['sql'],
                $rf['params']
            ) as $row) {
                if (empty($row['paused_at'])) {
                    $runningUsers[(int) $row['user_id']] = true;
                }
            }
        }

        $groups = [];
        foreach ($teamRows as $row) {
            $key = mb_strtolower(trim((string) $row['name']), 'UTF-8');
            $groups[$key][] = $row;
        }

        $out = [];
        $palette = self::PALETTE;
        foreach ($groups as $groupRows) {
            $name = (string) $groupRows[0]['name'];
            $userSeconds = [];
            $userNames = [];
            $projectSeconds = [];
            $counted = [];
            foreach ($groupRows as $row) {
                foreach ($peopleByTeam[(int) $row['id']] ?? [] as $person) {
                    $uid = (int) $person['id'];
                    // Same person in two same-name teams (e.g. Design Services on two projects) counts once.
                    if (isset($counted[$uid])) {
                        continue;
                    }
                    $counted[$uid] = true;
                    $userNames[$uid] = (string) $person['name'];
                    foreach ($secondsByUserProject[$uid] ?? [] as $pid => $sec) {
                        $userSeconds[$uid] = ($userSeconds[$uid] ?? 0) + $sec;
                        $projectSeconds[$pid] = ($projectSeconds[$pid] ?? 0) + $sec;
                    }
                    if (!isset($userSeconds[$uid])) {
                        $userSeconds[$uid] = 0;
                    }
                }
            }

            $total = array_sum($userSeconds);
            arsort($projectSeconds, SORT_NUMERIC);
            $projects = [];
            $rank = 0;
            foreach ($projectSeconds as $pid => $sec) {
                $projects[] = [
                    'id' => $pid,
                    'name' => $projectNames[$pid] ?? ('Project #' . $pid),
                    'seconds' => $sec,
                    'percent' => $total > 0 ? round($sec / $total * 100, 2) : 0.0,
                    'color' => $colors[$pid] ?? $palette[$rank % count($palette)],
                ];
                $rank++;
            }

            $people = [];
            foreach ($userNames as $uid => $uname) {
                $people[] = [
                    'user_id' => $uid,
                    'name' => $uname,
                    'initials' => self::initials($uname),
                    'seconds' => (int) ($userSeconds[$uid] ?? 0),
                    'working' => isset($runningUsers[$uid]),
                ];
            }
            usort($people, static function (array $a, array $b): int {
                if ((int) $a['working'] !== (int) $b['working']) {
                    return ((int) $b['working']) <=> ((int) $a['working']);
                }

                return $b['seconds'] <=> $a['seconds'] ?: strcasecmp($a['name'], $b['name']);
            });

            $out[] = [
                'name' => $name,
                'total' => $total,
                'top_project' => $projects[0] ?? null,
                'projects' => $projects,
                'people' => $people,
                'working_count' => count(array_filter($people, static fn (array $p): bool => !empty($p['working']))),
                'member_count' => count($people),
            ];
        }

        usort($out, static fn (array $a, array $b): int => $b['total'] <=> $a['total'] ?: strcasecmp($a['name'], $b['name']));

        return [
            'teams' => $out,
            'managed_team_count' => count($teamRows),
        ];
    }

    /**
     * @param list<int>|null $ids
     * @return array{sql: string, params: array<string, int>}
     */
    private static function userFilterSql(?array $ids, string $column, string $prefix): array
    {
        if ($ids === null) {
            return ['sql' => '', 'params' => []];
        }

        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return ['sql' => ' AND 1 = 0', 'params' => []];
        }

        $ph = [];
        $params = [];
        foreach ($ids as $i => $id) {
            $key = $prefix . $i;
            $ph[] = ':' . $key;
            $params[$key] = $id;
        }

        return ['sql' => ' AND ' . $column . ' IN (' . implode(', ', $ph) . ')', 'params' => $params];
    }

    private static function ago(DateTimeImmutable $then, DateTimeImmutable $now): string
    {
        $diff = max(0, $now->getTimestamp() - $then->getTimestamp());

        return match (true) {
            $diff < 90         => 'just now',
            $diff < 3600       => intdiv($diff, 60) . ' minutes ago',
            $diff < 5400       => 'an hour ago',
            $diff < 86400      => intdiv($diff, 3600) . ' hours ago',
            $diff < 172800     => 'yesterday',
            default            => intdiv($diff, 86400) . ' days ago',
        };
    }

    private static function initials(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name)) ?: [];
        $first = mb_strtoupper(mb_substr((string) ($parts[0] ?? '?'), 0, 1, 'UTF-8'), 'UTF-8');
        $last  = count($parts) > 1 ? mb_strtoupper(mb_substr((string) end($parts), 0, 1, 'UTF-8'), 'UTF-8') : '';

        return $first . $last;
    }

    /** Physical time_entries column for a logical field (null when the live table lacks it). */
    private static function column(string $logical): ?string
    {
        if (!class_exists('TimeEntry')) {
            return null;
        }

        try {
            return TimeEntry::column($logical);
        } catch (Throwable $e) {
            LoggerHelper::debug('WeekDashboard column lookup failed', ['error' => $e->getMessage()]);
            return null;
        }
    }

    private static function tableExists(string $table): bool
    {
        static $cache = [];

        if (!preg_match('/^[a-z_][a-z0-9_]*$/', $table)) {
            return false;
        }
        if (!array_key_exists($table, $cache)) {
            try {
                $cache[$table] = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :name',
                    ['name' => $table]
                ) > 0;
            } catch (Throwable $e) {
                LoggerHelper::debug('WeekDashboard tableExists failed', ['table' => $table, 'error' => $e->getMessage()]);
                $cache[$table] = false;
            }
        }

        return $cache[$table];
    }
}