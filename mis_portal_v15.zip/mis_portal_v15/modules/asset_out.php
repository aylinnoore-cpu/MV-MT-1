<?php require __DIR__.'/../includes/lib.php';allow(['support','ed']);
$id=(int)($_GET['id']??0);$a=($_GET['a']??'out')=='return'?'return':'out';$as=q('SELECT * FROM assets WHERE id=?',[$id])->fetch()?:die('Asset not found');
$isout=in_array($as['status'],['out_for_repair','out_for_maintenance']);$vendors=array_column(q('SELECT id,name FROM vendors ORDER BY name')->fetchAll(),'name','id');
$ok=fn($d)=>preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)$d)?$d:null;
if($a=='out'&&($isout||!in_array($as['status'],['working','in_storage','faulty'])))die('This asset cannot be sent out in its current status ('.h(pretty($as['status'])).').');
if($a=='return'&&!$isout)die('This asset is not currently out for repair or maintenance.');
if($_SERVER['REQUEST_METHOD']=='POST'){chk();$back="Location: records.php?m=assets&a=view&id=$id";
 if($a=='out'){$K=['repair'=>['repair','out_for_repair'],'preventive'=>['preventive','out_for_maintenance'],'service'=>['service','out_for_maintenance']][$_POST['kind']]??die('Invalid type');
  $vid=(int)$_POST['vendor_id']?:null;$tech=trim($_POST['tech']??'');if($vid&&$tech==='')$tech=$vendors[$vid]??'';$desc=trim($_POST['description']??'');
  if($desc===''){$_SESSION['err']='Please describe the problem / work required.';header("Location: asset_out.php?id=$id");exit;}
  $GLOBALS['pdo']->beginTransaction();
  q('INSERT INTO maintenance(asset_id,type,technician,description,cost,work_date,status,created_by,vendor_id,expected_return)VALUES(?,?,?,?,?,?,?,?,?,?)',[$id,$K[0],$tech,$desc,null,$ok($_POST['sent'])?:date('Y-m-d'),'scheduled',me()['id'],$vid,$ok($_POST['expected'])]);
  q('UPDATE assets SET status=? WHERE id=?',[$K[1],$id]);$GLOBALS['pdo']->commit();
  logit('Asset #'.$id.' ('.$as['name'].') sent out - '.pretty($K[1]).($tech?' to '.$tech:''));header($back);exit;}
 $o=['working','faulty','dead'];$res=in_array($_POST['outcome'],$o)?$_POST['outcome']:'working';$m=q("SELECT id FROM maintenance WHERE asset_id=? AND status='scheduled' ORDER BY id DESC LIMIT 1",[$id])->fetch();
 $GLOBALS['pdo']->beginTransaction();
 if($m)q("UPDATE maintenance SET returned_on=?,cost=?,status='done',description=CONCAT(IFNULL(description,''),?) WHERE id=?",[$ok($_POST['returned'])?:date('Y-m-d'),$_POST['cost']!==''?(float)$_POST['cost']:null,trim($_POST['remarks']??'')!==''?"\nReturn remarks: ".trim($_POST['remarks']):'',$m['id']]);
 q('UPDATE assets SET status=? WHERE id=?',[$res,$id]);$GLOBALS['pdo']->commit();logit('Asset #'.$id.' ('.$as['name'].') returned - now '.pretty($res));header($back);exit;}
head($a=='out'?'Send out for repair / maintenance':'Mark asset returned',$as['asset_tag'].' - '.$as['name']);
if(!empty($_SESSION['err'])){echo '<p class=err>'.h($_SESSION['err']).'</p>';unset($_SESSION['err']);}
[$wt,$wc]=warr($as['warranty_end']);$vn=$vendors[$as['vendor_id']]??($as['vendor']?:'');
echo '<div class=card><b>Warranty:</b> <span class="pill '.$wc.'">'.h($wt).'</span>'.($vn?' &nbsp; <b>Vendor:</b> '.h($vn):'').($wc=='g'||$wc=='o'?'<p style="margin:8px 0 0;color:#1d7a3c"><b>Under warranty - consider sending this to the vendor for a warranty claim.</b></p>':'').'</div>';
if($a=='out'){echo '<div class=card><form method=post><input type=hidden name=c value="'.csrf().'"><label>Type</label><select name=kind><option value=repair>Repair</option><option value=preventive>Preventive maintenance</option><option value=service>Service</option></select>
 <label>Sent to vendor</label><select name=vendor_id><option value=0>-- none / in-house technician --</option>';foreach($vendors as $i=>$n)echo "<option value=$i".($i==$as['vendor_id']?' selected':'').'>'.h($n).'</option>';
 echo '</select><label>Technician / contact person (optional)</label><input name=tech><label>Date sent</label><input type=date name=sent value="'.date('Y-m-d').'"><label>Expected return date</label><input type=date name=expected>
 <label>Problem / work required</label><textarea name=description rows=3 required></textarea><p><button>Send out</button> <a class="btn g" href="records.php?m=assets&a=view&id='.$id.'">Cancel</a></p></form></div>';}
else{$m=q("SELECT * FROM maintenance WHERE asset_id=? AND status='scheduled' ORDER BY id DESC LIMIT 1",[$id])->fetch();
 if($m)echo '<div class=card><b>Currently out:</b> '.h(pretty($m['type'])).' - sent '.h($m['work_date']).($m['technician']?' to '.h($m['technician']):'').($m['expected_return']?', expected back '.h($m['expected_return']):'').'<br>'.nl2br(h($m['description'])).'</div>';
 echo '<div class=card><form method=post><input type=hidden name=c value="'.csrf().'"><label>Returned on</label><input type=date name=returned value="'.date('Y-m-d').'"><label>Repair / maintenance cost (optional)</label><input type=number step=any name=cost>
 <label>Result</label><select name=outcome><option value=working>Working again</option><option value=faulty>Faulty - not repaired</option><option value=dead>Dead - beyond repair</option></select>
 <label>Remarks</label><textarea name=remarks rows=3></textarea><p><button>Mark returned</button> <a class="btn g" href="records.php?m=assets&a=view&id='.$id.'">Cancel</a></p></form></div>';}
foot();
