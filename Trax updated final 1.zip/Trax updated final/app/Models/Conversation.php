<?php
/**
 * Chat conversations: team (derived), project (on demand), custom, and DMs.
 *
 * Membership for team/project types is derived from team_members / project_members
 * on every request. conversation_members still stores last_read_message_id.
 */

declare(strict_types=1);

final class Conversation extends Model
{
    public const TYPE_DM      = 'dm';
    public const TYPE_TEAM    = 'team';
    public const TYPE_PROJECT = 'project';
    public const TYPE_CUSTOM  = 'custom';

    protected string $table = 'conversations';

    protected array $columns = [
        'id', 'type', 'team_id', 'project_id', 'name', 'created_by',
        'archived_at', 'archived_by', 'deleted_at', 'deleted_by',
        'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'type', 'team_id', 'project_id', 'name', 'created_by',
        'archived_at', 'archived_by', 'deleted_at', 'deleted_by',
    ];

    public static function installed(): bool
    {
        return ChatHelper::installed();
    }

    /** @return array<string, mixed>|null */
    public function findAlive(int $id): ?array
    {
        if ($id < 1 || !self::installed()) {
            return null;
        }

        return Database::fetchOne(
            'SELECT * FROM conversations WHERE id = :id AND deleted_at IS NULL LIMIT 1',
            ['id' => $id]
        );
    }

    /**
     * People currently allowed in this conversation. Derived for team/project;
     * stored rows for custom/DM. Client-role users are never included.
     *
     * @return list<array{id: int, name: string, email: string, avatar_path: string, handle: string, role: string}>
     */
    public function liveMembers(array $conversation): array
    {
        $type = (string) ($conversation['type'] ?? '');
        $ids = match ($type) {
            self::TYPE_TEAM    => $this->teamUserIds((int) ($conversation['team_id'] ?? 0)),
            self::TYPE_PROJECT => $this->projectUserIds((int) ($conversation['project_id'] ?? 0)),
            default            => $this->storedUserIds((int) ($conversation['id'] ?? 0)),
        };

        return $this->usersByIds($ids);
    }

    /** @return list<int> */
    public function liveMemberIds(array $conversation): array
    {
        return array_map(static fn (array $u): int => (int) $u['id'], $this->liveMembers($conversation));
    }

    public function userCanAccess(array $conversation, int $userId, bool $asAdminPeek = false): bool
    {
        if ($userId < 1 || (string) ($conversation['deleted_at'] ?? '') !== '') {
            return false;
        }
        if (ClientScope::isClient($userId)) {
            return false;
        }

        $ids = $this->liveMemberIds($conversation);
        if (in_array($userId, $ids, true)) {
            return true;
        }

        return $asAdminPeek
            && (string) ($conversation['type'] ?? '') === self::TYPE_DM
            && AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)
            && ChatHelper::adminCanReadDms();
    }

    public function isArchived(array $conversation): bool
    {
        return (string) ($conversation['archived_at'] ?? '') !== '';
    }

    /**
     * Ensure a row exists in conversation_members so last_read can be stored.
     */
    public function touchMembership(int $conversationId, int $userId): void
    {
        if ($conversationId < 1 || $userId < 1) {
            return;
        }
        try {
            Database::execute(
                'INSERT IGNORE INTO conversation_members (conversation_id, user_id, joined_at)
                 VALUES (:c, :u, UTC_TIMESTAMP())',
                ['c' => $conversationId, 'u' => $userId]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat membership touch failed', ['error' => $e->getMessage()]);
        }
    }

    public function markRead(int $conversationId, int $userId, int $messageId): void
    {
        if ($conversationId < 1 || $userId < 1 || $messageId < 1) {
            return;
        }
        $this->touchMembership($conversationId, $userId);
        Database::execute(
            'UPDATE conversation_members
             SET last_read_message_id = GREATEST(COALESCE(last_read_message_id, 0), :mid)
             WHERE conversation_id = :c AND user_id = :u',
            ['mid' => $messageId, 'c' => $conversationId, 'u' => $userId]
        );
    }

    /**
     * Sidebar list: team channels the user belongs to, project channels that exist
     * and they belong to, custom channels they are in, and their DMs.
     *
     * @return array{teams: list<array<string, mixed>>, projects: list<array<string, mixed>>, dms: list<array<string, mixed>>, custom: list<array<string, mixed>>, unread_total: int}
     */
    public function sidebarFor(int $userId): array
    {
        $empty = ['teams' => [], 'projects' => [], 'dms' => [], 'custom' => [], 'unread_total' => 0];
        if ($userId < 1 || !self::installed()) {
            return $empty;
        }

        $this->ensureTeamChannels($userId);

        $unreadExpr = 'COALESCE((
            SELECT COUNT(*) FROM messages m
            WHERE m.conversation_id = c.id AND m.deleted_at IS NULL
              AND m.id > COALESCE(cm.last_read_message_id, 0)
        ), 0)';
        $mentionExpr = 'COALESCE((
            SELECT COUNT(*) FROM message_mentions mm
            INNER JOIN messages m2 ON m2.id = mm.message_id
            WHERE m2.conversation_id = c.id AND m2.deleted_at IS NULL
              AND mm.user_id = :mu
              AND m2.id > COALESCE(cm.last_read_message_id, 0)
        ), 0)';
        $lastBody = '(SELECT m3.body FROM messages m3 WHERE m3.conversation_id = c.id AND m3.deleted_at IS NULL ORDER BY m3.id DESC LIMIT 1)';
        $lastAt = '(SELECT m3.created_at FROM messages m3 WHERE m3.conversation_id = c.id AND m3.deleted_at IS NULL ORDER BY m3.id DESC LIMIT 1)';
        $lastUser = '(SELECT m3.user_id FROM messages m3 WHERE m3.conversation_id = c.id AND m3.deleted_at IS NULL ORDER BY m3.id DESC LIMIT 1)';

        $rows = Database::fetchAll(
            "SELECT c.id, c.type, c.team_id, c.project_id, c.name, c.archived_at, c.created_by,
                    cm.last_read_message_id,
                    {$unreadExpr} AS unread_count,
                    {$mentionExpr} AS mention_count,
                    {$lastBody} AS last_body,
                    {$lastAt} AS last_at,
                    {$lastUser} AS last_user_id
             FROM conversations c
             LEFT JOIN conversation_members cm ON cm.conversation_id = c.id AND cm.user_id = :uid
             WHERE c.deleted_at IS NULL AND c.archived_at IS NULL
             ORDER BY last_at IS NULL, last_at DESC, c.id DESC",
            ['uid' => $userId, 'mu' => $userId]
        );

        $out = $empty;
        foreach ($rows as $row) {
            if (!$this->userCanAccess($row, $userId)) {
                continue;
            }
            $this->touchMembership((int) $row['id'], $userId);
            $item = $this->decorateSidebarRow($row, $userId);
            $bucket = match ((string) $row['type']) {
                self::TYPE_TEAM    => 'teams',
                self::TYPE_PROJECT => 'projects',
                self::TYPE_DM      => 'dms',
                default            => 'custom',
            };
            $out[$bucket][] = $item;
            $out['unread_total'] += (int) $item['unread_count'] > 0 ? 1 : 0;
        }

        return $out;
    }

    public function unreadConversationCount(int $userId): int
    {
        if ($userId < 1 || !self::installed() || ClientScope::isClient($userId)) {
            return 0;
        }
        try {
            $list = $this->sidebarFor($userId);

            return (int) $list['unread_total'];
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat unread count failed', ['error' => $e->getMessage()]);

            return 0;
        }
    }

    /**
     * Create missing team conversations for teams the user belongs to.
     */
    public function ensureTeamChannels(int $userId): void
    {
        if ($userId < 1 || !TeamGroup::installed() || !self::installed()) {
            return;
        }
        try {
            $teamIds = $this->teamIdsForUser($userId);
            foreach ($teamIds as $teamId) {
                $this->ensureTeamChannel($teamId, $userId);
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat team channel ensure failed', ['error' => $e->getMessage()]);
        }
    }

    public function ensureTeamChannel(int $teamId, int $actorId): ?array
    {
        if ($teamId < 1 || !self::installed()) {
            return null;
        }
        $existing = Database::fetchOne(
            'SELECT * FROM conversations WHERE type = :t AND team_id = :id AND deleted_at IS NULL LIMIT 1',
            ['t' => self::TYPE_TEAM, 'id' => $teamId]
        );
        if ($existing !== null) {
            return $existing;
        }
        $team = (new TeamGroup())->find($teamId);
        if ($team === null) {
            return null;
        }
        $id = $this->create([
            'type'       => self::TYPE_TEAM,
            'team_id'    => $teamId,
            'project_id' => null,
            'name'       => (string) $team['name'],
            'created_by' => $actorId > 0 ? $actorId : 1,
        ]);

        return $this->find($id);
    }

    public function ensureProjectChannel(int $projectId, int $actorId): array
    {
        $existing = Database::fetchOne(
            'SELECT * FROM conversations WHERE type = :t AND project_id = :id AND deleted_at IS NULL LIMIT 1',
            ['t' => self::TYPE_PROJECT, 'id' => $projectId]
        );
        if ($existing !== null) {
            return $existing;
        }
        $project = Database::fetchOne('SELECT id, name FROM projects WHERE id = :id LIMIT 1', ['id' => $projectId]);
        $name = is_array($project) ? (string) $project['name'] : 'Project';
        $id = $this->create([
            'type'       => self::TYPE_PROJECT,
            'team_id'    => null,
            'project_id' => $projectId,
            'name'       => $name,
            'created_by' => $actorId,
        ]);
        LoggerHelper::logEvent('chat.channel_created', LoggerHelper::MODULE_CHAT, $id, null, [
            'type'       => self::TYPE_PROJECT,
            'project_id' => $projectId,
            'name'       => $name,
        ]);

        return $this->find($id) ?? [];
    }

    public function findProjectChannel(int $projectId): ?array
    {
        if ($projectId < 1 || !self::installed()) {
            return null;
        }

        return Database::fetchOne(
            'SELECT * FROM conversations WHERE type = :t AND project_id = :id AND deleted_at IS NULL LIMIT 1',
            ['t' => self::TYPE_PROJECT, 'id' => $projectId]
        );
    }

    public function findOrCreateDm(int $userA, int $userB): array
    {
        $low = min($userA, $userB);
        $high = max($userA, $userB);
        $existing = Database::fetchOne(
            "SELECT c.* FROM conversations c
             INNER JOIN conversation_members a ON a.conversation_id = c.id AND a.user_id = :a
             INNER JOIN conversation_members b ON b.conversation_id = c.id AND b.user_id = :b
             WHERE c.type = :t AND c.deleted_at IS NULL
               AND (SELECT COUNT(*) FROM conversation_members x WHERE x.conversation_id = c.id) = 2
             LIMIT 1",
            ['a' => $low, 'b' => $high, 't' => self::TYPE_DM]
        );
        if ($existing !== null) {
            return $existing;
        }
        $id = Database::transaction(function () use ($low, $high): int {
            $id = $this->create([
                'type'       => self::TYPE_DM,
                'team_id'    => null,
                'project_id' => null,
                'name'       => null,
                'created_by' => $low,
            ]);
            Database::execute(
                'INSERT INTO conversation_members (conversation_id, user_id, joined_at) VALUES (:c, :u, UTC_TIMESTAMP())',
                ['c' => $id, 'u' => $low]
            );
            Database::execute(
                'INSERT INTO conversation_members (conversation_id, user_id, joined_at) VALUES (:c2, :u2, UTC_TIMESTAMP())',
                ['c2' => $id, 'u2' => $high]
            );

            return $id;
        });

        return $this->find($id) ?? [];
    }

    public function createCustom(string $name, int $actorId, array $memberIds): array
    {
        $memberIds[] = $actorId;
        $memberIds = array_values(array_unique(array_filter(array_map('intval', $memberIds), static fn (int $id): bool => $id > 0)));
        $id = Database::transaction(function () use ($name, $actorId, $memberIds): int {
            $id = $this->create([
                'type'       => self::TYPE_CUSTOM,
                'team_id'    => null,
                'project_id' => null,
                'name'       => $name,
                'created_by' => $actorId,
            ]);
            foreach ($memberIds as $uid) {
                Database::execute(
                    'INSERT IGNORE INTO conversation_members (conversation_id, user_id, joined_at)
                     VALUES (:c, :u, UTC_TIMESTAMP())',
                    ['c' => $id, 'u' => $uid]
                );
            }

            return $id;
        });
        LoggerHelper::logEvent('chat.channel_created', LoggerHelper::MODULE_CHAT, $id, null, [
            'type'    => self::TYPE_CUSTOM,
            'name'    => $name,
            'members' => $memberIds,
        ]);

        return $this->find($id) ?? [];
    }

    public function archive(int $id, int $actorId): void
    {
        Database::execute(
            'UPDATE conversations SET archived_at = UTC_TIMESTAMP(), archived_by = :u, updated_at = UTC_TIMESTAMP()
             WHERE id = :id AND deleted_at IS NULL',
            ['u' => $actorId, 'id' => $id]
        );
        LoggerHelper::logEvent('chat.channel_archived', LoggerHelper::MODULE_CHAT, $id, null, ['archived_by' => $actorId]);
    }

    public function unarchive(int $id, int $actorId): void
    {
        Database::execute(
            'UPDATE conversations SET archived_at = NULL, archived_by = NULL, updated_at = UTC_TIMESTAMP()
             WHERE id = :id AND deleted_at IS NULL',
            ['id' => $id]
        );
        LoggerHelper::logEvent('chat.channel_unarchived', LoggerHelper::MODULE_CHAT, $id, null, ['by' => $actorId]);
    }

    public function softDelete(int $id, int $actorId): void
    {
        Database::execute(
            'UPDATE conversations SET deleted_at = UTC_TIMESTAMP(), deleted_by = :u, updated_at = UTC_TIMESTAMP()
             WHERE id = :id AND deleted_at IS NULL',
            ['u' => $actorId, 'id' => $id]
        );
        LoggerHelper::logEvent('chat.channel_deleted', LoggerHelper::MODULE_CHAT, $id, null, ['deleted_by' => $actorId]);
    }

    /**
     * @param list<int> $memberIds
     */
    public function replaceCustomMembers(int $conversationId, array $memberIds, int $actorId): void
    {
        $memberIds = array_values(array_unique(array_filter(array_map('intval', $memberIds), static fn (int $id): bool => $id > 0)));
        $before = $this->storedUserIds($conversationId);
        Database::transaction(function () use ($conversationId, $memberIds): void {
            Database::execute('DELETE FROM conversation_members WHERE conversation_id = :c', ['c' => $conversationId]);
            foreach ($memberIds as $uid) {
                Database::execute(
                    'INSERT INTO conversation_members (conversation_id, user_id, joined_at)
                     VALUES (:c, :u, UTC_TIMESTAMP())',
                    ['c' => $conversationId, 'u' => $uid]
                );
            }
        });
        LoggerHelper::logEvent('chat.membership_changed', LoggerHelper::MODULE_CHAT, $conversationId, ['members' => $before], ['members' => $memberIds, 'by' => $actorId]);
    }

    /** @return list<array<string, mixed>> */
    public function dmCandidates(int $userId): array
    {
        $people = [];
        try {
            $avatar = SchemaHelper::columnExists('users', 'avatar_path') ? 'u.avatar_path' : 'NULL AS avatar_path';
            $rows = Database::fetchAll(
                "SELECT u.id, u.name, u.email, {$avatar}, r.name AS role
                 FROM users u
                 INNER JOIN roles r ON r.id = u.role_id
                 WHERE u.status = 'active' AND r.name IN ('admin','manager','employee') AND u.id <> :me
                 ORDER BY u.name ASC
                 LIMIT 300",
                ['me' => $userId]
            );
            foreach ($rows as $row) {
                $id = (int) $row['id'];
                if (!ChatHelper::shareTeamOrProject($userId, $id)) {
                    continue;
                }
                $people[] = [
                    'id'          => $id,
                    'name'        => (string) $row['name'],
                    'email'       => (string) $row['email'],
                    'avatar_path' => (string) ($row['avatar_path'] ?? ''),
                    'handle'      => ChatHelper::handleFor((string) $row['name'], $id),
                    'role'        => (string) $row['role'],
                ];
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat DM candidates failed', ['error' => $e->getMessage()]);
        }

        return $people;
    }

    /** @return list<array<string, mixed>> */
    public function staffDirectory(): array
    {
        $avatar = SchemaHelper::columnExists('users', 'avatar_path') ? 'u.avatar_path' : 'NULL AS avatar_path';
        $rows = Database::fetchAll(
            "SELECT u.id, u.name, u.email, {$avatar}, r.name AS role
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC
             LIMIT 400"
        );
        $out = [];
        foreach ($rows as $row) {
            $id = (int) $row['id'];
            $out[] = [
                'id'          => $id,
                'name'        => (string) $row['name'],
                'email'       => (string) $row['email'],
                'avatar_path' => (string) ($row['avatar_path'] ?? ''),
                'handle'      => ChatHelper::handleFor((string) $row['name'], $id),
                'role'        => (string) $row['role'],
            ];
        }

        return $out;
    }

    public function displayName(array $conversation, int $viewerId): string
    {
        $type = (string) ($conversation['type'] ?? '');
        if ($type === self::TYPE_DM) {
            foreach ($this->liveMembers($conversation) as $member) {
                if ((int) $member['id'] !== $viewerId) {
                    return (string) $member['name'];
                }
            }

            return 'Direct message';
        }
        $name = trim((string) ($conversation['name'] ?? ''));
        if ($name !== '') {
            return $name;
        }
        if ($type === self::TYPE_TEAM && (int) ($conversation['team_id'] ?? 0) > 0) {
            $team = (new TeamGroup())->find((int) $conversation['team_id']);

            return $team !== null ? (string) $team['name'] : 'Team';
        }
        if ($type === self::TYPE_PROJECT && (int) ($conversation['project_id'] ?? 0) > 0) {
            $projectName = Database::fetchValue('SELECT name FROM projects WHERE id = :id', ['id' => (int) $conversation['project_id']]);

            return is_string($projectName) && $projectName !== '' ? $projectName : 'Project';
        }

        return 'Channel';
    }

    /** @return list<int> */
    private function teamUserIds(int $teamId): array
    {
        if ($teamId < 1 || !TeamGroup::installed()) {
            return [];
        }
        $group = new TeamGroup();
        $ids = array_merge($group->memberIds($teamId), $group->managerIds($teamId));
        if (SchemaHelper::columnExists('teams', 'department_id') && SchemaHelper::tableExists('departments')) {
            $deptManager = (int) Database::fetchValue(
                'SELECT d.manager_id FROM teams t INNER JOIN departments d ON d.id = t.department_id WHERE t.id = :id LIMIT 1',
                ['id' => $teamId]
            );
            if ($deptManager > 0) {
                $ids[] = $deptManager;
            }
        }

        return $this->activeStaffIds($ids);
    }

    /** @return list<int> */
    private function projectUserIds(int $projectId): array
    {
        if ($projectId < 1) {
            return [];
        }
        $ids = [];
        if (SchemaHelper::tableExists('project_members')) {
            $ids = (new ProjectMember())->userIdsForProject($projectId);
        }
        $managerId = (int) Database::fetchValue('SELECT manager_id FROM projects WHERE id = :id LIMIT 1', ['id' => $projectId]);
        if ($managerId > 0) {
            $ids[] = $managerId;
        }

        return $this->activeStaffIds($ids);
    }

    /** @return list<int> */
    private function storedUserIds(int $conversationId): array
    {
        if ($conversationId < 1) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT user_id FROM conversation_members WHERE conversation_id = :c',
            ['c' => $conversationId]
        );

        return $this->activeStaffIds(array_map(static fn (array $r): int => (int) $r['user_id'], $rows));
    }

    /**
     * @param list<int> $ids
     * @return list<int>
     */
    private function activeStaffIds(array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return [];
        }
        $in = implode(',', $ids);
        $rows = Database::fetchAll(
            "SELECT u.id FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.id IN ({$in}) AND u.status = 'active' AND r.name IN ('admin','manager','employee')"
        );

        return array_map(static fn (array $r): int => (int) $r['id'], $rows);
    }

    /**
     * @param list<int> $ids
     * @return list<array{id: int, name: string, email: string, avatar_path: string, handle: string, role: string}>
     */
    private function usersByIds(array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return [];
        }
        $in = implode(',', $ids);
        $avatar = SchemaHelper::columnExists('users', 'avatar_path') ? 'u.avatar_path' : 'NULL AS avatar_path';
        $rows = Database::fetchAll(
            "SELECT u.id, u.name, u.email, {$avatar}, r.name AS role
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.id IN ({$in}) AND u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        );
        $out = [];
        foreach ($rows as $row) {
            $id = (int) $row['id'];
            $out[] = [
                'id'          => $id,
                'name'        => (string) $row['name'],
                'email'       => (string) $row['email'],
                'avatar_path' => (string) ($row['avatar_path'] ?? ''),
                'handle'      => ChatHelper::handleFor((string) $row['name'], $id),
                'role'        => (string) $row['role'],
            ];
        }

        return $out;
    }

    /** @return list<int> */
    private function teamIdsForUser(int $userId): array
    {
        $ids = [];
        if (SchemaHelper::tableExists('team_members')) {
            foreach (Database::fetchAll('SELECT team_id FROM team_members WHERE user_id = :u', ['u' => $userId]) as $row) {
                $ids[] = (int) $row['team_id'];
            }
        }
        if (SchemaHelper::tableExists('team_managers')) {
            foreach (Database::fetchAll('SELECT team_id FROM team_managers WHERE user_id = :u', ['u' => $userId]) as $row) {
                $ids[] = (int) $row['team_id'];
            }
        }

        return array_values(array_unique(array_filter($ids)));
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function decorateSidebarRow(array $row, int $viewerId): array
    {
        $unread = (int) ($row['unread_count'] ?? 0);
        $mentions = (int) ($row['mention_count'] ?? 0);
        $other = null;
        if ((string) $row['type'] === self::TYPE_DM) {
            foreach ($this->liveMembers($row) as $member) {
                if ((int) $member['id'] !== $viewerId) {
                    $other = $member;
                    break;
                }
            }
        }

        return [
            'id'            => (int) $row['id'],
            'type'          => (string) $row['type'],
            'team_id'       => (int) ($row['team_id'] ?? 0),
            'project_id'    => (int) ($row['project_id'] ?? 0),
            'name'          => $this->displayName($row, $viewerId),
            'unread_count'  => $unread,
            'mention_count' => $mentions,
            'last_body'     => (string) ($row['last_body'] ?? ''),
            'last_at'       => (string) ($row['last_at'] ?? ''),
            'last_user_id'  => (int) ($row['last_user_id'] ?? 0),
            'other'         => $other,
            'archived'      => $this->isArchived($row),
        ];
    }
}
