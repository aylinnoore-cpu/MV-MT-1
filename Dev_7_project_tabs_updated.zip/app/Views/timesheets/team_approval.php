<?php
/**
 * Manager approval queue: summary cards, filters, one-click and batch actions.
 *
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, counts: array<string, int>} $result
 * @var array{status: string, user_id: int, q: string} $filters
 * @var list<array<string, mixed>> $people
 * @var array<string, int> $counts
 * @var bool $canApprove
 */

$items  = $result['items'];
$counts = $counts ?? ($result['counts'] ?? []);
$canApprove = $canApprove ?? false;

$statusClass = static fn (string $s): string => match ($s) {
    Timesheet::STATUS_APPROVED  => 'completed',
    Timesheet::STATUS_REJECTED  => 'cancelled',
    Timesheet::STATUS_SUBMITTED => 'hold',
    default                     => 'planning',
};

$tabs = [
    Timesheet::STATUS_SUBMITTED => 'Awaiting',
    Timesheet::STATUS_APPROVED  => 'Approved',
    Timesheet::STATUS_REJECTED  => 'Rejected',
    'all'                       => 'All',
];

$qs = static function (array $extra = []) use ($filters): string {
    $data = array_filter([
        'status'  => $extra['status'] ?? $filters['status'],
        'user_id' => $extra['user_id'] ?? ($filters['user_id'] ?: ''),
        'q'       => $extra['q'] ?? $filters['q'],
        'page'    => $extra['page'] ?? null,
    ], static fn ($v) => $v !== null && $v !== '' && $v !== 0 && $v !== '0');

    return $data === [] ? '' : '?' . http_build_query($data);
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Timesheet approval</h2>
        <p class="page-lead">Review submitted weeks, approve in one click, or send them back with a note.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if ($canApprove && $filters['status'] === Timesheet::STATUS_SUBMITTED && $items !== []): ?>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#batchApproveModal" data-batch-open>
                <i class="fa-solid fa-check-double me-1" aria-hidden="true"></i>Batch approve
            </button>
        <?php endif; ?>
    </div>
</div>

<nav class="filter-tabs" aria-label="Timesheet views">
    <a class="filter-tab" href="<?= e(url('/timesheets')) ?>">My timesheet</a>
    <a class="filter-tab is-active" href="<?= e(url('/timesheets/team')) ?>">Team approval</a>
</nav>

<div class="kpi-grid mb-4">
    <article class="kpi-card">
        <p class="kpi-label">Awaiting</p>
        <p class="kpi-value"><?= (int) ($counts[Timesheet::STATUS_SUBMITTED] ?? 0) ?></p>
        <p class="kpi-sub">Need a decision</p>
    </article>
    <article class="kpi-card">
        <p class="kpi-label">Approved</p>
        <p class="kpi-value"><?= (int) ($counts[Timesheet::STATUS_APPROVED] ?? 0) ?></p>
        <p class="kpi-sub">Locked for billing</p>
    </article>
    <article class="kpi-card">
        <p class="kpi-label">Rejected</p>
        <p class="kpi-value"><?= (int) ($counts[Timesheet::STATUS_REJECTED] ?? 0) ?></p>
        <p class="kpi-sub">Sent back to edit</p>
    </article>
</div>

<nav class="filter-tabs" aria-label="Approval status">
    <?php foreach ($tabs as $key => $label): ?>
        <a class="filter-tab<?= $filters['status'] === $key ? ' is-active' : '' ?>"
           href="<?= e(url('/timesheets/team') . $qs(['status' => $key, 'page' => 1])) ?>">
            <?= e($label) ?>
            <?php
            $tabCount = $key === 'all'
                ? (int) ($counts['all'] ?? 0)
                : (int) ($counts[$key] ?? 0);
            ?>
            <span class="count-pill"><?= $tabCount ?></span>
        </a>
    <?php endforeach; ?>
</nav>

<form method="get" action="<?= e(url('/timesheets/team')) ?>" class="filter-bar">
    <input type="hidden" name="status" value="<?= e($filters['status']) ?>">
    <div class="filter-search">
        <label for="ts-q" class="visually-hidden">Search by name</label>
        <input type="search" id="ts-q" name="q" class="form-control" value="<?= e($filters['q']) ?>" placeholder="Search by name">
    </div>
    <div>
        <label for="ts-user" class="visually-hidden">Person</label>
        <select id="ts-user" name="user_id" class="form-select">
            <option value="">Everyone</option>
            <?php foreach ($people as $person): ?>
                <option value="<?= (int) $person['id'] ?>"<?= (int) $filters['user_id'] === (int) $person['id'] ? ' selected' : '' ?>>
                    <?= e($person['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Queue <span class="count-pill"><?= (int) $result['total'] ?></span></h2>
    </div>
    <?php if ($items === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-folder-open" aria-hidden="true"></i>
            <p>No timesheets match these filters.</p>
        </div>
    <?php else: ?>
        <form method="post" action="<?= e(url('/timesheets/batch-approve')) ?>" id="batchApproveForm" class="d-none" data-single-submit>
            <?= csrf_field() ?>
            <div id="batchApproveIds"></div>
        </form>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                    <thead>
                        <tr>
                            <?php if ($canApprove && $filters['status'] === Timesheet::STATUS_SUBMITTED): ?>
                                <th class="text-center" style="width:2.5rem">
                                    <input type="checkbox" class="form-check-input" data-check-all aria-label="Select all">
                                </th>
                            <?php endif; ?>
                            <th>Person</th>
                            <th>Week</th>
                            <th>Tracked</th>
                            <th>Billable</th>
                            <th>Submitted</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $row): ?>
                            <?php
                            $id     = (int) $row['id'];
                            $status = (string) $row['status'];
                            $startD = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $row['start_date']);
                            $endD   = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $row['end_date']);
                            $label  = ($startD && $endD)
                                ? $startD->format('M j') . ' – ' . $endD->format('M j')
                                : (string) $row['start_date'];
                            ?>
                            <tr>
                                <?php if ($canApprove && $filters['status'] === Timesheet::STATUS_SUBMITTED): ?>
                                    <td class="text-center">
                                        <input type="checkbox" class="form-check-input" name="ids[]" value="<?= $id ?>" data-row-check>
                                    </td>
                                <?php endif; ?>
                                <td>
                                    <div class="fw-medium"><?= e($row['user_name']) ?></div>
                                    <div class="small text-secondary"><?= e($row['user_job_title'] ?: ucfirst((string) $row['user_role'])) ?></div>
                                </td>
                                <td><?= e($label) ?></td>
                                <td class="mono"><?= e(FormatHelper::hours((int) $row['total_seconds'])) ?>h</td>
                                <td class="mono"><?= e(FormatHelper::hours((int) $row['billable_seconds'])) ?>h</td>
                                <td><?= e(FormatHelper::datetime((string) ($row['submitted_at'] ?? ''), 'M j, H:i')) ?></td>
                                <td><span class="status-badge status-<?= e($statusClass($status)) ?>"><?= e($status) ?></span></td>
                                <td class="text-end text-nowrap">
                                    <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/timesheets/' . $id)) ?>">View</a>
                                    <?php if ($canApprove && $status === Timesheet::STATUS_SUBMITTED): ?>
                                        <form method="post" action="<?= e(url('/timesheets/' . $id . '/approve')) ?>" class="d-inline"
                                              data-confirm="Approve this timesheet? Time entries will be locked."
                                              data-single-submit>
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-primary">Approve</button>
                                        </form>
                                        <button type="button"
                                                class="btn btn-sm btn-outline-danger"
                                                data-bs-toggle="modal"
                                                data-bs-target="#rejectTimesheetModal"
                                                data-reject-id="<?= $id ?>"
                                                data-reject-name="<?= e($row['user_name']) ?>"
                                                data-reject-week="<?= e($label) ?>">
                                            Reject
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php if ($result['pages'] > 1): ?>
            <nav class="pager" aria-label="Timesheet pages">
                <?php for ($p = 1; $p <= $result['pages']; $p++): ?>
                    <a class="btn btn-sm <?= $p === (int) $result['page'] ? 'btn-primary' : 'btn-outline-secondary' ?>"
                       href="<?= e(url('/timesheets/team') . $qs(['page' => $p])) ?>"><?= $p ?></a>
                <?php endfor; ?>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>

<div class="modal fade" id="rejectTimesheetModal" tabindex="-1" aria-labelledby="rejectTimesheetTitle" aria-hidden="true">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('/timesheets/0/reject')) ?>" id="rejectTimesheetForm" data-single-submit>
            <?= csrf_field() ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title fs-5" id="rejectTimesheetTitle">Reject timesheet</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="text-secondary" id="rejectTimesheetLead">Send this timesheet back with a note so the person can edit it.</p>
                    <label for="reject_reason" class="form-label">Reason</label>
                    <textarea id="reject_reason" name="reason" class="form-control" rows="4" required maxlength="500"
                              placeholder="What needs to change?"></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject timesheet</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="batchApproveModal" tabindex="-1" aria-labelledby="batchApproveTitle" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title fs-5" id="batchApproveTitle">Approve selected timesheets</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="mb-0">Approve <strong data-batch-count>0</strong> selected timesheet(s)? Their time entries will be locked.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" data-batch-confirm>Approve selected</button>
            </div>
        </div>
    </div>
</div>
