<?php
/**
 * Task detail: metadata, subtask tree, time log, schedule history, actions.
 *
 * @var array<string, mixed> $task
 * @var array<string, mixed> $project
 * @var array<string, mixed> $tree
 * @var list<array<string, mixed>> $children
 * @var list<array<string, mixed>> $members
 * @var list<array<string, mixed>> $timeLog
 * @var list<array<string, mixed>> $scheduleLog
 * @var list<string> $statuses
 * @var bool $canEdit
 * @var bool $canDelete
 * @var bool $canCreate
 * @var bool $canTrack
 * @var bool $canManual
 * @var bool $canSchedule
 * @var list<array<string, mixed>> $trackProjects
 */

$tid = (int) $task['id'];
$pct = (int) ($task['completion_percent'] ?? 0);
$names = array_map(static fn (array $a): string => (string) $a['name'], $task['assignees'] ?? []);
$assigneeLabel = $names === [] ? 'Anyone' : implode(', ', $names);
$overdue = !empty($task['due_date']) && (string) $task['due_date'] < gmdate('Y-m-d') && !Task::isClosed((string) $task['status']);
$planned = (float) ($task['planned_hours'] ?? $task['estimated_hours'] ?? 0);
$trackedH = (float) ($task['tracked_hours'] ?? 0);
$trackedS = (int) ($task['tracked_seconds'] ?? 0);

$renderTree = static function (array $nodes, int $depth = 0) use (&$renderTree, $canEdit): void {
    echo '<ul class="tk-tree' . ($depth === 0 ? ' tk-tree-root' : '') . '">';
    foreach ($nodes as $node) {
        $nid = (int) $node['id'];
        $done = Task::isDone((string) $node['status']);
        $npct = (int) ($node['completion_percent'] ?? 0);
        echo '<li class="tk-tree-item' . ($done ? ' is-done' : '') . '">';
        echo '<a class="tk-tree-link" href="' . e(url('/tasks/' . $nid)) . '">';
        echo '<span class="tk-tree-check" aria-hidden="true"><i class="fa-solid ' . ($done ? 'fa-circle-check' : 'fa-circle') . '"></i></span>';
        echo '<span class="tk-tree-name">' . e($node['name']) . '</span>';
        echo '<span class="status-badge status-' . e(Task::statusCss((string) $node['status'])) . '">' . e($node['status']) . '</span>';
        echo '<span class="tk-tree-pct">' . $npct . '%</span>';
        echo '</a>';
        if (!empty($node['children'])) {
            $renderTree($node['children'], $depth + 1);
        }
        echo '</li>';
    }
    echo '</ul>';
};
?>
<div class="page-toolbar">
    <div>
        <p class="cf-breadcrumb mb-1">
            <a href="<?= e(url('/tasks')) ?>">Tasks</a>
            <span class="text-secondary"> / </span>
            <a href="<?= e(url('/projects/' . (int) $project['id'] . '?tab=tasks')) ?>"><?= e($project['name']) ?></a>
            <?php if (!empty($task['parent_name'])): ?>
                <span class="text-secondary"> / </span>
                <a href="<?= e(url('/tasks/' . (int) $task['parent_task_id'])) ?>"><?= e($task['parent_name']) ?></a>
            <?php endif; ?>
        </p>
        <h2 class="page-heading"><?= e($task['name']) ?></h2>
        <p class="page-lead mb-0"><?= e($project['client_name'] ?? '') ?></p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if ($canTrack && !Task::isClosed((string) $task['status'])): ?>
            <button type="button" class="btn btn-primary" data-timer-start
                    data-project-id="<?= (int) $task['project_id'] ?>" data-task-id="<?= $tid ?>">
                <i class="fa-solid fa-play me-1" aria-hidden="true"></i> Start timer
            </button>
        <?php endif; ?>
        <?php if ($canManual): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/time?manual=1&project_id=' . (int) $task['project_id'] . '&task_id=' . $tid)) ?>"><i class="fa-solid fa-plus me-1" aria-hidden="true"></i> Add manual time</a>
        <?php endif; ?>
        <?php if ($canSchedule): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/schedule?project_id=' . (int) $task['project_id'] . '&task_id=' . $tid)) ?>"><i class="fa-regular fa-calendar me-1" aria-hidden="true"></i> Schedule</a>
        <?php endif; ?>
        <?php if ($canEdit): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/tasks/' . $tid . '/edit')) ?>">Edit</a>
        <?php endif; ?>
        <?php if ($canDelete): ?>
            <form method="post" action="<?= e(url('/tasks/' . $tid . '/delete')) ?>" class="m-0"
                  data-confirm="Delete task <?= e($task['name']) ?>? Subtasks will be deleted too.">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-outline-danger">Delete</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <section class="panel mb-4">
            <div class="panel-head">
                <h2 class="panel-title">Progress</h2>
                <?php if ($canEdit): ?>
                    <form method="post" action="<?= e(url('/tasks/' . $tid . '/status')) ?>" class="tk-status-form" data-task-status-form>
                        <?= csrf_field() ?>
                        <input type="hidden" name="back" value="<?= e('/tasks/' . $tid) ?>">
                        <label class="visually-hidden" for="task-status">Status</label>
                        <select id="task-status" name="status" class="form-select form-select-sm" data-auto-submit>
                            <?php foreach ($statuses as $st): ?>
                                <option value="<?= e($st) ?>"<?= (string) $task['status'] === $st ? ' selected' : '' ?>><?= e($st) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                <?php else: ?>
                    <span class="status-badge status-<?= e(Task::statusCss((string) $task['status'])) ?>"><?= e($task['status']) ?></span>
                <?php endif; ?>
            </div>
            <div class="panel-body">
                <div class="progress-label"><span>Completion</span><span><?= $pct ?>%</span></div>
                <div class="progress mb-3"><div class="progress-bar" style="width: <?= $pct ?>%"></div></div>
                <div class="tk-hours">
                    <article><span>Planned</span><strong><?= e(number_format($planned, 2)) ?> h</strong></article>
                    <article><span>Tracked</span><strong><?= e(FormatHelper::duration($trackedS)) ?></strong><small><?= e(number_format($trackedH, 2)) ?> h</small></article>
                    <article><span>Remaining</span><strong><?= e(number_format(max(0, $planned - $trackedH), 2)) ?> h</strong></article>
                </div>
                <?php if (!empty($task['description'])): ?>
                    <p class="mt-3 mb-0"><?= nl2br(e($task['description'])) ?></p>
                <?php endif; ?>
            </div>
        </section>

        <section class="panel mb-4">
            <div class="panel-head">
                <h2 class="panel-title">Subtasks</h2>
                <?php if ($canCreate): ?>
                    <a class="btn btn-sm btn-primary" href="<?= e(url('/tasks/create?parent_task_id=' . $tid)) ?>">Add subtask</a>
                <?php endif; ?>
            </div>
            <div class="panel-body">
                <?php if ($children === []): ?>
                    <p class="text-secondary mb-0">No subtasks yet.</p>
                <?php else: ?>
                    <?php $renderTree($children); ?>
                <?php endif; ?>
            </div>
        </section>

        <section class="panel mb-4">
            <div class="panel-head"><h2 class="panel-title">Time log</h2></div>
            <div class="panel-body p-0">
                <?php if ($timeLog === []): ?>
                    <p class="text-secondary p-3 mb-0">No time recorded on this task yet.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table data-table mb-0">
                            <thead><tr><th>When</th><th>Person</th><th>Duration</th><th>Note</th></tr></thead>
                            <tbody>
                            <?php foreach ($timeLog as $entry): ?>
                                <tr>
                                    <td><?= e(FormatHelper::datetime((string) ($entry['started_at'] ?? ''), 'M j, H:i')) ?></td>
                                    <td><?= e($entry['user_name'] ?? '') ?></td>
                                    <td class="mono"><?= e(FormatHelper::duration((int) ($entry['duration_seconds'] ?? 0))) ?></td>
                                    <td><?= e($entry['description'] ?? '') ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="panel mb-4">
            <div class="panel-head"><h2 class="panel-title">Schedule history</h2></div>
            <div class="panel-body p-0">
                <?php if ($scheduleLog === []): ?>
                    <p class="text-secondary p-3 mb-0">No planned blocks on this task.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table data-table mb-0">
                            <thead><tr><th>When</th><th>Person</th><th>Hours</th><th>Status</th></tr></thead>
                            <tbody>
                            <?php foreach ($scheduleLog as $block): ?>
                                <tr>
                                    <td><?= e(FormatHelper::datetime((string) $block['start_datetime'], 'M j, H:i')) ?>
                                        – <?= e(FormatHelper::datetime((string) $block['end_datetime'], 'H:i')) ?></td>
                                    <td><?= e($block['user_name'] ?? '') ?></td>
                                    <td class="mono"><?= e(number_format((float) ($block['estimated_hours'] ?? 0), 2)) ?> h</td>
                                    <td><span class="status-badge status-<?= e(Task::statusCss((string) $block['status'])) ?>"><?= e($block['status']) ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <div class="col-lg-4">
        <section class="panel mb-4">
            <div class="panel-head"><h2 class="panel-title">Details</h2></div>
            <div class="panel-body">
                <dl class="tk-meta">
                    <dt>Project</dt>
                    <dd><a href="<?= e(url('/projects/' . (int) $project['id'] . '?tab=tasks')) ?>"><?= e($project['name']) ?></a></dd>
                    <dt>Priority</dt>
                    <dd><span class="priority-badge priority-<?= e(Task::priorityCss((string) ($task['priority'] ?? 'Medium'))) ?>"><?= e($task['priority'] ?? 'Medium') ?></span></dd>
                    <dt>Assignees</dt>
                    <dd><?= e($assigneeLabel) ?></dd>
                    <dt>Start</dt>
                    <dd><?= !empty($task['start_date']) ? e(FormatHelper::date((string) $task['start_date'] . ' 00:00:00', 'M j, Y')) : '–' ?></dd>
                    <dt>Due</dt>
                    <dd class="<?= $overdue ? 'tk-due is-overdue' : '' ?>"><?= !empty($task['due_date']) ? e(FormatHelper::date((string) $task['due_date'] . ' 00:00:00', 'M j, Y')) : '–' ?></dd>
                    <dt>Billable</dt>
                    <dd><?= (int) ($task['is_billable'] ?? 0) === 1 ? 'Yes' : 'No' ?></dd>
                    <dt>Created</dt>
                    <dd><?= e(FormatHelper::datetime((string) ($task['created_at'] ?? ''), 'M j, Y H:i')) ?><?= !empty($task['created_by_name']) ? ' by ' . e($task['created_by_name']) : '' ?></dd>
                </dl>
            </div>
        </section>
    </div>
</div>
