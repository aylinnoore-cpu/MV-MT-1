-- ============================================================================
-- TimeTrack: the ONLY SQL file you need to run.
-- Target : live database u897128490_timetrack (MariaDB 11.8). Also runs on MySQL 8.
-- How    : phpMyAdmin > select the database > Import (or paste into the SQL tab).
-- Before : take a phpMyAdmin Export backup first, and upload the new PHP files
--          FIRST (the old code still selects clients.company, which STEP 8 drops).
-- Safe   : safe to run twice. No user, project, task, schedule or time row is
--          deleted. The only rows removed are the duplicate/empty timesheet header
--          rows described in STEP 4 and orphaned timesheet_entries link rows
--          (STEP 5). STEP 8 drops the unused clients.company column.
-- Portable: no ADD/DROP ... IF [NOT] EXISTS (MariaDB-only). Every structural change
--          is guarded by an information_schema check + PREPARE/EXECUTE, so the same
--          file works on MariaDB 10.4+/11.x and MySQL 8.
-- Result : the last query prints a checklist. Every row must say OK.
-- ============================================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- ---------------------------------------------------------------------------
-- STEP 1. Missing tables
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `agent_pair_attempts` (
    `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
    `ip` varchar(45) NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_agent_pair_attempts_ip_created` (`ip`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `client_users` (
    `user_id` int UNSIGNED NOT NULL,
    `client_id` int UNSIGNED NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`, `client_id`),
    UNIQUE KEY `uq_client_users_user_client` (`user_id`, `client_id`),
    KEY `idx_client_users_client` (`client_id`),
    CONSTRAINT `fk_client_users_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_client_users_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- STEP 2. Forced password change flag + keep users.role in sync with role_id
-- ---------------------------------------------------------------------------
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = 'must_change_password') = 0,
    'ALTER TABLE `users` ADD COLUMN `must_change_password` tinyint(1) NOT NULL DEFAULT 0 AFTER `password_changed_at`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

UPDATE `users` u
INNER JOIN `roles` r ON r.id = u.role_id
SET u.role = r.name
WHERE u.role <> r.name;

-- Clients are read-only: remove leftover schedule/time/admin grants.
DELETE rp FROM `role_permissions` rp
INNER JOIN `roles` r ON r.id = rp.role_id
INNER JOIN `permissions` p ON p.id = rp.permission_id
WHERE r.name = 'client'
  AND p.name IN (
      'schedule.view', 'schedule.create', 'schedule.edit', 'schedule.delete', 'schedule.view_team',
      'time.track', 'time.view_own', 'time.edit_own', 'time.approve',
      'users.view', 'settings.manage', 'reports.export', 'reports.billing'
  );

-- ---------------------------------------------------------------------------
-- STEP 3. One lock model: drop time_entries.status / approved_by / approved_at
-- Only runs if every entry is still 'Pending' (true on your live copy).
-- If some entry were Approved, this step is skipped and the checklist says so.
-- ---------------------------------------------------------------------------
SET @has_status := (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND column_name = 'status');
SET @non_pending := 0;
SET @sql := IF(@has_status = 1,
    'SELECT COUNT(*) INTO @non_pending FROM time_entries WHERE status <> ''Pending''',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @do_drop := IF(@has_status = 1 AND @non_pending = 0, 1, 0);

-- Drop whatever foreign key sits on time_entries.approved_by (whatever its name is).
SET @fk_name := (
    SELECT constraint_name FROM information_schema.key_column_usage
    WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND column_name = 'approved_by'
      AND referenced_table_name IS NOT NULL
    LIMIT 1
);
SET @sql := IF(@do_drop = 1 AND @fk_name IS NOT NULL,
    CONCAT('ALTER TABLE `time_entries` DROP FOREIGN KEY `', @fk_name, '`'),
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF(@do_drop = 1 AND (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND index_name = 'idx_time_entries_status') > 0,
    'ALTER TABLE `time_entries` DROP INDEX `idx_time_entries_status`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF(@do_drop = 1 AND (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND index_name = 'idx_time_entries_approved_by') > 0,
    'ALTER TABLE `time_entries` DROP INDEX `idx_time_entries_approved_by`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF(@do_drop = 1 AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND column_name = 'status') = 1,
    'ALTER TABLE `time_entries` DROP COLUMN `status`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF(@do_drop = 1 AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND column_name = 'approved_by') = 1,
    'ALTER TABLE `time_entries` DROP COLUMN `approved_by`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF(@do_drop = 1 AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND column_name = 'approved_at') = 1,
    'ALTER TABLE `time_entries` DROP COLUMN `approved_at`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------------------------------------------------------------------------
-- STEP 4. Timesheets: one sheet per person per period
-- Your live data: user 1 has sheets 1, 4, 5, 6 for 2026-09-28..2026-10-04 and a
-- leftover empty Rejected fragment (sheet 3). They are merged into the oldest
-- sheet (id 1). Because sheets 1 and 6 were only Submitted (never approved),
-- the merged sheet is Submitted so nothing becomes approved by accident.
-- Sheets that were approved (4, 5) go back to Submitted: approve it once more.
-- ---------------------------------------------------------------------------
DROP TEMPORARY TABLE IF EXISTS tmp_ts_groups;
CREATE TEMPORARY TABLE tmp_ts_groups AS
SELECT user_id, start_date, end_date,
       MIN(id) AS keep_id,
       COUNT(*) AS n,
       SUM(status = 'Approved') AS n_approved,
       SUM(status = 'Submitted') AS n_submitted,
       MIN(submitted_at) AS first_submitted
FROM `timesheets`
GROUP BY user_id, start_date, end_date
HAVING COUNT(*) > 1;

UPDATE `timesheet_entries` tse
INNER JOIN `timesheets` t ON t.id = tse.timesheet_id
INNER JOIN tmp_ts_groups g ON g.user_id = t.user_id AND g.start_date = t.start_date AND g.end_date = t.end_date
SET tse.timesheet_id = g.keep_id
WHERE t.id <> g.keep_id;

UPDATE `timesheets` k
INNER JOIN tmp_ts_groups g ON g.keep_id = k.id
SET k.status = CASE
        WHEN g.n_approved = g.n THEN 'Approved'
        WHEN g.n_submitted > 0 THEN 'Submitted'
        ELSE k.status
    END,
    k.approved_by = IF(g.n_approved = g.n, k.approved_by, NULL),
    k.approved_at = IF(g.n_approved = g.n, k.approved_at, NULL),
    k.rejection_reason = IF(g.n_submitted > 0 AND g.n_approved <> g.n, NULL, k.rejection_reason),
    k.submitted_at = COALESCE(g.first_submitted, k.submitted_at);

DELETE t FROM `timesheets` t
INNER JOIN tmp_ts_groups g ON g.user_id = t.user_id AND g.start_date = t.start_date AND g.end_date = t.end_date
WHERE t.id <> g.keep_id;

UPDATE `timesheets` t
INNER JOIN tmp_ts_groups g ON g.keep_id = t.id
SET t.total_seconds = COALESCE((
        SELECT SUM(te.duration_seconds) FROM timesheet_entries tse
        INNER JOIN time_entries te ON te.id = tse.time_entry_id
        WHERE tse.timesheet_id = t.id), 0),
    t.billable_seconds = COALESCE((
        SELECT SUM(CASE WHEN te.is_billable = 1 THEN te.duration_seconds ELSE 0 END) FROM timesheet_entries tse
        INNER JOIN time_entries te ON te.id = tse.time_entry_id
        WHERE tse.timesheet_id = t.id), 0);

DROP TEMPORARY TABLE IF EXISTS tmp_ts_groups;

-- Remove empty Draft/Rejected fragments that overlap another sheet of the same person.
-- (Self-join DELETE: works on MariaDB and MySQL 8, no "target table in FROM" error.)
DELETE t FROM `timesheets` t
INNER JOIN `timesheets` o
        ON o.user_id = t.user_id AND o.id <> t.id
       AND o.start_date <= t.end_date AND o.end_date >= t.start_date
WHERE t.status IN ('Draft', 'Rejected')
  AND NOT EXISTS (SELECT 1 FROM `timesheet_entries` x WHERE x.timesheet_id = t.id);

-- Enforce one sheet per person per period.

SET @sql := IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'timesheets' AND index_name = 'uq_timesheets_user_period') = 0,
    'ALTER TABLE `timesheets` ADD UNIQUE INDEX `uq_timesheets_user_period` (`user_id`, `start_date`, `end_date`)',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF(1 = 1 AND (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'timesheets' AND index_name = 'idx_timesheets_user_period') > 0,
    'ALTER TABLE `timesheets` DROP INDEX `idx_timesheets_user_period`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------------------------------------------------------------------------
-- STEP 5. timesheet_entries: same column type as time_entries.id + real FKs
-- ---------------------------------------------------------------------------
DELETE tse FROM `timesheet_entries` tse
LEFT JOIN `time_entries` te ON te.id = tse.time_entry_id
WHERE te.id IS NULL;

DELETE tse FROM `timesheet_entries` tse
LEFT JOIN `timesheets` t ON t.id = tse.timesheet_id
WHERE t.id IS NULL;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'timesheet_entries' AND column_name = 'time_entry_id' AND data_type = 'bigint' AND column_type LIKE '%unsigned%') = 0,
    'ALTER TABLE `timesheet_entries` MODIFY `time_entry_id` bigint UNSIGNED NOT NULL',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.table_constraints WHERE constraint_schema = DATABASE() AND table_name = 'timesheet_entries' AND constraint_name = 'fk_timesheet_entries_timesheet' AND constraint_type = 'FOREIGN KEY') = 0,
    'ALTER TABLE `timesheet_entries` ADD CONSTRAINT `fk_timesheet_entries_timesheet` FOREIGN KEY (`timesheet_id`) REFERENCES `timesheets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.table_constraints WHERE constraint_schema = DATABASE() AND table_name = 'timesheet_entries' AND constraint_name = 'fk_timesheet_entries_entry' AND constraint_type = 'FOREIGN KEY') = 0,
    'ALTER TABLE `timesheet_entries` ADD CONSTRAINT `fk_timesheet_entries_entry` FOREIGN KEY (`time_entry_id`) REFERENCES `time_entries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------------------------------------------------------------------------
-- STEP 6. time_entries: report indexes + "end not before start" CHECK
-- (the CHECK is added only if no existing row breaks it)
-- ---------------------------------------------------------------------------

SET @sql := IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND index_name = 'idx_time_entries_user_started') = 0,
    'ALTER TABLE `time_entries` ADD INDEX `idx_time_entries_user_started` (`user_id`, `started_at`)',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND index_name = 'idx_time_entries_project_started') = 0,
    'ALTER TABLE `time_entries` ADD INDEX `idx_time_entries_project_started` (`project_id`, `started_at`)',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @bad_rows := (SELECT COUNT(*) FROM time_entries WHERE ended_at IS NOT NULL AND ended_at < started_at);
SET @sql := IF(@bad_rows = 0 AND (SELECT COUNT(*) FROM information_schema.table_constraints WHERE constraint_schema = DATABASE() AND table_name = 'time_entries' AND constraint_name = 'chk_time_entries_ended_after_started') = 0,
    'ALTER TABLE `time_entries` ADD CONSTRAINT `chk_time_entries_ended_after_started` CHECK (`ended_at` IS NULL OR `ended_at` >= `started_at`)',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------------------------------------------------------------------------
-- STEP 7. Reports access: the admin decides who can open Reports.
-- No row = no access (admins always have full access). Existing people who
-- could already open Reports through their role keep access once, so nothing
-- disappears on upgrade; the admin can then change it on Reports > Access.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `report_access` (
    `user_id` int UNSIGNED NOT NULL,
    `access_level` enum('own','all') NOT NULL DEFAULT 'own',
    `can_export` tinyint(1) NOT NULL DEFAULT 0,
    `can_billing` tinyint(1) NOT NULL DEFAULT 0,
    `updated_by` int UNSIGNED NULL,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`),
    CONSTRAINT `fk_report_access_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `report_access` (`user_id`, `access_level`, `can_export`, `can_billing`)
SELECT u.id,
       IF(EXISTS(SELECT 1 FROM role_permissions rp INNER JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = u.role_id AND p.name = 'time.view_all'), 'all', 'own'),
       IF(EXISTS(SELECT 1 FROM role_permissions rp INNER JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = u.role_id AND p.name = 'reports.export'), 1, 0),
       IF(EXISTS(SELECT 1 FROM role_permissions rp INNER JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = u.role_id AND p.name = 'reports.billing'), 1, 0)
FROM users u
INNER JOIN roles r ON r.id = u.role_id
WHERE r.name <> 'admin'
  AND EXISTS(SELECT 1 FROM role_permissions rp INNER JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = u.role_id AND p.name = 'reports.view');

-- ---------------------------------------------------------------------------
-- STEP 8. Clients: drop the unused clients.company column (Name and Company are
-- the same thing). Does nothing if the column is already gone.
-- This permanently deletes that column's data; your backup covers it.
-- ---------------------------------------------------------------------------

SET @sql := IF(1 = 1 AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'clients' AND column_name = 'company') = 1,
    'ALTER TABLE `clients` DROP COLUMN `company`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ---------------------------------------------------------------------------
-- STEP 9. Schedules: recurrence_parent_id (+ index + foreign key) and the
-- scheduling_enabled workspace setting
-- The new column copies the exact type of schedules.id, so the foreign key is valid.
-- ---------------------------------------------------------------------------
SET @sched_id_type := (
    SELECT column_type FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'schedules' AND column_name = 'id'
);
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'schedules' AND column_name = 'recurrence_parent_id') = 0,
    CONCAT('ALTER TABLE `schedules` ADD COLUMN `recurrence_parent_id` ', @sched_id_type, ' NULL DEFAULT NULL'),
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- A pre-existing column could hold ids that no longer exist: clear those links so the FK can be created.
UPDATE `schedules` s
LEFT JOIN `schedules` p ON p.id = s.recurrence_parent_id
SET s.recurrence_parent_id = NULL
WHERE s.recurrence_parent_id IS NOT NULL AND p.id IS NULL;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'schedules' AND index_name = 'idx_schedules_recurrence_parent') = 0,
    'ALTER TABLE `schedules` ADD INDEX `idx_schedules_recurrence_parent` (`recurrence_parent_id`)',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.key_column_usage WHERE table_schema = DATABASE() AND table_name = 'schedules' AND column_name = 'recurrence_parent_id' AND referenced_table_name = 'schedules') = 0,
    'ALTER TABLE `schedules` ADD CONSTRAINT `fk_schedules_recurrence_parent` FOREIGN KEY (`recurrence_parent_id`) REFERENCES `schedules` (`id`) ON DELETE SET NULL',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- Scheduling is on by default: add the setting wherever the row is missing (never overwrites an existing value).
INSERT INTO `workspace_settings` (`workspace_id`, `setting_key`, `setting_value`, `updated_at`)
SELECT w.id, 'scheduling_enabled', '1', UTC_TIMESTAMP()
FROM `workspaces` w
WHERE NOT EXISTS (
    SELECT 1 FROM `workspace_settings` ws
    WHERE ws.workspace_id = w.id AND ws.setting_key = 'scheduling_enabled'
);

-- ---------------------------------------------------------------------------
-- STEP 10. SMTP invitations: pending users, assignment staging, password reset
-- Tokens are stored as SHA-256 hashes only. SMTP password lives in `settings`
-- (group mail) and is encrypted by the application, never in this file.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_invitations` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `email` varchar(190) NOT NULL,
    `name` varchar(120) NOT NULL,
    `job_title` varchar(100) NULL DEFAULT NULL,
    `phone` varchar(30) NULL DEFAULT NULL,
    `account_status` varchar(20) NOT NULL DEFAULT 'active',
    `invited_by` int UNSIGNED NOT NULL,
    `role_id` int UNSIGNED NOT NULL,
    `user_id` int UNSIGNED NULL DEFAULT NULL,
    `token_hash` char(64) NOT NULL,
    `expires_at` datetime NOT NULL,
    `status` varchar(20) NOT NULL DEFAULT 'pending',
    `sent_at` datetime NULL DEFAULT NULL,
    `accepted_at` datetime NULL DEFAULT NULL,
    `cancelled_at` datetime NULL DEFAULT NULL,
    `last_sent_at` datetime NULL DEFAULT NULL,
    `send_count` int UNSIGNED NOT NULL DEFAULT 0,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_user_invitations_token_hash` (`token_hash`),
    KEY `idx_user_invitations_email` (`email`),
    KEY `idx_user_invitations_status_expires` (`status`, `expires_at`),
    KEY `idx_user_invitations_invited_by` (`invited_by`),
    KEY `idx_user_invitations_user` (`user_id`),
    CONSTRAINT `fk_user_invitations_invited_by` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_user_invitations_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_user_invitations_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_invitation_projects` (
    `invitation_id` int UNSIGNED NOT NULL,
    `project_id` int UNSIGNED NOT NULL,
    PRIMARY KEY (`invitation_id`, `project_id`),
    KEY `idx_user_invitation_projects_project` (`project_id`),
    CONSTRAINT `fk_user_invitation_projects_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_user_invitation_projects_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_invitation_tasks` (
    `invitation_id` int UNSIGNED NOT NULL,
    `task_id` int UNSIGNED NOT NULL,
    PRIMARY KEY (`invitation_id`, `task_id`),
    KEY `idx_user_invitation_tasks_task` (`task_id`),
    CONSTRAINT `fk_user_invitation_tasks_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_user_invitation_tasks_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` int UNSIGNED NOT NULL,
    `token_hash` char(64) NOT NULL,
    `expires_at` datetime NOT NULL,
    `used_at` datetime NULL DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_password_reset_tokens_hash` (`token_hash`),
    KEY `idx_password_reset_tokens_user` (`user_id`),
    CONSTRAINT `fk_password_reset_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- STEP: Approval hierarchy (teams)
-- Admin > Project > Project Manager (projects.manager_id) > Team Manager > Team > Members
-- A timesheet goes only to the submitter's team manager, the project
-- manager of the team's project, and admins. Safe to re-run.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `teams` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id` int UNSIGNED NOT NULL,
    `name` varchar(120) NOT NULL,
    `manager_id` int UNSIGNED NULL DEFAULT NULL,
    `lead_id` int UNSIGNED NULL DEFAULT NULL,
    `status` varchar(20) NOT NULL DEFAULT 'active',
    `created_by` int UNSIGNED NULL DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_teams_project_name` (`project_id`, `name`),
    KEY `idx_teams_manager` (`manager_id`),
    KEY `idx_teams_lead` (`lead_id`),
    CONSTRAINT `fk_teams_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_teams_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_teams_lead` FOREIGN KEY (`lead_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `team_members` (
    `team_id` int UNSIGNED NOT NULL,
    `user_id` int UNSIGNED NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`team_id`, `user_id`),
    KEY `idx_team_members_user` (`user_id`),
    CONSTRAINT `fk_team_members_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_team_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'teams') = 1
        AND (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_invitation_teams') = 0,
    'CREATE TABLE `user_invitation_teams` (
        `invitation_id` int UNSIGNED NOT NULL,
        `team_id` int UNSIGNED NOT NULL,
        PRIMARY KEY (`invitation_id`, `team_id`),
        KEY `idx_user_invitation_teams_team` (`team_id`),
        CONSTRAINT `fk_user_invitation_teams_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT `fk_user_invitation_teams_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`)
VALUES
    ('smtp_enabled', '0', 'bool', 'mail', 'Send mail through SMTP'),
    ('smtp_host', '', 'string', 'mail', 'SMTP host'),
    ('smtp_port', '587', 'int', 'mail', 'SMTP port'),
    ('smtp_username', '', 'string', 'mail', 'SMTP username'),
    ('smtp_password', '', 'string', 'mail', 'SMTP password (encrypted by the app)'),
    ('smtp_encryption', 'tls', 'string', 'mail', 'SMTP encryption: tls, ssl or none'),
    ('smtp_from_name', '', 'string', 'mail', 'From name'),
    ('smtp_from_email', '', 'string', 'mail', 'From email'),
    ('smtp_reply_to', '', 'string', 'mail', 'Reply-To email'),
    ('invite_expiry_days', '7', 'int', 'mail', 'Invitation link lifetime in days');

-- ---------------------------------------------------------------------------
-- STEP 11. Task hierarchy: team stamp, review columns, workspace settings
-- Additive. Existing tasks stay team_id NULL (project-level). Safe to re-run.
-- task_scope_mode defaults to legacy so deploying the code does not change behaviour.
-- ---------------------------------------------------------------------------
SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'team_id') = 0,
    'ALTER TABLE `tasks` ADD COLUMN `team_id` int UNSIGNED NULL DEFAULT NULL AFTER `project_id`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'tasks' AND index_name = 'idx_tasks_team') = 0,
    'ALTER TABLE `tasks` ADD INDEX `idx_tasks_team` (`team_id`)',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'teams') = 1
        AND (SELECT COUNT(*) FROM information_schema.key_column_usage WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'team_id' AND referenced_table_name = 'teams') = 0,
    'ALTER TABLE `tasks` ADD CONSTRAINT `fk_tasks_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE SET NULL ON UPDATE CASCADE',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'reviewed_by') = 0,
    'ALTER TABLE `tasks` ADD COLUMN `reviewed_by` int UNSIGNED NULL DEFAULT NULL AFTER `created_by`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'reviewed_at') = 0,
    'ALTER TABLE `tasks` ADD COLUMN `reviewed_at` datetime NULL DEFAULT NULL AFTER `reviewed_by`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'review_note') = 0,
    'ALTER TABLE `tasks` ADD COLUMN `review_note` varchar(500) NULL DEFAULT NULL AFTER `reviewed_at`',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF((SELECT COUNT(*) FROM information_schema.key_column_usage WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'reviewed_by' AND referenced_table_name = 'users') = 0
        AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'reviewed_by') = 1,
    'ALTER TABLE `tasks` ADD CONSTRAINT `fk_tasks_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE',
    'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

INSERT INTO `workspace_settings` (`workspace_id`, `setting_key`, `setting_value`, `updated_at`)
SELECT w.id, 'task_scope_mode', 'legacy', UTC_TIMESTAMP()
FROM `workspaces` w
WHERE NOT EXISTS (
    SELECT 1 FROM `workspace_settings` ws
    WHERE ws.workspace_id = w.id AND ws.setting_key = 'task_scope_mode'
);

INSERT INTO `workspace_settings` (`workspace_id`, `setting_key`, `setting_value`, `updated_at`)
SELECT w.id, 'other_team_tasks_visibility', 'readonly', UTC_TIMESTAMP()
FROM `workspaces` w
WHERE NOT EXISTS (
    SELECT 1 FROM `workspace_settings` ws
    WHERE ws.workspace_id = w.id AND ws.setting_key = 'other_team_tasks_visibility'
);

INSERT INTO `workspace_settings` (`workspace_id`, `setting_key`, `setting_value`, `updated_at`)
SELECT w.id, 'members_can_create_subtasks', '0', UTC_TIMESTAMP()
FROM `workspaces` w
WHERE NOT EXISTS (
    SELECT 1 FROM `workspace_settings` ws
    WHERE ws.workspace_id = w.id AND ws.setting_key = 'members_can_create_subtasks'
);

INSERT INTO `workspace_settings` (`workspace_id`, `setting_key`, `setting_value`, `updated_at`)
SELECT w.id, 'task_review_required', '1', UTC_TIMESTAMP()
FROM `workspaces` w
WHERE NOT EXISTS (
    SELECT 1 FROM `workspace_settings` ws
    WHERE ws.workspace_id = w.id AND ws.setting_key = 'task_review_required'
);

-- ---------------------------------------------------------------------------
-- STEP: Team lead removed. Existing leads become members so nobody drops out,
-- then lead_id is cleared. The column stays in the database, unused. Safe to re-run.
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO `team_members` (`team_id`, `user_id`, `created_at`)
SELECT t.id, t.lead_id, UTC_TIMESTAMP()
FROM `teams` t
WHERE t.lead_id IS NOT NULL
  AND t.lead_id > 0
  AND (t.manager_id IS NULL OR t.manager_id <> t.lead_id);

UPDATE `teams` SET `lead_id` = NULL WHERE `lead_id` IS NOT NULL;

-- ---------------------------------------------------------------------------
-- STEP: Role label. The "employee" role is shown as "Member" (name unchanged). Safe to re-run.
-- ---------------------------------------------------------------------------
UPDATE `roles` SET `display_name` = 'Member' WHERE `name` = 'employee' AND `display_name` <> 'Member';

-- ---------------------------------------------------------------------------
-- FINAL CHECKLIST: every row must say OK
-- ---------------------------------------------------------------------------
SELECT 'agent_pair_attempts table' AS check_name,
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'agent_pair_attempts') = 1, 'OK', 'MISSING') AS result
UNION ALL SELECT 'client_users table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'client_users') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'users.must_change_password',
       IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = 'must_change_password') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'time_entries.status/approved_* removed',
       IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND column_name IN ('status', 'approved_by', 'approved_at')) = 0, 'OK', 'SKIPPED: some entries are not Pending, tell me')
UNION ALL SELECT 'timesheets unique per user+period',
       IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'timesheets' AND index_name = 'uq_timesheets_user_period' AND non_unique = 0) = 3, 'OK', 'MISSING')
UNION ALL SELECT 'no duplicate timesheet periods',
       IF((SELECT COUNT(*) FROM (SELECT 1 FROM timesheets GROUP BY user_id, start_date, end_date HAVING COUNT(*) > 1) d) = 0, 'OK', 'DUPLICATES')
UNION ALL SELECT 'timesheet_entries foreign keys (2)',
       IF((SELECT COUNT(*) FROM information_schema.referential_constraints WHERE constraint_schema = DATABASE() AND table_name = 'timesheet_entries') = 2, 'OK', 'MISSING')
UNION ALL SELECT 'timesheet_entries.time_entry_id is bigint unsigned',
       IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'timesheet_entries' AND column_name = 'time_entry_id' AND data_type = 'bigint' AND column_type LIKE '%unsigned%') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'time_entries indexes (2)',
       IF((SELECT COUNT(DISTINCT index_name) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'time_entries' AND index_name IN ('idx_time_entries_user_started', 'idx_time_entries_project_started')) = 2, 'OK', 'MISSING')
UNION ALL SELECT 'time_entries end>=start CHECK',
       IF((SELECT COUNT(*) FROM information_schema.table_constraints WHERE constraint_schema = DATABASE() AND table_name = 'time_entries' AND constraint_name = 'chk_time_entries_ended_after_started') = 1, 'OK', 'MISSING (bad rows exist)')
UNION ALL SELECT 'client role has no schedule/time grants',
       IF((SELECT COUNT(*) FROM role_permissions rp INNER JOIN roles r ON r.id = rp.role_id INNER JOIN permissions p ON p.id = rp.permission_id WHERE r.name = 'client' AND p.name LIKE 'schedule.%') = 0, 'OK', 'LEFTOVER GRANTS')
UNION ALL SELECT 'report_access table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'report_access') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'clients.company removed',
       IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'clients' AND column_name = 'company') = 0, 'OK', 'STILL THERE')
UNION ALL SELECT 'schedules.recurrence_parent_id column (same type as id)',
       IF((SELECT COUNT(*) FROM information_schema.columns a INNER JOIN information_schema.columns b ON b.table_schema = a.table_schema AND b.table_name = 'schedules' AND b.column_name = 'id' AND b.column_type = a.column_type WHERE a.table_schema = DATABASE() AND a.table_name = 'schedules' AND a.column_name = 'recurrence_parent_id') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'schedules.recurrence_parent_id index',
       IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'schedules' AND index_name = 'idx_schedules_recurrence_parent') >= 1, 'OK', 'MISSING')
UNION ALL SELECT 'schedules.recurrence_parent_id foreign key',
       IF((SELECT COUNT(*) FROM information_schema.key_column_usage WHERE table_schema = DATABASE() AND table_name = 'schedules' AND column_name = 'recurrence_parent_id' AND referenced_table_name = 'schedules') >= 1, 'OK', 'MISSING')
UNION ALL SELECT 'workspace_settings.scheduling_enabled present',
       IF((SELECT COUNT(*) FROM workspaces w WHERE NOT EXISTS (SELECT 1 FROM workspace_settings ws WHERE ws.workspace_id = w.id AND ws.setting_key = 'scheduling_enabled')) = 0, 'OK', 'MISSING')
UNION ALL SELECT 'user_invitations table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_invitations') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'user_invitation_projects table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_invitation_projects') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'user_invitation_tasks table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_invitation_tasks') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'password_reset_tokens table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'password_reset_tokens') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'teams table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'teams') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'team_members table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'team_members') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'teams foreign keys (3)',
       IF((SELECT COUNT(*) FROM information_schema.referential_constraints WHERE constraint_schema = DATABASE() AND table_name = 'teams') = 3, 'OK', 'MISSING')
UNION ALL SELECT 'user_invitation_teams table',
       IF((SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_invitation_teams') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'smtp settings keys',
       IF((SELECT COUNT(*) FROM settings WHERE setting_key IN ('smtp_host', 'smtp_from_email', 'invite_expiry_days')) = 3, 'OK', 'MISSING')
UNION ALL SELECT 'tasks.team_id column',
       IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'team_id') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'tasks.team_id index',
       IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'tasks' AND index_name = 'idx_tasks_team') >= 1, 'OK', 'MISSING')
UNION ALL SELECT 'tasks.team_id foreign key',
       IF((SELECT COUNT(*) FROM information_schema.key_column_usage WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'team_id' AND referenced_table_name = 'teams') >= 1, 'OK', 'MISSING')
UNION ALL SELECT 'tasks.reviewed_by column',
       IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'reviewed_by') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'tasks.reviewed_at column',
       IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'reviewed_at') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'tasks.review_note column',
       IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'review_note') = 1, 'OK', 'MISSING')
UNION ALL SELECT 'tasks.reviewed_by foreign key',
       IF((SELECT COUNT(*) FROM information_schema.key_column_usage WHERE table_schema = DATABASE() AND table_name = 'tasks' AND column_name = 'reviewed_by' AND referenced_table_name = 'users') >= 1, 'OK', 'MISSING')
UNION ALL SELECT 'workspace_settings.task_scope_mode present',
       IF((SELECT COUNT(*) FROM workspaces w WHERE NOT EXISTS (SELECT 1 FROM workspace_settings ws WHERE ws.workspace_id = w.id AND ws.setting_key = 'task_scope_mode')) = 0, 'OK', 'MISSING')
UNION ALL SELECT 'workspace_settings.other_team_tasks_visibility present',
       IF((SELECT COUNT(*) FROM workspaces w WHERE NOT EXISTS (SELECT 1 FROM workspace_settings ws WHERE ws.workspace_id = w.id AND ws.setting_key = 'other_team_tasks_visibility')) = 0, 'OK', 'MISSING')
UNION ALL SELECT 'workspace_settings.members_can_create_subtasks present',
       IF((SELECT COUNT(*) FROM workspaces w WHERE NOT EXISTS (SELECT 1 FROM workspace_settings ws WHERE ws.workspace_id = w.id AND ws.setting_key = 'members_can_create_subtasks')) = 0, 'OK', 'MISSING')
UNION ALL SELECT 'workspace_settings.task_review_required present',
       IF((SELECT COUNT(*) FROM workspaces w WHERE NOT EXISTS (SELECT 1 FROM workspace_settings ws WHERE ws.workspace_id = w.id AND ws.setting_key = 'task_review_required')) = 0, 'OK', 'MISSING')
UNION ALL SELECT 'team people missing from project_members',
       IF((SELECT COUNT(*) FROM (
               SELECT t.project_id, t.manager_id AS user_id FROM teams t WHERE t.manager_id IS NOT NULL
               UNION
               SELECT t.project_id, t.lead_id FROM teams t WHERE t.lead_id IS NOT NULL
               UNION
               SELECT t.project_id, tm.user_id FROM team_members tm INNER JOIN teams t ON t.id = tm.team_id
           ) x
           LEFT JOIN project_members pm ON pm.project_id = x.project_id AND pm.user_id = x.user_id
           WHERE pm.user_id IS NULL) = 0, 'OK', CONCAT((SELECT COUNT(*) FROM (
               SELECT t.project_id, t.manager_id AS user_id FROM teams t WHERE t.manager_id IS NOT NULL
               UNION
               SELECT t.project_id, t.lead_id FROM teams t WHERE t.lead_id IS NOT NULL
               UNION
               SELECT t.project_id, tm.user_id FROM team_members tm INNER JOIN teams t ON t.id = tm.team_id
           ) x
           LEFT JOIN project_members pm ON pm.project_id = x.project_id AND pm.user_id = x.user_id
           WHERE pm.user_id IS NULL), ' (run tools/repair_hierarchy.php)'))
UNION ALL SELECT 'stray project_members.manager rows',
       IF((SELECT COUNT(*) FROM project_members pm
           INNER JOIN projects p ON p.id = pm.project_id
           WHERE pm.project_role = 'manager' AND (p.manager_id IS NULL OR p.manager_id <> pm.user_id)) = 0,
          'OK', CONCAT((SELECT COUNT(*) FROM project_members pm
           INNER JOIN projects p ON p.id = pm.project_id
           WHERE pm.project_role = 'manager' AND (p.manager_id IS NULL OR p.manager_id <> pm.user_id)), ' (run tools/repair_hierarchy.php)'))
UNION ALL SELECT 'tasks.team_id belongs to task project',
       IF((SELECT COUNT(*) FROM tasks t INNER JOIN teams te ON te.id = t.team_id WHERE te.project_id <> t.project_id) = 0,
          'OK', CONCAT((SELECT COUNT(*) FROM tasks t INNER JOIN teams te ON te.id = t.team_id WHERE te.project_id <> t.project_id), ' mismatched'))
UNION ALL SELECT 'task assignees who are viewer or not on project',
       IF((SELECT COUNT(*) FROM task_assignees ta
           INNER JOIN tasks t ON t.id = ta.task_id
           INNER JOIN projects p ON p.id = t.project_id
           LEFT JOIN project_members pm ON pm.project_id = t.project_id AND pm.user_id = ta.user_id
           WHERE (pm.user_id IS NULL AND (p.manager_id IS NULL OR p.manager_id <> ta.user_id))
              OR pm.project_role = 'viewer') = 0,
          'OK', CONCAT((SELECT COUNT(*) FROM task_assignees ta
           INNER JOIN tasks t ON t.id = ta.task_id
           INNER JOIN projects p ON p.id = t.project_id
           LEFT JOIN project_members pm ON pm.project_id = t.project_id AND pm.user_id = ta.user_id
           WHERE (pm.user_id IS NULL AND (p.manager_id IS NULL OR p.manager_id <> ta.user_id))
              OR pm.project_role = 'viewer'), ' (see REPAIR_REPORT.sql)'));
