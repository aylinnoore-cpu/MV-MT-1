<?php

declare(strict_types=1);

final class SidebarService
{
    /**
     * Sidebar data is intentionally isolated from the view. Each database read is
     * independently guarded so one failed query cannot break the entire navigation.
     * Failures are logged without exposing SQL details to the user.
     *
     * @return array{unreadCount:int,recentNotifications:list<array<string,mixed>>,pendingCount:int}
     */
    public static function data(int $userId): array
    {
        $unreadCount = 0;
        $recentNotifications = [];
        $pendingCount = 0;

        try {
            $unreadCount = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0',
                ['id' => $userId]
            );
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }

        try {
            $recentNotifications = (new Notification())->recent($userId, 6);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }

        try {
            $pendingCount = SidebarHelper::pendingApprovalCount();
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }

        return [
            'unreadCount' => $unreadCount,
            'recentNotifications' => $recentNotifications,
            'pendingCount' => $pendingCount,
        ];
    }
}
