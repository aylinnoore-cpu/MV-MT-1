USE mis_portal;
CREATE TABLE IF NOT EXISTS item_requests(id INT AUTO_INCREMENT PRIMARY KEY,item VARCHAR(80),details TEXT,quantity INT DEFAULT 1,
 priority ENUM('low','medium','high') DEFAULT 'medium',reason TEXT,status ENUM('pending','approved','issued','rejected') DEFAULT 'pending',
 remarks VARCHAR(500) NULL,user_id INT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
