<?php
/**
 * Workspace-level computer activity policy for running timers.
 * Server is authoritative: the Windows agent only reports activity timestamps.
 */

declare(strict_types=1);

final class IdleDetectionService
{
    private const AGENT_STALE_SECONDS = 120;

    /** Cached idle policy for this request (and 5 s on disk) so pollers do not hit settings 3 times. */
    /** @return array{enabled:bool,threshold:int,warning:int} */
    private static function idleSettings(): array
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        $file = STORAGE_PATH . '/idle_settings.cache';
        if (is_file($file) && (time() - (int) filemtime($file)) < 5) {
            $raw = @file_get_contents($file);
            $decoded = is_string($raw) ? json_decode($raw, true) : null;
            if (is_array($decoded) && isset($decoded['enabled'], $decoded['threshold'], $decoded['warning'])) {
                return $cached = [
                    'enabled' => (bool) $decoded['enabled'],
                    'threshold' => (int) $decoded['threshold'],
                    'warning' => (int) $decoded['warning'],
                ];
            }
        }

        $cached = [
            'enabled' => WorkspacePolicy::string('idle_detection_enabled', '0') === '1',
            'threshold' => max(1, min(1440, WorkspacePolicy::int('idle_threshold_minutes', 10))),
            'warning' => max(10, min(3600, WorkspacePolicy::int('idle_warning_seconds', 60))),
        ];
        @file_put_contents($file, json_encode($cached), LOCK_EX);
        return $cached;
    }

    /** @return array<string,mixed> */
    public static function checkTimer(int $userId, int $timerId, bool $mutate = true): array
    {
        $settings = self::idleSettings();
        $enabled = $settings['enabled'];
        $threshold = $settings['threshold'];
        $warningSeconds = $settings['warning'];
        if (!$enabled) return self::payload(false, false, false, null, 0, $threshold, $warningSeconds, false);

        // A paused timer is never re-warned. If the pause came from this idle policy,
        // report it so the browser keeps the "Timer paused" prompt (Resume / Stop) open
        // until the person acts, even across page reloads.
        $pausedRow = Database::fetchOne('SELECT paused_at, started_at FROM active_timers WHERE id = :id LIMIT 1', ['id' => $timerId]);
        if ($pausedRow !== null && !empty($pausedRow['paused_at'])) {
            $byIdle = Database::fetchValue(
                "SELECT e.id FROM timer_idle_events e
                 INNER JOIN active_timers t ON t.id = e.timer_id
                 WHERE e.timer_id = :timer_id AND e.response = 'auto_paused'
                   AND ABS(TIMESTAMPDIFF(SECOND, e.responded_at, t.paused_at)) <= 15
                 ORDER BY e.id DESC LIMIT 1",
                ['timer_id' => $timerId]
            );
            return self::payload(true, true, false, null, 0, $threshold, $warningSeconds, false, false, !empty($byIdle), 0);
        }

        if (!DesktopAgent::installed()) {
            return self::payload(true, false, false, null, 0, $threshold, $warningSeconds, true);
        }

        $device = Database::fetchOne(
            "SELECT MAX(last_seen_at) AS last_seen_at, MAX(last_activity_at) AS last_activity_at
             FROM desktop_agent_devices
             WHERE user_id = :user_id AND status = 'active'",
            ['user_id' => $userId]
        );
        if ($device === null || empty($device['last_seen_at'])) {
            return self::payload(true, false, false, null, 0, $threshold, $warningSeconds, true);
        }

        $lastSeen = strtotime((string) $device['last_seen_at'] . ' UTC') ?: 0;
        $lastActivity = strtotime((string) ($device['last_activity_at'] ?? '') . ' UTC') ?: 0;
        if ($lastSeen < time() - self::AGENT_STALE_SECONDS || $lastActivity < 1) {
            return self::payload(true, false, false, null, 0, $threshold, $warningSeconds, true);
        }

        $continuedAt = Database::fetchValue(
            "SELECT MAX(responded_at) FROM timer_idle_events
             WHERE timer_id = :timer_id AND response = 'continued'",
            ['timer_id' => $timerId]
        );
        $continuedTs = $continuedAt ? (strtotime((string) $continuedAt . ' UTC') ?: 0) : 0;
        // Starting or resuming a timer is itself activity, and the agent's last report can be
        // up to 30 seconds old. Without this, clicking Resume right after an idle pause would
        // immediately trigger another warning from the stale reading.
        $startedTs = strtotime((string) ($pausedRow['started_at'] ?? '') . ' UTC') ?: 0;
        $baseline = max($lastActivity, $continuedTs, $startedTs);
        $idleSeconds = max(0, time() - $baseline);

        if ($idleSeconds < $threshold * 60) {
            return self::payload(true, true, false, null, $idleSeconds, $threshold, $warningSeconds, false);
        }

        $event = Database::fetchOne(
            'SELECT id, warning_at, response, responded_at FROM timer_idle_events
             WHERE timer_id = :timer_id AND response IS NULL ORDER BY id DESC LIMIT 1',
            ['timer_id' => $timerId]
        );

        if ($event === null) {
            if (!$mutate) {
                return self::payload(true, true, true, null, $idleSeconds, $threshold, $warningSeconds, false, false, false, $warningSeconds);
            }
            Database::execute(
                'INSERT INTO timer_idle_events (timer_id,user_id,last_activity_at,warning_at,created_at)
                 VALUES (:timer_id,:user_id,:last_activity_at,UTC_TIMESTAMP(),UTC_TIMESTAMP())',
                [
                    'timer_id' => $timerId,
                    'user_id' => $userId,
                    'last_activity_at' => gmdate('Y-m-d H:i:s', $baseline),
                ]
            );
            $event = Database::fetchOne(
                'SELECT id, warning_at, response, responded_at FROM timer_idle_events WHERE id = LAST_INSERT_ID()'
            );
        }

        $warningAt = strtotime((string) ($event['warning_at'] ?? '') . ' UTC') ?: time();
        if (time() - $warningAt >= $warningSeconds) {
            if (!$mutate) {
                return self::payload(true, true, true, (int) ($event['id'] ?? 0), $idleSeconds, $threshold, $warningSeconds, false, false, false, 0);
            }
            $paused = (new Timer())->pauseIfRunning($userId);
            if ($paused !== null) {
                $affected = Database::execute(
                    "UPDATE timer_idle_events SET response='auto_paused', responded_at=UTC_TIMESTAMP() WHERE id=:id AND response IS NULL",
                    ['id' => (int) $event['id']]
                );
                if ($affected > 0) {
                    LoggerHelper::info('Timer auto-paused after idle warning', [
                        'user_id' => $userId,
                        'timer_id' => $timerId,
                    ]);
                }
                return self::payload(true, true, false, (int) $event['id'], $idleSeconds, $threshold, $warningSeconds, false, true, true, 0);
            }
        }

        $remaining = max(0, $warningSeconds - (time() - $warningAt));
        return self::payload(true, true, true, (int) $event['id'], $idleSeconds, $threshold, $warningSeconds, false, false, false, $remaining);
    }

    public static function respond(int $userId, int $eventId, string $response): array
    {
        $response = strtolower(trim($response));
        if (!in_array($response, ['continued', 'manual_pause'], true)) {
            throw new InvalidArgumentException('Invalid idle response.');
        }

        $event = Database::fetchOne(
            'SELECT e.*, t.user_id AS timer_user_id, t.paused_at
             FROM timer_idle_events e
             INNER JOIN active_timers t ON t.id = e.timer_id
             WHERE e.id = :id LIMIT 1',
            ['id' => $eventId]
        );
        if ($event === null || (int) $event['user_id'] !== $userId || (int) $event['timer_user_id'] !== $userId || $event['response'] !== null) {
            throw new RuntimeException('That idle prompt is no longer active.');
        }

        if ($response === 'continued') {
            Database::execute(
                "UPDATE timer_idle_events SET response='continued', responded_at=UTC_TIMESTAMP() WHERE id=:id AND response IS NULL",
                ['id' => $eventId]
            );
            return ['ok' => true, 'response' => 'continued'];
        }

        $timer = (new Timer())->pause($userId);
        Database::execute(
            "UPDATE timer_idle_events SET response='manual_pause', responded_at=UTC_TIMESTAMP() WHERE id=:id AND response IS NULL",
            ['id' => $eventId]
        );
        return ['ok' => true, 'response' => 'manual_pause', 'timer' => $timer];
    }

    /** @return list<int> */
    public static function processAllRunningTimers(): array
    {
        if (!Timer::installed()) return [];
        $rows = Database::fetchAll('SELECT id,user_id FROM active_timers WHERE paused_at IS NULL ORDER BY id ASC');
        $paused = [];
        foreach ($rows as $row) {
            $state = self::checkTimer((int) $row['user_id'], (int) $row['id']);
            if (!empty($state['auto_paused'])) $paused[] = (int) $row['id'];
        }
        return $paused;
    }

    /** @return array<string,mixed> */
    private static function payload(bool $enabled, bool $agentConnected, bool $warning, ?int $eventId, int $idleSeconds, int $threshold, int $warningSeconds, bool $agentRequired, bool $autoPaused = false, bool $pausedByIdle = false, int $warningRemaining = 0): array
    {
        return [
            'enabled' => $enabled,
            'agent_connected' => $agentConnected,
            'agent_required' => $agentRequired,
            'warning' => $warning,
            'event_id' => $eventId,
            'idle_seconds' => $idleSeconds,
            'threshold_seconds' => $threshold * 60,
            'warning_seconds' => $warningSeconds,
            'auto_paused' => $autoPaused,
            'paused_by_idle' => $pausedByIdle,
            'warning_remaining' => $warningRemaining,
        ];
    }
}