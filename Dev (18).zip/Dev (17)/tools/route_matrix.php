<?php
// Prints the routes declared by routes/web.php for use in Step 20 manual/HTTP tests.
declare(strict_types=1);
$routesFile = dirname(__DIR__) . '/routes/web.php';
$text = file_get_contents($routesFile);
if ($text === false) { fwrite(STDERR, "Unable to read routes/web.php\n"); exit(1); }
preg_match_all('/\$router->(get|post|put|patch|delete)\(\s*\'([^\']+)\'/i', $text, $m, PREG_SET_ORDER);
foreach ($m as $row) echo strtoupper($row[1]) . "\t" . $row[2] . PHP_EOL;
