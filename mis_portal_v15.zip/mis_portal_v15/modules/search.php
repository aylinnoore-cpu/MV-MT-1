<?php require __DIR__.'/../includes/lib.php';need();$q=trim($_GET['q']??'');$r=role();$st=$r=='staff';$u=(int)me()['id'];
head('Search',$q===''?'Type something in the search box.':'Results for "'.$q.'"');
if($q!==''){$l='%'.$q.'%';$G=[['Assets','assets',['assets','name','CONCAT(asset_tag," | ",IFNULL(serial_no,""))',['name','asset_tag','serial_no','barcode','ip_address','mac_address'],$st?"assigned_to=$u":'1']],
 ['Support tickets','tickets',['tickets','title','ticket_no',['title','ticket_no'],$st?"created_by=$u":'1']]];
 if(in_array($r,['support','ed','finance']))$G[]=['Procurement','procurement',['procurement','title','CONCAT(status," ",IFNULL(po_number,""))',['title','po_number','vendor'],'1']];
 if(in_array($r,['support','ed','finance']))$G[]=['Vendors','vendors',['vendors','name','CONCAT(IFNULL(phone,"")," ",IFNULL(email,""))',['name','phone','email','contact_person'],'1']];
 if(in_array($r,['support','ed']))$G[]=['Staff','users',['users','name','CONCAT(IFNULL(employee_id,"")," ",IFNULL(department,""))',['name','employee_id','email'],'1']];$any=0;
 foreach($G as [$lb,$m,[$t,$tc,$dc,$cols,$w]]){$rows=q("SELECT id,$tc t,$dc d FROM $t WHERE $w AND (".implode(' OR ',array_map(fn($c)=>"$c LIKE ?",$cols)).') LIMIT 15',array_fill(0,count($cols),$l))->fetchAll();if(!$rows)continue;$any=1;
  echo '<div class=card><h3 style="margin-top:0">'.$lb.'</h3><table>';foreach($rows as $x)echo "<tr><td><a href='records.php?m=$m&a=view&id=$x[id]'>".h($x['t']).'</a><td>'.h($x['d']);echo '</table></div>';}
 if(!$any)echo '<div class=card>No results found.</div>';}
foot();
