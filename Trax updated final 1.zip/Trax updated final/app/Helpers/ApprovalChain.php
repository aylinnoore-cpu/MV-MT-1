<?php
/**
 * Timesheet approval hierarchy.
 *
 *   Admin
 *   └── Department ── Department Manager   (departments.manager_id)
 *        └── Team ── Team managers         (team_managers)
 *             └── Members                  (team_members)
 *
 * Departments and teams are organisation units. They are not tied to a project,
 * so a team can work on any project.
 *
 * Default routing for a member submission:
 *   team managers + admins
 *
 * Department managers and project managers stay available as workspace settings
 * (access / in-app / email). Email to those positions is off by default.
 *
 *   - team member        -> team managers, (optional DM / PM), admins
 *   - team manager       -> (optional DM / PM), admins
 *   - department manager -> (optional PM), admins
 *   - project manager    -> admins
 *   - admin              -> other admins
 */

declare(strict_types=1);

final class ApprovalChainHelper
{
    public const LABEL_MANAGER     = 'Team manager';
    public const LABEL_DEPARTMENT  = 'Department manager';
    public const LABEL_PROJECT     = 'Project manager';
    public const LABEL_ADMIN       = 'Admin';

    /** @var array<string, mixed>|null */
    private static ?array $snapshot = null;

    /** @var array<string, array<int, list<string>>> "submitter|projects" => approver id => labels */
    private static array $detailCache = [];

    /** @var array<int, list<int>> approver id => submitter ids */
    private static array $subordinateCache = [];

    /** Forget cached data (after teams are edited within the same request). */
    public static function reset(): void
    {
        self::$snapshot         = null;
        self::$detailCache      = [];
        self::$subordinateCache = [];
    }

    /**
     * Per-request hierarchy snapshot. Shared with TaskPolicy so positions and
     * timesheet approval never disagree.
     *
     * @return array<string, mixed>
     */
    public static function snapshot(): array
    {
        return self::load();
    }

    public static function teamsReady(): bool
    {
        return SchemaHelper::tableExists('teams') && SchemaHelper::tableExists('team_members');
    }

    /**
     * Active people who can decide this person's timesheet (never the submitter).
     * Pass the project ids of the submitted work to limit the chain to those projects;
     * null means "every project the person belongs to" (used when a submission has no entries).
     *
     * @param list<int>|null $projectIds
     * @return list<int>
     */
    public static function approversFor(int $submitterId, ?array $projectIds = null): array
    {
        return array_map('intval', array_keys(self::detailFor($submitterId, $projectIds)));
    }

    /** True when $approverId sits above $submitterId in the hierarchy (or is another admin). */
    public static function canDecide(int $approverId, int $submitterId, ?array $projectIds = null): bool
    {
        if ($approverId < 1 || $submitterId < 1 || $approverId === $submitterId) {
            return false;
        }

        return isset(self::detailFor($submitterId, $projectIds)[$approverId]);
    }

    /**
     * Project-by-project coverage of a non-admin approver: project id => submitter ids whose work
     * on THAT project this person may decide. Drives the approval queue and the sidebar badge.
     *
     * @return array<int, list<int>>
     */
    public static function coverageFor(int $approverId): array
    {
        $snap = self::load();
        $out  = [];
        foreach (array_keys($snap['projects']) as $projectId) {
            $projectId = (int) $projectId;
            foreach (array_keys($snap['users']) as $userId) {
                $userId = (int) $userId;
                if ($userId !== $approverId && isset(self::detailFor($userId, [$projectId])[$approverId])) {
                    $out[$projectId][] = $userId;
                }
            }
        }

        return $out;
    }

    /**
     * Everyone whose timesheets this approver may review (admins: everybody except themselves).
     *
     * @return list<int>
     */
    public static function subordinateIds(int $approverId): array
    {
        if (isset(self::$subordinateCache[$approverId])) {
            return self::$subordinateCache[$approverId];
        }

        $out = [];
        foreach (array_keys(self::load()['users']) as $userId) {
            $userId = (int) $userId;
            if ($userId !== $approverId && isset(self::detailFor($userId)[$approverId])) {
                $out[] = $userId;
            }
        }

        return self::$subordinateCache[$approverId] = $out;
    }

    /**
     * True when this person holds an approving position: team manager, department manager or project manager.
     * (Admins are handled by role.) Used to open the Approvals page for people whose ROLE is employee.
     */
    public static function isApprover(int $userId): bool
    {
        if ($userId < 1) {
            return false;
        }

        $snap = self::load();
        if (in_array($userId, $snap['projectManagers'], true)) {
            return true;
        }
        if (in_array($userId, $snap['departmentManagers'] ?? [], true)) {
            return true;
        }

        foreach ($snap['teams'] as $team) {
            if (in_array($userId, $team['manager_ids'] ?? [$team['manager_id']], true)) {
                return true;
            }
        }

        return false;
    }

    /** Opens the Approvals page / actions: the time.approve permission OR a place in the chain. */
    public static function canAccessApprovals(int $userId): bool
    {
        if ($userId < 1) {
            return false;
        }

        $snap = self::load();
        if (isset($snap['adminSet'][$userId]) && WorkspacePolicy::workflowAccessFor('admin')) {
            return true;
        }
        if (in_array($userId, $snap['projectManagers'], true) && WorkspacePolicy::workflowAccessFor('project_manager')) {
            return true;
        }
        if (in_array($userId, $snap['departmentManagers'] ?? [], true) && WorkspacePolicy::workflowAccessFor('department_manager')) {
            return true;
        }
        foreach ($snap['teams'] as $team) {
            $mgrs = $team['manager_ids'] ?? [(int) $team['manager_id']];
            if (in_array($userId, array_map('intval', $mgrs), true) && WorkspacePolicy::workflowAccessFor('team_manager')) {
                return true;
            }
        }

        return PermissionHelper::has('time.approve');
    }

    /**
     * Approvers for a person on one team (team manager, project manager, admins).
     * Used by task review so someone in two teams does not route to the wrong manager.
     *
     * @return list<int>
     */
    public static function approversForTeam(int $submitterId, int $teamId): array
    {
        return array_map('intval', array_keys(self::detailForTeam($submitterId, $teamId)));
    }

    /**
     * Approvers for a person on a project with no team (project manager + admins).
     *
     * @return list<int>
     */
    public static function approversForProject(int $submitterId, int $projectId): array
    {
        return self::approversFor($submitterId, [$projectId]);
    }

    /**
     * Approvers for a submitter with the position(s) they hold, for display.
     *
     * @param list<int>|null $projectIds
     * @return list<array{id: int, name: string, labels: list<string>}>
     */
    public static function describe(int $submitterId, ?array $projectIds = null): array
    {
        $detail = self::detailFor($submitterId, $projectIds);
        if ($detail === []) {
            return [];
        }

        $ids  = array_map('intval', array_keys($detail));
        $in   = implode(',', $ids);
        $rows = Database::fetchAll("SELECT id, name FROM users WHERE id IN ({$in})");
        $names = [];
        foreach ($rows as $row) {
            $names[(int) $row['id']] = (string) $row['name'];
        }

        $order = [self::LABEL_MANAGER => 0, self::LABEL_DEPARTMENT => 1, self::LABEL_PROJECT => 2, self::LABEL_ADMIN => 3];
        $out   = [];
        foreach ($detail as $id => $labels) {
            usort($labels, static fn (string $a, string $b): int => ($order[$a] ?? 9) <=> ($order[$b] ?? 9));
            $out[] = ['id' => (int) $id, 'name' => $names[(int) $id] ?? ('User #' . $id), 'labels' => $labels];
        }

        usort($out, static function (array $a, array $b) use ($order): int {
            return [$order[$a['labels'][0]] ?? 9, $a['name']] <=> [$order[$b['labels'][0]] ?? 9, $b['name']];
        });

        return $out;
    }

    /* ------------------------------------------------------------------ internals */

    /**
     * approver id => labels, for one submitter.
     *
     * @return array<int, list<string>>
     */
    private static function detailFor(int $submitterId, ?array $projectIds = null): array
    {
        $projectSet = null;
        if ($projectIds !== null) {
            $projectIds = array_values(array_unique(array_filter(array_map('intval', $projectIds), static fn (int $id): bool => $id > 0)));
            sort($projectIds);
            $projectSet = array_flip($projectIds);
        }

        $cacheKey = $submitterId . '|' . ($projectIds === null ? '*' : implode(',', $projectIds));
        if (isset(self::$detailCache[$cacheKey])) {
            return self::$detailCache[$cacheKey];
        }

        $snap   = self::load();
        $detail = [];
        $add    = static function (int $id, string $label) use (&$detail, $snap, $submitterId): void {
            if ($id < 1 || $id === $submitterId || !isset($snap['active'][$id])) {
                return;
            }
            $position = WorkspacePolicy::workflowPositionKey($label);
            if ($position !== null && !WorkspacePolicy::workflowAccessFor($position)) {
                return;
            }
            if (!isset($detail[$id]) || !in_array($label, $detail[$id], true)) {
                $detail[$id][] = $label;
            }
        };

        if (!isset($snap['users'][$submitterId])) {
            return self::$detailCache[$cacheKey] = [];
        }

        foreach ($snap['admins'] as $adminId) {
            $add($adminId, self::LABEL_ADMIN);
        }

        // Admins are reviewed by other admins only.
        if (isset($snap['adminSet'][$submitterId])) {
            return self::$detailCache[$cacheKey] = $detail;
        }

        foreach ($snap['teamRoles'][$submitterId] ?? [] as $teamId => $rank) {
            $team = $snap['teams'][$teamId] ?? null;
            if ($team === null) {
                continue;
            }
            $departmentManager = (int) ($team['department_manager_id'] ?? 0);
            $managerIds = array_map('intval', $team['manager_ids'] ?? [(int) ($team['manager_id'] ?? 0)]);

            if ($rank === 'member') {
                foreach ($managerIds as $managerId) {
                    $add($managerId, self::LABEL_MANAGER);
                }
                $add($departmentManager, self::LABEL_DEPARTMENT);
            } elseif ($rank === 'manager') {
                $add($departmentManager, self::LABEL_DEPARTMENT);
            }
        }

        // Not on a team: optional project-manager fallback, gated by workspace settings.
        if (($snap['teamRoles'][$submitterId] ?? []) === []) {
            $fallbackProjects = $projectSet !== null
                ? array_keys($projectSet)
                : ($snap['projectMembers'][$submitterId] ?? []);
            foreach ($fallbackProjects as $projectId) {
                $add((int) ($snap['projectManager'][(int) $projectId] ?? 0), self::LABEL_PROJECT);
            }
        }

        return self::$detailCache[$cacheKey] = $detail;
    }

    /**
     * approver id => labels, for one submitter on one team.
     *
     * @return array<int, list<string>>
     */
    private static function detailForTeam(int $submitterId, int $teamId): array
    {
        $cacheKey = $submitterId . '|t' . $teamId;
        if (isset(self::$detailCache[$cacheKey])) {
            return self::$detailCache[$cacheKey];
        }

        $snap = self::load();
        $team = $snap['teams'][$teamId] ?? null;
        if ($team === null || !isset($snap['users'][$submitterId])) {
            return self::$detailCache[$cacheKey] = [];
        }

        $detail = [];
        $add    = static function (int $id, string $label) use (&$detail, $snap, $submitterId): void {
            if ($id < 1 || $id === $submitterId || !isset($snap['active'][$id])) {
                return;
            }
            $position = WorkspacePolicy::workflowPositionKey($label);
            if ($position !== null && !WorkspacePolicy::workflowAccessFor($position)) {
                return;
            }
            if (!isset($detail[$id]) || !in_array($label, $detail[$id], true)) {
                $detail[$id][] = $label;
            }
        };

        foreach ($snap['admins'] as $adminId) {
            $add($adminId, self::LABEL_ADMIN);
        }

        if (isset($snap['adminSet'][$submitterId])) {
            return self::$detailCache[$cacheKey] = $detail;
        }

        $rank              = (string) ($snap['teamRoles'][$submitterId][$teamId] ?? '');
        $departmentManager = (int) ($team['department_manager_id'] ?? 0);
        $managerIds        = array_map('intval', $team['manager_ids'] ?? [(int) ($team['manager_id'] ?? 0)]);

        if ($rank === 'member') {
            foreach ($managerIds as $managerId) {
                $add($managerId, self::LABEL_MANAGER);
            }
            $add($departmentManager, self::LABEL_DEPARTMENT);
        } elseif ($rank === 'manager') {
            $add($departmentManager, self::LABEL_DEPARTMENT);
        }

        return self::$detailCache[$cacheKey] = $detail;
    }

    /** @return array<string, mixed> */
    private static function load(): array
    {
        if (self::$snapshot !== null) {
            return self::$snapshot;
        }

        $snap = [
            'users'              => [],
            'userNames'          => [],
            'active'             => [],
            'admins'             => [],
            'adminSet'           => [],
            'projects'           => [],
            'projectManager'     => [],
            'projectManagers'    => [],
            'projectMembers'     => [],
            'projectMemberSet'   => [],
            'projectMemberRoles' => [],
            'teams'               => [],
            'teamNames'           => [],
            'teamRoles'           => [],
            'teamProjects'        => [],
            'teamMemberIds'       => [],
            'teamManagerIds'      => [],
            'departments'         => [],
            'departmentManagers'  => [],
        ];

        try {
            foreach (Database::fetchAll(
                'SELECT u.id, u.name, u.status, r.name AS role
                 FROM users u INNER JOIN roles r ON r.id = u.role_id'
            ) as $row) {
                $id = (int) $row['id'];
                $snap['users'][$id]     = true;
                $snap['userNames'][$id] = (string) $row['name'];
                if ((string) $row['status'] === 'active') {
                    $snap['active'][$id] = true;
                    if ((string) $row['role'] === 'admin') {
                        $snap['admins'][]    = $id;
                        $snap['adminSet'][$id] = true;
                    }
                }
            }

            foreach (Database::fetchAll('SELECT id, manager_id FROM projects') as $row) {
                $snap['projects'][(int) $row['id']] = true;
                if ($row['manager_id'] !== null) {
                    $snap['projectManager'][(int) $row['id']] = (int) $row['manager_id'];
                }
            }
            $snap['projectManagers'] = array_values(array_unique(array_map('intval', array_values($snap['projectManager']))));

            foreach (Database::fetchAll('SELECT project_id, user_id, project_role FROM project_members') as $row) {
                $userId    = (int) $row['user_id'];
                $projectId = (int) $row['project_id'];
                $snap['projectMembers'][$userId][] = $projectId;
                $snap['projectMemberSet'][$userId][$projectId] = true;
                $snap['projectMemberRoles'][$userId][$projectId] = strtolower((string) ($row['project_role'] ?? 'member'));
            }

            if (self::teamsReady()) {
                self::loadTeams($snap);
            }
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }

        return self::$snapshot = $snap;
    }

    /** @param array<string, mixed> $snap */
    private static function loadTeams(array &$snap): void
    {
        SchemaHelper::ensureOrgStructure();

        $priority = ['member' => 1, 'manager' => 2, 'dept_manager' => 3, 'pm' => 4];
        $assign = static function (array &$snap, int $userId, int $teamId, int $projectId, string $rank) use ($priority): void {
            if ($userId < 1) {
                return;
            }
            $current = $snap['teamRoles'][$userId][$teamId] ?? null;
            if ($current === null || ($priority[$rank] ?? 0) > ($priority[$current] ?? 0)) {
                $snap['teamRoles'][$userId][$teamId] = $rank;
            }
            if ($projectId > 0) {
                $snap['teamProjects'][$userId][$projectId] = true;
            }
        };

        $hasDept = SchemaHelper::tableExists('departments') && SchemaHelper::columnExists('teams', 'department_id');
        $deptById = [];
        if ($hasDept) {
            foreach (Database::fetchAll(
                "SELECT id, name, manager_id FROM departments WHERE status = 'active' OR status IS NULL"
            ) as $row) {
                $deptId = (int) $row['id'];
                $deptById[$deptId] = [
                    'manager_id' => (int) ($row['manager_id'] ?? 0),
                    'name'       => (string) ($row['name'] ?? ''),
                ];
                $snap['departments'][$deptId] = $deptById[$deptId];
                if ((int) ($row['manager_id'] ?? 0) > 0) {
                    $snap['departmentManagers'][] = (int) $row['manager_id'];
                }
            }
            $snap['departmentManagers'] = array_values(array_unique(array_map('intval', $snap['departmentManagers'])));
        }

        $teamSql = $hasDept
            ? "SELECT id, department_id, name, manager_id FROM teams WHERE status = 'active' OR status IS NULL"
            : "SELECT id, name, manager_id FROM teams WHERE status = 'active' OR status IS NULL";

        foreach (Database::fetchAll($teamSql) as $row) {
            $teamId  = (int) $row['id'];
            $deptId  = (int) ($row['department_id'] ?? 0);
            $deptMgr = (int) ($deptById[$deptId]['manager_id'] ?? 0);
            $primary = (int) ($row['manager_id'] ?? 0);
            $snap['teams'][$teamId] = [
                'project_id'            => 0,
                'manager_id'            => $primary,
                'manager_ids'           => $primary > 0 ? [$primary] : [],
                'department_id'         => $deptId,
                'department_manager_id' => $deptMgr,
            ];
            $snap['teamNames'][$teamId] = (string) ($row['name'] ?? '');

            if ($primary > 0) {
                $assign($snap, $primary, $teamId, 0, 'manager');
                $snap['teamManagerIds'][$teamId][] = $primary;
            }
            $assign($snap, $deptMgr, $teamId, 0, 'dept_manager');
        }

        if (SchemaHelper::tableExists('team_managers')) {
            foreach (Database::fetchAll('SELECT team_id, user_id FROM team_managers') as $row) {
                $teamId = (int) $row['team_id'];
                if (!isset($snap['teams'][$teamId])) {
                    continue;
                }
                $userId = (int) $row['user_id'];
                $assign($snap, $userId, $teamId, 0, 'manager');
                if (!in_array($userId, $snap['teams'][$teamId]['manager_ids'], true)) {
                    $snap['teams'][$teamId]['manager_ids'][] = $userId;
                }
                $snap['teamManagerIds'][$teamId][] = $userId;
            }
        }

        if ($snap['teams'] === []) {
            return;
        }

        foreach (Database::fetchAll('SELECT team_id, user_id FROM team_members') as $row) {
            $teamId = (int) $row['team_id'];
            if (!isset($snap['teams'][$teamId])) {
                continue;
            }
            $userId = (int) $row['user_id'];
            $assign($snap, $userId, $teamId, 0, 'member');
            $snap['teamMemberIds'][$teamId][] = $userId;
        }
    }
}
