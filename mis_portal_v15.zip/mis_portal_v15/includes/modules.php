<?php
// Module definitions (fields, roles) and approval workflows
$ALL=['staff','support','ed','finance'];$SE=['support','ed'];
// Module definitions: f=fields [label,type,options], view/add/edit roles, own=column that limits staff to their own rows
function mods(){global $ALL,$SE;return [
'assets'=>['title'=>'Assets','own'=>'assigned_to','view'=>['staff','support','ed','finance'],'add'=>$SE,'edit'=>$SE,
 'del'=>$SE,'hide'=>['cost'],'cols'=>['asset_tag','name','category','status','assigned_to','ip_address','warranty_end','cost'],'f'=>[
 'asset_tag'=>['Barcode / Asset tag','text'],'name'=>['Asset name','text'],'category'=>['Category','text'],'serial_no'=>['Serial no.','text'],
 'purchase_date'=>['Purchase date','date'],'cost'=>['Cost','number'],'vendor_id'=>['Vendor','vendor'],'warranty_months'=>['Warranty period (months)','number'],'warranty_start'=>['Warranty start (blank = purchase date)','date'],'warranty_notes'=>['Warranty terms / claim notes','textarea'],
 'status'=>['Status','select',['working','out_for_repair','out_for_maintenance','in_storage','faulty','dead','lost']],'assigned_to'=>['Assigned to','user'],
 'assigned_date'=>['Assignment date','date'],
 'mac_supported'=>['Network device (has MAC / IP address)','select',['No','Yes']],'mac_address'=>['MAC address','opt','','net'],'ip_address'=>['IP address used by this device','opt','','net'],'ip_type'=>['IP assignment type','select',['Static','DHCP reservation'],'net'],'notes'=>['Notes','textarea']]],
'procurement'=>['title'=>'Procurement','view'=>['support','ed','finance'],'add'=>$SE,'edit'=>$SE,'auto'=>'requested_by',
 'cols'=>['id','type','title','vendor_id','amount','po_number','status'],'f'=>[
 'type'=>['Request type','select',['procurement','repair']],'title'=>['Title','text'],'description'=>['Description','textarea'],
 'vendor_id'=>['Vendor','vendor'],'amount'=>['Amount','number'],'quotation_notes'=>['Quotation comparison / notes','textarea']]],
'tickets'=>['title'=>'Support Tickets','own'=>'created_by','view'=>$ALL,'add'=>$ALL,'edit'=>$SE,'auto'=>'created_by',
 'cols'=>['ticket_no','title','category','priority','status','created_by','created_at'],'f'=>[
 'title'=>['Subject','text'],'category'=>['Category','select',['hardware','software','network','other']],
 'priority'=>['Priority','select',['low','medium','high']],'description'=>['Description','textarea']]],
'maintenance'=>['title'=>'Maintenance','view'=>$SE,'add'=>$SE,'edit'=>$SE,'auto'=>'created_by',
 'cols'=>['asset_id','warranty','type','technician','cost','work_date','next_due','status'],'f'=>[
 'asset_id'=>['Asset','asset'],'type'=>['Type','select',['preventive','repair','service']],'technician'=>['Technician / vendor','text'],
 'description'=>['Work / parts details','textarea'],'cost'=>['Cost','number'],'work_date'=>['Work date','date'],'next_due'=>['Next due','date'],'expected_return'=>['Expected return date (if out)','date'],'returned_on'=>['Returned on','date'],'vendor_id'=>['Sent to vendor','vendor'],
 'status'=>['Status','select',['scheduled','done']]]],
'vendors'=>['title'=>'Vendors','view'=>['support','ed','finance'],'add'=>$SE,'edit'=>$SE,'del'=>$SE,
 'cols'=>['name','category','contact_person','phone','email','city','status'],'f'=>[
 'name'=>['Vendor / company name','text'],'category'=>['Category','select',['IT Hardware','Software','Services','Networking','Stationery','Furniture','Other']],
 'contact_person'=>['Contact person','opt'],'phone'=>['Phone / mobile','opt'],'email'=>['Email','opt'],'address'=>['Address','textarea'],'city'=>['City','opt'],
 'ntn'=>['NTN / Sales tax reg.','opt'],'website'=>['Website','opt'],'payment_terms'=>['Payment terms','opt'],'bank_details'=>['Bank / cheque details','textarea'],
 'notes'=>['Notes','textarea'],'status'=>['Status','select',['active','inactive']]]],
'item_requests'=>['title'=>'IT Item Requests','own'=>'user_id','full'=>$SE,'view'=>$ALL,'add'=>$ALL,'edit'=>$SE,'auto'=>'user_id',
 'cols'=>['id','item','quantity','priority','status','user_id','created_at'],'f'=>[
 'item'=>['Item needed','select',['Mouse','Keyboard','Monitor','Headset','Webcam','USB drive','Laptop bag','Charger / adapter','Cables (HDMI / LAN / USB)','Printer toner / cartridge','Other']],
 'details'=>['Details (type / brand / model, if any)','textarea'],'quantity'=>['Quantity','select',['1','2','3','4','5','6','7','8','9','10']],
 'priority'=>['Priority','select',['low','medium','high']],'reason'=>['Reason / purpose','textarea']]],
'users'=>['title'=>'Staff','own'=>'id','full'=>$SE,'view'=>$ALL,'add'=>$SE,'edit'=>$SE,
 'cols'=>['employee_id','name','email','role','department','designation','location','status'],'f'=>[
 'employee_id'=>['Employee ID','text'],'name'=>['Full name','text'],'phone'=>['Contact no.','text'],'email'=>['Email','text'],'password'=>['Password','password'],'role'=>['Role','select',['staff','support','ed','finance']],
 'department'=>['Department','text'],'designation'=>['Designation','text'],'location'=>['Location','text'],'status'=>['Status','select',['active','inactive']]]],
];}
// Approval / ticket workflow: current status => [next status, roles allowed, button label]
function flow(){return [
'procurement'=>['requested'=>[['ed_approved',['ed'],'Approve (ED)'],['rejected',['ed'],'Reject']],
 'ed_approved'=>[['finance_approved',['finance'],'Finance approve'],['rejected',['finance'],'Reject']],
 'finance_approved'=>[['po_issued',['support','ed'],'Issue PO']]],
'item_requests'=>['pending'=>[['approved',['support','ed'],'Approve'],['rejected',['support','ed'],'Reject']],'approved'=>[['issued',['support','ed'],'Mark as issued']]],
'tickets'=>['open'=>[['in_progress',['support','ed'],'Start work']],'in_progress'=>[['resolved',['support','ed'],'Resolve']],
 'resolved'=>[['closed',['support','ed'],'Close'],['in_progress',['support','ed'],'Reopen']]]];}

function slots(){return ["mis"=>"MIS Department","proc"=>"Procurement Services","corp"=>"Corporate Services Division"];}
