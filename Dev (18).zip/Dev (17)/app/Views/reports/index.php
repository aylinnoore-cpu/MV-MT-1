<?php
/** @var array<string,mixed> $summary */
$totals = $summary['totals'];
$moneyVisible = (bool) $canBilling;
$hours = static fn(int $seconds): string => FormatHelper::hours($seconds);
$money = static fn(float $amount): string => FormatHelper::money($amount, SettingsService::systemString('currency', 'USD'));
?>
<div class="page-head d-flex flex-wrap align-items-center justify-content-between gap-3">
    <div><h1 class="page-heading mb-1">Reports</h1><p class="text-muted mb-0">Time summaries by project, task, user and client.</p></div>
    <?php if ($canExport): ?><a class="btn btn-outline-secondary" href="<?= e(url('/reports/export.csv') . '?' . http_build_query($filters)) ?>"><i class="fa-solid fa-file-csv me-2"></i>Export CSV</a><?php endif; ?>
</div>

<form method="get" action="<?= e(url('/reports')) ?>" class="filter-bar mb-4">
    <div><label class="form-label" for="report-from">From</label><input class="form-control" id="report-from" type="date" name="from" value="<?= e($filters['from']) ?>"></div>
    <div><label class="form-label" for="report-to">To</label><input class="form-control" id="report-to" type="date" name="to" value="<?= e($filters['to']) ?>"></div>
    <?php if ($canViewAll): ?>
    <div><label class="form-label" for="report-user">User</label><select class="form-select" id="report-user" name="user_id"><option value="0">All users</option><?php foreach($people as $person): ?><option value="<?= (int)$person['id'] ?>"<?= (int)$filters['user_id']===(int)$person['id']?' selected':'' ?>><?= e($person['name']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="report-client">Client</label><select class="form-select" id="report-client" name="client_id"><option value="0">All clients</option><?php foreach($clients as $client): ?><option value="<?= (int)$client['id'] ?>"<?= (int)$filters['client_id']===(int)$client['id']?' selected':'' ?>><?= e($client['name']) ?></option><?php endforeach; ?></select></div>
    <?php endif; ?>
    <div><label class="form-label" for="report-project">Project</label><select class="form-select" id="report-project" name="project_id"><option value="0">All projects</option><?php foreach($projects as $project): ?><option value="<?= (int)$project['id'] ?>"<?= (int)$filters['project_id']===(int)$project['id']?' selected':'' ?>><?= e($project['name']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="report-task">Task</label><select class="form-select" id="report-task" name="task_id"><option value="0">All tasks</option><?php foreach($tasks as $task): ?><option value="<?= (int)$task['id'] ?>"<?= (int)$filters['task_id']===(int)$task['id']?' selected':'' ?>><?= e($task['name']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="report-billable">Type</label><select class="form-select" id="report-billable" name="billable"><option value="">All</option><option value="1"<?= $filters['billable']==='1'?' selected':'' ?>>Billable</option><option value="0"<?= $filters['billable']==='0'?' selected':'' ?>>Non-billable</option></select></div>
    <div class="align-self-end d-flex gap-2"><button class="btn btn-primary" type="submit">Apply</button><a class="btn btn-outline-secondary" href="<?= e(url('/reports')) ?>">Reset</a></div>
</form>

<div class="row g-3 mb-4">
<?php foreach ([['Entries',(string)$totals['entry_count'],'fa-list-check'],['Total hours',$hours((int)$totals['seconds']),'fa-clock'],['Billable hours',$hours((int)$totals['billable_seconds']),'fa-circle-check'],['Non-billable hours',$hours((int)$totals['nonbillable_seconds']),'fa-circle-minus']] as [$label,$value,$icon]): ?>
<div class="col-6 col-xl-3"><div class="card h-100"><div class="card-body"><div class="text-muted small"><?= e($label) ?></div><div class="fs-4 fw-semibold mt-1"><i class="fa-solid <?= e($icon) ?> me-2 text-muted"></i><?= e($value) ?></div></div></div></div>
<?php endforeach; ?>
<?php if ($moneyVisible): ?><div class="col-12"><div class="card"><div class="card-body d-flex justify-content-between align-items-center"><span class="text-muted">Billable amount (frozen entry rates)</span><strong class="fs-4"><?= e($money((float)$totals['billable_amount'])) ?></strong></div></div></div><?php endif; ?>
</div>

<div class="row g-4">
<?php foreach ([['Projects','projects','project_name','Project'],['Tasks','tasks','task_name','Task'],['Users','users','user_name','User'],['Clients','clients','client_name','Client']] as [$title,$key,$nameKey,$nameLabel]): ?>
<div class="col-12 col-xxl-6"><div class="card h-100"><div class="card-header d-flex justify-content-between align-items-center"><strong><?= e($title) ?></strong><span class="text-muted small"><?= count($summary[$key]) ?> groups</span></div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th><?= e($nameLabel) ?></th><th>Hours</th><th>Billable</th><th>Non-billable</th><?php if($moneyVisible): ?><th>Amount</th><?php endif; ?></tr></thead><tbody>
<?php if ($summary[$key] === []): ?><tr><td colspan="<?= $moneyVisible?5:4 ?>" class="text-muted text-center py-4">No time entries match these filters.</td></tr><?php else: foreach($summary[$key] as $row): ?><tr><td><strong><?= e((string)($row[$nameKey] ?? '')) ?></strong><?php if($key==='projects' && !empty($row['client_name'])): ?><div class="small text-muted"><?= e((string)$row['client_name']) ?></div><?php elseif($key==='tasks' && !empty($row['project_name'])): ?><div class="small text-muted"><?= e((string)$row['project_name']) ?></div><?php endif; ?></td><td><?= e($hours((int)$row['seconds'])) ?></td><td><?= e($hours((int)$row['billable_seconds'])) ?></td><td><?= e($hours((int)$row['nonbillable_seconds'])) ?></td><?php if($moneyVisible): ?><td><?= e($money((float)$row['billable_amount'])) ?></td><?php endif; ?></tr><?php endforeach; endif; ?>
</tbody></table></div></div></div>
<?php endforeach; ?>
</div>

<div class="card mt-4"><div class="card-header"><strong>Billable vs non-billable</strong></div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Category</th><th>Entries</th><th>Hours</th><?php if($moneyVisible): ?><th>Amount</th><?php endif; ?></tr></thead><tbody><?php foreach($summary['billable'] as $row): ?><tr><td><?= e((string)$row['category']) ?></td><td><?= (int)$row['entry_count'] ?></td><td><?= e($hours((int)$row['seconds'])) ?></td><?php if($moneyVisible): ?><td><?= e($money((float)$row['billable_amount'])) ?></td><?php endif; ?></tr><?php endforeach; ?></tbody></table></div></div>
