<?php
/**
 * Department setup: departments in a project, the department manager,
 * team managers under each department, and their members.
 *
 *   Admin > Project Manager > Department Manager > Team Manager > Members
 *
 * Admins see every project. A project manager sees and edits only departments where
 * projects.manager_id = self. The project manager is set on the project itself
 * (Projects > Edit). Admins still need settings.manage.
 */

declare(strict_types=1);

final class TeamGroupController extends Controller
{
    private TeamGroup $teams;
    private Department $departments;

    public function __construct()
    {
        parent::__construct(true);
        $this->teams       = new TeamGroup();
        $this->departments = new Department();
    }

    /** GET /teams */
    public function index(Request $request, array $params): void
    {
        $this->requireCanOpen();

        $ready     = Department::installed();
        $projectId = (int) $request->input('project_id', 0);
        $search    = trim((string) $request->input('q', ''));
        $allowed   = $this->allowedProjectIds();

        if ($projectId > 0 && $allowed !== null && !in_array($projectId, $allowed, true)) {
            $this->forbidden();
        }

        $rows  = [];
        $teams = [];
        if ($ready) {
            $rows = $this->departments->all($projectId, $search);
            if ($allowed !== null) {
                $rows = array_values(array_filter(
                    $rows,
                    static fn (array $row): bool => in_array((int) $row['project_id'], $allowed, true)
                ));
            }
            $teams = $this->departments->teamsByDepartment(array_map(static fn (array $r): int => (int) $r['id'], $rows));
        }
        $teamIds = [];
        foreach ($teams as $list) {
            foreach ($list as $team) {
                $teamIds[] = (int) $team['id'];
            }
        }
        $members = $ready ? $this->teams->membersByTeam($teamIds) : [];
        foreach ($rows as &$row) {
            $row['task_count'] = $ready ? $this->teams->taskCountForDepartment((int) $row['id']) : 0;
        }
        unset($row);

        $this->render('teams/index', [
            'pageTitle' => 'Department setup',
            'ready'     => $ready,
            'rows'      => $rows,
            'teams'     => $teams,
            'members'   => $members,
            'projects'  => $this->projectOptions(),
            'projectId' => $projectId,
            'search'    => $search,
        ]);
    }

    /** GET /teams/create */
    public function create(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $projectId = (int) $request->input('project_id', 0);
        $this->assertCanManageProject($projectId > 0 ? $projectId : null);

        $this->renderForm(null, [], $projectId);
    }

    /** POST /teams */
    public function store(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        [$data, $teamBlocks] = $this->validated(null, 0);
        $this->assertCanManageProject((int) $data['project_id']);

        $id = (int) Database::transaction(function () use ($data, $teamBlocks): int {
            $deptId = $this->departments->create($data, (int) AuthHelper::id());
            $this->syncTeams($deptId, (int) $data['project_id'], (string) $data['status'], $teamBlocks, $data['manager_id']);

            return $deptId;
        });
        ApprovalChainHelper::reset();

        $warnings = $this->syncPeople((int) $data['project_id'], $data['manager_id'], $teamBlocks);

        LoggerHelper::audit('department.created', 'department', $id, [
            'name' => $data['name'], 'project_id' => $data['project_id'],
            'manager_id' => $data['manager_id'], 'teams' => count($teamBlocks),
        ]);
        $this->flash('success', 'Department "' . $data['name'] . '" was created.');
        foreach ($warnings as $warning) {
            $this->flash('warning', $warning);
        }
        $this->redirect('/teams');
    }

    /** GET /teams/{id}/edit */
    public function edit(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $department = $this->departments->find((int) ($params['id'] ?? 0));
        if ($department === null) {
            $this->notFound();
        }
        $this->assertCanManageProject((int) $department['project_id']);

        $this->renderForm($department, $this->existingTeamBlocks((int) $department['id']), (int) $department['project_id']);
    }

    /** POST /teams/{id} */
    public function update(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $id         = (int) ($params['id'] ?? 0);
        $department = $this->departments->find($id);
        if ($department === null) {
            $this->notFound();
        }
        $this->assertCanManageProject((int) $department['project_id']);

        [$data, $teamBlocks] = $this->validated($department, $id);
        $this->assertCanManageProject((int) $data['project_id']);

        Database::transaction(function () use ($id, $data, $teamBlocks): void {
            $this->departments->update($id, $data);
            $this->syncTeams($id, (int) $data['project_id'], (string) $data['status'], $teamBlocks, $data['manager_id']);
        });
        ApprovalChainHelper::reset();

        $warnings = $this->syncPeople((int) $data['project_id'], $data['manager_id'], $teamBlocks);

        LoggerHelper::audit('department.updated', 'department', $id, [
            'name' => $data['name'], 'project_id' => $data['project_id'],
            'manager_id' => $data['manager_id'], 'teams' => count($teamBlocks),
        ]);
        $this->flash('success', 'Department "' . $data['name'] . '" was updated.');
        foreach ($warnings as $warning) {
            $this->flash('warning', $warning);
        }
        $this->redirect('/teams');
    }

    /** POST /teams/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $id         = (int) ($params['id'] ?? 0);
        $department = $this->departments->find($id);
        if ($department === null) {
            $this->notFound();
        }
        $this->assertCanManageProject((int) $department['project_id']);

        $taskCount = $this->teams->taskCountForDepartment($id);
        $this->departments->delete($id);
        ApprovalChainHelper::reset();

        LoggerHelper::audit('department.deleted', 'department', $id, [
            'name'       => (string) $department['name'],
            'project_id' => (int) $department['project_id'],
            'task_count' => $taskCount,
        ]);
        $message = 'Department "' . (string) $department['name'] . '" was deleted. Its people keep their accounts and project access.';
        if ($taskCount > 0) {
            $message .= ' ' . $taskCount . ' task' . ($taskCount === 1 ? '' : 's') . ' became project-level.';
        }
        $this->flash('success', $message);
        $this->redirect('/teams');
    }

    /* ------------------------------------------------------------------ helpers */

    private function requireReady(): void
    {
        if (Department::installed()) {
            return;
        }

        $this->flash('warning', 'Department tables are not installed yet. Run database/UPGRADE_LIVE.sql.');
        $this->redirect('/teams');
    }

    /** Admins with settings.manage, or a PM of at least one project. */
    private function requireCanOpen(): void
    {
        if (ClientScope::isClient()) {
            $this->forbidden();
        }

        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            PermissionHelper::require('settings.manage');

            return;
        }

        if ($this->managedProjectIds() === []) {
            throw new HttpException(403, 'Only an administrator or a project manager can manage departments.');
        }
    }

    private function assertCanManageProject(?int $projectId): void
    {
        if ($projectId === null || $projectId < 1) {
            if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
                return;
            }
            throw new HttpException(403, 'Choose a project you manage.');
        }

        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            return;
        }

        if (!WorkspacePolicy::isProjectManagerOf($projectId)) {
            throw new HttpException(403, 'You can only manage departments of your own project.');
        }
    }

    /**
     * null = all projects (admin). Otherwise the PM's own project ids.
     *
     * @return list<int>|null
     */
    private function allowedProjectIds(): ?array
    {
        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            return null;
        }

        return $this->managedProjectIds();
    }

    /** @return list<int> */
    private function managedProjectIds(): array
    {
        $userId = (int) AuthHelper::id();
        if ($userId < 1) {
            return [];
        }

        $rows = Database::fetchAll(
            'SELECT id FROM projects WHERE manager_id = :id',
            ['id' => $userId]
        );

        return array_map(static fn (array $row): int => (int) $row['id'], $rows);
    }

    /**
     * @param array<string, mixed>|null $department
     * @param list<array{id: int, name: string, manager_id: int, member_ids: list<int>}> $teamBlocks
     */
    private function renderForm(?array $department, array $teamBlocks, int $projectId, array $errors = []): void
    {
        if ($errors !== []) {
            $old = [];
            foreach ($this->request->body() as $key => $value) {
                if (in_array($key, ['_csrf', '_method'], true)) {
                    continue;
                }
                if (is_string($value) || is_array($value)) {
                    $old[$key] = $value;
                }
            }
            FormatHelper::withState($old, $errors);
        }

        $this->render('teams/form', [
            'pageTitle'  => $department === null ? 'New department' : 'Edit department',
            'department' => $department,
            'teamBlocks' => $teamBlocks,
            'projectId'  => $projectId,
            'projects'   => $this->projectOptions(),
            'people'     => $this->peopleOptions(),
            'statuses'   => Department::STATUSES,
            'taskCount'  => $department !== null ? $this->teams->taskCountForDepartment((int) $department['id']) : 0,
        ]);
    }

    /** @return list<array<string, mixed>> */
    private function projectOptions(): array
    {
        $allowed = $this->allowedProjectIds();
        $sql     = 'SELECT p.id, p.name, p.project_code, p.status, p.manager_id, pm.name AS manager_name
             FROM projects p
             LEFT JOIN users pm ON pm.id = p.manager_id';
        $params  = [];
        if ($allowed !== null) {
            if ($allowed === []) {
                return [];
            }
            $placeholders = [];
            foreach ($allowed as $i => $id) {
                $key              = 'p' . $i;
                $placeholders[]   = ':' . $key;
                $params[$key]     = $id;
            }
            $sql .= ' WHERE p.id IN (' . implode(',', $placeholders) . ')';
        }
        $sql .= ' ORDER BY p.name ASC';

        return Database::fetchAll($sql, $params);
    }

    /** @return list<array<string, mixed>> */
    private function peopleOptions(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name, r.name AS role
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        );
    }

    /**
     * @return list<array{id: int, name: string, manager_id: int, member_ids: list<int>}>
     */
    private function existingTeamBlocks(int $departmentId): array
    {
        $out = [];
        foreach ($this->departments->teamsOf($departmentId) as $team) {
            $out[] = [
                'id'         => (int) $team['id'],
                'name'       => (string) $team['name'],
                'manager_id' => (int) ($team['manager_id'] ?? 0),
                'member_ids' => $this->teams->memberIds((int) $team['id']),
            ];
        }

        return $out;
    }

    /**
     * @param array<string, mixed>|null $department
     * @return array{0: array{project_id: int, name: string, manager_id: ?int, status: string}, 1: list<array{id: int, name: string, manager_id: int, member_ids: list<int>}>}
     */
    private function validated(?array $department, int $exceptId): array
    {
        $request   = $this->request;
        $errors    = [];
        $name      = trim((string) $request->input('name', ''));
        $projectId = (int) $request->input('project_id', 0);
        $managerId = (int) $request->input('manager_id', 0);
        $status    = (string) $request->input('status', 'active');
        $failPath  = $exceptId > 0 ? '/teams/' . $exceptId . '/edit' : '/teams/create';

        $validPeople = [];
        $peopleNames = [];
        foreach ($this->peopleOptions() as $person) {
            $validPeople[(int) $person['id']] = true;
            $peopleNames[(int) $person['id']] = (string) $person['name'];
        }

        if ($name === '') {
            $errors['name'] = 'Enter a department name.';
        } elseif (mb_strlen($name, 'UTF-8') > 120) {
            $errors['name'] = 'Use 120 characters or fewer.';
        }

        $allowed = $this->allowedProjectIds();
        if ($projectId < 1 || (int) Database::fetchValue('SELECT COUNT(*) FROM projects WHERE id = :id', ['id' => $projectId]) === 0) {
            $errors['project_id'] = 'Choose the project this department belongs to.';
        } elseif ($allowed !== null && !in_array($projectId, $allowed, true)) {
            $errors['project_id'] = 'You can only manage departments of your own project.';
        } elseif ($name !== '' && $this->departments->nameTaken($projectId, $name, $exceptId)) {
            $errors['name'] = 'This project already has a department with that name.';
        }

        if (!in_array($status, Department::STATUSES, true)) {
            $status = 'active';
        }

        if ($managerId > 0 && !isset($validPeople[$managerId])) {
            $errors['manager_id'] = 'Choose an active user as department manager.';
        }

        $teamBlocks = $this->postedTeamBlocks($validPeople, $peopleNames, $managerId, $errors);

        if ($errors !== []) {
            $this->renderForm(
                $department,
                $teamBlocks !== [] ? $teamBlocks : [['id' => 0, 'name' => '', 'manager_id' => 0, 'member_ids' => []]],
                $projectId,
                $errors
            );
            exit;
        }

        unset($failPath);

        return [[
            'project_id' => $projectId,
            'name'       => $name,
            'manager_id' => $managerId > 0 ? $managerId : null,
            'status'     => $status,
        ], $teamBlocks];
    }

    /**
     * @param array<int, true> $validPeople
     * @param array<int, string> $peopleNames
     * @param array<string, string> $errors
     * @return list<array{id: int, name: string, manager_id: int, member_ids: list<int>}>
     */
    private function postedTeamBlocks(array $validPeople, array $peopleNames, int $deptManagerId, array &$errors): array
    {
        $raw = $this->request->input('teams', []);
        if (!is_array($raw)) {
            return [];
        }

        $out        = [];
        $usedNames  = [];
        $usedMgrs   = [];

        foreach (array_values($raw) as $i => $block) {
            if (!is_array($block)) {
                continue;
            }
            $id        = (int) ($block['id'] ?? 0);
            $teamName  = trim((string) ($block['name'] ?? ''));
            $mgrId     = (int) ($block['manager_id'] ?? 0);
            $rawMembers = $block['member_ids'] ?? [];
            if (!is_array($rawMembers)) {
                $rawMembers = [$rawMembers];
            }
            $memberIds = array_values(array_unique(array_filter(
                array_map('intval', $rawMembers),
                static fn (int $uid): bool => $uid > 0
            )));

            $empty = $teamName === '' && $mgrId < 1 && $memberIds === [];
            if ($empty) {
                continue;
            }

            if ($mgrId < 1 || !isset($validPeople[$mgrId])) {
                $errors['teams.' . $i . '.manager_id'] = 'Choose an active user as team manager.';
                $mgrId = 0;
            } elseif ($deptManagerId > 0 && $mgrId === $deptManagerId) {
                $errors['teams.' . $i . '.manager_id'] = 'The department manager cannot also be a team manager in this department.';
            } elseif (isset($usedMgrs[$mgrId])) {
                $errors['teams.' . $i . '.manager_id'] = 'Each team manager can only be added once in this department.';
            } else {
                $usedMgrs[$mgrId] = true;
            }

            if ($teamName === '' && $mgrId > 0) {
                $teamName = ($peopleNames[$mgrId] ?? 'Team') . "'s team";
            }
            if ($teamName === '') {
                $errors['teams.' . $i . '.name'] = 'Enter a team name.';
            } elseif (mb_strlen($teamName, 'UTF-8') > 120) {
                $errors['teams.' . $i . '.name'] = 'Use 120 characters or fewer.';
            } else {
                $key = mb_strtolower($teamName, 'UTF-8');
                if (isset($usedNames[$key])) {
                    $errors['teams.' . $i . '.name'] = 'Each team in this department needs a unique name.';
                }
                $usedNames[$key] = true;
            }

            $memberIds = array_values(array_filter(
                $memberIds,
                static fn (int $uid): bool => isset($validPeople[$uid]) && $uid !== $mgrId && $uid !== $deptManagerId
            ));

            $out[] = [
                'id'         => $id,
                'name'       => $teamName,
                'manager_id' => $mgrId,
                'member_ids' => $memberIds,
            ];
        }

        return $out;
    }

    /**
     * @param list<array{id: int, name: string, manager_id: int, member_ids: list<int>}> $teamBlocks
     */
    private function syncTeams(int $departmentId, int $projectId, string $status, array $teamBlocks, ?int $deptManagerId): void
    {
        $keep = [];
        foreach ($teamBlocks as $block) {
            $payload = [
                'project_id'    => $projectId,
                'department_id' => $departmentId,
                'name'          => $block['name'],
                'manager_id'    => $block['manager_id'] > 0 ? $block['manager_id'] : null,
                'status'        => $status,
            ];
            $id = (int) $block['id'];
            if ($id > 0) {
                $existing = $this->teams->find($id);
                if ($existing === null || (int) ($existing['department_id'] ?? 0) !== $departmentId) {
                    $id = $this->teams->create($payload, $block['member_ids'], (int) AuthHelper::id());
                } else {
                    $this->teams->update($id, $payload, $block['member_ids']);
                }
            } else {
                $id = $this->teams->create($payload, $block['member_ids'], (int) AuthHelper::id());
            }
            $keep[] = $id;
        }

        foreach ($this->departments->teamsOf($departmentId) as $team) {
            $tid = (int) $team['id'];
            if (!in_array($tid, $keep, true)) {
                $this->teams->delete($tid);
            }
        }

        unset($deptManagerId);
    }

    /**
     * @param list<array{id: int, name: string, manager_id: int, member_ids: list<int>}> $teamBlocks
     * @return list<string>
     */
    private function syncPeople(int $projectId, ?int $deptManagerId, array $teamBlocks): array
    {
        $ids = [];
        if ($deptManagerId !== null && $deptManagerId > 0) {
            $ids[] = $deptManagerId;
        }
        foreach ($teamBlocks as $block) {
            if ($block['manager_id'] > 0) {
                $ids[] = $block['manager_id'];
            }
            foreach ($block['member_ids'] as $uid) {
                $ids[] = $uid;
            }
        }

        return $this->teams->syncProjectMembers($projectId, $deptManagerId, $ids);
    }
}
