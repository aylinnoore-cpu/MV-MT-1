<?php
// Page layout: top bar, role-based sidebar, page header, footer
function ic($n,$s=20){static $P=[
'dashboard'=>'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
'assets'=>'<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
'cart'=>'<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
'check'=>'<path d="M22 11.1V12a10 10 0 1 1-5.9-9.1"/><path d="M22 4 12 14l-3-3"/>',
'file'=>'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
'doc'=>'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>',
'cols'=>'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M12 3v18M3 9h18"/>',
'chart'=>'<path d="M12 20V10M18 20V4M6 20v-4"/>','barcode'=>'<path d="M4 5v14M8 5v14M12 5v14M15 5v14M20 5v14"/>',
'users'=>'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
'user'=>'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
'tool'=>'<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
'head'=>'<path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/>',
'shield'=>'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>',
'set'=>'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
'out'=>'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>','search'=>'<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/>',
'bell'=>'<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>','clock'=>'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
'cal'=>'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>','arr'=>'<path d="M5 12h14M12 5l7 7-7 7"/>','chev'=>'<path d="M9 18l6-6-6-6"/>',
'zap'=>'<path d="M13 2L3 14h9l-1 8 10-12h-9z"/>','down'=>'<path d="M6 9l6 6 6-6"/>',
'box'=>'<path d="M21 16V8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.7z"/><path d="M3.3 7L12 12l8.7-5M12 22V12"/>',
'alert'=>'<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01"/>',
'ticket'=>'<path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2z"/>',
'truck'=>'<rect x="1" y="3" width="15" height="13"/><path d="M16 8h4l3 3v5h-7V8z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
'plus'=>'<circle cx="12" cy="12" r="10"/><path d="M12 8v8M8 12h8"/>','up'=>'<path d="M16 16l-4-4-4 4M12 12v9"/><path d="M20.4 18.9A5 5 0 0 0 18 9h-1.3A8 8 0 1 0 4 16.3"/>'];
 return '<svg width="'.$s.'" height="'.$s.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'.($P[$n]??'').'</svg>';}
function logo_html(){$l=q('SELECT id,ref_id FROM documents WHERE kind="logo" ORDER BY id DESC LIMIT 1')->fetch();
 if($l)return '<img class="'.($l['ref_id']?'w':'').'" src="'.BASE.'/logo.php?v='.$l['id'].'" alt="Logo">';
 return is_file(ROOT.'/assets/img/logo.png')?'<img src="'.BASE.'/assets/img/logo.png" alt="Logo">':'M<em>A</em>VEN';}
function head($t,$sub=''){$u=me();$r=role();$F=['support','ed','finance'];$S=['support','ed'];$AL=['staff','support','ed','finance'];
 $nv=[['index.php','Dashboard',$AL,'dashboard'],['modules/records.php?m=assets','Assets',$AL,'assets'],['modules/records.php?m=procurement','Procurement',$F,'cart'],['modules/records.php?m=vendors','Vendors',$F,'truck'],['modules/approvals.php','Approvals',$F,'check'],
 ['modules/quotes.php','Quotations',$F,'doc'],['modules/gen.php?k=cs','Comparative Statements',$F,'cols'],['modules/gen.php?k=po','Purchase Orders',$F,'file'],['modules/reports.php','Reports',$F,'chart'],
 ['modules/barcode.php','Barcode Generator',$S,'barcode'],['modules/records.php?m=users','Staff Management',$S,'users'],['modules/records.php?m=maintenance','Maintenance',$S,'tool']];
 if(!in_array($r,$S))$nv[]=['modules/records.php?m=users&a=view&id='.$u['id'],'My Profile',$AL,'user'];
 $nv=array_merge($nv,[['modules/records.php?m=tickets','Support Desk',$AL,'head'],['modules/records.php?m=item_requests',in_array($r,$S)?'Item Requests':'Request IT Items',$AL,'box'],['modules/signatories.php','Authorized Signatures',['ed'],'shield'],['modules/deletion_log.php','Deletion Log',$S,'alert'],['modules/settings.php','Settings',$AL,'set'],['logout.php','Sign out',$AL,'out']]);
 $st=['ed'=>'requested','finance'=>'ed_approved','support'=>'finance_approved'];
 if($r=='staff')$bn=q('SELECT COUNT(*) c FROM tickets WHERE created_by=? AND status IN("open","in_progress")',[$u['id']])->fetch()['c'];
 else{$bn=q('SELECT COUNT(*) c FROM procurement WHERE status=?',[$st[$r]])->fetch()['c'];if($r=='support')$bn+=q('SELECT COUNT(*) c FROM tickets WHERE status IN("open","in_progress")')->fetch()['c'];}
 $B=BASE;echo '<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>'.h($t).' - MIS Portal</title><link rel=stylesheet href="'.$B.'/assets/css/style.css"><body>
<header class=tb><div class=lg>'.logo_html().'<span>MIS Portal</span></div>
<form class=sr action="'.$B.'/modules/search.php">'.ic('search',18).'<input id=gs name=q placeholder="Search..." autocomplete=off><kbd>Ctrl + K</kbd></form>
<div class=rt><a class=bell href="'.$B.'/'.($r=='staff'?'modules/records.php?m=tickets':'modules/approvals.php').'" title="Pending items">'.ic('bell',22).($bn?'<i>'.$bn.'</i>':'').'</a>
<details class=um><summary>'.ic('user',30).'<span class=nm>'.h($u['name']).' ('.h(pretty($r)).')</span>'.ic('down',14).'</summary><div><a href="'.$B.'/modules/settings.php">Settings</a><a href="'.$B.'/logout.php">Sign out</a></div></details></div></header>
<nav class=side>';
 foreach($nv as $x){if(!in_array($r,$x[2]))continue;if($x[1]=='Support Desk')echo '<hr>';
  $on=$x[0]=='index.php'?basename($_SERVER['SCRIPT_NAME'])=='index.php':strpos($_SERVER['REQUEST_URI'],$x[0])!==false;
  echo '<a href="'.$B.'/'.$x[0].'"'.($on?' class=on':'').'>'.ic($x[3]).$x[1].'</a>';}
 echo '</nav><main><div class=ph><div><h1>'.h($t).'</h1>'.($sub?'<p>'.h($sub).'</p>':'').'</div><div class=dt>'.ic('cal',20).date('D, d M Y').'<s></s>'.ic('clock',20).'<span id=clk></span></div></div>
<script>function dl(f){var r=prompt("Reason for deleting (required - it is recorded in the deletion log):");if(!r||!r.trim())return false;f.reason.value=r.trim();return true}function tk(){document.getElementById("clk").textContent=new Date().toLocaleTimeString([],{hour:"numeric",minute:"2-digit"})}tk();setInterval(tk,30000);
addEventListener("keydown",function(e){if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()=="k"){e.preventDefault();document.getElementById("gs").focus()}})</script>';}
function foot(){echo '</main></body>';}
