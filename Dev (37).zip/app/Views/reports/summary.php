<?php
/**
 * Time report > Summary (Clockify layout).
 *
 * @var array<string,mixed> $chart
 * @var list<array<string,mixed>> $groups
 */
require APP_PATH . '/Views/reports/_header.php';
$options = ['project' => 'Project', 'user' => 'Team', 'client' => 'Client', 'task' => 'Task'];
$thenOptions = ['description' => 'Description', 'task' => 'Task', 'user' => 'Team', 'none' => 'None'];
?>
<div class="rk-panel">
    <div class="rk-total-label">Total:</div>
    <div class="rk-total"><?= e($hms($total)) ?></div>
    <div class="rk-panel-row">
        <span class="rk-spacer"></span>
        <button type="button" class="rk-ico" data-report-print title="Print" aria-label="Print"><i class="fa-solid fa-print"></i></button>
    </div>
</div>
<div class="rk-box">
    <div class="rk-chart-bar">
        <span class="rk-chip">Billability</span>
        <span class="rk-legend"><span><i style="background:#8bc34a"></i>Billable <?= e($hms($billableSeconds)) ?></span><span><i style="background:#03a9f4"></i>Non-billable <?= e($hms($total - $billableSeconds)) ?></span></span>
    </div>
    <div class="rk-chart" data-report-bar="<?= e(json_encode($chart['days'], JSON_UNESCAPED_UNICODE)) ?>"><canvas aria-label="Hours per day" role="img"></canvas></div>
</div>

<form method="get" action="<?= e(url('/reports/summary')) ?>" class="rk-groupby">
    <?php foreach (['from', 'to'] as $k): ?><input type="hidden" name="<?= $k ?>" value="<?= e($filters[$k]) ?>"><?php endforeach; ?>
    <?php foreach (['user_id', 'client_id', 'project_id', 'task_id'] as $k): if ((int) $filters[$k] > 0): ?><input type="hidden" name="<?= $k ?>" value="<?= (int) $filters[$k] ?>"><?php endif; endforeach; ?>
    <?php if ($filters['billable'] !== ''): ?><input type="hidden" name="billable" value="<?= e($filters['billable']) ?>"><?php endif; ?>
    <span class="rk-gl">Group by:</span>
    <select name="group" aria-label="Group by" data-autosubmit><?php foreach ($options as $k => $t): ?><option value="<?= $k ?>"<?= $primary === $k ? ' selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select>
    <select name="then" aria-label="Then by" data-autosubmit><?php foreach ($thenOptions as $k => $t): ?><option value="<?= $k ?>"<?= $secondary === $k ? ' selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select>
    <noscript><button class="rk-apply" type="submit">Apply</button></noscript>
</form>
<div class="rk-split">
    <div class="rk-scroll">
        <table class="rk-table">
            <thead><tr><th style="width:5rem"><span class="rk-chev" data-collapse-all title="Expand / collapse all"><i class="fa-solid fa-chevron-down"></i></span></th><th class="rk-l">Title <i class="fa-solid fa-sort"></i></th><th class="rk-r">Duration <i class="fa-solid fa-sort"></i></th></tr></thead>
            <tbody>
            <?php if ($groups === []): ?><tr><td colspan="3" class="rk-empty">No time entries match these filters.</td></tr><?php endif; ?>
            <?php foreach ($groups as $i => $g): ?>
                <tr<?= $g['children'] !== [] ? ' class="rk-click" data-bs-toggle="collapse" data-bs-target=".rk-g' . $i . '" role="button"' : '' ?>>
                    <td class="rk-c"><span class="rk-num"><?= (int) $g['count'] ?></span></td>
                    <td class="rk-l"><span class="rk-dot" style="background:<?= e($g['color']) ?>"></span><span class="rk-name" style="color:<?= e($g['color']) ?>"><?= e($g['label']) ?></span><?php if ($g['sub'] !== ''): ?><span class="rk-client">- <?= e($g['sub']) ?></span><?php endif; ?></td>
                    <td class="rk-r"><?= e($hms((int) $g['seconds'])) ?></td>
                </tr>
                <?php foreach ($g['children'] as $child): ?>
                <tr class="collapse show rk-child rk-g<?= $i ?>">
                    <td class="rk-c"><span class="rk-num"><?= (int) $child['count'] ?></span></td>
                    <td class="rk-l ps-5"><?= e($child['label']) ?></td>
                    <td class="rk-r"><?= e($hms((int) $child['seconds'])) ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="rk-side">
        <div class="rk-donut" data-report-donut="<?= e(json_encode($chart['groups'], JSON_UNESCAPED_UNICODE)) ?>">
            <canvas aria-label="Share of time" role="img"></canvas>
            <div class="rk-donut-center"><?= e($hms($total)) ?></div>
        </div>
    </div>
</div>
</div>
