<?php require __DIR__.'/../includes/lib.php';allow(['support','ed']);
function norm($s){return preg_replace('/[^a-z0-9]/','',strtolower((string)$s));}
function alias(){return ['asset_tag'=>['assettag','tag','assetid','assetcode'],'name'=>['name','assetname','item','itemname','description'],'category'=>['category','type','assettype'],'serial_no'=>['serialno','serialnumber','serial','sn'],
 'purchase_date'=>['purchasedate','dateofpurchase','purchaseddate'],'cost'=>['cost','price','purchasecost','amount','value'],'vendor'=>['vendor','supplier','vendorname'],'status'=>['status','condition'],
 'assigned_to'=>['assignedto','user','staff','employee','assignedstaff','custodian'],'assigned_date'=>['assigneddate','issuedate','dateassigned'],'warranty_months'=>['warrantymonths','warranty','warrantyperiod','warrantyperiodmonths'],
 'warranty_start'=>['warrantystart','warrantystartdate'],'mac_address'=>['mac','macaddress'],'ip_address'=>['ip','ipaddress'],'ip_type'=>['iptype','ipassignment'],'notes'=>['notes','remarks','comments']];}
function read_csv($p){$h=fopen($p,'r');$f=fgets($h);rewind($h);$d=',';foreach([';',"\t"] as $c)if(substr_count($f,$c)>substr_count($f,$d))$d=$c;$rows=[];
 while(($r=fgetcsv($h,0,$d,'"','\\'))!==false){if(count($r)==1&&trim((string)$r[0])==='')continue;$rows[]=$r;}fclose($h);if($rows)$rows[0][0]=preg_replace('/^\xEF\xBB\xBF/','',(string)$rows[0][0]);return $rows;}
function read_xlsx($p){$z=new ZipArchive;if($z->open($p)!==true)return [];$ss=[];
 if(($x=$z->getFromName('xl/sharedStrings.xml'))!==false){$s=simplexml_load_string($x);foreach($s->si as $si){if(isset($si->t))$ss[]=(string)$si->t;else{$t='';foreach($si->r as $r)$t.=(string)$r->t;$ss[]=$t;}}}
 $sh=false;for($i=1;$i<=30&&$sh===false;$i++)$sh=$z->getFromName("xl/worksheets/sheet$i.xml");if($sh===false)return [];$s=simplexml_load_string($sh);$rows=[];
 foreach($s->sheetData->row as $row){$r=[];foreach($row->c as $c){$col=0;foreach(str_split(preg_replace('/\d/','',(string)$c['r'])) as $ch)$col=$col*26+ord($ch)-64;$col--;$t=(string)$c['t'];$v=(string)$c->v;
  if($t=='s')$v=$ss[(int)$v]??'';elseif($t=='inlineStr')$v=(string)$c->is->t;$r[$col]=$v;}
  if($r){$o=array_fill(0,max(array_keys($r))+1,'');foreach($r as $k=>$v)$o[$k]=$v;$rows[]=$o;}}return $rows;}
function read_pdf($p){$b=defined('PDFTOTEXT')?PDFTOTEXT:'pdftotext';$out=[];@exec(escapeshellarg($b).' -layout '.escapeshellarg($p).' - 2>&1',$out,$rc);if($rc!==0)return null;
 $rows=[];foreach($out as $l){if(trim($l)==='')continue;$c=preg_split('/\s{2,}|\t/',trim($l));if(count($c)>=2)$rows[]=$c;}return $rows;}
function pdate($v){$v=trim((string)$v);if($v==='')return null;if(is_numeric($v)&&$v>20000&&$v<80000)return gmdate('Y-m-d',(int)(($v-25569)*86400));
 foreach(['Y-m-d','d/m/Y','d-m-Y','d.m.Y','d-M-Y','d M Y','j/n/Y','j-n-Y','m/d/Y'] as $f){$d=DateTime::createFromFormat($f,$v);if($d&&$d->format($f)==$v)return $d->format('Y-m-d');}
 $t=strtotime($v);return $t?date('Y-m-d',$t):false;}
function conv($rows){$al=alias();$hdr=array_map('norm',$rows[0]);$map=[];foreach($al as $f=>$ns)foreach($hdr as $i=>$h)if(in_array($h,$ns)){$map[$f]=$i;break;}
 if(!isset($map['name']))return [null,'No "Name" column found in the first row. Use the column headers from the sample file.'];
 $us=[];foreach(q('SELECT id,name,email,employee_id FROM users')->fetchAll() as $u)foreach([$u['name'],$u['email'],$u['employee_id']] as $k)if($k)$us[strtolower(trim($k))]=$u['id'];
 $vd=[];foreach(q('SELECT id,name FROM vendors')->fetchAll() as $v)$vd[strtolower(trim($v['name']))]=$v['id'];
 $tags=array_flip(array_map('strtolower',array_column(q('SELECT asset_tag FROM assets WHERE asset_tag IS NOT NULL')->fetchAll(),'asset_tag')));
 $macs=array_flip(array_column(q('SELECT mac_address FROM assets WHERE mac_address IS NOT NULL')->fetchAll(),'mac_address'));$ips=array_flip(array_column(q('SELECT ip_address FROM assets WHERE ip_address IS NOT NULL')->fetchAll(),'ip_address'));
 $SA=['active'=>'working','under_repair'=>'out_for_repair','repair'=>'out_for_repair','maintenance'=>'out_for_maintenance','storage'=>'in_storage','stock'=>'in_storage','lost_stolen'=>'lost'];
 $valid=['working','out_for_repair','out_for_maintenance','in_storage','faulty','dead','lost'];$items=[];
 foreach(array_slice($rows,1) as $n=>$r){$g=fn($f)=>isset($map[$f])?trim((string)($r[$map[$f]]??'')):'';if(!array_filter($r,fn($c)=>trim((string)$c)!==''))continue;if(count($items)>=2000)break;$e=[];$w=[];
  $it=['row'=>$n+2,'asset_tag'=>$g('asset_tag')?:null,'name'=>$g('name'),'category'=>$g('category')?:null,'serial_no'=>$g('serial_no')?:null,'notes'=>$g('notes')?:null,'vendor_id'=>null,'vendor_name'=>$g('vendor'),'assigned_to'=>null,'assigned_name'=>$g('assigned_to')];
  if($it['name']==='')$e[]='Name is missing';
  if($it['asset_tag']&&isset($tags[strtolower($it['asset_tag'])]))$e[]='Asset tag already exists';
  $st=str_replace([' ','-','/'],'_',strtolower($g('status')?:'working'));$st=$SA[$st]??$st;if(!in_array($st,$valid)){$e[]='Unknown status "'.$g('status').'"';$st='working';}$it['status']=$st;
  foreach(['purchase_date','assigned_date','warranty_start'] as $f){$d=pdate($g($f));if($d===false){$e[]='Invalid date in '.pretty($f);$d=null;}$it[$f]=$d;}
  $c=preg_replace('/[^0-9.]/','',$g('cost'));$it['cost']=$c!==''?(float)$c:null;
  $wm=$g('warranty_months');if(preg_match('/(\d+(?:\.\d+)?)\s*(y|yr|year)/i',$wm,$m))$wm=(int)round($m[1]*12);elseif(preg_match('/(\d+)/',$wm,$m))$wm=(int)$m[1];else $wm=null;$it['warranty_months']=$wm?:null;
  $ws=$it['warranty_start']?:$it['purchase_date'];$it['warranty_end']=($ws&&$wm)?(new DateTime($ws))->modify("+$wm months")->format('Y-m-d'):null;
  $it['vendor_id']=$it['vendor_name']!==''?($vd[strtolower($it['vendor_name'])]??null):null;if($it['vendor_name']!==''&&!$it['vendor_id'])$w[]='New vendor "'.$it['vendor_name'].'" will be created';
  if($it['assigned_name']!==''){$it['assigned_to']=$us[strtolower($it['assigned_name'])]??null;if(!$it['assigned_to'])$w[]='Staff "'.$it['assigned_name'].'" not found - left unassigned';}
  $mac=$g('mac_address');$ip=$g('ip_address');$it['mac_supported']=($mac!==''||$ip!=='')?'Yes':'No';$it['mac_address']=null;$it['ip_address']=null;$it['ip_type']=null;
  if($mac!==''){$m=preg_replace('/[^0-9A-F]/','',strtoupper($mac));if(strlen($m)!=12)$e[]='Invalid MAC address';else{$it['mac_address']=implode(':',str_split($m,2));if(isset($macs[$it['mac_address']]))$e[]='MAC address already used';}}
  if($ip!==''){if(!filter_var($ip,FILTER_VALIDATE_IP))$e[]='Invalid IP address';elseif(isset($ips[$ip]))$e[]='IP address already in use';else $it['ip_address']=$ip;}
  $t=strtolower($g('ip_type'));$it['ip_type']=$t===''?null:(strpos($t,'dhcp')!==false?'DHCP reservation':(strpos($t,'static')!==false?'Static':null));
  $it['ok']=!$e;$it['msg']=implode('; ',$e);$it['warn']=implode('; ',$w);
  if($it['ok']){if($it['asset_tag'])$tags[strtolower($it['asset_tag'])]=1;if($it['mac_address'])$macs[$it['mac_address']]=1;if($it['ip_address'])$ips[$it['ip_address']]=1;}
  $items[]=$it;}
 return [$items,null];}
if(isset($_GET['sample'])){header('Content-Type:text/csv');header('Content-Disposition:attachment;filename=asset_import_sample.csv');$o=fopen('php://output','w');
 csvput($o,['Asset Tag','Name','Category','Serial No','Purchase Date','Cost','Vendor','Status','Assigned To','Assigned Date','Warranty (months)','Warranty Start','MAC Address','IP Address','IP Type','Notes']);
 csvput($o,['MAVENIT200','Dell Latitude 5440','Laptop','SN12345','2026-01-15','185000','Laptop Station','Working','Rummish Saleem','2026-01-20','12','','AA:BB:CC:DD:EE:FF','192.168.1.50','Static','Sample row - delete me']);exit;}
$msg='';$good='';$prev=null;
if($_SERVER['REQUEST_METHOD']=='POST'){chk();
 if(isset($_POST['commit'])){$items=$_SESSION['imp']??[];unset($_SESSION['imp']);$n=0;$nv=0;$pdo=$GLOBALS['pdo'];$pdo->beginTransaction();
  foreach($items as $it){if(!$it['ok'])continue;$vid=$it['vendor_id'];
   if(!$vid&&$it['vendor_name']!==''){$x=q('SELECT id FROM vendors WHERE name=?',[$it['vendor_name']])->fetch();if($x)$vid=$x['id'];else{q('INSERT INTO vendors(name)VALUES(?)',[$it['vendor_name']]);$vid=$pdo->lastInsertId();$nv++;}}
   q('INSERT INTO assets(asset_tag,name,category,serial_no,purchase_date,cost,vendor_id,status,assigned_to,assigned_date,warranty_months,warranty_start,warranty_end,mac_supported,mac_address,ip_address,ip_type,notes)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
    [$it['asset_tag'],$it['name'],$it['category'],$it['serial_no'],$it['purchase_date'],$it['cost'],$vid,$it['status'],$it['assigned_to'],$it['assigned_date'],$it['warranty_months'],$it['warranty_start'],$it['warranty_end'],$it['mac_supported'],$it['mac_address'],$it['ip_address'],$it['ip_type'],$it['notes']]);
   $id=$pdo->lastInsertId();$b='AST-'.str_pad($id,6,'0',STR_PAD_LEFT);q('UPDATE assets SET barcode=?,asset_tag=COALESCE(asset_tag,?) WHERE id=?',[$b,$b,$id]);$n++;}
  $pdo->commit();logit("Imported $n assets from file");$good="Imported $n asset(s)".($nv?" and created $nv new vendor(s)":'').'.';}
 elseif(isset($_FILES['file'])){$f=$_FILES['file'];$ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
  if(empty($f['tmp_name'])||!is_uploaded_file($f['tmp_name'])||$f['size']>8000000||!in_array($ext,['xlsx','csv','pdf']))$msg='Choose an .xlsx, .csv or .pdf file up to 8MB.';
  elseif($ext=='pdf'&&file_get_contents($f['tmp_name'],false,null,0,4)!=='%PDF')$msg='That does not look like a valid PDF.';
  else{$rows=$ext=='xlsx'?read_xlsx($f['tmp_name']):($ext=='csv'?read_csv($f['tmp_name']):read_pdf($f['tmp_name']));
   if($rows===null)$msg='PDF import needs the free "pdftotext" tool (Poppler) installed on the server (see config/config.php). Alternatively export the PDF to Excel or CSV and upload that.';
   elseif(count($rows)<2)$msg='No data rows were found in the file.';
   else{[$items,$er]=conv($rows);if($er)$msg=$er;else{$_SESSION['imp']=$items;$prev=$items;}}}}}
head('Import Assets','Add many assets at once from an Excel (.xlsx), CSV or PDF table');
if($msg)echo '<p class=err style="font-weight:600">'.h($msg).'</p>';if($good)echo '<p style="color:#1d7a3c;font-weight:600">'.h($good).' <a href="records.php?m=assets">View assets</a></p>';
if($prev===null){echo '<div class=card><form method=post enctype=multipart/form-data><input type=hidden name=c value="'.csrf().'"><label>Choose file (.xlsx, .csv or .pdf, max 8MB, up to 2000 rows)</label><input type=file name=file accept=.xlsx,.csv,.pdf required><p><button>Upload &amp; preview</button> <a class="btn g" href="?sample=1">Download sample CSV</a> <a class="btn g" href="records.php?m=assets">Cancel</a></p></form>
 <p style="color:#6b7385">The first row must be column headers. <b>Name</b> is required. Optional columns: Asset Tag, Category, Serial No, Purchase Date, Cost, Vendor, Status, Assigned To (name, email or employee ID), Assigned Date, Warranty (months), Warranty Start, MAC Address, IP Address, IP Type, Notes.
 You will see a preview and any problems before anything is saved. Rows with errors are skipped. PDFs must contain a text table (not a scanned picture).</p></div>';}
else{$ok=count(array_filter($prev,fn($i)=>$i['ok']));$bad=count($prev)-$ok;
 echo '<div class=card><b>'.count($prev).' rows read:</b> <span class="pill g">'.$ok.' ready</span> <span class="pill r">'.$bad.' with errors (will be skipped)</span>';
 if($ok)echo '<form method=post style="margin-top:12px"><input type=hidden name=c value="'.csrf().'"><input type=hidden name=commit value=1><button>Import '.$ok.' asset(s)</button> <a class="btn g" href="asset_import.php">Cancel</a></form>';else echo '<p><a class="btn g" href="asset_import.php">Try another file</a></p>';
 echo '</div><div class=card><table><tr><th>Row<th>Tag<th>Name<th>Category<th>Serial<th>Status<th>Assigned<th>Vendor<th>Result';
 foreach($prev as $i)echo '<tr><td>'.$i['row'].'<td>'.h($i['asset_tag']).'<td>'.h($i['name']).'<td>'.h($i['category']).'<td>'.h($i['serial_no']).'<td>'.h(pretty($i['status'])).'<td>'.h($i['assigned_name']).'<td>'.h($i['vendor_name']).'<td>'.($i['ok']?'<span class="pill g">OK</span>':'<span class="pill r">'.h($i['msg']).'</span>').($i['warn']?'<br><small>'.h($i['warn']).'</small>':'');
 echo '</table></div>';}
foot();
