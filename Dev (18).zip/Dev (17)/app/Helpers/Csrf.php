<?php
/**
 * CSRF protection (synchronizer token + Origin check).
 *
 * Forms:  <?= CsrfHelper::field() ?>
 * AJAX :  put <?= CsrfHelper::meta() ?> in <head>; app.js sends it as the X-CSRF-Token header.
 *
 * The Router calls verify() automatically for every POST/PUT/PATCH/DELETE route.
 */

declare(strict_types=1);

final class CsrfHelper
{
    private const SESSION_KEY = '_csrf';
    private const FIELD_NAME  = '_csrf';
    private const HEADER_NAME = 'x-csrf-token';

    /** Per-session token (shared across tabs so a second tab does not invalidate the first). */
    public static function token(): string
    {
        if (!isset($_SESSION[self::SESSION_KEY]) || !is_string($_SESSION[self::SESSION_KEY])) {
            $_SESSION[self::SESSION_KEY] = bin2hex(random_bytes(32));
        }

        return $_SESSION[self::SESSION_KEY];
    }

    /** Issue a fresh token. Called on login so a pre-login token cannot be reused afterwards. */
    public static function regenerate(): void
    {
        $_SESSION[self::SESSION_KEY] = bin2hex(random_bytes(32));
    }

    /** Hidden input for HTML forms. */
    public static function field(): string
    {
        return '<input type="hidden" name="' . self::FIELD_NAME . '" value="'
            . htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8') . '">';
    }

    /** Meta tag read by assets/js/app.js to attach the token to fetch/XHR calls. */
    public static function meta(): string
    {
        return '<meta name="csrf-token" content="'
            . htmlspecialchars(self::token(), ENT_QUOTES, 'UTF-8') . '">';
    }

    /** Constant-time comparison against the session token. */
    public static function isValid(?string $submitted): bool
    {
        $expected = $_SESSION[self::SESSION_KEY] ?? null;

        return is_string($expected)
            && is_string($submitted)
            && $submitted !== ''
            && hash_equals($expected, $submitted);
    }

    /**
     * Reject the request with HTTP 419 unless it carries a valid token
     * (form field "_csrf" or header X-CSRF-Token) and a same-origin Origin/Referer.
     */
    public static function verify(Request $request): void
    {
        $submitted = $request->header(self::HEADER_NAME);

        if ($submitted === null) {
            $field = $request->input(self::FIELD_NAME);
            $submitted = is_string($field) ? $field : null;
        }

        if (!self::isValid($submitted)) {
            LoggerHelper::warning('CSRF token rejected', ['path' => $request->path(), 'ip' => $request->ip()]);
            throw new HttpException(419);
        }

        if (Config::get('security.check_origin', true) && !self::isSameOrigin($request)) {
            LoggerHelper::warning('Cross-origin request rejected', ['path' => $request->path(), 'ip' => $request->ip()]);
            throw new HttpException(419);
        }
    }

    /**
     * If the browser sent Origin (or, failing that, Referer) it must match this host.
     * Requests with neither header are allowed: the token check above still protects them.
     */
    private static function isSameOrigin(Request $request): bool
    {
        $source = $request->header('origin') ?? $request->header('referer');

        if ($source === null || $source === '') {
            return true;
        }

        $parts = parse_url($source);
        if ($parts === false || empty($parts['host'])) {
            return false; // "null" origins and garbage are rejected for state-changing requests
        }

        $originHost = strtolower((string) $parts['host']);
        $hostName   = strtolower(explode(':', $request->host(), 2)[0]);

        return $originHost === $hostName;
    }
}
