<?php
/**
 * Projects: CRUD, visibility filters, member sync, estimated vs tracked vs billable totals.
 */

declare(strict_types=1);

final class Project extends Model
{
    public const STATUS_PLANNING  = 'Planning';
    public const STATUS_ACTIVE    = 'Active';
    public const STATUS_ON_HOLD   = 'On Hold';
    public const STATUS_COMPLETED = 'Completed';
    public const STATUS_CANCELLED = 'Cancelled';
    public const STATUS_ARCHIVED  = 'Archived';

    public const STATUSES = [
        self::STATUS_PLANNING,
        self::STATUS_ACTIVE,
        self::STATUS_ON_HOLD,
        self::STATUS_COMPLETED,
        self::STATUS_CANCELLED,
        self::STATUS_ARCHIVED,
    ];

    public const OPEN_STATUSES = [
        self::STATUS_PLANNING,
        self::STATUS_ACTIVE,
        self::STATUS_ON_HOLD,
    ];

    /** Only Active projects accept new or edited time. */
    public const TRACKABLE_STATUSES = [
        self::STATUS_ACTIVE,
    ];

    public const PRIORITY_LOW    = 'Low';
    public const PRIORITY_MEDIUM = 'Medium';
    public const PRIORITY_HIGH   = 'High';
    public const PRIORITY_URGENT = 'Urgent';

    public const PRIORITIES = [
        self::PRIORITY_LOW,
        self::PRIORITY_MEDIUM,
        self::PRIORITY_HIGH,
        self::PRIORITY_URGENT,
    ];

    protected string $table = 'projects';

    protected array $columns = [
        'id', 'client_id', 'project_code', 'name', 'description',
        'start_date', 'due_date', 'status', 'priority',
        'estimated_hours', 'budget', 'hourly_rate', 'is_billable',
        'manager_id', 'created_by', 'created_at', 'updated_at',
        'is_public', 'color', 'estimate_type',
    ];

    protected array $fillable = [
        'client_id', 'project_code', 'name', 'description',
        'start_date', 'due_date', 'status', 'priority',
        'estimated_hours', 'budget', 'hourly_rate', 'is_billable',
        'manager_id', 'created_by',
        'is_public', 'color', 'estimate_type',
    ];

    /** True when the project visibility columns exist (is_public, color, estimate_type). */
    public static function extrasReady(): bool
    {
        static $ready = null;

        if ($ready === null) {
            $ready = SchemaHelper::columnExists('projects', 'is_public')
                && SchemaHelper::columnExists('projects', 'color')
                && SchemaHelper::columnExists('projects', 'estimate_type');
        }

        return $ready;
    }

    /** True when the project_favorites table exists (created with the live database). */
    public static function favoritesReady(): bool
    {
        static $ready = null;

        if ($ready === null) {
            $ready = SchemaHelper::tableExists('project_favorites');
        }

        return $ready;
    }

    public function isFavorite(int $projectId, int $userId): bool
    {
        if (!self::favoritesReady()) {
            return false;
        }

        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM project_favorites WHERE project_id = :p AND user_id = :u',
            ['p' => $projectId, 'u' => $userId]
        ) > 0;
    }

    /** @return bool the new favourite state */
    public function toggleFavorite(int $projectId, int $userId): bool
    {
        if (!self::favoritesReady()) {
            return false;
        }

        if ($this->isFavorite($projectId, $userId)) {
            Database::execute(
                'DELETE FROM project_favorites WHERE project_id = :p AND user_id = :u',
                ['p' => $projectId, 'u' => $userId]
            );

            return false;
        }

        Database::execute(
            'INSERT INTO project_favorites (user_id, project_id, created_at) VALUES (:u, :p, UTC_TIMESTAMP())',
            ['p' => $projectId, 'u' => $userId]
        );

        return true;
    }

    public function findWithRelations(int $id): ?array
    {
        return Database::fetchOne(
            "SELECT p.*,
                    c.name AS client_name, c.email AS client_email, c.status AS client_status,
                    m.name AS manager_name, m.email AS manager_email,
                    creator.name AS created_by_name
             FROM projects p
             INNER JOIN clients c ON c.id = p.client_id
             LEFT JOIN users m ON m.id = p.manager_id
             LEFT JOIN users creator ON creator.id = p.created_by
             WHERE p.id = :id
             LIMIT 1",
            ['id' => $id]
        );
    }

    /**
     * @param array{
     *     tab?: string,
     *     status?: string,
     *     client_id?: int|null,
     *     manager_id?: int|null,
     *     q?: string
     * } $filters
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, counts: array<string, int>}
     */
    public function listFiltered(array $filters, int $page, int $perPage, int $userId, bool $viewAll): array
    {
        $perPage = min(100, max(1, $perPage));
        [$accessSql, $accessParams] = $this->accessClause($userId, $viewAll);

        $where  = [$accessSql];
        $params = $accessParams;

        $tab = (string) ($filters['tab'] ?? 'all');
        if (!in_array($tab, ['all', 'active', 'completed', 'archived'], true)) {
            $tab = 'all';
        }

        if ($tab === 'active') {
            $where[] = "p.status IN ('Planning','Active','On Hold')";
        } elseif ($tab === 'completed') {
            $where[] = "p.status = 'Completed'";
        } elseif ($tab === 'archived') {
            $where[] = "p.status = 'Archived'";
        } else {
            $where[] = "p.status <> 'Archived'";
        }

        $status = (string) ($filters['status'] ?? '');
        if ($status !== '' && in_array($status, self::STATUSES, true)) {
            $where[]           = 'p.status = :status';
            $params['status']  = $status;
        }

        $clientId = (int) ($filters['client_id'] ?? 0);
        if ($clientId > 0) {
            $where[]              = 'p.client_id = :client_id';
            $params['client_id']  = $clientId;
        }

        $managerId = (int) ($filters['manager_id'] ?? 0);
        if ($managerId > 0) {
            $where[]               = 'p.manager_id = :manager_id';
            $params['manager_id']  = $managerId;
        }

        // Access filter: projects any of the selected people work on (member or manager).
        $memberIds = array_values(array_unique(array_filter(
            array_map('intval', (array) ($filters['member_ids'] ?? [])),
            static fn (int $id): bool => $id > 0
        )));
        if ($memberIds !== []) {
            // Native prepared statements: every placeholder may appear only once, so the
            // manager check and the membership check each get their own set.
            $managerMarks = [];
            $memberMarks  = [];
            foreach ($memberIds as $i => $mid) {
                $managerMarks[]          = ':fmm' . $i;
                $memberMarks[]           = ':fpm' . $i;
                $params['fmm' . $i]      = $mid;
                $params['fpm' . $i]      = $mid;
            }
            $where[] = '(p.manager_id IN (' . implode(',', $managerMarks) . ')
                OR EXISTS (SELECT 1 FROM project_members fpm
                           WHERE fpm.project_id = p.id AND fpm.user_id IN (' . implode(',', $memberMarks) . ')))';
        }

        $search = trim((string) ($filters['q'] ?? ''));
        if ($search !== '') {
            $term = '%' . self::like($search) . '%';
            $where[] = '(p.name LIKE :q_name OR p.project_code LIKE :q_code OR c.name LIKE :q_client)';
            $params['q_name']    = $term;
            $params['q_code']    = $term;
            $params['q_client']  = $term;
        }

        $whereSql = ' WHERE ' . implode(' AND ', $where);

        $counts = $this->tabCounts($userId, $viewAll, $clientId, $managerId, $search);

        $total = (int) Database::fetchValue(
            "SELECT COUNT(*) FROM projects p INNER JOIN clients c ON c.id = p.client_id{$whereSql}",
            $params
        );

        $pages = max(1, (int) ceil($total / $perPage));
        $page  = min(max(1, $page), $pages);

        $params['limit']  = $perPage;
        $params['offset'] = ($page - 1) * $perPage;

        $taskCountSql = Task::installed()
            ? '(SELECT COUNT(*) FROM tasks tk WHERE tk.project_id = p.id)'
            : '0';

        $trackedSql = $this->timeEntriesExist()
            ? '(SELECT COALESCE(SUM(te.duration_seconds), 0) FROM time_entries te WHERE te.project_id = p.id)'
            : '0';
        $progressSql = "(CASE WHEN p.estimated_hours > 0 THEN {$trackedSql} / 3600 / p.estimated_hours ELSE 0 END)";

        $dir = strtolower((string) ($filters['dir'] ?? 'asc')) === 'desc' ? 'DESC' : 'ASC';
        $orderBy = match ((string) ($filters['sort'] ?? 'name')) {
            'client'   => "c.name {$dir}, p.name ASC",
            'tracked'  => "{$trackedSql} {$dir}, p.name ASC",
            'progress' => "{$progressSql} {$dir}, p.name ASC",
            default    => "p.name {$dir}",
        };

        if (self::favoritesReady()) {
            $favoriteSql        = '(SELECT COUNT(*) FROM project_favorites pf WHERE pf.project_id = p.id AND pf.user_id = :fav_uid)';
            $params['fav_uid']  = $userId;
        } else {
            $favoriteSql = '0';
        }

        $items = Database::fetchAll(
            "SELECT p.*,
                    c.name AS client_name,
                    m.name AS manager_name,
                    (SELECT COUNT(*) FROM project_members pm WHERE pm.project_id = p.id) AS member_count,
                    {$taskCountSql} AS task_count,
                    {$favoriteSql} AS is_favorite
             FROM projects p
             INNER JOIN clients c ON c.id = p.client_id
             LEFT JOIN users m ON m.id = p.manager_id
             {$whereSql}
             ORDER BY {$orderBy}
             LIMIT :limit OFFSET :offset",
            $params
        );

        $items = $this->attachTotals($items);

        return [
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => $pages,
            'counts'   => $counts,
        ];
    }

    /**
     * Estimated hours vs tracked vs billable, plus budget used.
     *
     * @return array{
     *     estimated_hours: float,
     *     tracked_hours: float,
     *     billable_hours: float,
     *     budget: float,
     *     budget_used: float,
     *     progress: int
     * }
     */
    public function totals(int $projectId): array
    {
        $project = $this->find($projectId);
        if ($project === null) {
            return [
                'estimated_hours' => 0.0,
                'tracked_hours'   => 0.0,
                'billable_hours'  => 0.0,
                'budget'          => 0.0,
                'budget_used'     => 0.0,
                'progress'        => 0,
            ];
        }

        $estimated = (float) $project['estimated_hours'];
        $budget    = (float) $project['budget'];
        $rate      = (float) $project['hourly_rate'];
        $tracked   = 0.0;
        $billable  = 0.0;

        if ($this->timeEntriesExist()) {
            $row = Database::fetchOne(
                'SELECT
                    COALESCE(SUM(duration_seconds), 0) AS tracked_seconds,
                    COALESCE(SUM(CASE WHEN is_billable = 1 THEN duration_seconds ELSE 0 END), 0) AS billable_seconds
                 FROM time_entries
                 WHERE project_id = :id',
                ['id' => $projectId]
            );
            $tracked  = ((int) ($row['tracked_seconds'] ?? 0)) / 3600;
            $billable = ((int) ($row['billable_seconds'] ?? 0)) / 3600;
        }

        $budgetUsed = ((int) $project['is_billable'] === 1) ? $billable * $rate : 0.0;
        $progress   = $estimated > 0 ? (int) min(100, round(($tracked / $estimated) * 100)) : 0;

        return [
            'estimated_hours' => $estimated,
            'tracked_hours'   => round($tracked, 2),
            'billable_hours'  => round($billable, 2),
            'budget'          => $budget,
            'budget_used'     => round($budgetUsed, 2),
            'progress'        => $progress,
        ];
    }

    public function nextCode(): string
    {
        $last = Database::fetchValue(
            "SELECT project_code FROM projects
             WHERE project_code REGEXP '^PRJ-[0-9]+$'
             ORDER BY CAST(SUBSTRING(project_code, 5) AS UNSIGNED) DESC
             LIMIT 1"
        );

        $n = 1;
        if (is_string($last) && preg_match('/^PRJ-(\d+)$/', $last, $m) === 1) {
            $n = (int) $m[1] + 1;
        }

        return sprintf('PRJ-%04d', $n);
    }

    /**
     * Timer access is deliberately stricter than normal project visibility:
     * regular users must be explicit project members whose role is not viewer.
     * Admins are exempt from every permission restriction here: no membership is
     * needed and a viewer assignment does not block them. Status/start-date rules
     * are enforced separately in TimeTrackingRules::assertCanTrack().
     */
    public function userCanTrack(array $project, int $userId, bool $viewAll): bool
    {
        if (TimeTrackingRules::isAdmin($userId)) {
            return true;
        }

        $role = (new ProjectMember())->roleFor((int) $project['id'], $userId);
        if ($role === ProjectMember::ROLE_VIEWER) {
            return false;
        }

        if ($viewAll) {
            return true;
        }

        return $role !== null;
    }

    public function userCanView(array $project, int $userId, bool $viewAll): bool
    {
        if ($viewAll) {
            return true;
        }

        if ((int) ($project['manager_id'] ?? 0) === $userId || (int) ($project['created_by'] ?? 0) === $userId) {
            return true;
        }

        // Public projects (Access tab > Visibility) are open to everyone.
        if (!empty($project['is_public'])) {
            return true;
        }

        return (new ProjectMember())->isMember((int) $project['id'], $userId);
    }

    public function userCanManage(array $project, int $userId, bool $isAdmin): bool
    {
        if ($isAdmin) {
            return true;
        }

        return (int) ($project['manager_id'] ?? 0) === $userId;
    }

    public function archive(int $id): int
    {
        return Database::execute(
            "UPDATE projects SET status = 'Archived', updated_at = UTC_TIMESTAMP() WHERE id = :id",
            ['id' => $id]
        );
    }

    /**
     * Permanently remove an archived project that has no time entries and no timers.
     * The row is locked and re-checked inside the transaction so a concurrent stop
     * cannot leave billed hours on a deleted project.
     */
    public function deleteIfEmpty(int $id): string
    {
        return Database::transaction(function () use ($id): string {
            $row = Database::fetchOne(
                'SELECT id, name, status, project_code FROM projects WHERE id = :id FOR UPDATE',
                ['id' => $id]
            );
            if ($row === null) {
                return 'missing';
            }
            if ((string) $row['status'] !== self::STATUS_ARCHIVED) {
                return 'not_archived';
            }

            $entries = 0;
            if (class_exists('TimeEntry') && TimeEntry::installed()) {
                $entries = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM time_entries WHERE project_id = :id',
                    ['id' => $id]
                );
            }
            $timers = 0;
            if (class_exists('Timer') && Timer::installed()) {
                $timers = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM active_timers WHERE project_id = :id',
                    ['id' => $id]
                );
            }
            if ($entries > 0 || $timers > 0) {
                return 'has_time';
            }

            Database::execute('DELETE FROM projects WHERE id = :id', ['id' => $id]);

            return 'deleted';
        });
    }

    /**
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function accessClause(int $userId, bool $viewAll): array
    {
        if (ClientScope::isClient($userId)) {
            return ClientScope::projectClause('p');
        }

        if ($viewAll) {
            return ['1 = 1', []];
        }

        $public = self::extrasReady() ? ' OR p.is_public = 1' : '';

        return [
            '(p.manager_id = :uid_manager OR p.created_by = :uid_creator OR EXISTS (
                SELECT 1 FROM project_members pm
                WHERE pm.project_id = p.id AND pm.user_id = :uid_member
             )' . $public . ')',
            [
                'uid_manager' => $userId,
                'uid_creator' => $userId,
                'uid_member'  => $userId,
            ],
        ];
    }

    /**
     * @return array<string, int>
     */
    private function tabCounts(int $userId, bool $viewAll, int $clientId, int $managerId, string $search): array
    {
        [$accessSql, $params] = $this->accessClause($userId, $viewAll);
        $where = [$accessSql];

        if ($clientId > 0) {
            $where[]             = 'p.client_id = :client_id';
            $params['client_id'] = $clientId;
        }
        if ($managerId > 0) {
            $where[]              = 'p.manager_id = :manager_id';
            $params['manager_id'] = $managerId;
        }
        if ($search !== '') {
            $term = '%' . self::like($search) . '%';
            $where[] = '(p.name LIKE :q_name OR p.project_code LIKE :q_code OR c.name LIKE :q_client)';
            $params['q_name']    = $term;
            $params['q_code']    = $term;
            $params['q_client']  = $term;
        }

        $whereSql = ' WHERE ' . implode(' AND ', $where);

        $row = Database::fetchOne(
            "SELECT
                SUM(CASE WHEN p.status <> 'Archived' THEN 1 ELSE 0 END) AS all_count,
                SUM(CASE WHEN p.status IN ('Planning','Active','On Hold') THEN 1 ELSE 0 END) AS active_count,
                SUM(CASE WHEN p.status = 'Completed' THEN 1 ELSE 0 END) AS completed_count,
                SUM(CASE WHEN p.status = 'Archived' THEN 1 ELSE 0 END) AS archived_count
             FROM projects p
             INNER JOIN clients c ON c.id = p.client_id
             {$whereSql}",
            $params
        ) ?? [];

        return [
            'all'       => (int) ($row['all_count'] ?? 0),
            'active'    => (int) ($row['active_count'] ?? 0),
            'completed' => (int) ($row['completed_count'] ?? 0),
            'archived'  => (int) ($row['archived_count'] ?? 0),
        ];
    }

    /**
     * @param list<array<string, mixed>> $items
     * @return list<array<string, mixed>>
     */
    private function attachTotals(array $items): array
    {
        if ($items === []) {
            return $items;
        }

        $tracked  = [];
        $billable = [];

        if ($this->timeEntriesExist()) {
            $ids = array_map(static fn (array $row): int => (int) $row['id'], $items);
            $placeholders = [];
            $params = [];
            foreach ($ids as $i => $id) {
                $key = 'p' . $i;
                $placeholders[] = ':' . $key;
                $params[$key] = $id;
            }

            $rows = Database::fetchAll(
                'SELECT project_id,
                        COALESCE(SUM(duration_seconds), 0) AS tracked_seconds,
                        COALESCE(SUM(CASE WHEN is_billable = 1 THEN duration_seconds ELSE 0 END), 0) AS billable_seconds
                 FROM time_entries
                 WHERE project_id IN (' . implode(',', $placeholders) . ')
                 GROUP BY project_id',
                $params
            );

            foreach ($rows as $row) {
                $pid = (int) $row['project_id'];
                $tracked[$pid]  = ((int) $row['tracked_seconds']) / 3600;
                $billable[$pid] = ((int) $row['billable_seconds']) / 3600;
            }
        }

        foreach ($items as &$item) {
            $id        = (int) $item['id'];
            $estimated = (float) $item['estimated_hours'];
            $rate      = (float) $item['hourly_rate'];
            $th        = $tracked[$id] ?? 0.0;
            $bh        = $billable[$id] ?? 0.0;

            $item['tracked_hours']  = round($th, 2);
            $item['billable_hours'] = round($bh, 2);
            $item['budget_used']    = ((int) $item['is_billable'] === 1) ? round($bh * $rate, 2) : 0.0;
            $item['progress']       = $estimated > 0 ? (int) min(100, round(($th / $estimated) * 100)) : 0;
        }
        unset($item);

        return $items;
    }

    private function timeEntriesExist(): bool
    {
        return SchemaHelper::tableExists('time_entries');
    }

    private static function like(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value);
    }
}
