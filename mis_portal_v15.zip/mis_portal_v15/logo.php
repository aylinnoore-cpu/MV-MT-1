<?php require __DIR__.'/includes/lib.php';
$d=q('SELECT * FROM documents WHERE kind="logo" ORDER BY id DESC LIMIT 1')->fetch();
if(!$d||!is_file(ST.$d['stored'])){http_response_code(404);exit;}
header('Content-Type: '.$d['mime']);header('X-Content-Type-Options: nosniff');header('Cache-Control: public, max-age=86400');readfile(ST.$d['stored']);
