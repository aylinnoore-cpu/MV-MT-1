<?php
/**
 * Requires a logged-in, still-active user.
 *
 * SECURITY: the session only proves identity. Role and status are re-read from the
 * database on every request, so a deactivated account or a role change takes effect
 * immediately instead of lasting until the session expires. Cost: one primary-key lookup.
 *
 * Expects the users table (Phase 2) to provide: id, name, email, role, status, timezone.
 */

declare(strict_types=1);

final class AuthMiddleware
{
    public function handle(): void
    {
        $userId = AuthHelper::id();

        if ($userId === null) {
            throw new HttpException(401);
        }

        $row = Database::fetchOne(
            'SELECT id, name, email, role, status, timezone FROM users WHERE id = :id LIMIT 1',
            ['id' => $userId]
        );

        if ($row === null || $row['status'] !== 'active') {
            LoggerHelper::warning('Blocked request from missing or inactive account', ['user_id' => $userId]);
            AuthHelper::logout();

            throw new HttpException(401);
        }

        AuthHelper::syncFromDatabase($row);
    }
}
