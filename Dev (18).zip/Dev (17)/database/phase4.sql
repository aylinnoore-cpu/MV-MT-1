-- =====================================================================
--  TimeTrack: Phase 4 schema + sample planned schedules
--  Run AFTER Phase 1 and Phase 2 on an existing database.
--  Safe to re-run: tables use IF NOT EXISTS; sample rows are skipped
--  when they already exist.
--
--      mysql -u USER -p DATABASE < database/phase4.sql
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `schedules` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id`      INT UNSIGNED NOT NULL,
    `task_id`         INT UNSIGNED NULL,
    `user_id`         INT UNSIGNED NOT NULL,
    `start_datetime`  DATETIME     NOT NULL,
    `end_datetime`    DATETIME     NOT NULL,
    `estimated_hours` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    `status`          ENUM('Scheduled','In Progress','Completed','Missed','Cancelled','Rescheduled') NOT NULL DEFAULT 'Scheduled',
    `notes`           TEXT         NULL,
    `created_by`      INT UNSIGNED NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_schedules_user_time` (`user_id`, `start_datetime`, `end_datetime`),
    KEY `idx_schedules_project` (`project_id`),
    KEY `idx_schedules_task` (`task_id`),
    KEY `idx_schedules_status` (`status`),
    KEY `idx_schedules_created_by` (`created_by`),
    CONSTRAINT `fk_schedules_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_schedules_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_schedules_created_by`
        FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `schedule_recurrences` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `schedule_id`     INT UNSIGNED NOT NULL,
    `recurrence_type` ENUM('daily','weekly','weekdays','custom') NOT NULL DEFAULT 'weekly',
    `repeat_until`    DATE         NULL,
    `days_of_week`    VARCHAR(20)  NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_recurrence_schedule` (`schedule_id`),
    CONSTRAINT `fk_recurrence_schedule`
        FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
    ('schedule.view',      'View schedule',       'schedule', 'See planned work on assigned projects.'),
    ('schedule.create',    'Create schedule',     'schedule', 'Add planned work blocks.'),
    ('schedule.edit',      'Edit schedule',       'schedule', 'Change planned work blocks.'),
    ('schedule.delete',    'Delete schedule',     'schedule', 'Remove planned work blocks.'),
    ('schedule.view_team', 'View team schedule',  'schedule', 'See planned work for the whole team.')
ON DUPLICATE KEY UPDATE
    `display_name` = VALUES(`display_name`),
    `module`       = VALUES(`module`),
    `description`  = VALUES(`description`);

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, `id` FROM `permissions` WHERE `name` LIKE 'schedule.%';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, `id` FROM `permissions` WHERE `name` IN (
    'schedule.view', 'schedule.create', 'schedule.edit', 'schedule.delete', 'schedule.view_team'
);

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 3, `id` FROM `permissions` WHERE `name` IN (
    'schedule.view', 'schedule.create', 'schedule.edit'
);

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 4, `id` FROM `permissions` WHERE `name` IN ('schedule.view');

INSERT INTO `schedules` (
    `project_id`, `user_id`, `start_datetime`, `end_datetime`, `estimated_hours`,
    `status`, `notes`, `created_by`
)
SELECT p.`id`, u.`id`,
       DATE_ADD(UTC_DATE(), INTERVAL 9 HOUR),
       DATE_ADD(UTC_DATE(), INTERVAL 12 HOUR),
       3.00, 'Scheduled', 'Homepage layout and CMS mapping.',
       (SELECT `id` FROM `users` WHERE `email` = 'manager@timetrack.local' LIMIT 1)
FROM `projects` p
INNER JOIN `users` u ON u.`email` = 'john@timetrack.local'
WHERE p.`project_code` = 'PRJ-0001'
  AND NOT EXISTS (
      SELECT 1 FROM `schedules` s
      WHERE s.`project_id` = p.`id` AND s.`user_id` = u.`id`
        AND s.`start_datetime` = DATE_ADD(UTC_DATE(), INTERVAL 9 HOUR)
  );

INSERT INTO `schedules` (
    `project_id`, `user_id`, `start_datetime`, `end_datetime`, `estimated_hours`,
    `status`, `notes`, `created_by`
)
SELECT p.`id`, u.`id`,
       DATE_ADD(UTC_DATE(), INTERVAL 13 HOUR),
       DATE_ADD(UTC_DATE(), INTERVAL 16 HOUR),
       3.00, 'Scheduled', 'Mobile navigation prototype.',
       (SELECT `id` FROM `users` WHERE `email` = 'manager@timetrack.local' LIMIT 1)
FROM `projects` p
INNER JOIN `users` u ON u.`email` = 'john@timetrack.local'
WHERE p.`project_code` = 'PRJ-0002'
  AND NOT EXISTS (
      SELECT 1 FROM `schedules` s
      WHERE s.`project_id` = p.`id` AND s.`user_id` = u.`id`
        AND s.`start_datetime` = DATE_ADD(UTC_DATE(), INTERVAL 13 HOUR)
  );

INSERT INTO `schedules` (
    `project_id`, `user_id`, `start_datetime`, `end_datetime`, `estimated_hours`,
    `status`, `notes`, `created_by`
)
SELECT p.`id`, u.`id`,
       DATE_ADD(UTC_DATE(), INTERVAL 10 HOUR),
       DATE_ADD(UTC_DATE(), INTERVAL 14 HOUR),
       4.00, 'In Progress', 'Visual system and template polish.',
       (SELECT `id` FROM `users` WHERE `email` = 'manager@timetrack.local' LIMIT 1)
FROM `projects` p
INNER JOIN `users` u ON u.`email` = 'sarah@timetrack.local'
WHERE p.`project_code` = 'PRJ-0001'
  AND NOT EXISTS (
      SELECT 1 FROM `schedules` s
      WHERE s.`project_id` = p.`id` AND s.`user_id` = u.`id`
        AND s.`start_datetime` = DATE_ADD(UTC_DATE(), INTERVAL 10 HOUR)
  );

INSERT INTO `schedules` (
    `project_id`, `user_id`, `start_datetime`, `end_datetime`, `estimated_hours`,
    `status`, `notes`, `created_by`
)
SELECT p.`id`, u.`id`,
       DATE_ADD(DATE_ADD(UTC_DATE(), INTERVAL 1 DAY), INTERVAL 9 HOUR),
       DATE_ADD(DATE_ADD(UTC_DATE(), INTERVAL 1 DAY), INTERVAL 12 HOUR),
       3.00, 'Scheduled', 'Planning review with the client.',
       u.`id`
FROM `projects` p
INNER JOIN `users` u ON u.`email` = 'manager@timetrack.local'
WHERE p.`project_code` = 'PRJ-0002'
  AND NOT EXISTS (
      SELECT 1 FROM `schedules` s
      WHERE s.`project_id` = p.`id` AND s.`user_id` = u.`id`
        AND s.`start_datetime` = DATE_ADD(DATE_ADD(UTC_DATE(), INTERVAL 1 DAY), INTERVAL 9 HOUR)
  );
