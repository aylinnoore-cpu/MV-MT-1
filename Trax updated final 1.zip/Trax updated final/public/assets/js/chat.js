(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        var root = document.querySelector('[data-chat-root]');
        if (!root || !window.TT || !window.TT.request) { return; }

        var cfg = {};
        try { cfg = JSON.parse(root.getAttribute('data-config') || '{}'); } catch (e) { cfg = {}; }

        var log = root.querySelector('[data-chat-log]');
        var composer = root.querySelector('[data-chat-composer]');
        var input = root.querySelector('[data-chat-input]');
        var filesInput = root.querySelector('[data-chat-files]');
        var chips = root.querySelector('[data-chat-chips]');
        var errorEl = root.querySelector('[data-chat-error]');
        var mentionBox = root.querySelector('[data-chat-mentions]');
        var olderBtn = root.querySelector('[data-chat-older]');
        var members = Array.isArray(cfg.members) ? cfg.members : [];
        var maxId = parseInt(cfg.maxId, 10) || 0;
        var conversationId = parseInt(cfg.conversationId, 10) || 0;
        var pollTimer = null;
        var sending = false;
        var loadingOlder = false;
        var hasMore = true;

        function appUrl(path) {
            var base = (window.TT && window.TT.baseUrl ? String(window.TT.baseUrl).replace(/\/$/, '') : '');
            return base + '/' + String(path || '').replace(/^\//, '');
        }

        function showError(text) {
            if (!errorEl) { return; }
            errorEl.hidden = !text;
            errorEl.textContent = text || '';
        }

        function setBadge(count) {
            count = Math.max(0, parseInt(count, 10) || 0);
            document.querySelectorAll('[data-chat-badge]').forEach(function (badge) {
                badge.hidden = count < 1;
                badge.textContent = count > 9 ? '9+' : String(count);
            });
        }

        function scrollBottom(force) {
            if (!log) { return; }
            var near = log.scrollHeight - log.scrollTop - log.clientHeight < 120;
            if (force || near) { log.scrollTop = log.scrollHeight; }
        }

        function escapeHtml(value) {
            return String(value == null ? '' : value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        }

        function formatBody(body) {
            var escaped = escapeHtml(body).replace(/\n/g, '<br>');
            escaped = escaped.replace(/(^|\s)@(all|everyone|team|members)\b/gi, '$1<span class="chat-mention">@$2</span>');
            escaped = escaped.replace(/(^|\s)@([A-Za-z0-9_]+)/g, '$1<span class="chat-mention">@$2</span>');
            return escaped;
        }

        function renderAttachments(list) {
            if (!list || !list.length) { return ''; }
            return '<div class="chat-files">' + list.map(function (file) {
                if (file.preview) {
                    return '<a class="chat-file-preview" href="' + escapeHtml(file.url) + '" target="_blank" rel="noopener"><img src="' + escapeHtml(file.url) + '" alt="' + escapeHtml(file.name) + '"></a>';
                }
                return '<a class="chat-file" href="' + escapeHtml(file.url) + '">' + escapeHtml(file.name) + ' <span>' + escapeHtml(file.size_label || '') + '</span></a>';
            }).join('') + '</div>';
        }

        function renderMessage(msg, prepend) {
            if (!log || !msg || !msg.id) { return; }
            if (log.querySelector('[data-message-id="' + msg.id + '"]')) { return; }
            var mine = parseInt(msg.user_id, 10) === parseInt(cfg.userId, 10);
            var deleted = !!msg.deleted;
            var article = document.createElement('article');
            article.className = 'chat-msg' + (mine ? ' is-mine' : '') + (deleted ? ' is-deleted' : '');
            article.setAttribute('data-message-id', String(msg.id));
            article.setAttribute('data-user-id', String(msg.user_id || 0));
            var actions = '';
            if (!deleted) {
                actions = '<div class="chat-msg-actions">';
                if (mine) { actions += '<button type="button" class="btn btn-link btn-sm p-0" data-chat-edit>Edit</button>'; }
                if (cfg.canManage) { actions += '<button type="button" class="btn btn-link btn-sm p-0 text-danger" data-chat-delete>Delete</button>'; }
                if (cfg.canCreateTask) { actions += '<button type="button" class="btn btn-link btn-sm p-0" data-chat-task data-body="' + escapeHtml(msg.body || '') + '">Create task</button>'; }
                actions += '</div>';
            }
            article.innerHTML =
                (msg.avatar_html || '') +
                '<div class="chat-msg-main"><div class="chat-msg-meta"><strong>' + escapeHtml(msg.user_name) + '</strong><time>' + escapeHtml(msg.created || '') + '</time>' +
                (msg.edited ? '<span class="chat-edited">edited</span>' : '') +
                '</div><div class="chat-msg-body" data-chat-body>' + (deleted ? '<em>This message was deleted.</em>' : (msg.body_html || formatBody(msg.body || ''))) + '</div>' +
                (msg.task_name ? (msg.task_url ? '<a class="chat-task-link" href="' + escapeHtml(msg.task_url) + '">' + escapeHtml(msg.task_name) + '</a>' : '<span class="chat-task-link">' + escapeHtml(msg.task_name) + '</span>') : '') +
                renderAttachments(msg.attachments) + actions + '</div>';
            if (prepend) {
                var first = log.querySelector('.chat-msg');
                if (first) { log.insertBefore(article, first); } else { log.appendChild(article); }
            } else {
                log.appendChild(article);
            }
        }

        function poll() {
            if (!cfg.pollUrl) { return; }
            var url = cfg.pollUrl + '?c=' + encodeURIComponent(conversationId) + '&since_id=' + encodeURIComponent(maxId);
            window.TT.request(url, { headers: { Accept: 'application/json' } }).then(function (res) {
                if (!res.ok || !res.data) { return; }
                setBadge(res.data.unread);
                (res.data.messages || []).forEach(function (msg) {
                    renderMessage(msg, false);
                    if (msg.id > maxId) { maxId = msg.id; }
                });
                if ((res.data.messages || []).length) { scrollBottom(false); }
                if (res.data.max_id && res.data.max_id > maxId) { maxId = res.data.max_id; }
            });
        }

        function schedulePoll() {
            if (pollTimer) { clearInterval(pollTimer); }
            var ms = document.hidden ? 30000 : 5000;
            pollTimer = setInterval(poll, ms);
        }

        document.addEventListener('visibilitychange', schedulePoll);
        schedulePoll();
        if (log) { scrollBottom(true); if (olderBtn && log.querySelectorAll('.chat-msg').length >= 50) { olderBtn.hidden = false; } }

        if (olderBtn) {
            olderBtn.addEventListener('click', function () {
                if (loadingOlder || !cfg.historyUrl) { return; }
                var first = log && log.querySelector('.chat-msg');
                var before = first ? first.getAttribute('data-message-id') : '';
                if (!before) { return; }
                loadingOlder = true;
                window.TT.request(cfg.historyUrl + '?before_id=' + encodeURIComponent(before), { headers: { Accept: 'application/json' } }).then(function (res) {
                    loadingOlder = false;
                    if (!res.ok || !res.data) { return; }
                    var rows = res.data.messages || [];
                    var prevHeight = log.scrollHeight;
                    rows.forEach(function (msg) { renderMessage(msg, true); });
                    log.scrollTop = log.scrollHeight - prevHeight;
                    hasMore = !!res.data.has_more;
                    olderBtn.hidden = !hasMore;
                });
            });
        }

        if (composer && input) {
            composer.addEventListener('submit', function (event) {
                event.preventDefault();
                if (sending || !cfg.sendUrl) { return; }
                var body = (input.value || '').trim();
                var files = filesInput && filesInput.files ? filesInput.files : [];
                if (!body && files.length < 1) { showError('Write a message or attach a file.'); return; }
                if (files.length > (cfg.filesPerMessage || 10)) { showError('Too many files.'); return; }
                sending = true;
                showError('');
                var data = new FormData();
                data.append('body', body);
                Array.prototype.forEach.call(files, function (file) { data.append('files[]', file); });
                window.TT.request(cfg.sendUrl, { method: 'POST', body: data, headers: { Accept: 'application/json' } }).then(function (res) {
                    sending = false;
                    if (!res.ok) {
                        showError((res.data && res.data.error && res.data.error.message) || window.TT.errorMessage(res.status, res.message));
                        return;
                    }
                    if (res.data && res.data.message) {
                        renderMessage(res.data.message, false);
                        if (res.data.message.id > maxId) { maxId = res.data.message.id; }
                        scrollBottom(true);
                    }
                    if (res.data && res.data.notice) { showError(res.data.notice); }
                    input.value = '';
                    input.style.height = '';
                    if (filesInput) { filesInput.value = ''; }
                    if (chips) { chips.innerHTML = ''; }
                });
            });

            input.addEventListener('input', function () {
                input.style.height = 'auto';
                input.style.height = Math.min(input.scrollHeight, 160) + 'px';
                updateMentions();
            });

            input.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' && !event.shiftKey) {
                    event.preventDefault();
                    composer.requestSubmit();
                }
            });
        }

        if (filesInput && chips) {
            filesInput.addEventListener('change', function () {
                chips.innerHTML = '';
                Array.prototype.forEach.call(filesInput.files || [], function (file) {
                    var chip = document.createElement('span');
                    chip.className = 'chat-chip';
                    chip.textContent = file.name;
                    chips.appendChild(chip);
                });
            });
        }

        function currentMention() {
            if (!input) { return null; }
            var value = input.value;
            var start = input.selectionStart || value.length;
            var before = value.slice(0, start);
            var match = before.match(/@([A-Za-z0-9_]*)$/);
            if (!match) { return null; }
            return { token: match[1].toLowerCase(), start: start - match[0].length, end: start };
        }

        function updateMentions() {
            if (!mentionBox) { return; }
            var ctx = currentMention();
            if (!ctx) { mentionBox.hidden = true; mentionBox.innerHTML = ''; return; }
            var hits = members.filter(function (m) {
                return String(m.handle || '').toLowerCase().indexOf(ctx.token) === 0 || String(m.name || '').toLowerCase().indexOf(ctx.token) !== -1;
            }).slice(0, 8);
            var extras = ['all', 'everyone', 'team', 'members'].filter(function (alias) {
                return alias.indexOf(ctx.token) === 0;
            });
            mentionBox.innerHTML = extras.map(function (alias) {
                return '<button type="button" class="chat-mention-item" data-handle="' + alias + '">@' + alias + '</button>';
            }).join('') + hits.map(function (m) {
                return '<button type="button" class="chat-mention-item" data-handle="' + escapeHtml(m.handle) + '">@' + escapeHtml(m.handle) + ' <span>' + escapeHtml(m.name) + '</span></button>';
            }).join('');
            mentionBox.hidden = mentionBox.childNodes.length < 1;
        }

        if (mentionBox) {
            mentionBox.addEventListener('click', function (event) {
                var btn = event.target.closest('[data-handle]');
                if (!btn || !input) { return; }
                var ctx = currentMention();
                if (!ctx) { return; }
                var handle = btn.getAttribute('data-handle') || '';
                input.value = input.value.slice(0, ctx.start) + '@' + handle + ' ' + input.value.slice(ctx.end);
                mentionBox.hidden = true;
                input.focus();
            });
        }

        if (log) {
            log.addEventListener('click', function (event) {
                var editBtn = event.target.closest('[data-chat-edit]');
                var delBtn = event.target.closest('[data-chat-delete]');
                var taskBtn = event.target.closest('[data-chat-task]');
                var msg = event.target.closest('[data-message-id]');
                if (!msg) { return; }
                var id = msg.getAttribute('data-message-id');
                if (editBtn) {
                    var bodyEl = msg.querySelector('[data-chat-body]');
                    var next = window.prompt('Edit message', (bodyEl && bodyEl.innerText) || '');
                    if (next == null) { return; }
                    next = next.trim();
                    if (!next) { return; }
                    window.TT.request(appUrl('/chat/conversations/' + conversationId + '/messages/' + id + '/edit'), {
                        method: 'POST',
                        headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'body=' + encodeURIComponent(next)
                    }).then(function (res) {
                        if (res.ok && res.data && res.data.message && bodyEl) {
                            bodyEl.innerHTML = res.data.message.body_html || formatBody(res.data.message.body || next);
                        }
                    });
                }
                if (delBtn && window.confirm('Delete this message?')) {
                    window.TT.request(appUrl('/chat/conversations/' + conversationId + '/messages/' + id + '/delete'), {
                        method: 'POST',
                        headers: { Accept: 'application/json' }
                    }).then(function (res) {
                        if (res.ok) {
                            msg.classList.add('is-deleted');
                            var bodyEl = msg.querySelector('[data-chat-body]');
                            if (bodyEl) { bodyEl.innerHTML = '<em>This message was deleted.</em>'; }
                        }
                    });
                }
                if (taskBtn) {
                    var modalEl = document.getElementById('chatTaskModal');
                    var name = document.getElementById('chat_task_name');
                    var desc = document.getElementById('chat_task_description');
                    var text = taskBtn.getAttribute('data-body') || '';
                    if (name) { name.value = text.slice(0, 160); }
                    if (desc) { desc.value = text; }
                    if (modalEl && window.bootstrap) { window.bootstrap.Modal.getOrCreateInstance(modalEl).show(); }
                }
            });
        }

        var dmForm = document.querySelector('[data-chat-dm]');
        if (dmForm) {
            dmForm.addEventListener('submit', function (event) {
                event.preventDefault();
                var userId = dmForm.querySelector('[name="user_id"]');
                if (!userId || !userId.value) { return; }
                var data = new FormData();
                data.append('user_id', userId.value);
                window.TT.request(cfg.dmUrl, { method: 'POST', body: data, headers: { Accept: 'application/json' } }).then(function (res) {
                    if (res.ok && res.data && res.data.url) { window.location.href = res.data.url; }
                });
            });
        }

        var channelForm = document.querySelector('[data-chat-channel]');
        if (channelForm) {
            channelForm.addEventListener('submit', function (event) {
                event.preventDefault();
                window.TT.request(cfg.channelUrl, { method: 'POST', body: new FormData(channelForm), headers: { Accept: 'application/json' } }).then(function (res) {
                    if (res.ok && res.data && res.data.url) { window.location.href = res.data.url; }
                });
            });
        }

        var taskForm = document.querySelector('[data-chat-task-form]');
        var taskProject = document.querySelector('[data-chat-task-project]');
        if (taskForm && taskProject) {
            taskProject.addEventListener('change', function () {
                taskForm.setAttribute('action', appUrl('/projects/' + taskProject.value + '/tasks'));
            });
        }
    });
})();
