<?php
/**
 * AJAX endpoints for the notification bell (Phase 9).
 *
 * Every method operates only on the signed-in user's own notifications; the
 * user_id guard lives in SQL, so an attacker cannot mark someone else's row read
 * even by guessing an id.
 */

declare(strict_types=1);

final class NotificationController extends Controller
{
    public function __construct()
    {
        parent::__construct(true); // any authenticated role
        PermissionHelper::require('notifications.view');
    }

    /**
     * GET /notifications : the full notifications page (All / Unread tabs, type filter, pagination).
     *
     * Database failures are deliberately not caught here. A swallowed error would show an empty
     * list ("you are all caught up") when the truth is "we could not load them". Letting it
     * propagate means the Router answers 503 with a Try again button.
     */
    public function index(Request $request, array $params): void
    {
        $userId = (int) AuthHelper::id();

        // Allow-list every filter value; anything unexpected falls back to the default.
        $filter = (string) $request->input('filter', 'all') === 'unread' ? 'unread' : 'all';
        $type   = (string) $request->input('type', '');
        $type   = in_array($type, Notification::TYPES, true) ? $type : '';
        $page   = max(1, (int) $request->input('page', 1));

        $installed = Notification::installed();
        $model     = new Notification();

        $result = $installed
            ? $model->paginateFor($userId, $page, 20, $filter, $type)
            : ['items' => [], 'total' => 0, 'page' => 1, 'per_page' => 20, 'pages' => 1];
        $counts = $installed ? $model->counts($userId) : ['total' => 0, 'unread' => 0];

        $this->render('notifications/index', [
            'pageTitle'          => 'Notifications',
            'notificationAssets' => true,
            'installed'          => $installed,
            'result'             => $result,
            'counts'             => $counts,
            'filter'             => $filter,
            'type'               => $type,
        ]);
    }

    /** GET /notifications/unread : header dropdown payload. */
    public function getUnread(Request $request, array $params): void
    {
        $userId = (int) AuthHelper::id();

        if (!Notification::installed()) {
            $this->json(['ok' => true, 'unread' => 0, 'items' => []]);
        }

        $model = new Notification();

        $items = array_map(
            static fn (array $n): array => [
                'id'        => (int) $n['id'],
                'type'      => (string) $n['type'],
                'title'     => (string) $n['title'],
                'message'   => (string) ($n['message'] ?? ''),
                'link'      => (string) ($n['link'] ?? ''),
                'href'      => Notification::href((string) ($n['link'] ?? '')) ?: FormatHelper::url('/notifications'),
                'is_read'   => (bool) $n['is_read'],
                'created'   => FormatHelper::datetime((string) $n['created_at'], 'M j, H:i'),
            ],
            $model->recent($userId, 8)
        );

        // Read-only endpoint: release the session lock before the response.
        AuthHelper::releaseSession();

        $this->json([
            'ok'     => true,
            'unread' => $model->unreadCount($userId),
            'items'  => $items,
        ]);
    }

    /** POST /notifications/{id}/read */
    public function markAsRead(Request $request, array $params): void
    {
        $id     = (int) ($params['id'] ?? 0);
        $userId = (int) AuthHelper::id();
        $model  = new Notification();

        $ok = $id > 0 && $model->markRead($id, $userId);

        // Plain form post (JavaScript off): go back to the page the person was on.
        if (!$request->wantsJson()) {
            $this->redirect($this->returnPath($request));
        }

        $this->json([
            'ok'     => true,
            'changed' => $ok,
            'unread' => $model->unreadCount($userId),
        ]);
    }

    /** POST /notifications/read-all */
    public function markAllAsRead(Request $request, array $params): void
    {
        $userId = (int) AuthHelper::id();
        $model  = new Notification();

        $changed = $model->markAllRead($userId);

        if (!$request->wantsJson()) {
            $this->flash('success', $changed > 0 ? 'All notifications marked as read.' : 'You have no unread notifications.');
            $this->redirect($this->returnPath($request));
        }

        $this->json(['ok' => true, 'changed' => $changed, 'unread' => 0]);
    }

    /**
     * Where a non-AJAX read action returns to. SECURITY: only /notifications with a plain query
     * string is accepted, so the hidden "return" field can never become an open redirect.
     */
    private function returnPath(Request $request): string
    {
        $return = (string) $request->input('return', '');

        return preg_match('#^/notifications(\?[A-Za-z0-9=&_%.\-]*)?$#D', $return) === 1
            ? $return
            : '/notifications';
    }
}
