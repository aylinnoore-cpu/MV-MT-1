<?php
/**
 * Team directory with weekly workload (Phase 14).
 *
 * @var list<array<string, mixed>>  $rows
 * @var array<string, mixed>        $summary
 * @var array<string, mixed>        $filters         q, role, status, project, sort
 * @var list<array<string, mixed>>  $projectOptions
 * @var DateTimeImmutable           $weekStart
 * @var DateTimeImmutable           $weekEnd
 * @var string                      $prevWeek
 * @var string                      $nextWeek
 * @var bool                        $isThisWeek
 * @var float                       $capacityHours   weekly capacity per person
 * @var bool                        $planning        scheduling on: bar shows planned time, else tracked
 * @var bool                        $canWorkload     may see other people's workload
 * @var int                         $viewerId
 */

$hours = static fn (int $seconds): string => number_format($seconds / 3600, 1);

// Keep the current filters when moving between weeks or changing the sort.
$link = static function (array $extra = []) use ($filters, $weekStart): string {
    $params = array_merge([
        'q'       => $filters['q'],
        'role'    => $filters['role'],
        'status'  => $filters['status'] !== 'active' ? $filters['status'] : '',
        'project' => $filters['project'] ?: '',
        'sort'    => $filters['sort'] !== 'name' ? $filters['sort'] : '',
        'week'    => '',
    ], $extra);
    $params = array_filter($params, static fn ($v): bool => $v !== '' && $v !== null);

    return url('/team') . ($params === [] ? '' : '?' . http_build_query($params));
};

$weekEndShown = $weekEnd->modify('-1 day');
$weekLabel    = $weekStart->format('M j') . ' – ' . $weekEndShown->format('M j, Y');
$barBasis     = $planning ? 'planned' : 'tracked';
$maxChips     = 3;

require __DIR__ . '/_styles.php';
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Team</h2>
        <p class="page-lead">Members, roles, the projects each person is on and their workload for the week.</p>
    </div>
    <div class="tm-week" role="group" aria-label="Choose week">
        <a class="btn btn-outline-secondary" href="<?= e($link(['week' => $prevWeek])) ?>" aria-label="Previous week"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></a>
        <span class="tm-week-label"><?= e($weekLabel) ?></span>
        <a class="btn btn-outline-secondary" href="<?= e($link(['week' => $nextWeek])) ?>" aria-label="Next week"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a>
        <?php if (!$isThisWeek): ?>
            <a class="btn btn-outline-secondary" href="<?= e($link()) ?>">This week</a>
        <?php endif; ?>
    </div>
</div>

<div class="kpi-grid mb-4">
    <article class="kpi-card">
        <p class="kpi-label">Team members</p>
        <p class="kpi-value"><?= (int) $summary['members'] ?></p>
        <p class="kpi-sub"><?= $filters['status'] === 'all' ? 'all statuses' : e($filters['status']) ?></p>
    </article>
    <?php if ($canWorkload && $summary['counted'] > 0): ?>
        <article class="kpi-card">
            <p class="kpi-label"><?= $planning ? 'Planned this week' : 'Tracked this week' ?></p>
            <p class="kpi-value"><?= e($hours($planning ? (int) $summary['planned'] : (int) $summary['tracked'])) ?>h</p>
            <p class="kpi-sub"><?= $planning ? e($hours((int) $summary['tracked'])) . 'h tracked so far' : 'time entries starting this week' ?></p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Average load</p>
            <p class="kpi-value"><?= (int) $summary['avg_percent'] ?>%</p>
            <p class="kpi-sub">of <?= e(rtrim(rtrim(number_format($capacityHours, 1), '0'), '.')) ?>h weekly capacity</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Over capacity</p>
            <p class="kpi-value"><?= (int) $summary['over'] ?></p>
            <p class="kpi-sub"><?= (int) $summary['available'] ?> with room for more</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Overdue tasks</p>
            <p class="kpi-value"><?= (int) $summary['overdue'] ?></p>
            <p class="kpi-sub">assigned to the people listed</p>
        </article>
    <?php endif; ?>
</div>

<form method="get" action="<?= e(url('/team')) ?>" class="filter-bar">
    <input type="hidden" name="week" value="<?= e($weekStart->format('Y-m-d')) ?>">
    <div class="filter-search">
        <label for="team-q" class="visually-hidden">Search team</label>
        <input type="search" id="team-q" name="q" class="form-control" placeholder="Search name, email or job title" value="<?= e($filters['q']) ?>">
    </div>
    <div>
        <label for="team-role" class="visually-hidden">Role</label>
        <select id="team-role" name="role" class="form-select">
            <option value="">All roles</option>
            <?php foreach (['admin', 'manager', 'employee'] as $role): ?>
                <option value="<?= e($role) ?>"<?= $filters['role'] === $role ? ' selected' : '' ?>><?= e(ucfirst($role)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="team-project" class="visually-hidden">Project</label>
        <select id="team-project" name="project" class="form-select">
            <option value="">All projects</option>
            <?php foreach ($projectOptions as $project): ?>
                <option value="<?= (int) $project['id'] ?>"<?= (int) $filters['project'] === (int) $project['id'] ? ' selected' : '' ?>><?= e($project['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="team-status" class="visually-hidden">Status</label>
        <select id="team-status" name="status" class="form-select">
            <?php foreach (['active' => 'Active', 'inactive' => 'Inactive', 'suspended' => 'Suspended', 'all' => 'All statuses'] as $value => $label): ?>
                <option value="<?= e($value) ?>"<?= $filters['status'] === $value ? ' selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="team-sort" class="visually-hidden">Sort by</label>
        <select id="team-sort" name="sort" class="form-select">
            <?php foreach (['name' => 'Sort: name', 'load' => 'Sort: heaviest load', 'projects' => 'Sort: most projects'] as $value => $label): ?>
                <option value="<?= e($value) ?>"<?= $filters['sort'] === $value ? ' selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Apply</button>
</form>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">People <span class="count-pill"><?= count($rows) ?></span></h2>
        <?php if (!$canWorkload): ?>
            <span class="tm-muted small">Workload is shown for you only.</span>
        <?php endif; ?>
    </div>

    <?php if ($rows === []): ?>
        <div class="empty-state">
            <i class="fa-solid fa-users" aria-hidden="true"></i>
            <p>No team members match these filters.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table table-stack mb-0">
                <thead>
                    <tr>
                        <th>Member</th>
                        <th>Role</th>
                        <th>Projects</th>
                        <th>Tracked today</th>
                        <th>Workload (<?= e($barBasis) ?>)</th>
                        <th>Open tasks</th>
                        <th class="text-end"><span class="visually-hidden">Actions</span></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row): ?>
                        <?php
                        $uid     = (int) $row['id'];
                        $initial = mb_strtoupper(mb_substr((string) $row['name'], 0, 1, 'UTF-8'), 'UTF-8');
                        $profile = url('/team/' . $uid);
                        $projs   = $row['projects'];
                        ?>
                        <tr>
                            <td data-label="Member">
                                <div class="tm-person">
                                    <span class="avatar avatar-sm" aria-hidden="true"><?= e($initial) ?></span>
                                    <span>
                                        <a class="tm-name" href="<?= e($profile) ?>"><?= e($row['name']) ?><?= $uid === $viewerId ? ' (you)' : '' ?></a>
                                        <span class="tm-sub"><?= e($row['job_title'] ?: $row['email']) ?></span>
                                        <?php if ($row['status'] !== 'active'): ?>
                                            <span class="tm-sub"><?= e(ucfirst((string) $row['status'])) ?></span>
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </td>
                            <td data-label="Role"><span class="role-pill role-<?= e(strtolower((string) $row['role'])) ?>"><?= e($row['role_name']) ?></span></td>
                            <td data-label="Projects">
                                <?php if ($projs === []): ?>
                                    <span class="tm-muted">No open projects</span>
                                <?php else: ?>
                                    <div class="tm-chips">
                                        <?php foreach (array_slice($projs, 0, $maxChips) as $project): ?>
                                            <a class="tm-chip<?= $project['project_role'] === 'manager' ? ' is-manager' : '' ?>"
                                               href="<?= e(url('/projects/' . (int) $project['project_id'])) ?>"
                                               title="<?= e($project['name'] . ' · ' . ucfirst((string) $project['project_role'])) ?>">
                                                <span class="tm-dot"<?= !empty($project['color']) && preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) $project['color']) ? ' style="background:' . e($project['color']) . '"' : '' ?>></span>
                                                <?= e($project['project_code'] ?: $project['name']) ?>
                                            </a>
                                        <?php endforeach; ?>
                                        <?php if (count($projs) > $maxChips): ?>
                                            <a class="tm-chip-more" href="<?= e($profile) ?>">+<?= count($projs) - $maxChips ?> more</a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td data-label="Tracked today">
                                <?php if (!$row['today_shared']): ?>
                                    <span class="tm-muted">Not shared</span>
                                <?php else: ?>
                                    <?= e(FormatHelper::durationShort((int) $row['today_seconds'])) ?>
                                <?php endif; ?>
                            </td>
                            <td data-label="Workload" class="tm-load">
                                <?php if (!$row['has_load']): ?>
                                    <span class="tm-muted">Not shared</span>
                                <?php else: ?>
                                    <div class="tm-load-top">
                                        <span><strong><?= e($hours((int) $row['load_seconds'])) ?></strong> / <?= e(rtrim(rtrim(number_format($capacityHours, 1), '0'), '.')) ?>h
                                            <span class="tm-muted">(<?= (int) $row['load_percent'] ?>%)</span></span>
                                        <span class="tm-state is-<?= e($row['load_state']) ?>"><?= e($row['load_label']) ?></span>
                                    </div>
                                    <div class="tm-bar is-<?= e($row['load_state']) ?>" role="progressbar"
                                         aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?= min(100, (int) $row['load_percent']) ?>"
                                         aria-label="Workload <?= (int) $row['load_percent'] ?> percent of weekly capacity">
                                        <span style="width:<?= min(100, max(0, (int) $row['load_percent'])) ?>%"></span>
                                    </div>
                                    <?php if ($planning): ?>
                                        <span class="tm-sub"><?= e($hours((int) $row['tracked_seconds'])) ?>h tracked<?= (int) $row['blocks'] > 0 ? ' · ' . (int) $row['blocks'] . ' block' . ((int) $row['blocks'] === 1 ? '' : 's') : '' ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td data-label="Open tasks" class="tm-tasks">
                                <?php if (!$row['has_load']): ?>
                                    <span class="tm-muted">–</span>
                                <?php else: ?>
                                    <b><?= (int) $row['open_tasks'] ?></b>
                                    <?php if ((int) $row['overdue'] > 0): ?>
                                        <span class="tm-sub"><b class="is-overdue"><?= (int) $row['overdue'] ?> overdue</b></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td data-label="Actions" class="text-end text-nowrap">
                                <a class="btn btn-sm btn-outline-secondary" href="<?= e($profile . '?week=' . $weekStart->format('Y-m-d')) ?>">View</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<p class="tm-muted small mt-3 mb-0">
    Capacity is the workspace daily capacity times five working days.
    <?= $planning
        ? 'The bar shows planned schedule blocks for the week; tracked time counts entries that started in the week (a running timer is not included until it stops).'
        : 'Scheduling is off, so the bar shows tracked time for the week (a running timer is not included until it stops).' ?>
    <?php if (PermissionHelper::has('projects.view_all')): ?>
        You can see every project, so all hours are included.
    <?php elseif ($canWorkload): ?>
        For other people, hours include only projects you manage or created; your own hours include all your projects.
    <?php else: ?>
        You can see your own hours; other people's hours are visible to managers and admins.
    <?php endif; ?>
</p>
