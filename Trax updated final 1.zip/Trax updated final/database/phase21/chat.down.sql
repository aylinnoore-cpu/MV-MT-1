-- Rollback Phase 21 Chat. Drops chat tables and leaves workspace_settings rows
-- (unknown keys are ignored by SettingsService). Chat files under storage/chat/
-- are not deleted by this script; remove that folder manually if needed.

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `chat_user_preferences`;
DROP TABLE IF EXISTS `message_attachments`;
DROP TABLE IF EXISTS `message_mentions`;
DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `conversation_members`;
DROP TABLE IF EXISTS `conversations`;

SET FOREIGN_KEY_CHECKS = 1;
