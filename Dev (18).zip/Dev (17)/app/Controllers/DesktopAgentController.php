<?php

declare(strict_types=1);

final class DesktopAgentController extends Controller
{
    public function __construct()
    {
        // Not authenticated here: pair() and heartbeat() are called by the Windows agent,
        // which has no browser session. The browser-facing methods authenticate themselves.
        parent::__construct(false);
    }

    private function requireLogin(): void
    {
        (new AuthMiddleware())->handle();
    }

    /** Pairing codes and disconnecting computers are administrator-only. */
    private function requireAdmin(): void
    {
        $this->requireLogin();
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            throw new HttpException(403);
        }
    }

    public function index(Request $request, array $params): void
    {
        $this->requireLogin();
        PermissionHelper::require('time.track');
        $isAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);
        $this->render('agent/index', [
            'pageTitle' => 'Desktop Agent',
            'isAdmin' => $isAdmin,
            'users' => $isAdmin ? DesktopAgent::pairableUsers() : [],
            'devices' => $isAdmin ? DesktopAgent::allWithUsers() : DesktopAgent::forUser((int) AuthHelper::id()),
            'idleEnabled' => WorkspacePolicy::string('idle_detection_enabled', '0') === '1',
            'threshold' => WorkspacePolicy::int('idle_threshold_minutes', 10),
            'warningSeconds' => WorkspacePolicy::int('idle_warning_seconds', 60),
            'pairing' => $isAdmin ? ($_SESSION['_agent_pairing'] ?? null) : null,
        ]);
    }

    public function pairingCode(Request $request, array $params): void
    {
        $this->requireAdmin();
        $targetId = (int) $request->input('user_id', 0);
        $target = null;
        foreach (DesktopAgent::pairableUsers() as $u) {
            if ((int) $u['id'] === $targetId) { $target = $u; break; }
        }
        if ($target === null) {
            $this->flash('danger', 'Choose an active user to pair a computer for.');
            $this->redirect('/agent');
        }
        $pair = DesktopAgent::createPairingCode($targetId);
        $pair['user_name'] = (string) $target['name'];
        $_SESSION['_agent_pairing'] = $pair;
        $this->flash('success', 'Pairing code generated for ' . $target['name'] . '. It expires in 10 minutes.');
        $this->redirect('/agent');
    }

    public function revoke(Request $request, array $params): void
    {
        $this->requireAdmin();
        $id = (int) ($params['id'] ?? 0);
        if ($id > 0) DesktopAgent::revokeAny($id);
        $this->flash('success', 'Desktop agent disconnected.');
        $this->redirect('/agent');
    }

    /** POST /api/agent/pair — intentionally CSRF-free; the six-digit code is the one-time proof. */
    public function pair(Request $request, array $params): void
    {
        if (!$request->isHttps()) {
            $this->json(['ok' => false, 'error' => 'The desktop agent must use HTTPS.'], 400);
        }
        $ip = $request->ip();
        if (DesktopAgent::pairAttemptsFrom($ip) >= 10) {
            $this->json(['ok' => false, 'error' => 'Too many pairing attempts. Try again later.'], 429);
        }

        $data = $request->body();
        $code = (string) ($data['code'] ?? '');
        $deviceId = (string) ($data['device_id'] ?? '');
        $deviceName = (string) ($data['device_name'] ?? 'Windows PC');
        $version = (string) ($data['agent_version'] ?? 'unknown');

        $result = DesktopAgent::pair($code, $deviceId, $deviceName, $version);
        if ($result === null) {
            DesktopAgent::recordPairAttempt($ip);
            $this->json(['ok' => false, 'error' => 'Invalid or expired pairing code.'], 422);
        }
        $this->json([
            'ok' => true,
            'token' => $result['token'],
            'device_id' => $result['device_id'],
            'workspace_id' => $result['workspace_id'],
        ]);
    }

    /** POST /api/agent/heartbeat — authenticated only by the device token. */
    public function heartbeat(Request $request, array $params): void
    {
        if (!$request->isHttps()) {
            $this->json(['ok' => false, 'error' => 'The desktop agent must use HTTPS.'], 400);
        }
        $authorization = trim((string) ($request->header('authorization') ?? ''));
        if (!preg_match('/^Bearer\s+(.+)$/i', $authorization, $m)) {
            $this->json(['ok' => false, 'error' => 'Missing agent token.'], 401);
        }
        $device = DesktopAgent::authenticateToken($m[1]);
        if ($device === null) {
            $this->json(['ok' => false, 'error' => 'Invalid agent token.'], 401);
        }

        DesktopAgent::heartbeat($device, $request->body());
        $this->json([
            'ok' => true,
            'server_time' => time(),
            'idle_detection_enabled' => WorkspacePolicy::string('idle_detection_enabled', '0') === '1',
        ]);
    }
}
