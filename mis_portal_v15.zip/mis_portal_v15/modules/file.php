<?php require __DIR__.'/../includes/lib.php';need();$r=role();
if(isset($_GET['photo'])){$u=(int)$_GET['photo'];if(!(in_array($r,['support','ed'])||me()['id']==$u))die('Access denied');
 $d=q("SELECT * FROM documents WHERE kind='photo' AND ref_id=?",[$u])->fetch();}
else{$d=q('SELECT * FROM documents WHERE id=?',[(int)($_GET['id']??0)])->fetch();
 $F=['support','ed','finance'];$roles=['quotation'=>$F,'out_cs'=>$F,'out_po'=>$F,'tpl_cs'=>['support','ed'],'tpl_po'=>['support','ed'],'signature'=>$F,'vendor_doc'=>$F];
 if($d&&!in_array($r,$roles[$d['kind']]??[]))die('Access denied');}
if(!$d||!is_file(ST.$d['stored'])){http_response_code(404);exit;}
header('Content-Type: '.$d['mime']);header('X-Content-Type-Options: nosniff');
header('Content-Disposition: '.(isset($_GET['dl'])?'attachment':'inline').'; filename="'.preg_replace('/[^\w. -]/','_',$d['orig_name']).'"');
readfile(ST.$d['stored']);
