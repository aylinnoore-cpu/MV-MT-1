<?php
/**
 * Document head and opening of <body>. Shared by the "app" and "auth" layouts.
 *
 * Reads from the page data:  $pageTitle (string, optional)
 * Assets come from jsDelivr, which the Content-Security-Policy in config/config.php allows.
 * There are no inline scripts anywhere: the policy forbids them. Behaviour lives in assets/js/app.js.
 *
 * @var string|null $pageTitle
 */

$appName   = SettingsService::appName();
$workspaceBrand = class_exists('Workspace') ? Workspace::current() : null;
$displayName = $workspaceBrand ? (string) $workspaceBrand['name'] : $appName;
$fullTitle = isset($pageTitle) && $pageTitle !== '' ? $pageTitle . ' | ' . $appName : $appName;
$isShell   = AuthHelper::check(); // signed-in screens get the sidebar shell, guests get a bare page
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="color-scheme" content="light">
    <?= csrf_meta() ?>
    <title><?= e($fullTitle) ?></title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css" integrity="sha384-PPIZEGYM1v8zp5Py7UjFb79S58UeqCL9pYVnVPURKEqvioPROaVAJKKLzvH2rDnI" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/ibm-plex-sans@5/400.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/ibm-plex-sans@5/500.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/ibm-plex-sans@5/600.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/roboto@5/400.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/roboto@5/500.css" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/dark.css')) ?>">
    <script src="<?= e(asset('js/theme-init.js')) ?>"></script>
</head>
<body class="<?= $isShell ? 'app-body' : 'auth-body' ?>" data-base-url="<?= e(url('/')) ?>">
<a class="skip-link" href="#main-content">Skip to content</a>
<?php if ($isShell): ?>
<div class="app-shell">
<?php endif; ?>
