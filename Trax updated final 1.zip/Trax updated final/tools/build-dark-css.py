#!/usr/bin/env python3
"""
Generate public/assets/css/dark.css from public/assets/css/app.css.

app.css hard-codes its light palette in hundreds of rules, so the dark theme is derived
mechanically: every colour is mapped to a dark counterpart and emitted under
html[data-bs-theme='dark'] (specificity above the original). Re-run after editing app.css:

    python3 tools/build-dark-css.py
"""
import colorsys
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'public/assets/css/app.css')
OUT = os.path.join(ROOT, 'public/assets/css/dark.css')
SCOPE = "html[data-bs-theme='dark']"

HEX = re.compile(r'#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b')
BG_PROPS = {'background', 'background-color'}
BORDER_PROPS = {'border', 'border-color', 'border-top', 'border-bottom', 'border-left', 'border-right',
                'border-top-color', 'border-bottom-color', 'border-left-color', 'border-right-color',
                'outline', 'outline-color', 'border-block', 'border-inline'}
FG_PROPS = {'color', 'fill', 'stroke', 'text-decoration-color', 'caret-color'}


def parse_hex(h):
    h = h.lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def to_hex(r, g, b):
    return '#%02x%02x%02x' % tuple(max(0, min(255, round(v * 255))) for v in (r, g, b))


def hls(h):
    r, g, b = parse_hex(h)
    hh, l, s = colorsys.rgb_to_hls(r, g, b)
    return hh, l, s


def is_accent(l, s, lo, hi):
    return s >= 0.5 and lo <= l <= hi


def dark_bg(h, extra=0.0):
    hh, l, s = hls(h)
    l2 = 0.08 + (1 - l) * 0.82 + extra
    if l > 0.8:
        s *= 0.6  # pale tints become muted dark tints, not neon
    return to_hex(*colorsys.hls_to_rgb(hh, min(l2, 0.95), s))


def dark_fg(h):
    hh, l, s = hls(h)
    l2 = 0.96 - l * 0.75
    return to_hex(*colorsys.hls_to_rgb(hh, l2, s))


def kind_of_var(name):
    n = name.lower()
    if re.search(r'(ink|text|muted|color)', n):
        return 'fg'
    if re.search(r'(line|border)', n):
        return 'border'
    return 'bg'


def map_value(prop, value, kind):
    """Replace every hex colour in `value`. Returns (new_value, changed, held)."""
    held = False
    changed = False

    def sub(m):
        nonlocal held, changed
        hx = m.group(0)
        hh, l, s = hls(hx)
        if kind == 'bg':
            if is_accent(l, s, 0.2, 0.72) or l < 0.35:
                held = True
                return hx
            changed = True
            return dark_bg(hx)
        if kind == 'border':
            if is_accent(l, s, 0.3, 0.7):
                return hx
            changed = True
            return dark_bg(hx, 0.045)
        # foreground
        if is_accent(l, s, 0.38, 0.65):
            return hx
        changed = True
        return dark_fg(hx)

    return HEX.sub(sub, value), changed, held


def split_top(text, sep):
    parts, depth, quote, cur = [], 0, None, []
    for ch in text:
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
            continue
        if ch in '"\'':
            quote = ch
        elif ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif ch == sep and depth == 0:
            parts.append(''.join(cur))
            cur = []
            continue
        cur.append(ch)
    if ''.join(cur).strip():
        parts.append(''.join(cur))
    return parts


def read_blocks(css):
    """Yield (prelude, body) for top-level blocks of `css`."""
    i, n = 0, len(css)
    while i < n:
        j = css.find('{', i)
        if j == -1:
            break
        prelude = css[i:j].strip()
        depth, k = 1, j + 1
        while k < n and depth:
            if css[k] == '{':
                depth += 1
            elif css[k] == '}':
                depth -= 1
            k += 1
        yield prelude, css[j + 1:k - 1]
        i = k


def scope_selector(sel):
    out = []
    for part in split_top(sel, ','):
        part = part.strip()
        if not part:
            continue
        if part.startswith(':root') or part == 'html':
            continue
        if part.startswith('html'):
            out.append(SCOPE + part[4:])
        else:
            out.append(SCOPE + ' ' + part)
    return out


def convert_rule(prelude, body):
    selectors = scope_selector(prelude)
    if not selectors:
        return ''
    decls = []
    for raw in split_top(body, ';'):
        if ':' not in raw:
            continue
        prop, value = raw.split(':', 1)
        decls.append((prop.strip(), value.strip()))

    out, mapped = [], []
    holds_surface = False

    # pass 1: backgrounds & borders (they decide whether text colours may flip)
    for prop, value in decls:
        pl = prop.lower()
        if pl in BG_PROPS:
            if not HEX.search(value):
                # var()/gradient surface: light token surfaces are remapped by the MANUAL block,
                # anything else (ink, accent...) is a surface we must not flip text on.
                if not re.search(r'var\(--(tt-surface|tt-paper|clock-bg|clock-card|bs-body-bg|bs-tertiary-bg|bs-secondary-bg)\)', value) \
                        and not re.match(r'^(transparent|none|inherit|initial|unset)', value):
                    holds_surface = True
                continue
            new, changed, held = map_value(pl, value, 'bg')
            holds_surface = holds_surface or held
            if changed:
                mapped.append((prop, new))
        elif pl in BORDER_PROPS and HEX.search(value):
            new, changed, _ = map_value(pl, value, 'border')
            if changed:
                mapped.append((prop, new))
        elif pl.startswith('--') and HEX.search(value):
            k = kind_of_var(pl)
            new, changed, _ = map_value(pl, value, k)
            if changed:
                mapped.append((prop, new))

    has_bg = any(p.lower() in BG_PROPS for p, _ in decls)
    # pass 2: foreground colours
    for prop, value in decls:
        pl = prop.lower()
        if pl in FG_PROPS and HEX.search(value):
            if holds_surface:
                continue  # accent / dark surface keeps its own text colour
            hh, l, s = hls(HEX.search(value).group(0))
            if l > 0.9 and not has_bg:
                continue  # white text with the surface defined elsewhere (accent button, bar...)
            new, changed, _ = map_value(pl, value, 'fg')
            if changed:
                mapped.append((prop, new))

    if not mapped:
        return ''
    lines = []
    for prop, value in mapped:
        orig = next(v for p, v in decls if p == prop)
        imp = ' !important' if '!important' in orig and '!important' not in value else ''
        lines.append('    %s: %s%s;' % (prop, value, imp))
    return ',\n'.join(selectors) + ' {\n' + '\n'.join(lines) + '\n}\n'


def convert(css, depth=0):
    out = []
    for prelude, body in read_blocks(css):
        if prelude.startswith('@media') or prelude.startswith('@supports'):
            inner = convert(body, depth + 1)
            if inner.strip():
                out.append(prelude + ' {\n' + inner + '}\n')
        elif prelude.startswith('@'):
            continue  # keyframes, font-face, ...
        else:
            rule = convert_rule(prelude, body)
            if rule:
                out.append(rule)
    return ''.join(out)


HEADER = """/* =====================================================================
   TimeTrack dark theme. GENERATED by tools/build-dark-css.py from app.css:
   do not edit by hand, edit the generator (or the MANUAL block below) and re-run it.
   Active when <html data-bs-theme="dark"> (the sidebar moon button / OS preference).
   ===================================================================== */
"""

MANUAL = """
/* ---- MANUAL: design tokens + Bootstrap variables (app.css pins these on :root) ---- */
html[data-bs-theme='dark'] {
    --tt-paper: #14181b;
    --tt-surface: #1b2024;
    --tt-line: #2c343a;
    --tt-text: #d6dde3;
    --tt-muted: #97a5ab;
    --clock-bg: #14181b;
    --clock-card: #1b2024;
    --clock-border: #2c343a;
    --clock-muted: #8e9ba6;
    --clock-text: #d6dde3;

    --bs-body-bg: #14181b;
    --bs-body-bg-rgb: 20, 24, 27;
    --bs-body-color: #d6dde3;
    --bs-body-color-rgb: 214, 221, 227;
    --bs-emphasis-color: #ffffff;
    --bs-emphasis-color-rgb: 255, 255, 255;
    --bs-secondary-color: rgba(214, 221, 227, .68);
    --bs-secondary-bg: #20262b;
    --bs-tertiary-bg: #1b2024;
    --bs-border-color: #2c343a;
    --bs-link-color: #4cc2f5;
    --bs-link-color-rgb: 76, 194, 245;
    --bs-link-hover-color: #82d6f8;
    --bs-link-hover-color-rgb: 130, 214, 248;
}

html[data-bs-theme='dark'] body { background: #14181b; color: #d6dde3; }
html[data-bs-theme='dark'] .app-shell,
html[data-bs-theme='dark'] .app-main { background: #14181b; }

/* Bootstrap widgets that app.css restyles */
html[data-bs-theme='dark'] .dropdown-menu,
html[data-bs-theme='dark'] .modal-content,
html[data-bs-theme='dark'] .popover,
html[data-bs-theme='dark'] .offcanvas {
    --bs-dropdown-bg: #20262b;
    --bs-dropdown-color: #d6dde3;
    --bs-dropdown-border-color: #343d44;
    --bs-dropdown-link-color: #d6dde3;
    --bs-dropdown-link-hover-bg: #2a3238;
    --bs-dropdown-link-hover-color: #ffffff;
    background-color: #20262b;
    color: #d6dde3;
    border-color: #343d44;
}
html[data-bs-theme='dark'] .modal-header,
html[data-bs-theme='dark'] .modal-footer { border-color: #2c343a; }
html[data-bs-theme='dark'] .form-control,
html[data-bs-theme='dark'] .form-select,
html[data-bs-theme='dark'] .cf-input,
html[data-bs-theme='dark'] .cf-select,
html[data-bs-theme='dark'] .cf-note-box,
html[data-bs-theme='dark'] .cf-search input,
html[data-bs-theme='dark'] .cf-add input {
    background-color: #1b2024;
    color: #d6dde3;
    border-color: #343d44;
}
html[data-bs-theme='dark'] .form-control::placeholder,
html[data-bs-theme='dark'] .cf-search input::placeholder,
html[data-bs-theme='dark'] .cf-add input::placeholder,
html[data-bs-theme='dark'] .cf-note-box::placeholder { color: #7f8c97; opacity: 1; }
html[data-bs-theme='dark'] .form-control:focus,
html[data-bs-theme='dark'] .form-select:focus,
html[data-bs-theme='dark'] .cf-input:focus,
html[data-bs-theme='dark'] .cf-search input:focus,
html[data-bs-theme='dark'] .cf-add input:focus { background-color: #1b2024; color: #fff; border-color: #03a9f4; }
html[data-bs-theme='dark'] .table { --bs-table-bg: transparent; --bs-table-color: #d6dde3; --bs-table-border-color: #2c343a; --bs-table-striped-bg: rgba(255,255,255,.03); --bs-table-hover-bg: rgba(255,255,255,.04); }
html[data-bs-theme='dark'] .btn-outline-secondary { --bs-btn-color: #b9c4cc; --bs-btn-border-color: #3a444c; --bs-btn-hover-bg: #2a3238; --bs-btn-hover-color: #fff; --bs-btn-hover-border-color: #4a555e; }
html[data-bs-theme='dark'] .btn-close { filter: invert(1) grayscale(100%) brightness(200%); }

/* Project list (.cfl-) and project page (.cf-): the few spots that mix tokens and literals */
html[data-bs-theme='dark'] .cfl-select select { color: #d6dde3; }
html[data-bs-theme='dark'] .cfl-select select option { background: #1b2024; color: #d6dde3; }
html[data-bs-theme='dark'] .cfl-select::after,
html[data-bs-theme='dark'] .cfl-caret { border-top-color: #9aa8b2; }
html[data-bs-theme='dark'] .cfl-apply { background: transparent; color: #4cc2f5; border-color: #2a6f92; }
html[data-bs-theme='dark'] .cfl-apply:hover { background: rgba(3, 169, 244, .14); }
html[data-bs-theme='dark'] .cfl-access-btn.has-value { color: #4cc2f5; }
html[data-bs-theme='dark'] .cfl-access-btn:hover,
html[data-bs-theme='dark'] .cfl-access-btn.show { background: #252c32; }
html[data-bs-theme='dark'] .cfl-checkbox,
html[data-bs-theme='dark'] .cf-check input { accent-color: #03a9f4; }
html[data-bs-theme='dark'] .cfl-progress-bar { background: #2c343a; }
html[data-bs-theme='dark'] .cf-dots i { border-color: #8e9ba6; }
html[data-bs-theme='dark'] .cf-kebab:hover .cf-dots i { border-color: #d6dde3; }
html[data-bs-theme='dark'] .cf-icon-btn { background: #1b2024; border-color: #2c343a; color: #8e9ba6; }
html[data-bs-theme='dark'] .cf-icon-btn:hover { background: #252c32; color: #d6dde3; }
html[data-bs-theme='dark'] .cf-icon-btn.is-on,
html[data-bs-theme='dark'] .cfl-star.is-on { color: #f5a623; }

html[data-bs-theme='dark'] .cf-pill { color: #c3d4de; }
html[data-bs-theme='dark'] .cf-pill i { color: #9fb0bb; }
html[data-bs-theme='dark'] .cf-tab { color: #a7b6c0; }
html[data-bs-theme='dark'] .cf-tab:hover { color: #fff; }
html[data-bs-theme='dark'] .cf-tab.is-active { color: #fff; }
html[data-bs-theme='dark'] .cf-menu-hint { color: #8e9ba6; }

/* Scrollbars follow the theme (color-scheme: dark comes from style.css) */
html[data-bs-theme='dark'] { scrollbar-color: #3a444c #14181b; }

/* Notification bell */
html[data-bs-theme='dark'] .notification-menu { box-shadow: 0 12px 32px rgba(0, 0, 0, .5); }
html[data-bs-theme='dark'] .notification-item.is-unread { background: rgba(76, 194, 245, .08); }
html[data-bs-theme='dark'] .notification-item.is-unread::before { background: #4cc2f5; }
html[data-bs-theme='dark'] .notification-head .btn-link,
html[data-bs-theme='dark'] .notification-foot { color: #4cc2f5; }

/* Logo: uploaded wordmarks are usually dark artwork, so give them a light plate on the dark theme */
html[data-bs-theme='dark'] .brand-mark.has-logo { background: #eef2ef !important; padding: .3rem .6rem; border-radius: .5rem; }
"""


def main():
    css = open(SRC, encoding='utf-8').read()
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.S)
    body = convert(css)
    open(OUT, 'w', encoding='utf-8').write(HEADER + body + MANUAL)
    print('wrote %s (%d bytes, %d rules)' % (OUT, os.path.getsize(OUT), body.count('{')))


if __name__ == '__main__':
    main()
