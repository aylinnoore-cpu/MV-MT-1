<?php
/**
 * Closing markup and scripts. Shared by the "app" and "auth" layouts.
 */

$isShell = AuthHelper::check();
?>
<?php if ($isShell): ?>
        </main>

        <footer class="app-footer">
            <span>&copy; <?= e(gmdate('Y')) ?> <?= e((string) Config::get('app.name', 'TimeTrack')) ?></span>
            <span class="text-secondary">Times are shown in <?= e(str_replace('_', ' ', FormatHelper::displayTimezone())) ?></span>
        </footer>
    </div><!-- /.app-main -->
</div><!-- /.app-shell -->
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<?php if (!empty($chartAssets)): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js" integrity="sha384-NrKB+u6Ts6AtkIhwPixiKTzgSKNblyhlk0Sohlgar9UHUBzai/sgnNNWWd291xqt" crossorigin="anonymous"></script>
<?php endif; ?>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<?php if (!empty($projectAssets)): ?>
<script src="<?= e(asset('js/project.js')) ?>"></script>
<?php endif; ?>
<?php if ($isShell && PermissionHelper::hasAny('time.track', 'time.edit_own')): ?>
<script src="<?= e(asset('js/timer.js')) ?>"></script>
<?php endif; ?>
<?php if (!empty($scheduleAssets)): ?>
<script src="<?= e(asset('js/schedule.js')) ?>"></script>
<?php endif; ?>
<?php if ($isShell): ?>
<script src="<?= e(asset('js/dashboard.js')) ?>"></script>
<?php endif; ?>
</body>
</html>
