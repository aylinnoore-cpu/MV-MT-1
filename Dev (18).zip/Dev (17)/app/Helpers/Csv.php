<?php
declare(strict_types=1);

final class CsvHelper
{
    /** Prefix cells that spreadsheet applications may interpret as formulas. */
    public static function safeCell(mixed $value): string
    {
        $value = (string) $value;
        if ($value !== '' && in_array($value[0], ['=', '+', '-', '@', "\t", "\r"], true)) {
            return "'" . $value;
        }
        return $value;
    }

    /** @param list<mixed> $values */
    public static function row(array $values): void
    {
        fputcsv(STDOUT, array_map([self::class, 'safeCell'], $values), ',', '"', "\\");
    }
}
