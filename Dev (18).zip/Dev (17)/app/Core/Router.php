<?php
/**
 * Minimal front-controller router.
 *
 *   $router->get('/projects/{id:\d+}', [ProjectController::class, 'show']);
 *   $router->post('/projects', [ProjectController::class, 'store']);
 *
 * Handlers receive (Request $request, array $params). Controllers are only
 * instantiated after a route matches, so their constructors (where AuthN/RBAC
 * middleware runs) never execute for unknown URLs.
 *
 * Security: every non-GET route verifies the CSRF token BEFORE the controller is
 * constructed. Opt out per route with ['csrf' => false] (only for signed webhooks).
 */

declare(strict_types=1);

final class Router
{
    /** @var list<array{method: string, regex: string, handler: array|callable, csrf: bool}> */
    private array $routes = [];

    public function get(string $path, array|callable $handler): void
    {
        $this->add('GET', $path, $handler, []);
    }

    /** @param array{csrf?: bool} $options */
    public function post(string $path, array|callable $handler, array $options = []): void
    {
        $this->add('POST', $path, $handler, $options);
    }

    /** @param array{csrf?: bool} $options */
    public function put(string $path, array|callable $handler, array $options = []): void
    {
        $this->add('PUT', $path, $handler, $options);
    }

    /** @param array{csrf?: bool} $options */
    public function patch(string $path, array|callable $handler, array $options = []): void
    {
        $this->add('PATCH', $path, $handler, $options);
    }

    /** @param array{csrf?: bool} $options */
    public function delete(string $path, array|callable $handler, array $options = []): void
    {
        $this->add('DELETE', $path, $handler, $options);
    }

    /** Handle the request and always produce a response, converting any failure into an error page. */
    public function run(Request $request): void
    {
        try {
            $this->dispatch($request);
        } catch (HttpException $e) {
            $this->respondToHttpException($request, $e);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            // Details are shown only when debug is on, never in production.
            $message = Config::get('app.debug', false)
                ? $e::class . ': ' . $e->getMessage()
                : 'An unexpected error occurred. It has been logged.';

            Response::error(500, $message, $request->wantsJson());
        }
    }

    /** @param array{csrf?: bool} $options */
    private function add(string $method, string $path, array|callable $handler, array $options): void
    {
        $this->routes[] = [
            'method'  => $method,
            'regex'   => $this->compile('/' . trim($path, '/')),
            'handler' => $handler,
            'csrf'    => $method !== 'GET' && ($options['csrf'] ?? true),
        ];
    }

    /** Turn "/tasks/{id:\d+}" into a named-group regex. Literal parts are regex-quoted. */
    private function compile(string $path): string
    {
        $parts = preg_split('/(\{[^}]+\})/', $path, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        $regex = '';

        foreach ($parts as $part) {
            if (preg_match('/^\{([a-zA-Z_][a-zA-Z0-9_]*)(?::(.+))?\}$/', $part, $m)) {
                $regex .= '(?P<' . $m[1] . '>' . ($m[2] ?? '[^/]+') . ')';
            } else {
                $regex .= preg_quote($part, '#');
            }
        }

        return '#^' . $regex . '$#D';
    }

    private function dispatch(Request $request): void
    {
        // HEAD is served by the GET handler (the web server strips the body).
        $method = $request->method() === 'HEAD' ? 'GET' : $request->method();
        $allowed = [];

        foreach ($this->routes as $route) {
            if (!preg_match($route['regex'], $request->path(), $matches)) {
                continue;
            }

            if ($route['method'] !== $method) {
                $allowed[] = $route['method'];
                continue;
            }

            if ($route['csrf']) {
                CsrfHelper::verify($request);
            }

            /** @var array<string, string> $params */
            $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

            $this->invoke($route['handler'], $request, $params);
            return;
        }

        if ($allowed !== []) {
            throw new HttpException(405, '', ['Allow' => implode(', ', array_unique($allowed))]);
        }

        throw new HttpException(404);
    }

    /** @param array<string, string> $params */
    private function invoke(array|callable $handler, Request $request, array $params): void
    {
        if (is_array($handler)) {
            [$class, $action] = $handler;
            $controller = new $class();

            if (!is_callable([$controller, $action])) {
                throw new LogicException("Route handler {$class}::{$action} is not callable.");
            }

            $controller->$action($request, $params);
            return;
        }

        $handler($request, $params);
    }

    private function respondToHttpException(Request $request, HttpException $e): void
    {
        $wantsJson = $request->wantsJson();

        // Unauthenticated browser navigation goes to the login page and returns afterwards.
        if ($e->status() === 401 && !$wantsJson) {
            if ($request->method() === 'GET') {
                $query = $request->query();
                AuthHelper::rememberIntended($request->path() . ($query !== [] ? '?' . http_build_query($query) : ''));
            }
            Response::redirect('/login');
        }

        if ($e->status() >= 500) {
            LoggerHelper::exception($e);
        }

        Response::error($e->status(), $e->getMessage(), $wantsJson, $e->headers());
    }
}
