<?php
/**
 * Organisation departments.
 *
 *   Department ── Department Manager
 *     └── Team ── Team managers ── Members
 *
 * Departments are not tied to a project. Teams inside a department can work
 * on any project.
 */

declare(strict_types=1);

final class Department
{
    public const STATUSES = ['active', 'inactive'];

    public static function installed(): bool
    {
        SchemaHelper::ensureOrgStructure();

        return SchemaHelper::tableExists('departments')
            && SchemaHelper::tableExists('teams')
            && SchemaHelper::tableExists('team_members')
            && SchemaHelper::columnExists('teams', 'department_id');
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function all(string $search = ''): array
    {
        $where  = ['1 = 1'];
        $params = [];
        $searchJoin = '';

        $search = trim($search);
        if ($search !== '') {
            $where[]      = '(d.name LIKE :q OR t.name LIKE :q2 OR dm.name LIKE :q3 OR mgr.name LIKE :q4)';
            $params['q']  = '%' . $search . '%';
            $params['q2'] = '%' . $search . '%';
            $params['q3'] = '%' . $search . '%';
            $params['q4'] = '%' . $search . '%';
            $mgrJoin = SchemaHelper::tableExists('team_managers')
                ? 'LEFT JOIN team_managers tmg ON tmg.team_id = t.id LEFT JOIN users mgr ON mgr.id = tmg.user_id'
                : 'LEFT JOIN users mgr ON mgr.id = t.manager_id';
            $searchJoin = 'LEFT JOIN teams t ON t.department_id = d.id ' . $mgrJoin;
        }

        return Database::fetchAll(
            'SELECT DISTINCT d.id, d.name, d.manager_id, d.status, d.created_at,
                    dm.name AS manager_name,
                    (SELECT COUNT(*) FROM teams x WHERE x.department_id = d.id) AS team_count
             FROM departments d
             LEFT JOIN users dm ON dm.id = d.manager_id
             ' . $searchJoin . '
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY d.name ASC',
            $params
        );
    }

    /** @return array<string, mixed>|null */
    public function find(int $id): ?array
    {
        if ($id < 1) {
            return null;
        }

        return Database::fetchOne(
            'SELECT d.id, d.name, d.manager_id, d.status
             FROM departments d WHERE d.id = :id LIMIT 1',
            ['id' => $id]
        );
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function teamsOf(int $departmentId): array
    {
        if ($departmentId < 1) {
            return [];
        }

        return Database::fetchAll(
            'SELECT t.id, t.department_id, t.name, t.manager_id, t.status,
                    tm.name AS manager_name,
                    (SELECT COUNT(*) FROM team_members x WHERE x.team_id = t.id) AS member_count
             FROM teams t
             LEFT JOIN users tm ON tm.id = t.manager_id
             WHERE t.department_id = :id
             ORDER BY t.name ASC',
            ['id' => $departmentId]
        );
    }

    /**
     * @param list<int> $departmentIds
     * @return array<int, list<array<string, mixed>>>
     */
    public function teamsByDepartment(array $departmentIds): array
    {
        $departmentIds = array_values(array_unique(array_filter(
            array_map('intval', $departmentIds),
            static fn (int $id): bool => $id > 0
        )));
        if ($departmentIds === []) {
            return [];
        }

        $in   = implode(',', $departmentIds);
        $rows = Database::fetchAll(
            "SELECT t.id, t.department_id, t.name, t.manager_id, t.status,
                    tm.name AS manager_name,
                    (SELECT COUNT(*) FROM team_members x WHERE x.team_id = t.id) AS member_count
             FROM teams t
             LEFT JOIN users tm ON tm.id = t.manager_id
             WHERE t.department_id IN ({$in})
             ORDER BY t.name ASC"
        );

        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['department_id']][] = $row;
        }

        return $out;
    }

    public function nameTaken(string $name, int $exceptId = 0): bool
    {
        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM departments WHERE name = :n AND id <> :id',
            ['n' => $name, 'id' => $exceptId]
        ) > 0;
    }

    /**
     * @param array{name: string, manager_id: ?int, status: string} $data
     */
    public function create(array $data, int $createdBy): int
    {
        $sql = SchemaHelper::columnExists('departments', 'project_id')
            ? 'INSERT INTO departments (project_id, name, manager_id, status, created_by, created_at, updated_at)
               VALUES (NULL, :name, :manager_id, :status, :created_by, UTC_TIMESTAMP(), UTC_TIMESTAMP())'
            : 'INSERT INTO departments (name, manager_id, status, created_by, created_at, updated_at)
               VALUES (:name, :manager_id, :status, :created_by, UTC_TIMESTAMP(), UTC_TIMESTAMP())';

        Database::execute($sql, [
            'name'       => $data['name'],
            'manager_id' => $data['manager_id'],
            'status'     => $data['status'],
            'created_by' => $createdBy > 0 ? $createdBy : null,
        ]);

        return Database::lastInsertId();
    }

    /**
     * @param array{name: string, manager_id: ?int, status: string} $data
     */
    public function update(int $id, array $data): void
    {
        Database::execute(
            'UPDATE departments
             SET name = :name, manager_id = :manager_id,
                 status = :status, updated_at = UTC_TIMESTAMP()
             WHERE id = :id',
            [
                'name'       => $data['name'],
                'manager_id' => $data['manager_id'],
                'status'     => $data['status'],
                'id'         => $id,
            ]
        );
    }

    public function delete(int $id): void
    {
        Database::execute('DELETE FROM departments WHERE id = :id', ['id' => $id]);
    }
}
