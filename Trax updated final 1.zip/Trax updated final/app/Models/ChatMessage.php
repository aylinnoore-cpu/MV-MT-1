<?php
/**
 * Chat messages, mentions and attachments.
 */

declare(strict_types=1);

final class ChatMessage extends Model
{
    protected string $table = 'messages';

    protected bool $timestamps = false;

    protected array $columns = [
        'id', 'conversation_id', 'user_id', 'body', 'task_id',
        'edited_at', 'deleted_at', 'deleted_by', 'created_at',
    ];

    protected array $fillable = [
        'conversation_id', 'user_id', 'body', 'task_id',
        'edited_at', 'deleted_at', 'deleted_by',
    ];

    public static function installed(): bool
    {
        return SchemaHelper::tableExists('messages');
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function latest(int $conversationId, int $limit = 50, ?int $beforeId = null): array
    {
        $limit = min(100, max(1, $limit));
        $params = ['c' => $conversationId];
        $before = '';
        if ($beforeId !== null && $beforeId > 0) {
            $before = ' AND m.id < :before';
            $params['before'] = $beforeId;
        }
        $avatar = SchemaHelper::columnExists('users', 'avatar_path') ? 'u.avatar_path' : 'NULL AS avatar_path';
        $rows = Database::fetchAll(
            "SELECT m.id, m.conversation_id, m.user_id, m.body, m.task_id, m.edited_at, m.deleted_at, m.deleted_by, m.created_at,
                    u.name AS user_name, {$avatar}
             FROM messages m
             INNER JOIN users u ON u.id = m.user_id
             WHERE m.conversation_id = :c{$before}
             ORDER BY m.id DESC
             LIMIT {$limit}",
            $params
        );

        return array_reverse($this->hydrate($rows));
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function since(int $conversationId, int $sinceId, int $limit = 100): array
    {
        $limit = min(200, max(1, $limit));
        $avatar = SchemaHelper::columnExists('users', 'avatar_path') ? 'u.avatar_path' : 'NULL AS avatar_path';
        $rows = Database::fetchAll(
            "SELECT m.id, m.conversation_id, m.user_id, m.body, m.task_id, m.edited_at, m.deleted_at, m.deleted_by, m.created_at,
                    u.name AS user_name, {$avatar}
             FROM messages m
             INNER JOIN users u ON u.id = m.user_id
             WHERE m.conversation_id = :c AND m.id > :since
             ORDER BY m.id ASC
             LIMIT {$limit}",
            ['c' => $conversationId, 'since' => $sinceId]
        );

        return $this->hydrate($rows);
    }

    public function maxId(int $conversationId): int
    {
        return (int) Database::fetchValue(
            'SELECT COALESCE(MAX(id), 0) FROM messages WHERE conversation_id = :c',
            ['c' => $conversationId]
        );
    }

    public function newestIdForUser(int $userId): int
    {
        if ($userId < 1 || !self::installed()) {
            return 0;
        }

        return (int) Database::fetchValue(
            'SELECT COALESCE(MAX(m.id), 0)
             FROM messages m
             INNER JOIN conversations c ON c.id = m.conversation_id
             WHERE c.deleted_at IS NULL AND m.deleted_at IS NULL',
            []
        );
    }

    /**
     * @param list<array{stored_name: string, original_name: string, size_bytes: int, mime: string, extension: string}> $files
     * @param list<int> $mentionUserIds
     * @return array<string, mixed>
     */
    public function post(
        int $conversationId,
        int $userId,
        string $body,
        array $files,
        array $mentionUserIds,
        bool $groupMention,
        ?int $taskId
    ): array {
        $id = Database::transaction(function () use ($conversationId, $userId, $body, $files, $mentionUserIds, $groupMention, $taskId): int {
            Database::execute(
                'INSERT INTO messages (conversation_id, user_id, body, task_id, created_at)
                 VALUES (:c, :u, :body, :task, UTC_TIMESTAMP())',
                [
                    'c'    => $conversationId,
                    'u'    => $userId,
                    'body' => $body,
                    'task' => $taskId,
                ]
            );
            $id = Database::lastInsertId();
            foreach ($mentionUserIds as $uid) {
                $uid = (int) $uid;
                if ($uid < 1) {
                    continue;
                }
                Database::execute(
                    'INSERT IGNORE INTO message_mentions (message_id, user_id, is_group, handle)
                     VALUES (:m, :uid, :g, :h)',
                    [
                        'm'   => $id,
                        'uid' => $uid,
                        'g'   => $groupMention ? 1 : 0,
                        'h'   => $groupMention ? 'all' : '',
                    ]
                );
            }
            foreach ($files as $file) {
                Database::execute(
                    'INSERT INTO message_attachments
                        (message_id, original_name, stored_name, size_bytes, mime, extension, created_at)
                     VALUES (:m, :orig, :stored, :size, :mime, :ext, UTC_TIMESTAMP())',
                    [
                        'm'      => $id,
                        'orig'   => $file['original_name'],
                        'stored' => $file['stored_name'],
                        'size'   => $file['size_bytes'],
                        'mime'   => $file['mime'],
                        'ext'    => $file['extension'],
                    ]
                );
            }

            return $id;
        });

        $avatar = SchemaHelper::columnExists('users', 'avatar_path') ? 'u.avatar_path' : 'NULL AS avatar_path';
        $row = Database::fetchOne(
            "SELECT m.id, m.conversation_id, m.user_id, m.body, m.task_id, m.edited_at, m.deleted_at, m.deleted_by, m.created_at,
                    u.name AS user_name, {$avatar}
             FROM messages m INNER JOIN users u ON u.id = m.user_id
             WHERE m.id = :id LIMIT 1",
            ['id' => $id]
        );

        return $this->hydrate([$row ?? []])[0] ?? [];
    }

    public function editBody(int $messageId, int $userId, string $body): bool
    {
        $n = Database::execute(
            'UPDATE messages SET body = :body, edited_at = UTC_TIMESTAMP()
             WHERE id = :id AND user_id = :u AND deleted_at IS NULL',
            ['body' => $body, 'id' => $messageId, 'u' => $userId]
        );

        return $n > 0;
    }

    public function softDelete(int $messageId, int $actorId): bool
    {
        $n = Database::execute(
            'UPDATE messages SET deleted_at = UTC_TIMESTAMP(), deleted_by = :u, body = \'\'
             WHERE id = :id AND deleted_at IS NULL',
            ['u' => $actorId, 'id' => $messageId]
        );
        if ($n > 0) {
            LoggerHelper::logEvent('chat.message_deleted', LoggerHelper::MODULE_CHAT, $messageId, null, [
                'deleted_by' => $actorId,
            ]);
        }

        return $n > 0;
    }

    /** @return array<string, mixed>|null */
    public function findWithConversation(int $messageId): ?array
    {
        if ($messageId < 1 || !self::installed()) {
            return null;
        }

        return Database::fetchOne(
            'SELECT m.*, c.type AS conversation_type, c.team_id, c.project_id, c.deleted_at AS conversation_deleted_at
             FROM messages m
             INNER JOIN conversations c ON c.id = m.conversation_id
             WHERE m.id = :id LIMIT 1',
            ['id' => $messageId]
        );
    }

    /** @return array<string, mixed>|null */
    public function findAttachment(int $attachmentId): ?array
    {
        if ($attachmentId < 1 || !SchemaHelper::tableExists('message_attachments')) {
            return null;
        }

        return Database::fetchOne(
            'SELECT a.*, m.conversation_id, m.deleted_at AS message_deleted_at, c.type AS conversation_type,
                    c.team_id, c.project_id, c.deleted_at AS conversation_deleted_at
             FROM message_attachments a
             INNER JOIN messages m ON m.id = a.message_id
             INNER JOIN conversations c ON c.id = m.conversation_id
             WHERE a.id = :id LIMIT 1',
            ['id' => $attachmentId]
        );
    }

    public function softDeleteAttachment(int $attachmentId, int $actorId): bool
    {
        $n = Database::execute(
            'UPDATE message_attachments SET deleted_at = UTC_TIMESTAMP(), deleted_by = :u
             WHERE id = :id AND deleted_at IS NULL',
            ['u' => $actorId, 'id' => $attachmentId]
        );
        if ($n > 0) {
            LoggerHelper::logEvent('chat.file_deleted', LoggerHelper::MODULE_CHAT, $attachmentId, null, [
                'deleted_by' => $actorId,
            ]);
        }

        return $n > 0;
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return list<array<string, mixed>>
     */
    private function hydrate(array $rows): array
    {
        $ids = [];
        foreach ($rows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id > 0) {
                $ids[] = $id;
            }
        }
        $mentions = $this->mentionsFor($ids);
        $files = $this->attachmentsFor($ids);
        $taskMeta = $this->taskMetaFor($rows);

        $out = [];
        foreach ($rows as $row) {
            if ($row === []) {
                continue;
            }
            $id = (int) $row['id'];
            $deleted = (string) ($row['deleted_at'] ?? '') !== '';
            $taskId = (int) ($row['task_id'] ?? 0);
            $out[] = [
                'id'              => $id,
                'conversation_id' => (int) $row['conversation_id'],
                'user_id'         => (int) $row['user_id'],
                'user_name'       => (string) ($row['user_name'] ?? ''),
                'avatar_path'     => (string) ($row['avatar_path'] ?? ''),
                'body'            => $deleted ? '' : (string) ($row['body'] ?? ''),
                'task_id'         => $taskId > 0 ? $taskId : null,
                'task_name'       => $taskMeta[$taskId]['name'] ?? null,
                'task_project_id' => $taskMeta[$taskId]['project_id'] ?? null,
                'edited_at'       => (string) ($row['edited_at'] ?? ''),
                'deleted'         => $deleted,
                'deleted_by'      => (int) ($row['deleted_by'] ?? 0) ?: null,
                'created_at'      => (string) ($row['created_at'] ?? ''),
                'mentions'        => $mentions[$id] ?? [],
                'attachments'     => $deleted ? [] : ($files[$id] ?? []),
            ];
        }

        return $out;
    }

    /**
     * @param list<int> $messageIds
     * @return array<int, list<array{user_id: int, is_group: bool}>>
     */
    private function mentionsFor(array $messageIds): array
    {
        if ($messageIds === [] || !SchemaHelper::tableExists('message_mentions')) {
            return [];
        }
        $in = implode(',', array_map('intval', $messageIds));
        $rows = Database::fetchAll(
            "SELECT message_id, user_id, is_group FROM message_mentions WHERE message_id IN ({$in})"
        );
        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['message_id']][] = [
                'user_id'  => (int) $row['user_id'],
                'is_group' => (int) $row['is_group'] === 1,
            ];
        }

        return $out;
    }

    /**
     * @param list<int> $messageIds
     * @return array<int, list<array<string, mixed>>>
     */
    private function attachmentsFor(array $messageIds): array
    {
        if ($messageIds === [] || !SchemaHelper::tableExists('message_attachments')) {
            return [];
        }
        $in = implode(',', array_map('intval', $messageIds));
        $rows = Database::fetchAll(
            "SELECT id, message_id, original_name, stored_name, size_bytes, mime, extension, deleted_at
             FROM message_attachments
             WHERE message_id IN ({$in}) AND deleted_at IS NULL
             ORDER BY id ASC"
        );
        $out = [];
        foreach ($rows as $row) {
            $ext = strtolower((string) $row['extension']);
            $mime = strtolower((string) $row['mime']);
            $preview = in_array($ext, ChatHelper::INLINE_IMAGE_EXTENSIONS, true)
                && in_array($mime, ChatHelper::PREVIEW_IMAGE_MIMES, true);
            $out[(int) $row['message_id']][] = [
                'id'            => (int) $row['id'],
                'name'          => (string) $row['original_name'],
                'size'          => (int) $row['size_bytes'],
                'size_label'    => ChatHelper::formatBytes((int) $row['size_bytes']),
                'mime'          => $mime,
                'extension'     => $ext,
                'preview'       => $preview,
                'url'           => '/chat/files/' . (int) $row['id'],
            ];
        }

        return $out;
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return array<int, array{name: string, project_id: int}>
     */
    private function taskMetaFor(array $rows): array
    {
        $ids = [];
        foreach ($rows as $row) {
            $tid = (int) ($row['task_id'] ?? 0);
            if ($tid > 0) {
                $ids[] = $tid;
            }
        }
        $ids = array_values(array_unique($ids));
        if ($ids === [] || !SchemaHelper::tableExists('tasks')) {
            return [];
        }
        $in = implode(',', $ids);
        $found = Database::fetchAll("SELECT id, name, project_id FROM tasks WHERE id IN ({$in})");
        $out = [];
        foreach ($found as $row) {
            $out[(int) $row['id']] = [
                'name'       => (string) $row['name'],
                'project_id' => (int) $row['project_id'],
            ];
        }

        return $out;
    }
}
