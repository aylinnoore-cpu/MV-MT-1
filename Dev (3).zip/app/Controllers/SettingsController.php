<?php
/**
 * Global/system settings: currency defaults and the application default timezone.
 * Workspace identity and workspace policies are managed separately under /workspace.
 *
 * Settings live in the key/value `settings` table. Only the keys listed in
 * $editable can be written from this screen, so a crafted POST cannot create
 * arbitrary configuration rows.
 */

declare(strict_types=1);

final class SettingsController extends Controller
{
    /** @var list<string> global/system setting keys writable here */
    private const EDITABLE = [
        'currency_symbol',
        'currency',
        'default_hourly_rate',
        'default_timezone',
    ];

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN]);
    }

    /** GET /settings */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $this->render('settings/index', [
            'pageTitle' => 'System settings',
            'settings'  => $this->load(),
            'timezones' => DateTimeZone::listIdentifiers(),
            'currencies' => ['USD', 'EUR', 'GBP', 'PKR', 'INR', 'AED', 'SAR', 'AUD', 'CAD', 'JPY'],
        ]);
    }

    /** GET /settings/audit-logs : searchable, filterable audit trail. */
    public function auditLogs(Request $request, array $params): void
    {
        PermissionHelper::require('activity.view');

        $filters = [
            'q'       => trim((string) $request->input('q', '')),
            'module'  => (string) $request->input('module', 'all'),
            'action'  => trim((string) $request->input('action', '')),
            'user_id' => (int) $request->input('user_id', 0),
        ];

        $model = new ActivityLog();
        $result = $model->search($filters, (int) $request->input('page', 1), 25);

        $this->render('settings/audit_logs', [
            'pageTitle' => 'Activity log',
            'result'    => $result,
            'filters'   => $filters,
            'modules'   => $model->modules(),
        ]);
    }

    /** POST /settings */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'currency_symbol'      => 'required|string|max:6',
            'currency'             => 'required|string|max:3',
            'default_hourly_rate'  => 'required|numeric|min:0|max:100000',
            'default_timezone'     => 'required|timezone',
        ], '/settings', [
            'currency_symbol'       => 'Currency symbol',
            'currency'             => 'Currency code',
            'default_hourly_rate'   => 'Default hourly rate',
            'default_timezone'     => 'Timezone',
        ]);

        $before = $this->load();
        $after  = [];

        Database::transaction(function () use ($data, &$after): void {
            foreach (self::EDITABLE as $key) {
                if (!array_key_exists($key, $data)) continue;
                $value = (string) $data[$key];
                SettingsService::setSystem($key, $value);
                $after[$key] = $value;
            }
        });

        LoggerHelper::logEvent('settings.updated', LoggerHelper::MODULE_SETTINGS, null, $before, $after);

        $this->flash('success', 'System settings were saved.');
        $this->redirect('/settings');
    }

    /* ------------------------------------------------------------- helpers */

    /** @return array<string, string> */
    private function load(): array
    {
        $system = SettingsService::system();
        return [
            'currency_symbol' => $system['currency_symbol'],
            'currency' => $system['currency'],
            'default_hourly_rate' => $system['default_hourly_rate'],
            'default_timezone' => $system['default_timezone'],
        ];
    }

}
