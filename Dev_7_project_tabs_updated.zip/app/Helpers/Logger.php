<?php
/**
 * Two kinds of logging:
 *
 *  1. Application log (info/warning/error/exception): daily files in storage/logs,
 *     for operators debugging problems.
 *  2. Audit trail (audit): rows in the audit_logs table (schema in Phase 2) recording
 *     WHO did WHAT to which record, for accountability.
 *
 * SECURITY: never log passwords, tokens, or full request bodies. Newlines are stripped
 * from messages and context so an attacker cannot forge extra log lines (log injection).
 */

declare(strict_types=1);

final class LoggerHelper
{
    /** @param array<string, mixed> $context */
    public static function info(string $message, array $context = []): void
    {
        self::write('INFO', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function warning(string $message, array $context = []): void
    {
        self::write('WARNING', $message, $context);
    }

    /** @param array<string, mixed> $context */
    public static function error(string $message, array $context = []): void
    {
        self::write('ERROR', $message, $context);
    }

    /** Log an exception with file and line; the stack trace is included only when debug is on. */
    public static function exception(Throwable $e): void
    {
        $context = [
            'type' => $e::class,
            'file' => basename($e->getFile()) . ':' . $e->getLine(),
        ];

        if (Config::get('app.debug', false)) {
            $context['trace'] = $e->getTraceAsString();
        }

        self::write('ERROR', $e->getMessage(), $context);
    }

    /**
     * Record a business event in audit_logs (e.g. "project.created", "timesheet.approved").
     * Failures fall back to the file log: auditing must never break the user's action.
     *
     * @param array<string, mixed> $meta Small JSON-serialisable details (no secrets)
     */
    public static function audit(string $action, ?string $entityType = null, ?int $entityId = null, array $meta = []): void
    {
        try {
            $request = Request::current();

            Database::execute(
                'INSERT INTO audit_logs (user_id, action, entity_type, entity_id, ip_address, user_agent, meta, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())',
                [
                    AuthHelper::id(),
                    substr($action, 0, 100),
                    $entityType !== null ? substr($entityType, 0, 60) : null,
                    $entityId,
                    $request->ip(),
                    $request->userAgent(),
                    $meta === [] ? null : json_encode($meta, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                ]
            );
        } catch (Throwable $e) {
            self::write('ERROR', 'Audit write failed', [
                'action' => $action,
                'reason' => $e->getMessage(),
            ]);
        }
    }

    /** @param array<string, mixed> $context */
    private static function write(string $level, string $message, array $context): void
    {
        $dir = STORAGE_PATH . '/logs';

        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            error_log("[{$level}] {$message}"); // last resort: PHP's own error log
            return;
        }

        $line = sprintf(
            "[%s] %s %s%s\n",
            gmdate('Y-m-d H:i:s') . ' UTC',
            $level,
            self::clean($message),
            $context === [] ? '' : ' ' . self::clean((string) json_encode($context, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR))
        );

        @file_put_contents($dir . '/app-' . gmdate('Y-m-d') . '.log', $line, FILE_APPEND | LOCK_EX);
    }

    /** Collapse CR/LF so one log call is always exactly one line. */
    private static function clean(string $text): string
    {
        return str_replace(["\r", "\n"], ['\r', '\n'], $text);
    }
}
