<?php
/**
 * Tasks: the work items inside a project, with optional assignees.
 *
 * A task with no assignees is open to "Anyone" on the project (same as Clockify).
 */

declare(strict_types=1);

final class Task extends Model
{
    public const STATUS_OPEN        = 'Open';
    public const STATUS_IN_PROGRESS = 'In Progress';
    public const STATUS_DONE        = 'Done';

    public const STATUSES = [
        self::STATUS_OPEN,
        self::STATUS_IN_PROGRESS,
        self::STATUS_DONE,
    ];

    protected string $table = 'tasks';

    protected array $columns = [
        'id', 'project_id', 'name', 'description', 'status',
        'estimated_hours', 'due_date', 'created_by', 'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'project_id', 'name', 'description', 'status',
        'estimated_hours', 'due_date', 'created_by',
    ];

    /** True when the tasks tables have been installed (database/phase5.sql). */
    public static function installed(): bool
    {
        static $installed = null;

        if ($installed === null) {
            try {
                $installed = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name IN ('tasks', 'task_assignees')"
                ) === 2;
            } catch (Throwable) {
                $installed = false;
            }
        }

        return $installed;
    }

    /**
     * Tasks of one project with their assignees attached.
     *
     * @param string $filter 'active' (Open + In Progress), 'done' or 'all'
     * @return list<array<string, mixed>>
     */
    public function forProject(int $projectId, string $filter = 'active', string $search = ''): array
    {
        $where  = ['t.project_id = :project_id'];
        $params = ['project_id' => $projectId];

        if ($filter === 'active') {
            $where[] = "t.status <> 'Done'";
        } elseif ($filter === 'done') {
            $where[] = "t.status = 'Done'";
        }

        $search = trim($search);
        if ($search !== '') {
            $where[]        = 't.name LIKE :q';
            $params['q']    = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
        }

        $tasks = Database::fetchAll(
            'SELECT t.id, t.project_id, t.name, t.description, t.status, t.estimated_hours, t.due_date, t.created_at
             FROM tasks t
             WHERE ' . implode(' AND ', $where) . "
             ORDER BY (t.status = 'Done') ASC, t.name ASC",
            $params
        );

        return $this->attachAssignees($tasks);
    }

    /** @return array{all: int, active: int, done: int} */
    public function counts(int $projectId): array
    {
        $row = Database::fetchOne(
            "SELECT COUNT(*) AS total,
                    COALESCE(SUM(status <> 'Done'), 0) AS active,
                    COALESCE(SUM(status = 'Done'), 0)  AS done
             FROM tasks WHERE project_id = :id",
            ['id' => $projectId]
        );

        return [
            'all'    => (int) ($row['total'] ?? 0),
            'active' => (int) ($row['active'] ?? 0),
            'done'   => (int) ($row['done'] ?? 0),
        ];
    }

    public function nameTaken(int $projectId, string $name, ?int $ignoreId = null): bool
    {
        $sql    = 'SELECT COUNT(*) FROM tasks WHERE project_id = :project_id AND name = :name';
        $params = ['project_id' => $projectId, 'name' => $name];

        if ($ignoreId !== null) {
            $sql .= ' AND id <> :id';
            $params['id'] = $ignoreId;
        }

        return (int) Database::fetchValue($sql, $params) > 0;
    }

    public function setStatus(int $id, string $status): int
    {
        return $this->update($id, ['status' => $status]);
    }

    /**
     * Replace a task's assignees. Only users who belong to the project are kept.
     *
     * @param list<int> $userIds
     * @param list<int> $allowedUserIds project members (the only valid assignees)
     */
    public function syncAssignees(int $taskId, array $userIds, array $allowedUserIds): void
    {
        $userIds = array_values(array_unique(array_intersect(
            array_map('intval', $userIds),
            array_map('intval', $allowedUserIds)
        )));

        Database::transaction(static function () use ($taskId, $userIds): void {
            Database::execute('DELETE FROM task_assignees WHERE task_id = :id', ['id' => $taskId]);

            foreach ($userIds as $userId) {
                Database::execute(
                    'INSERT INTO task_assignees (task_id, user_id) VALUES (:task_id, :user_id)',
                    ['task_id' => $taskId, 'user_id' => $userId]
                );
            }
        });
    }

    /** Delete a task; schedule blocks that pointed at it are kept but detached. */
    public function deleteWithLinks(int $id): void
    {
        Database::transaction(static function () use ($id): void {
            try {
                Database::execute('UPDATE schedules SET task_id = NULL WHERE task_id = :id', ['id' => $id]);
            } catch (Throwable) {
                // schedules table not installed yet: nothing to detach
            }
            Database::execute('DELETE FROM task_assignees WHERE task_id = :id', ['id' => $id]);
            Database::execute('DELETE FROM tasks WHERE id = :id', ['id' => $id]);
        });
    }

    /**
     * @param list<array<string, mixed>> $tasks
     * @return list<array<string, mixed>>
     */
    private function attachAssignees(array $tasks): array
    {
        if ($tasks === []) {
            return $tasks;
        }

        $placeholders = [];
        $params       = [];
        foreach ($tasks as $i => $task) {
            $placeholders[]    = ':t' . $i;
            $params['t' . $i]  = (int) $task['id'];
        }

        $rows = Database::fetchAll(
            'SELECT ta.task_id, u.id AS user_id, u.name
             FROM task_assignees ta
             INNER JOIN users u ON u.id = ta.user_id
             WHERE ta.task_id IN (' . implode(',', $placeholders) . ')
             ORDER BY u.name ASC',
            $params
        );

        $byTask = [];
        foreach ($rows as $row) {
            $byTask[(int) $row['task_id']][] = ['id' => (int) $row['user_id'], 'name' => (string) $row['name']];
        }

        foreach ($tasks as &$task) {
            $task['assignees']    = $byTask[(int) $task['id']] ?? [];
            $task['assignee_ids'] = array_map(static fn (array $a): int => $a['id'], $task['assignees']);
        }
        unset($task);

        return $tasks;
    }
}
