<?php
/**
 * Project page, Clockify layout. One page, six tabs.
 *
 * Common: $project, $members, $tab, $tasksReady, $taskCounts, $isFavorite, $extrasReady,
 *         $currency, $canEdit, $canArchive, $canManageMembers
 * Per tab: see the matching partial (tasks/panel.php, projects/tab_*.php).
 */

$activeProjectTab = (string) $tab;
?>
<div class="cf-page">
    <?php require APP_PATH . '/Views/projects/_header.php'; ?>

    <?php if ($tab === 'tasks' && $tasksReady): ?>
        <?php require APP_PATH . '/Views/tasks/panel.php'; ?>
    <?php elseif ($tab === 'access'): ?>
        <?php require APP_PATH . '/Views/projects/tab_access.php'; ?>
    <?php elseif ($tab === 'forecast'): ?>
        <?php require APP_PATH . '/Views/projects/tab_forecast.php'; ?>
    <?php elseif ($tab === 'note'): ?>
        <?php require APP_PATH . '/Views/projects/tab_note.php'; ?>
    <?php elseif ($tab === 'settings' && $canEdit): ?>
        <?php require APP_PATH . '/Views/projects/tab_settings.php'; ?>
    <?php else: ?>
        <?php require APP_PATH . '/Views/projects/tab_status.php'; ?>
    <?php endif; ?>
</div>
