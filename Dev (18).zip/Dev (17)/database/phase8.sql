-- TimeTrack Phase 8: pause/resume timers and non-blocking submitted weeks
-- Run once on the existing database. Safe to run again on MariaDB versions
-- that support ADD COLUMN IF NOT EXISTS.

ALTER TABLE active_timers
    ADD COLUMN IF NOT EXISTS paused_at DATETIME NULL AFTER last_activity_at,
    ADD COLUMN IF NOT EXISTS accumulated_seconds INT UNSIGNED NOT NULL DEFAULT 0 AFTER paused_at;
