-- Remove the unused clients.company column (Name and Company were always the same).
--
-- ORDER MATTERS: upload the updated PHP files FIRST, then run this script.
-- The old code selects clients.company and would error once the column is gone.
--
-- Safe to run more than once: it does nothing if the column is already gone.
-- Works on MariaDB and MySQL (no "DROP COLUMN IF EXISTS" needed).
-- This permanently deletes the column's data. Take a database export first if
-- any client rows you still need contain a company value.

SET @has_company := (
    SELECT COUNT(*) FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'clients' AND column_name = 'company'
);

SET @sql := IF(@has_company = 1,
    'ALTER TABLE `clients` DROP COLUMN `company`',
    'SELECT ''clients.company already removed'' AS note'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify (should return 0 rows):
SHOW COLUMNS FROM `clients` LIKE 'company';
