CREATE DATABASE IF NOT EXISTS mis_portal CHARACTER SET utf8mb4;
USE mis_portal;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(120) UNIQUE,password VARCHAR(255),
 role ENUM('staff','support','ed','finance') DEFAULT 'staff',department VARCHAR(100),designation VARCHAR(100),location VARCHAR(100),
 status ENUM('active','inactive') DEFAULT 'active');
CREATE TABLE assets(id INT AUTO_INCREMENT PRIMARY KEY,asset_tag VARCHAR(60) UNIQUE,name VARCHAR(150),category VARCHAR(80),serial_no VARCHAR(100),
 purchase_date DATE NULL,cost DECIMAL(12,2) DEFAULT 0,vendor VARCHAR(120),status ENUM('working','out_for_repair','out_for_maintenance','in_storage','faulty','dead','lost') DEFAULT 'working',
 assigned_to INT NULL,assigned_date DATE NULL,mac_supported ENUM('No','Yes') DEFAULT 'No',mac_address VARCHAR(17) NULL,ip_address VARCHAR(45) NULL,ip_type ENUM('Static','DHCP reservation') NULL,notes TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE procurement(id INT AUTO_INCREMENT PRIMARY KEY,type ENUM('procurement','repair') DEFAULT 'procurement',title VARCHAR(200),description TEXT,
 vendor VARCHAR(120),amount DECIMAL(12,2) DEFAULT 0,quotation_notes TEXT,po_number VARCHAR(40) NULL,
 status ENUM('requested','ed_approved','finance_approved','po_issued','rejected') DEFAULT 'requested',requested_by INT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE tickets(id INT AUTO_INCREMENT PRIMARY KEY,ticket_no VARCHAR(20),title VARCHAR(200),category ENUM('hardware','software','network','other') DEFAULT 'other',
 priority ENUM('low','medium','high') DEFAULT 'medium',description TEXT,status ENUM('open','in_progress','resolved','closed') DEFAULT 'open',
 created_by INT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP);
CREATE TABLE ticket_comments(id INT AUTO_INCREMENT PRIMARY KEY,ticket_id INT,user_id INT,body TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE maintenance(id INT AUTO_INCREMENT PRIMARY KEY,asset_id INT,type ENUM('preventive','repair','service') DEFAULT 'preventive',technician VARCHAR(120),
 description TEXT,cost DECIMAL(12,2) DEFAULT 0,work_date DATE NULL,next_due DATE NULL,status ENUM('scheduled','done') DEFAULT 'scheduled',created_by INT);
CREATE TABLE activity(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,message VARCHAR(255),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
