<?php
session_start();
require __DIR__.'/../config/config.php';
$pdo=new PDO('mysql:host='.DB[0].';dbname='.DB[1].';charset=utf8mb4',DB[2],DB[3],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
function q($s,$p=[]){global $pdo;$r=$pdo->prepare($s);$r->execute($p);return $r;}
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES);}
function me(){return $_SESSION['u']??null;}
function role(){return me()['role']??'';}
function need(){if(!me()){header('Location: '.BASE.'/login.php');exit;}}
function csrf(){return $_SESSION['c']??=bin2hex(random_bytes(16));}
function chk(){if(($_POST['c']??'')!==csrf())die('Invalid request token');}
function logit($m){q('INSERT INTO activity(user_id,message)VALUES(?,?)',[me()['id'],$m]);}
function pretty($s){return preg_replace('/ Id$/','',ucwords(str_replace('_',' ',$s)));}

function allow($r){need();if(!in_array(role(),$r))die('Access denied');}
function store($f,$ex,$max=8000000){ // validates extension, real MIME type and size; saves outside public access
 if(empty($f['tmp_name'])||!is_uploaded_file($f['tmp_name'])||$f['size']>$max)return null;
 $e=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION));
 $ok=['pdf'=>['application/pdf'],'jpg'=>['image/jpeg'],'jpeg'=>['image/jpeg'],'png'=>['image/png'],'xlsx'=>['application/zip','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']];
 $m=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
 if(!in_array($e,$ex)||!in_array($m,$ok[$e]??[]))return null;
 $n=bin2hex(random_bytes(16)).".$e";return move_uploaded_file($f['tmp_name'],ST.$n)?[$n,$m]:null;}
function adddoc($kind,$ref,$name,$stored,$mime){q('INSERT INTO documents(kind,ref_id,orig_name,stored,mime,uploaded_by)VALUES(?,?,?,?,?,?)',[$kind,$ref,$name,$stored,$mime,me()['id']]);return $GLOBALS['pdo']->lastInsertId();}
function set_photo($uid,$f){$r=store($f,['jpg','jpeg','png'],3000000);if(!$r)return;
 foreach(q("SELECT stored FROM documents WHERE kind='photo' AND ref_id=?",[$uid])->fetchAll() as $o)@unlink(ST.$o['stored']);
 q("DELETE FROM documents WHERE kind='photo' AND ref_id=?",[$uid]);adddoc('photo',$uid,$f['name'],$r[0],$r[1]);logit("Photo updated for user #$uid");}
require __DIR__.'/modules.php';
require __DIR__.'/layout.php';

function wfmt($d){$p=[];if($d->y)$p[]=$d->y.' yr';if($d->m)$p[]=$d->m.' mo';if($d->d||!$p)$p[]=$d->d.' day'.($d->d==1?'':'s');return implode(' ',$p);}
function warr($end,$asof=null){if(!$end)return ['No warranty info',''];$a=new DateTime($asof?:'today');$e=new DateTime($end);
 if($e<$a)return ['Warranty expired '.wfmt($e->diff($a)).' ago','r'];return ['In warranty: '.wfmt($a->diff($e)).' remaining (until '.$e->format('d-M-Y').')',$a->diff($e)->days<=60?'o':'g'];}
function csvput($o,$r){fputcsv($o,$r,',','"','\\');}

/* Permanent, tamper-evident deletion log: every entry is chained to the previous one by a SHA-256 hash. */
function log_delete($entity,$eid,$label,$snap,$reason=''){$u=me();$pdo=$GLOBALS['pdo'];$own=!$pdo->inTransaction();if($own)$pdo->beginTransaction();
 $label=mb_substr((string)$label,0,255);$reason=mb_substr((string)$reason,0,500);$eid=(int)$eid;$at=date('Y-m-d H:i:s');$js=json_encode($snap,JSON_UNESCAPED_UNICODE|JSON_PARTIAL_OUTPUT_ON_ERROR);
 $prev=q('SELECT row_hash FROM deletion_log ORDER BY id DESC LIMIT 1 FOR UPDATE')->fetch()['row_hash']??'';
 $h=hash('sha256',implode('|',[$prev,$entity,$eid,$label,$js,$reason,$u['id'],$u['name'],$at]));
 q('INSERT INTO deletion_log(entity,entity_id,label,snapshot,reason,deleted_by,deleted_by_name,client_ip,deleted_at,prev_hash,row_hash)VALUES(?,?,?,?,?,?,?,?,?,?,?)',[$entity,$eid,$label,$js,$reason,$u['id'],$u['name'],$_SERVER['REMOTE_ADDR']??'',$at,$prev,$h]);
 if($own)$pdo->commit();}
