<?php
/**
 * Retention cleanup: old logs, sessions, activity_logs, pairing codes.
 *
 * Recommended cron cadence: daily.
 * Example:
 *   15 3 * * * /usr/bin/php /home/USER/public_html/Dev/tools/cron_cleanup.php
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found.\n");
}

if (PHP_VERSION_ID < 80200) {
    fwrite(STDERR, "PHP 8.2 or newer is required.\n");
    exit(1);
}

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CONFIG_PATH', BASE_PATH . '/config');
define('STORAGE_PATH', BASE_PATH . '/storage');

spl_autoload_register(static function (string $class): void {
    if (!preg_match('/^[A-Za-z][A-Za-z0-9]*$/', $class)) {
        return;
    }

    $names = [$class];
    if (str_ends_with($class, 'Helper')) {
        $names[] = substr($class, 0, -strlen('Helper'));
    }

    foreach (['Core', 'Helpers', 'Middleware', 'Controllers', 'Models'] as $folder) {
        foreach ($names as $name) {
            $file = APP_PATH . '/' . $folder . '/' . $name . '.php';
            if (is_file($file)) {
                require $file;
                return;
            }
        }
    }
});

date_default_timezone_set('UTC');
Config::load(require CONFIG_PATH . '/config.php');
Config::set('database', require CONFIG_PATH . '/database.php');

try {
    $logDir = STORAGE_PATH . '/logs';
    $logsRemoved = 0;
    if (is_dir($logDir)) {
        foreach (scandir($logDir) ?: [] as $file) {
            if (!preg_match('/^app-\d{4}-\d{2}-\d{2}\.log$/', $file) && $file !== 'php-error.log') {
                continue;
            }
            $path = $logDir . '/' . $file;
            if (is_file($path) && (time() - (int) filemtime($path)) > 30 * 86400) {
                @unlink($path);
                $logsRemoved++;
            }
        }
    }

    $sessionDir = STORAGE_PATH . '/sessions';
    $sessionsRemoved = 0;
    $maxAge = (int) Config::get('session.absolute_timeout', 43200);
    if (is_dir($sessionDir)) {
        foreach (scandir($sessionDir) ?: [] as $file) {
            if (!str_starts_with($file, 'sess_')) {
                continue;
            }
            $path = $sessionDir . '/' . $file;
            if (is_file($path) && (time() - (int) filemtime($path)) > $maxAge) {
                @unlink($path);
                $sessionsRemoved++;
            }
        }
    }

    $activity = 0;
    if (SchemaHelper::tableExists('activity_logs')) {
        $activity = Database::execute(
            'DELETE FROM activity_logs WHERE created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 180 DAY)'
        );
    }

    $resets = 0;
    if (SchemaHelper::tableExists('password_reset_tokens')) {
        $resets = Database::execute(
            'DELETE FROM password_reset_tokens WHERE used_at IS NOT NULL OR expires_at < UTC_TIMESTAMP()'
        );
    }

    DesktopAgent::cleanupExpired(90);

    printf(
        "Cleanup complete: %d log file(s), %d session file(s), %d activity_log row(s), %d password-reset token(s).\n",
        $logsRemoved,
        $sessionsRemoved,
        $activity,
        $resets
    );
    exit(0);
} catch (Throwable $e) {
    LoggerHelper::exception($e);
    fwrite(STDERR, "Cleanup failed. See the application log.\n");
    exit(1);
}
