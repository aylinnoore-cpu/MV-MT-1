<?php
declare(strict_types=1);

/** @var bool $installed */
/** @var array{teams: list<array<string, mixed>>, projects: list<array<string, mixed>>, dms: list<array<string, mixed>>, custom: list<array<string, mixed>>, unread_total: int} $sidebar */
/** @var array<string, mixed>|null $conversation */
/** @var string $conversationName */
/** @var list<array<string, mixed>> $members */
/** @var list<array<string, mixed>> $history */
/** @var int $maxId */
/** @var bool $adminPeek */
/** @var bool $noticeEnabled */
/** @var string $noticeText */
/** @var bool $canCreateChannel */
/** @var bool $canCreateTask */
/** @var bool $canManage */
/** @var list<array<string, mixed>> $dmCandidates */
/** @var list<array<string, mixed>> $staffDirectory */
/** @var list<array{id: int, name: string}> $createProjects */
/** @var int $maxFileBytes */
/** @var string $maxFileLabel */
/** @var list<string> $allowedTypes */
/** @var int $bodyMax */
/** @var int $filesPerMessage */
/** @var int $userId */

$sidebar = $sidebar ?? ['teams' => [], 'projects' => [], 'dms' => [], 'custom' => [], 'unread_total' => 0];
$members = $members ?? [];
$history = $history ?? [];
$dmCandidates = $dmCandidates ?? [];
$staffDirectory = $staffDirectory ?? [];
$createProjects = $createProjects ?? [];
$openId = $conversation !== null ? (int) $conversation['id'] : 0;
$openType = $conversation !== null ? (string) $conversation['type'] : '';
$archived = $conversation !== null && (string) ($conversation['archived_at'] ?? '') !== '';
$canCompose = $openId > 0 && !$adminPeek && !$archived;
$memberChoices = $staffDirectory !== [] ? $staffDirectory : $dmCandidates;
$accept = implode(',', array_map(static fn (string $ext): string => '.' . $ext, $allowedTypes));

$jsonFlags = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
$config = [
    'pollUrl'         => url('/chat/poll'),
    'sendUrl'         => $openId > 0 ? url('/chat/conversations/' . $openId . '/messages') : '',
    'historyUrl'      => $openId > 0 ? url('/chat/conversations/' . $openId . '/messages') : '',
    'dmUrl'           => url('/chat/dm'),
    'channelUrl'      => url('/chat/channels'),
    'conversationId'  => $openId,
    'maxId'           => (int) $maxId,
    'userId'          => (int) $userId,
    'bodyMax'         => (int) $bodyMax,
    'filesPerMessage' => (int) $filesPerMessage,
    'maxFileBytes'    => (int) $maxFileBytes,
    'canCompose'      => $canCompose,
    'canCreateTask'   => (bool) $canCreateTask,
    'canManage'       => (bool) $canManage,
    'members'         => array_map(static fn (array $m): array => [
        'id'     => (int) $m['id'],
        'name'   => (string) $m['name'],
        'handle' => (string) ($m['handle'] ?? ''),
    ], $members),
];

$renderItem = static function (array $item, int $openId): void {
    $id = (int) $item['id'];
    $unread = (int) ($item['unread_count'] ?? 0);
    $mentions = (int) ($item['mention_count'] ?? 0);
    $active = $id === $openId;
    $preview = trim((string) ($item['last_body'] ?? ''));
    if (mb_strlen($preview, 'UTF-8') > 72) {
        $preview = mb_substr($preview, 0, 72, 'UTF-8') . '…';
    }
    $when = (string) ($item['last_at'] ?? '');
    echo '<a class="chat-item' . ($active ? ' is-active' : '') . ($unread > 0 ? ' is-unread' : '') . '" href="' . e(url('/chat?c=' . $id)) . '">';
    if (!empty($item['other'])) {
        echo UserAvatarHelper::html((string) ($item['other']['avatar_path'] ?? ''), (string) ($item['other']['name'] ?? ''), 'avatar avatar-sm');
    } else {
        $icon = match ((string) $item['type']) {
            'team'    => 'fa-user-group',
            'project' => 'fa-diagram-project',
            default   => 'fa-hashtag',
        };
        echo '<span class="chat-item-icon" aria-hidden="true"><i class="fa-solid ' . $icon . '"></i></span>';
    }
    echo '<span class="chat-item-body"><span class="chat-item-top"><span class="chat-item-name">' . e((string) $item['name']) . '</span>';
    if ($when !== '') {
        echo '<span class="chat-item-time">' . e(FormatHelper::datetime($when, 'M j')) . '</span>';
    }
    echo '</span><span class="chat-item-preview">' . e($preview !== '' ? $preview : 'No messages yet') . '</span></span>';
    if ($mentions > 0) {
        echo '<span class="chat-item-badge is-mention">@</span>';
    } elseif ($unread > 0) {
        echo '<span class="chat-item-badge">' . e($unread > 9 ? '9+' : (string) $unread) . '</span>';
    }
    echo '</a>';
};
?>
<div class="chat-app<?= $openId > 0 ? ' is-thread' : '' ?>" data-chat-root data-config="<?= e(json_encode($config, $jsonFlags) ?: '{}') ?>">
    <aside class="chat-list" aria-label="Conversations">
        <div class="chat-list-head">
            <h1 class="chat-title">Messages</h1>
            <div class="chat-list-actions">
                <?php if ($canCreateChannel): ?>
                    <button type="button" class="btn btn-icon" data-bs-toggle="modal" data-bs-target="#chatChannelModal" aria-label="New channel" title="New channel"><i class="fa-solid fa-plus" aria-hidden="true"></i></button>
                <?php endif; ?>
                <button type="button" class="btn btn-icon" data-bs-toggle="modal" data-bs-target="#chatDmModal" aria-label="New message" title="New message"><i class="fa-regular fa-pen-to-square" aria-hidden="true"></i></button>
            </div>
        </div>
        <?php if (!$installed): ?>
            <p class="chat-empty">Chat is not installed yet. Run database/phase21/chat.sql, then reload.</p>
        <?php else: ?>
            <div class="chat-list-scroll">
                <?php if ($sidebar['teams'] !== []): ?>
                    <h2 class="chat-group-label">Teams</h2>
                    <?php foreach ($sidebar['teams'] as $item) { $renderItem($item, $openId); } ?>
                <?php endif; ?>
                <?php if ($sidebar['projects'] !== []): ?>
                    <h2 class="chat-group-label">Projects</h2>
                    <?php foreach ($sidebar['projects'] as $item) { $renderItem($item, $openId); } ?>
                <?php endif; ?>
                <?php if ($sidebar['custom'] !== []): ?>
                    <h2 class="chat-group-label">Channels</h2>
                    <?php foreach ($sidebar['custom'] as $item) { $renderItem($item, $openId); } ?>
                <?php endif; ?>
                <?php if ($sidebar['dms'] !== []): ?>
                    <h2 class="chat-group-label">Direct</h2>
                    <?php foreach ($sidebar['dms'] as $item) { $renderItem($item, $openId); } ?>
                <?php endif; ?>
                <?php if ($sidebar['teams'] === [] && $sidebar['projects'] === [] && $sidebar['custom'] === [] && $sidebar['dms'] === []): ?>
                    <p class="chat-empty">No conversations yet. Start a direct message<?= $canCreateChannel ? ' or create a channel' : '' ?>.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </aside>

    <section class="chat-thread" aria-label="Conversation">
        <?php if ($conversation === null): ?>
            <div class="chat-thread-empty">
                <i class="fa-regular fa-comments" aria-hidden="true"></i>
                <p>Select a conversation to start talking.</p>
            </div>
        <?php else: ?>
            <header class="chat-thread-head">
                <a class="chat-back btn btn-icon" href="<?= e(url('/chat')) ?>" aria-label="Back to conversations"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i></a>
                <div class="chat-thread-title">
                    <strong><?= e($conversationName) ?></strong>
                    <span><?php
                        $count = count($members);
                        echo e($openType === 'dm' ? 'Direct message' : ($count . ' member' . ($count === 1 ? '' : 's')));
                    ?></span>
                </div>
                <?php if ($canManage && $openType === 'custom'): ?>
                    <div class="dropdown">
                        <button type="button" class="btn btn-icon" data-bs-toggle="dropdown" aria-label="Channel actions"><i class="fa-solid fa-ellipsis" aria-hidden="true"></i></button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <form method="post" action="<?= e(url('/chat/channels/' . $openId . ($archived ? '/unarchive' : '/archive'))) ?>">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="dropdown-item"><?= $archived ? 'Restore channel' : 'Archive channel' ?></button>
                                </form>
                            </li>
                            <li>
                                <form method="post" action="<?= e(url('/chat/channels/' . $openId . '/delete')) ?>" data-confirm="Delete this channel? Messages stay in the audit trail.">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="dropdown-item text-danger">Delete channel</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>
            </header>
            <?php if ($noticeEnabled): ?>
                <p class="chat-notice"><?= e($noticeText) ?></p>
            <?php endif; ?>
            <?php if ($adminPeek): ?>
                <p class="chat-notice is-admin">You are viewing this direct message as an admin. Sending is disabled.</p>
            <?php endif; ?>
            <?php if ($archived): ?>
                <p class="chat-notice">This channel is archived.</p>
            <?php endif; ?>
            <div class="chat-log" data-chat-log>
                <button type="button" class="chat-load-more" data-chat-older hidden>Load earlier messages</button>
                <?php foreach ($history as $msg): ?>
                    <?php
                    $mine = (int) $msg['user_id'] === (int) $userId;
                    $deleted = !empty($msg['deleted']);
                    ?>
                    <article class="chat-msg<?= $mine ? ' is-mine' : '' ?><?= $deleted ? ' is-deleted' : '' ?>" data-message-id="<?= (int) $msg['id'] ?>" data-user-id="<?= (int) $msg['user_id'] ?>">
                        <?= $msg['avatar_html'] ?? '' ?>
                        <div class="chat-msg-main">
                            <div class="chat-msg-meta">
                                <strong><?= e((string) $msg['user_name']) ?></strong>
                                <time><?= e((string) $msg['created']) ?></time>
                                <?php if (!empty($msg['edited'])): ?><span class="chat-edited">edited</span><?php endif; ?>
                            </div>
                            <div class="chat-msg-body" data-chat-body><?= $deleted ? '<em>This message was deleted.</em>' : ($msg['body_html'] ?? '') ?></div>
                            <?php if (!empty($msg['task_name'])): ?>
                                <?php if (!empty($msg['task_url'])): ?>
                                    <a class="chat-task-link" href="<?= e((string) $msg['task_url']) ?>"><?= e((string) $msg['task_name']) ?></a>
                                <?php else: ?>
                                    <span class="chat-task-link"><?= e((string) $msg['task_name']) ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if (!empty($msg['attachments'])): ?>
                                <div class="chat-files">
                                    <?php foreach ($msg['attachments'] as $file): ?>
                                        <?php if (!empty($file['preview'])): ?>
                                            <a class="chat-file-preview" href="<?= e((string) $file['url']) ?>" target="_blank" rel="noopener"><img src="<?= e((string) $file['url']) ?>" alt="<?= e((string) $file['name']) ?>"></a>
                                        <?php else: ?>
                                            <a class="chat-file" href="<?= e((string) $file['url']) ?>"><?= e((string) $file['name']) ?> <span><?= e((string) ($file['size_label'] ?? '')) ?></span></a>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!$deleted): ?>
                                <div class="chat-msg-actions">
                                    <?php if ($mine): ?>
                                        <button type="button" class="btn btn-link btn-sm p-0" data-chat-edit>Edit</button>
                                    <?php endif; ?>
                                    <?php if ($canManage): ?>
                                        <button type="button" class="btn btn-link btn-sm p-0 text-danger" data-chat-delete>Delete</button>
                                    <?php endif; ?>
                                    <?php if ($canCreateTask && $createProjects !== []): ?>
                                        <button type="button" class="btn btn-link btn-sm p-0" data-chat-task data-body="<?= e((string) $msg['body']) ?>">Create task</button>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <?php if ($canCompose): ?>
                <form class="chat-composer" data-chat-composer enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <div class="chat-mention-list" data-chat-mentions hidden></div>
                    <div class="chat-file-chips" data-chat-chips></div>
                    <div class="chat-composer-row">
                        <label class="btn btn-icon chat-attach" title="Attach files">
                            <i class="fa-solid fa-paperclip" aria-hidden="true"></i>
                            <span class="visually-hidden">Attach files</span>
                            <input type="file" name="files[]" multiple accept="<?= e($accept) ?>" data-chat-files hidden>
                        </label>
                        <textarea name="body" rows="1" maxlength="<?= (int) $bodyMax ?>" class="form-control" data-chat-input placeholder="Message" aria-label="Message"></textarea>
                        <button type="submit" class="btn btn-primary chat-send" aria-label="Send"><i class="fa-solid fa-paper-plane" aria-hidden="true"></i></button>
                    </div>
                    <p class="chat-composer-hint">Up to <?= e($maxFileLabel) ?> per file. <?= e(implode(', ', $allowedTypes)) ?>.</p>
                    <p class="chat-composer-error" data-chat-error hidden></p>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>

<div class="modal fade" id="chatDmModal" tabindex="-1" aria-labelledby="chatDmTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content" data-chat-dm>
            <div class="modal-header">
                <h2 class="modal-title h5" id="chatDmTitle">New message</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if ($dmCandidates === []): ?>
                    <p class="text-secondary mb-0">You can only message people who share a team or project with you.</p>
                <?php else: ?>
                    <label class="form-label" for="chat_dm_user">Colleague</label>
                    <select class="form-select" id="chat_dm_user" name="user_id" required>
                        <option value="">Choose someone</option>
                        <?php foreach ($dmCandidates as $person): ?>
                            <option value="<?= (int) $person['id'] ?>"><?= e((string) $person['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </div>
            <?php if ($dmCandidates !== []): ?>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Open chat</button>
                </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php if ($canCreateChannel): ?>
<div class="modal fade" id="chatChannelModal" tabindex="-1" aria-labelledby="chatChannelTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content" data-chat-channel>
            <div class="modal-header">
                <h2 class="modal-title h5" id="chatChannelTitle">New channel</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label class="form-label" for="chat_channel_name">Name</label>
                <input class="form-control" id="chat_channel_name" name="name" maxlength="120" required>
                <fieldset class="mt-3">
                    <legend class="form-label">Members</legend>
                    <div class="chat-member-grid">
                        <?php foreach ($memberChoices as $person): ?>
                            <?php if ((int) $person['id'] === (int) $userId) { continue; } ?>
                            <label class="form-check">
                                <input class="form-check-input" type="checkbox" name="member_ids[]" value="<?= (int) $person['id'] ?>">
                                <span class="form-check-label"><?= e((string) $person['name']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </fieldset>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Create channel</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php if ($canCreateTask && $createProjects !== []): ?>
<div class="modal fade" id="chatTaskModal" tabindex="-1" aria-labelledby="chatTaskTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="<?= e(url('/projects/' . (int) $createProjects[0]['id'] . '/tasks')) ?>" class="modal-content" data-chat-task-form data-single-submit>
            <?= csrf_field() ?>
            <input type="hidden" name="back" value="<?= e('/chat' . ($openId > 0 ? '?c=' . $openId : '')) ?>">
            <div class="modal-header">
                <h2 class="modal-title h5" id="chatTaskTitle">Create task from message</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label class="form-label" for="chat_task_project">Project</label>
                <select class="form-select" id="chat_task_project" data-chat-task-project>
                    <?php foreach ($createProjects as $project): ?>
                        <option value="<?= (int) $project['id'] ?>"><?= e((string) $project['name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <label class="form-label mt-3" for="chat_task_name">Task name</label>
                <input class="form-control" id="chat_task_name" name="name" maxlength="160" required>
                <label class="form-label mt-3" for="chat_task_description">Description</label>
                <textarea class="form-control" id="chat_task_description" name="description" rows="3" maxlength="2000"></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Create task</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
