<?php require __DIR__.'/../includes/lib.php';allow(['support','ed']);head('Barcode Generator');
$as=q('SELECT a.id,a.barcode,a.name,a.serial_no,a.category,u.name holder FROM assets a LEFT JOIN users u ON u.id=a.assigned_to ORDER BY a.id')->fetchAll();?>
<style>@media print{main{padding:0!important}.top,.ctl{display:none!important}}.pg{background:#fff;box-sizing:border-box;margin:0 auto 12px;box-shadow:0 0 3px #888;overflow:hidden;display:grid;align-content:start}
@media print{.pg{margin:0;box-shadow:none;page-break-after:always}}.lb{border:.1mm solid #ddd;box-sizing:border-box;overflow:hidden;text-align:center;font:7pt sans-serif;padding:.8mm;background:#fff}.lb svg{width:100%;display:block}.cg{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:0 10px}</style>
<div class="card ctl"><div class=cg>
<div><label>Paper</label><select id=paper><option>A4<option>A5<option>custom</select></div><div><label>Paper W×H (mm)</label><input id=pw type=number value=210 style="width:49%"><input id=ph type=number value=297 style="width:49%"></div>
<div><label>Label width (mm)</label><input id=lw type=number value=60></div><div><label>Label height (mm)</label><input id=lh type=number value=30></div>
<div><label>Barcode height (mm)</label><input id=bh type=number value=14></div><div><label>Columns</label><input id=cols type=number value=3></div><div><label>Rows per page</label><input id=rows type=number value=8></div>
<div><label>Margin (mm)</label><input id=mg type=number value=10></div><div><label>Spacing (mm)</label><input id=gp type=number value=2></div>
<div><label>Layout</label><select id=lay><option value=0>Barcode only<option value=1 selected>Barcode + asset name<option value=2>+ serial no.<option value=3>+ assigned to</select></div></div>
<label>Assets <input id=f placeholder=Search style="max-width:200px"> <button type=button id=all class="btn g">Select all shown</button> <button type=button id=none class="btn g">Clear</button></label>
<div id=al style="max-height:170px;overflow:auto;border:1px solid #dcdfe4;padding:6px;display:grid"></div><p><button onclick=print()>Print</button> <span id=cnt></span></p></div><div id=sheet></div><style id=pgs></style>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script><script>
const A=<?=json_encode($as,JSON_HEX_TAG|JSON_HEX_AMP)?>,$=i=>document.getElementById(i),g=i=>+$(i).value,sel=new Set((new URLSearchParams(location.search).get('ids')||'').split(',').filter(Boolean).map(Number));
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function list(){const f=$('f').value.toLowerCase();$('al').innerHTML=A.filter(a=>(a.name+a.barcode+(a.serial_no||'')).toLowerCase().includes(f)).map(a=>`<label style="margin:2px 0"><input type=checkbox style="width:auto" value=${a.id} ${sel.has(+a.id)?'checked':''}> ${esc(a.barcode)} — ${esc(a.name)}</label>`).join('')}
function render(){let W=g('pw'),H=g('ph');const p=$('paper').value;if(p=='A4'){W=210;H=297}if(p=='A5'){W=148;H=210}$('pw').value=W;$('ph').value=H;$('pw').disabled=$('ph').disabled=p!='custom';
 const it=A.filter(a=>sel.has(+a.id)),per=Math.max(1,g('cols')*g('rows')),lay=g('lay');$('cnt').textContent=it.length+' label(s), '+Math.ceil(it.length/per)+' page(s)';
 $('pgs').textContent=`@media print{@page{size:${W}mm ${H}mm;margin:0}}`;let h='';
 for(let i=0;i<it.length;i+=per){h+=`<div class=pg style="width:${W}mm;height:${H}mm;padding:${g('mg')}mm;gap:${g('gp')}mm;grid-template-columns:repeat(${g('cols')},${g('lw')}mm);grid-auto-rows:${g('lh')}mm">`+
  it.slice(i,i+per).map(a=>`<div class=lb><svg data-c="${esc(a.barcode)}"></svg>${lay>=1?'<div><b>'+esc(a.name)+'</b></div>':''}${lay>=2?'<div>S/N: '+esc(a.serial_no)+'</div>':''}${lay>=3?'<div>'+esc(a.holder||'Unassigned')+'</div>':''}</div>`).join('')+'</div>'}
 $('sheet').innerHTML=h;document.querySelectorAll('svg[data-c]').forEach(s=>{JsBarcode(s,s.dataset.c,{format:'CODE128',width:2,height:60,displayValue:true,fontSize:16,margin:0});
  const w=s.getAttribute('width').replace('px',''),hh=s.getAttribute('height').replace('px','');s.setAttribute('viewBox',`0 0 ${w} ${hh}`);s.setAttribute('preserveAspectRatio','none');s.removeAttribute('width');s.removeAttribute('height');s.style.height=g('bh')+'mm'})}
$('al').onchange=e=>{e.target.checked?sel.add(+e.target.value):sel.delete(+e.target.value);render()};$('f').oninput=list;
$('all').onclick=()=>{document.querySelectorAll('#al input').forEach(c=>sel.add(+c.value));list();render()};$('none').onclick=()=>{sel.clear();list();render()};
document.querySelectorAll('.ctl input,.ctl select').forEach(e=>{if(e.id!='f')e.addEventListener('input',render)});list();render();</script>
<?php foot();
