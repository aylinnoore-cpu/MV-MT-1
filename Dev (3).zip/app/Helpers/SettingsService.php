<?php
/**
 * Single typed access layer for system and workspace settings.
 *
 * System settings are global. Workspace settings are policy/configuration for the
 * current workspace. Values are cached for the request and invalidated after writes.
 */

declare(strict_types=1);

final class SettingsService
{
    /** @var array<string,string>|null */
    private static ?array $systemCache = null;
    /** @var array<int,array<string,string>> */
    private static array $workspaceCache = [];

    /** @var array<string,string> */
    private const SYSTEM_DEFAULTS = [
        'app_name' => 'TimeTrack',
        'company_email' => 'hello@timetrack.local',
        'date_format' => 'M j, Y',
        'time_format' => 'H:i',
        'currency' => 'USD',
        'currency_symbol' => '$',
        'default_hourly_rate' => '0',
        'default_timezone' => 'UTC',
        'timer_max_hours' => '12',
        'allow_manual_time_entries' => '1',
        'notifications_enabled' => '1',
        'maintenance_mode' => '0',
    ];

    /** @return array<string,string> */
    public static function system(): array
    {
        if (self::$systemCache !== null) return self::$systemCache;

        $keys = array_keys(self::SYSTEM_DEFAULTS);
        $rows = Database::fetchAll(
            'SELECT setting_key, setting_value FROM settings WHERE setting_key IN (' .
            implode(', ', array_fill(0, count($keys), '?')) . ')',
            $keys
        );
        $out = self::SYSTEM_DEFAULTS;
        foreach ($rows as $row) {
            $key = (string) $row['setting_key'];
            if (array_key_exists($key, $out)) $out[$key] = (string) ($row['setting_value'] ?? '');
        }
        return self::$systemCache = $out;
    }

    public static function systemString(string $key, ?string $default = null): string
    {
        $values = self::system();
        if (array_key_exists($key, $values)) return $values[$key];
        if ($default !== null) return $default;
        throw new InvalidArgumentException('Unknown system setting: ' . $key);
    }

    public static function systemInt(string $key, ?int $default = null): int
    {
        $value = self::systemString($key, $default === null ? null : (string) $default);
        return is_numeric($value) ? (int) $value : ($default ?? 0);
    }

    public static function systemFloat(string $key, ?float $default = null): float
    {
        $value = self::systemString($key, $default === null ? null : (string) $default);
        return is_numeric($value) ? (float) $value : ($default ?? 0.0);
    }

    public static function systemBool(string $key, ?bool $default = null): bool
    {
        $value = strtolower(trim(self::systemString($key, $default === null ? null : ($default ? '1' : '0'))));
        return in_array($value, ['1','true','yes','on'], true);
    }

    public static function systemTimezone(): string
    {
        $zone = self::systemString('default_timezone', 'UTC');
        return in_array($zone, DateTimeZone::listIdentifiers(), true) ? $zone : 'UTC';
    }

    public static function setSystem(string $key, string $value): void
    {
        if (!array_key_exists($key, self::SYSTEM_DEFAULTS)) {
            throw new InvalidArgumentException('Unknown system setting.');
        }
        Database::execute(
            'INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
             VALUES (:key, :value, :type, :grp, NULL)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP()',
            [
                'key' => $key,
                'value' => $value,
                'type' => in_array($key, ['allow_manual_time_entries','notifications_enabled','maintenance_mode'], true) ? 'bool' : 'string',
                'grp' => in_array($key, ['currency','currency_symbol','default_hourly_rate'], true) ? 'billing' : 'general',
            ]
        );
        self::clearSystemCache();
    }

    /** @return array<string,string> */
    public static function workspace(int $workspaceId): array
    {
        if ($workspaceId < 1) throw new InvalidArgumentException('Invalid workspace id.');
        if (isset(self::$workspaceCache[$workspaceId])) return self::$workspaceCache[$workspaceId];

        $defaults = Workspace::DEFAULT_SETTINGS;
        $rows = Database::fetchAll(
            'SELECT setting_key, setting_value FROM workspace_settings WHERE workspace_id = :id',
            ['id' => $workspaceId]
        );
        foreach ($rows as $row) {
            $key = (string) $row['setting_key'];
            if (array_key_exists($key, $defaults)) $defaults[$key] = (string) ($row['setting_value'] ?? '');
        }
        return self::$workspaceCache[$workspaceId] = $defaults;
    }

    public static function workspaceString(int $workspaceId, string $key, ?string $default = null): string
    {
        $values = self::workspace($workspaceId);
        if (array_key_exists($key, $values)) return $values[$key];
        if ($default !== null) return $default;
        throw new InvalidArgumentException('Unknown workspace setting: ' . $key);
    }

    public static function workspaceInt(int $workspaceId, string $key, ?int $default = null): int
    {
        $value = self::workspaceString($workspaceId, $key, $default === null ? null : (string) $default);
        return is_numeric($value) ? (int) $value : ($default ?? 0);
    }

    public static function workspaceFloat(int $workspaceId, string $key, ?float $default = null): float
    {
        $value = self::workspaceString($workspaceId, $key, $default === null ? null : (string) $default);
        return is_numeric($value) ? (float) $value : ($default ?? 0.0);
    }

    public static function workspaceBool(int $workspaceId, string $key, ?bool $default = null): bool
    {
        $value = strtolower(trim(self::workspaceString($workspaceId, $key, $default === null ? null : ($default ? '1' : '0'))));
        return in_array($value, ['1','true','yes','on'], true);
    }

    public static function setWorkspace(int $workspaceId, string $key, string $value): void
    {
        if (!array_key_exists($key, Workspace::DEFAULT_SETTINGS)) {
            throw new InvalidArgumentException('Unknown workspace setting.');
        }
        Database::execute(
            'INSERT INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
             VALUES (:workspace_id, :setting_key, :setting_value, UTC_TIMESTAMP())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP()',
            ['workspace_id' => $workspaceId, 'setting_key' => $key, 'setting_value' => $value]
        );
        self::clearWorkspaceCache($workspaceId);
    }

    public static function clearSystemCache(): void { self::$systemCache = null; }
    public static function clearWorkspaceCache(?int $workspaceId = null): void
    {
        if ($workspaceId === null) self::$workspaceCache = [];
        else unset(self::$workspaceCache[$workspaceId]);
    }
    public static function clearAllCaches(): void { self::clearSystemCache(); self::clearWorkspaceCache(); }
}
