<?php
/**
 * Teams used for the approval hierarchy (tables `teams`, `team_managers`, `team_members`).
 *
 *   Department ── Department Manager
 *     └── Team ── Team managers ── Members
 *
 * Not tied to a project. Teams can work on any project.
 * Not to be confused with the read-only Team model, which powers the /team people page.
 */

declare(strict_types=1);

final class TeamGroup
{
    public const STATUSES = ['active', 'inactive'];

    public static function installed(): bool
    {
        SchemaHelper::ensureOrgStructure();

        return SchemaHelper::tableExists('teams') && SchemaHelper::tableExists('team_members');
    }

    public static function multiManagersReady(): bool
    {
        return SchemaHelper::tableExists('team_managers');
    }

    /** @return array<string, mixed>|null */
    public function find(int $id): ?array
    {
        if ($id < 1) {
            return null;
        }

        $deptCol = SchemaHelper::columnExists('teams', 'department_id') ? ', t.department_id' : '';

        return Database::fetchOne(
            "SELECT t.id, t.name, t.manager_id, t.status{$deptCol}
             FROM teams t WHERE t.id = :id LIMIT 1",
            ['id' => $id]
        );
    }

    /**
     * @param list<int> $teamIds
     * @return array<int, list<array{id: int, name: string}>>
     */
    public function membersByTeam(array $teamIds): array
    {
        $teamIds = array_values(array_unique(array_filter(array_map('intval', $teamIds), static fn (int $id): bool => $id > 0)));
        if ($teamIds === []) {
            return [];
        }

        $in   = implode(',', $teamIds);
        $rows = Database::fetchAll(
            "SELECT tm.team_id, u.id, u.name
             FROM team_members tm
             INNER JOIN users u ON u.id = tm.user_id
             WHERE tm.team_id IN ({$in})
             ORDER BY u.name ASC"
        );

        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['team_id']][] = ['id' => (int) $row['id'], 'name' => (string) $row['name']];
        }

        return $out;
    }

    /**
     * @param list<int> $teamIds
     * @return array<int, list<array{id: int, name: string}>>
     */
    public function managersByTeam(array $teamIds): array
    {
        $teamIds = array_values(array_unique(array_filter(array_map('intval', $teamIds), static fn (int $id): bool => $id > 0)));
        if ($teamIds === []) {
            return [];
        }

        if (!self::multiManagersReady()) {
            $in   = implode(',', $teamIds);
            $rows = Database::fetchAll(
                "SELECT t.id AS team_id, u.id, u.name
                 FROM teams t
                 INNER JOIN users u ON u.id = t.manager_id
                 WHERE t.id IN ({$in}) AND t.manager_id IS NOT NULL
                 ORDER BY u.name ASC"
            );
            $out = [];
            foreach ($rows as $row) {
                $out[(int) $row['team_id']][] = ['id' => (int) $row['id'], 'name' => (string) $row['name']];
            }

            return $out;
        }

        $in   = implode(',', $teamIds);
        $rows = Database::fetchAll(
            "SELECT tmg.team_id, u.id, u.name
             FROM team_managers tmg
             INNER JOIN users u ON u.id = tmg.user_id
             WHERE tmg.team_id IN ({$in})
             ORDER BY u.name ASC"
        );

        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['team_id']][] = ['id' => (int) $row['id'], 'name' => (string) $row['name']];
        }

        return $out;
    }

    /** @return list<int> */
    public function memberIds(int $teamId): array
    {
        $rows = Database::fetchAll('SELECT user_id FROM team_members WHERE team_id = :id', ['id' => $teamId]);

        return array_map(static fn (array $row): int => (int) $row['user_id'], $rows);
    }

    /** @return list<int> */
    public function managerIds(int $teamId): array
    {
        if ($teamId < 1) {
            return [];
        }

        if (self::multiManagersReady()) {
            $rows = Database::fetchAll('SELECT user_id FROM team_managers WHERE team_id = :id', ['id' => $teamId]);

            return array_map(static fn (array $row): int => (int) $row['user_id'], $rows);
        }

        $id = (int) Database::fetchValue('SELECT manager_id FROM teams WHERE id = :id LIMIT 1', ['id' => $teamId]);

        return $id > 0 ? [$id] : [];
    }

    public function nameTaken(string $name, int $exceptId = 0, int $departmentId = 0): bool
    {
        if ($departmentId > 0 && SchemaHelper::columnExists('teams', 'department_id')) {
            return (int) Database::fetchValue(
                'SELECT COUNT(*) FROM teams WHERE department_id = :d AND name = :n AND id <> :id',
                ['d' => $departmentId, 'n' => $name, 'id' => $exceptId]
            ) > 0;
        }

        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM teams WHERE name = :n AND id <> :id',
            ['n' => $name, 'id' => $exceptId]
        ) > 0;
    }

    /**
     * @param array{name: string, manager_id: ?int, status: string, department_id?: ?int} $data
     * @param list<int> $memberIds
     * @param list<int> $managerIds
     */
    public function create(array $data, array $memberIds, int $createdBy, array $managerIds = []): int
    {
        return (int) Database::transaction(function () use ($data, $memberIds, $createdBy, $managerIds): int {
            $hasDept    = SchemaHelper::columnExists('teams', 'department_id');
            $hasProject = SchemaHelper::columnExists('teams', 'project_id');
            $primary    = $this->primaryManagerId($managerIds, $data['manager_id'] ?? null);

            $cols   = [];
            $marks  = [];
            $params = [
                'name'       => $data['name'],
                'manager_id' => $primary,
                'status'     => $data['status'],
                'created_by' => $createdBy > 0 ? $createdBy : null,
            ];

            if ($hasProject) {
                $cols[]  = 'project_id';
                $marks[] = 'NULL';
            }
            if ($hasDept) {
                $cols[]                = 'department_id';
                $marks[]               = ':department_id';
                $params['department_id'] = $data['department_id'] ?? null;
            }
            $cols[]  = 'name';
            $marks[] = ':name';
            $cols[]  = 'manager_id';
            $marks[] = ':manager_id';
            $cols[]  = 'status';
            $marks[] = ':status';
            $cols[]  = 'created_by';
            $marks[] = ':created_by';
            $cols[]  = 'created_at';
            $marks[] = 'UTC_TIMESTAMP()';
            $cols[]  = 'updated_at';
            $marks[] = 'UTC_TIMESTAMP()';

            Database::execute(
                'INSERT INTO teams (' . implode(', ', $cols) . ') VALUES (' . implode(', ', $marks) . ')',
                $params
            );
            $id = Database::lastInsertId();
            $this->syncMembers($id, $memberIds);
            $this->syncManagers($id, $managerIds !== [] ? $managerIds : ($primary !== null ? [$primary] : []));

            return $id;
        });
    }

    /**
     * @param array{name: string, manager_id: ?int, status: string, department_id?: ?int} $data
     * @param list<int> $memberIds
     * @param list<int> $managerIds
     */
    public function update(int $id, array $data, array $memberIds, array $managerIds = []): void
    {
        Database::transaction(function () use ($id, $data, $memberIds, $managerIds): void {
            $hasDept = SchemaHelper::columnExists('teams', 'department_id');
            $primary = $this->primaryManagerId($managerIds, $data['manager_id'] ?? null);

            $sql = 'UPDATE teams SET name = :name, manager_id = :manager_id, status = :status, updated_at = UTC_TIMESTAMP()';
            $params = [
                'name'       => $data['name'],
                'manager_id' => $primary,
                'status'     => $data['status'],
                'id'         => $id,
            ];
            if ($hasDept) {
                $sql .= ', department_id = :department_id';
                $params['department_id'] = $data['department_id'] ?? null;
            }
            $sql .= ' WHERE id = :id';
            Database::execute($sql, $params);
            $this->syncMembers($id, $memberIds);
            $this->syncManagers($id, $managerIds !== [] ? $managerIds : ($primary !== null ? [$primary] : []));
        });
    }

    public function delete(int $id): void
    {
        Database::execute('DELETE FROM teams WHERE id = :id', ['id' => $id]);
    }

    public function taskCount(int $teamId): int
    {
        if ($teamId < 1 || !SchemaHelper::columnExists('tasks', 'team_id')) {
            return 0;
        }

        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM tasks WHERE team_id = :id',
            ['id' => $teamId]
        );
    }

    public function taskCountForDepartment(int $departmentId): int
    {
        if ($departmentId < 1 || !SchemaHelper::columnExists('tasks', 'team_id') || !SchemaHelper::columnExists('teams', 'department_id')) {
            return 0;
        }

        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM tasks ta INNER JOIN teams t ON t.id = ta.team_id WHERE t.department_id = :id',
            ['id' => $departmentId]
        );
    }

    /** @param list<int> $memberIds */
    private function syncMembers(int $teamId, array $memberIds): void
    {
        Database::execute('DELETE FROM team_members WHERE team_id = :id', ['id' => $teamId]);

        foreach (array_values(array_unique($memberIds)) as $userId) {
            $userId = (int) $userId;
            if ($userId < 1) {
                continue;
            }
            Database::execute(
                'INSERT INTO team_members (team_id, user_id, created_at) VALUES (:t, :u, UTC_TIMESTAMP())',
                ['t' => $teamId, 'u' => $userId]
            );
        }
    }

    /** @param list<int> $managerIds */
    private function syncManagers(int $teamId, array $managerIds): void
    {
        $ids = array_values(array_unique(array_filter(
            array_map('intval', $managerIds),
            static fn (int $id): bool => $id > 0
        )));

        if (self::multiManagersReady()) {
            Database::execute('DELETE FROM team_managers WHERE team_id = :id', ['id' => $teamId]);
            foreach ($ids as $userId) {
                Database::execute(
                    'INSERT INTO team_managers (team_id, user_id, created_at) VALUES (:t, :u, UTC_TIMESTAMP())',
                    ['t' => $teamId, 'u' => $userId]
                );
            }
        }

        Database::execute(
            'UPDATE teams SET manager_id = :m WHERE id = :id',
            ['m' => $ids[0] ?? null, 'id' => $teamId]
        );
    }

    /** @param list<int> $managerIds */
    private function primaryManagerId(array $managerIds, mixed $fallback): ?int
    {
        foreach ($managerIds as $id) {
            $id = (int) $id;
            if ($id > 0) {
                return $id;
            }
        }
        $fallback = (int) ($fallback ?? 0);

        return $fallback > 0 ? $fallback : null;
    }
}
