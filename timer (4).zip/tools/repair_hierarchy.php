<?php
/**
 * CLI repair for project / team membership mismatches.
 *
 *   php tools/repair_hierarchy.php              dry-run (default)
 *   php tools/repair_hierarchy.php --dry-run    same
 *   php tools/repair_hierarchy.php --apply      write the changes
 *
 * (a) Inserts missing project_members rows for team manager / members as member.
 * (b) Demotes stray project_role=manager rows that are not projects.manager_id.
 * (c) Sets the true PM's row to manager (inserts it if missing).
 * Never deletes rows. Viewer rows are never overwritten; they are reported and skipped.
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found.\n");
}

if (PHP_VERSION_ID < 80200) {
    fwrite(STDERR, "PHP 8.2 or newer is required.\n");
    exit(1);
}

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CONFIG_PATH', BASE_PATH . '/config');
define('STORAGE_PATH', BASE_PATH . '/storage');

spl_autoload_register(static function (string $class): void {
    if (!preg_match('/^[A-Za-z][A-Za-z0-9]*$/', $class)) {
        return;
    }
    $names = [$class];
    if (str_ends_with($class, 'Helper')) {
        $names[] = substr($class, 0, -strlen('Helper'));
    }
    foreach (['Core', 'Helpers', 'Middleware', 'Controllers', 'Models'] as $folder) {
        foreach ($names as $name) {
            $file = APP_PATH . '/' . $folder . '/' . $name . '.php';
            if (is_file($file)) {
                require $file;
                return;
            }
        }
    }
});

date_default_timezone_set('UTC');
Config::load(require CONFIG_PATH . '/config.php');
Config::set('database', require CONFIG_PATH . '/database.php');

$options = getopt('', ['apply', 'dry-run', 'help']);
if (isset($options['help']) || $options === false) {
    fwrite(STDOUT, "Usage: php tools/repair_hierarchy.php [--dry-run|--apply]\n");
    fwrite(STDOUT, "       Default is --dry-run. --apply is required to write.\n");
    exit(isset($options['help']) ? 0 : 1);
}

$apply = isset($options['apply']);
$label = $apply ? 'APPLY' : 'DRY-RUN';
fwrite(STDOUT, "repair_hierarchy.php [{$label}]\n");

try {
    Database::fetchValue('SELECT 1');
} catch (Throwable $e) {
    fwrite(STDERR, "Database: FAILED (" . $e->getMessage() . ")\n");
    exit(1);
}

$changes = 0;
$skipped = 0;

$missing = Database::fetchAll(
    'SELECT x.project_id, p.name AS project_name, x.user_id, u.name AS user_name
     FROM (
          SELECT t.project_id, t.manager_id AS user_id FROM teams t WHERE t.manager_id IS NOT NULL
          UNION
          SELECT t.project_id, tm.user_id FROM team_members tm INNER JOIN teams t ON t.id = tm.team_id
     ) x
     INNER JOIN projects p ON p.id = x.project_id
     INNER JOIN users u ON u.id = x.user_id
     LEFT JOIN project_members pm ON pm.project_id = x.project_id AND pm.user_id = x.user_id
     WHERE pm.user_id IS NULL
     ORDER BY x.project_id, u.name'
);

foreach ($missing as $row) {
    $projectId = (int) $row['project_id'];
    $userId    = (int) $row['user_id'];
    $pmId      = (int) Database::fetchValue(
        'SELECT manager_id FROM projects WHERE id = :id LIMIT 1',
        ['id' => $projectId]
    );
    $role = $pmId === $userId ? 'manager' : 'member';
    fwrite(STDOUT, sprintf(
        "  + project_members project=%d (%s) user=%d (%s) role=%s\n",
        $projectId,
        (string) $row['project_name'],
        $userId,
        (string) $row['user_name'],
        $role
    ));
    if ($apply) {
        Database::execute(
            'INSERT INTO project_members (project_id, user_id, project_role, created_at)
             VALUES (:p, :u, :r, UTC_TIMESTAMP())',
            ['p' => $projectId, 'u' => $userId, 'r' => $role]
        );
        LoggerHelper::audit('hierarchy.member_inserted', 'project', $projectId, [
            'user_id' => $userId,
            'role'    => $role,
            'source'  => 'repair_hierarchy',
        ]);
    }
    $changes++;
}

$stray = Database::fetchAll(
    'SELECT pm.project_id, p.name AS project_name, pm.user_id, u.name AS user_name, p.manager_id
     FROM project_members pm
     INNER JOIN projects p ON p.id = pm.project_id
     INNER JOIN users u ON u.id = pm.user_id
     WHERE pm.project_role = :role
       AND (p.manager_id IS NULL OR p.manager_id <> pm.user_id)
     ORDER BY pm.project_id, u.name',
    ['role' => 'manager']
);

foreach ($stray as $row) {
    fwrite(STDOUT, sprintf(
        "  ~ demote manager project=%d (%s) user=%d (%s) -> member\n",
        (int) $row['project_id'],
        (string) $row['project_name'],
        (int) $row['user_id'],
        (string) $row['user_name']
    ));
    if ($apply) {
        Database::execute(
            'UPDATE project_members SET project_role = :member
             WHERE project_id = :p AND user_id = :u AND project_role = :manager',
            [
                'member'  => 'member',
                'p'       => (int) $row['project_id'],
                'u'       => (int) $row['user_id'],
                'manager' => 'manager',
            ]
        );
        LoggerHelper::audit('hierarchy.manager_demoted', 'project', (int) $row['project_id'], [
            'user_id' => (int) $row['user_id'],
            'source'  => 'repair_hierarchy',
        ]);
    }
    $changes++;
}

$viewers = Database::fetchAll(
    'SELECT x.project_id, p.name AS project_name, x.user_id, u.name AS user_name
     FROM (
          SELECT t.project_id, t.manager_id AS user_id FROM teams t WHERE t.manager_id IS NOT NULL
          UNION
          SELECT t.project_id, tm.user_id FROM team_members tm INNER JOIN teams t ON t.id = tm.team_id
     ) x
     INNER JOIN projects p ON p.id = x.project_id
     INNER JOIN users u ON u.id = x.user_id
     INNER JOIN project_members pm ON pm.project_id = x.project_id AND pm.user_id = x.user_id
     WHERE pm.project_role = :viewer
     ORDER BY x.project_id, u.name',
    ['viewer' => 'viewer']
);

foreach ($viewers as $row) {
    fwrite(STDOUT, sprintf(
        "  ! skip viewer project=%d (%s) user=%d (%s)\n",
        (int) $row['project_id'],
        (string) $row['project_name'],
        (int) $row['user_id'],
        (string) $row['user_name']
    ));
    $skipped++;
}

$pms = Database::fetchAll(
    'SELECT p.id AS project_id, p.name AS project_name, p.manager_id, u.name AS manager_name, pm.project_role
     FROM projects p
     INNER JOIN users u ON u.id = p.manager_id
     LEFT JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = p.manager_id
     WHERE p.manager_id IS NOT NULL
       AND (pm.user_id IS NULL OR pm.project_role <> :manager)
     ORDER BY p.id',
    ['manager' => 'manager']
);

foreach ($pms as $row) {
    $projectId = (int) $row['project_id'];
    $userId    = (int) $row['manager_id'];
    $hasRow    = $row['project_role'] !== null && $row['project_role'] !== '';
    fwrite(STDOUT, sprintf(
        "  %s PM manager role project=%d (%s) user=%d (%s)\n",
        $hasRow ? '~' : '+',
        $projectId,
        (string) $row['project_name'],
        $userId,
        (string) $row['manager_name']
    ));
    if ($apply) {
        if ($hasRow) {
            Database::execute(
                'UPDATE project_members SET project_role = :manager
                 WHERE project_id = :p AND user_id = :u',
                ['manager' => 'manager', 'p' => $projectId, 'u' => $userId]
            );
        } else {
            Database::execute(
                'INSERT INTO project_members (project_id, user_id, project_role, created_at)
                 VALUES (:p, :u, :r, UTC_TIMESTAMP())',
                ['p' => $projectId, 'u' => $userId, 'r' => 'manager']
            );
        }
        LoggerHelper::audit('hierarchy.pm_role_set', 'project', $projectId, [
            'user_id' => $userId,
            'source'  => 'repair_hierarchy',
        ]);
    }
    $changes++;
}

fwrite(STDOUT, sprintf(
    "Done. %d change(s)%s, %d viewer(s) skipped.\n",
    $changes,
    $apply ? ' applied' : ' would be applied',
    $skipped
));

exit(0);
