<?php
/**
 * Create / edit a team.
 *
 * @var array<string, mixed>|null $team
 * @var list<int> $memberIds
 * @var int $projectId
 * @var list<array<string, mixed>> $projects
 * @var list<array<string, mixed>> $people
 * @var list<string> $statuses
 */

$isEdit  = is_array($team);
$action  = $isEdit ? '/teams/' . (int) $team['id'] : '/teams';
$hasOld  = old('name') !== '' || old('project_id') !== '' || old_array('member_ids') !== [];

$name     = $hasOld ? old('name') : (string) ($team['name'] ?? '');
$selProj  = $hasOld ? (int) old('project_id', '0') : $projectId;
$selMgr   = $hasOld ? (int) old('manager_id', '0') : (int) ($team['manager_id'] ?? 0);
$selStat  = $hasOld ? old('status', 'active') : (string) ($team['status'] ?? 'active');
$selMembers = $hasOld ? array_map('intval', old_array('member_ids')) : $memberIds;
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading"><?= $isEdit ? 'Edit team' : 'New team' ?></h2>
        <p class="page-lead">A team sits under one project. Its team manager and the project manager review its members' timesheets.</p>
    </div>
    <a class="btn btn-outline-secondary" href="<?= e(url('/teams')) ?>">Back to teams</a>
</div>

<div class="row">
    <div class="col-lg-8">
        <section class="panel">
            <form method="post" action="<?= e(url($action)) ?>" novalidate>
                <?= csrf_field() ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="team-name" class="form-label">Team name</label>
                        <input type="text" id="team-name" name="name" maxlength="120" required
                               class="form-control<?= field_error('name') ? ' is-invalid' : '' ?>" value="<?= e($name) ?>">
                        <?php if (field_error('name')): ?><div class="invalid-feedback"><?= e(field_error('name')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="team-project-id" class="form-label">Project</label>
                        <select id="team-project-id" name="project_id" required class="form-select<?= field_error('project_id') ? ' is-invalid' : '' ?>">
                            <option value="">Choose a project</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= (int) $project['id'] ?>"<?= $selProj === (int) $project['id'] ? ' selected' : '' ?>>
                                    <?= e((string) $project['name']) ?> — PM: <?= !empty($project['manager_name']) ? e((string) $project['manager_name']) : 'not set' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('project_id')): ?><div class="invalid-feedback"><?= e(field_error('project_id')) ?></div><?php endif; ?>
                        <div class="form-text">The project manager of this project approves for every team in it.</div>
                    </div>
                    <div class="col-md-8">
                        <label for="team-manager" class="form-label">Team manager</label>
                        <select id="team-manager" name="manager_id" class="form-select<?= field_error('manager_id') ? ' is-invalid' : '' ?>">
                            <option value="0">None</option>
                            <?php foreach ($people as $person): ?>
                                <option value="<?= (int) $person['id'] ?>"<?= $selMgr === (int) $person['id'] ? ' selected' : '' ?>><?= e((string) $person['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('manager_id')): ?><div class="invalid-feedback"><?= e(field_error('manager_id')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <label for="team-status" class="form-label">Status</label>
                        <select id="team-status" name="status" class="form-select">
                            <?php foreach ($statuses as $status): ?>
                                <option value="<?= e($status) ?>"<?= $selStat === $status ? ' selected' : '' ?>><?= e(ucfirst($status)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <div class="d-flex justify-content-between align-items-end mb-1">
                            <label class="form-label mb-0">Members</label>
                            <input type="search" class="form-control form-control-sm w-auto" placeholder="Filter people" aria-label="Filter people" data-team-filter>
                        </div>
                        <div class="border rounded p-2" style="max-height:260px;overflow:auto" data-team-members>
                            <?php foreach ($people as $person): ?>
                                <div class="form-check" data-team-person data-name="<?= e(mb_strtolower((string) $person['name'], 'UTF-8')) ?>" data-user-id="<?= (int) $person['id'] ?>">
                                    <input class="form-check-input" type="checkbox" name="member_ids[]" id="member-<?= (int) $person['id'] ?>"
                                           value="<?= (int) $person['id'] ?>"<?= in_array((int) $person['id'], $selMembers, true) ? ' checked' : '' ?>>
                                    <label class="form-check-label" for="member-<?= (int) $person['id'] ?>">
                                        <?= e((string) $person['name']) ?> <span class="text-muted small">(<?= e((string) $person['role']) ?>)</span>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="form-text">The team manager is chosen above and does not need to be ticked here. A person can belong to several teams.</div>
                    </div>
                </div>
                <div class="mt-4 d-flex gap-2 flex-wrap">
                    <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Save team' : 'Create team' ?></button>
                    <a class="btn btn-outline-secondary" href="<?= e(url('/teams')) ?>">Cancel</a>
                </div>
            </form>
        </section>
    </div>
</div>
<script src="<?= e(asset('js/team-form.js')) ?>"></script>
