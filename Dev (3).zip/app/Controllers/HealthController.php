<?php
/**
 * GET /health : liveness probe for uptime monitors and a quick install check.
 *
 * Public by design, so it reveals nothing beyond ok / not ok unless app.debug is on
 * (PHP version and DB details help attackers fingerprint the server).
 */

declare(strict_types=1);

final class HealthController extends Controller
{
    public function __construct()
    {
        parent::__construct(false);
    }

    /** @param array<string, string> $params */
    public function index(Request $request, array $params): void
    {
        AuthHelper::releaseSession(); // read-only endpoint: do not hold the session lock

        $details = [];
        $healthy = true;

        try {
            $details['database_time_utc'] = (string) Database::fetchValue('SELECT UTC_TIMESTAMP()');
            $details['database_session_tz'] = (string) Database::fetchValue('SELECT @@session.time_zone');
        } catch (Throwable $e) {
            $healthy = false;
            LoggerHelper::exception($e);
        }

        $payload = ['ok' => $healthy, 'status' => $healthy ? 'ok' : 'database unavailable'];

        if (Config::get('app.debug', false)) {
            $payload['debug'] = $details + [
                'php_version' => PHP_VERSION,
                'app_env'     => Config::get('app.env'),
                'https'       => $request->isHttps(),
            ];
        }

        $this->json($payload, $healthy ? 200 : 503);
    }
}
