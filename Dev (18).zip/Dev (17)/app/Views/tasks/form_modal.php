<?php
/**
 * Add / edit task modal. Filled by assets/js/app.js (initTaskModal) from data-task-edit.
 * Included by tasks/panel.php (shares its variables).
 *
 * @var array<string, mixed> $project
 * @var list<array<string, mixed>> $members project members (assignee choices)
 * @var list<string> $taskStatuses
 * @var bool $canCreateTask
 * @var bool $canAssignTask
 */

$assignable = array_values(array_filter($members, static fn (array $m): bool => (string) ($m['status'] ?? 'active') === 'active'));
?>
<div class="modal fade" id="taskModal" tabindex="-1" aria-labelledby="taskModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form method="post" action="<?= e(url('/projects/' . (int) $project['id'] . '/tasks')) ?>"
              data-create-action="<?= e(url('/projects/' . (int) $project['id'] . '/tasks')) ?>"
              id="taskForm" class="modal-content" novalidate data-single-submit>
            <?= csrf_field() ?>
            <div class="modal-header">
                <h2 class="modal-title h5" id="taskModalTitle">Add task</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-12">
                        <label for="task_name" class="form-label">Task name</label>
                        <input type="text" id="task_name" name="name" maxlength="160" required class="form-control"
                               placeholder="e.g. CON - Building Envelope">
                    </div>
                    <div class="col-12">
                        <label for="task_description" class="form-label">Description <span class="text-secondary">(optional)</span></label>
                        <textarea id="task_description" name="description" rows="2" maxlength="2000" class="form-control"></textarea>
                    </div>
                    <div class="col-md-4">
                        <label for="task_status" class="form-label">Status</label>
                        <select id="task_status" name="status" class="form-select">
                            <?php foreach ($taskStatuses as $st): ?>
                                <option value="<?= e($st) ?>"><?= e($st) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="task_estimated_hours" class="form-label">Estimate (hours)</label>
                        <input type="number" id="task_estimated_hours" name="estimated_hours" min="0" max="9999" step="0.25" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="task_due_date" class="form-label">Due date</label>
                        <input type="date" id="task_due_date" name="due_date" class="form-control">
                    </div>

                    <?php if ($canAssignTask): ?>
                        <div class="col-12">
                            <span class="form-label d-block">Assignees</span>
                            <?php if ($assignable === []): ?>
                                <p class="text-secondary small mb-0">Add members to the project first (Overview tab) to assign tasks to people.</p>
                            <?php else: ?>
                                <div class="task-assignee-grid">
                                    <?php foreach ($assignable as $member): ?>
                                        <label class="task-assignee-pick">
                                            <input type="checkbox" class="task-assignee" name="assignee_ids[]" value="<?= (int) $member['user_id'] ?>">
                                            <span><?= e($member['name']) ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                                <p class="text-secondary small mt-2 mb-0">Leave everyone unchecked to let <strong>anyone</strong> on the project use this task.</p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" id="taskSubmit">Add task</button>
            </div>
        </form>
    </div>
</div>
