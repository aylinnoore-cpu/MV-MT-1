<?php
/**
 * Tasks: work items on a project, with hierarchical subtasks and assignees.
 *
 * A task with no task_assignees rows is open to "Anyone" on the project.
 */

declare(strict_types=1);

final class Task extends Model
{
    public const STATUS_TODO        = 'To Do';
    public const STATUS_IN_PROGRESS = 'In Progress';
    public const STATUS_ON_HOLD     = 'On Hold';
    public const STATUS_REVIEW      = 'Review';
    public const STATUS_COMPLETED   = 'Completed';
    public const STATUS_CANCELLED   = 'Cancelled';

    /** Legacy values still present on some live databases before the Phase 3 upgrade. */
    public const STATUS_OPEN = 'Open';
    public const STATUS_DONE = 'Done';

    public const STATUSES = [
        self::STATUS_TODO,
        self::STATUS_IN_PROGRESS,
        self::STATUS_ON_HOLD,
        self::STATUS_REVIEW,
        self::STATUS_COMPLETED,
        self::STATUS_CANCELLED,
    ];

    public const ACTIVE_STATUSES = [
        self::STATUS_TODO,
        self::STATUS_IN_PROGRESS,
        self::STATUS_ON_HOLD,
        self::STATUS_REVIEW,
        self::STATUS_OPEN,
    ];

    public const DONE_STATUSES = [
        self::STATUS_COMPLETED,
        self::STATUS_DONE,
    ];

    public const CLOSED_STATUSES = [
        self::STATUS_COMPLETED,
        self::STATUS_DONE,
        self::STATUS_CANCELLED,
    ];

    public const PRIORITY_LOW    = 'Low';
    public const PRIORITY_MEDIUM = 'Medium';
    public const PRIORITY_HIGH   = 'High';
    public const PRIORITY_URGENT = 'Urgent';

    public const PRIORITIES = [
        self::PRIORITY_LOW,
        self::PRIORITY_MEDIUM,
        self::PRIORITY_HIGH,
        self::PRIORITY_URGENT,
    ];

    protected string $table = 'tasks';

    protected array $columns = [
        'id', 'project_id', 'parent_task_id', 'name', 'description',
        'status', 'priority', 'estimated_hours',
        'completion_percent', 'start_date', 'due_date', 'is_billable',
        'created_by', 'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'project_id', 'parent_task_id', 'name', 'description',
        'status', 'priority', 'estimated_hours',
        'completion_percent', 'start_date', 'due_date', 'is_billable',
        'created_by',
    ];

    /** True when the tasks tables have been installed (part of the live database). */
    public static function installed(): bool
    {
        return SchemaHelper::tableExists('tasks') && SchemaHelper::tableExists('task_assignees');
    }

    public static function hasColumn(string $name): bool
    {
        return SchemaHelper::columnExists('tasks', $name);
    }

    public static function normalizeStatus(string $status): string
    {
        return match ($status) {
            self::STATUS_OPEN, 'Todo', 'TODO' => self::STATUS_TODO,
            self::STATUS_DONE, 'Done', 'Complete' => self::STATUS_COMPLETED,
            default => $status,
        };
    }

    /** Map a canonical status onto whatever the live ENUM still allows. */
    public static function persistStatus(string $status): string
    {
        $status = self::normalizeStatus($status);
        if (self::statusEnumAllows($status)) {
            return $status;
        }

        return match ($status) {
            self::STATUS_TODO => self::statusEnumAllows(self::STATUS_OPEN)
                ? self::STATUS_OPEN : $status,
            self::STATUS_COMPLETED => self::statusEnumAllows(self::STATUS_DONE)
                ? self::STATUS_DONE : $status,
            self::STATUS_CANCELLED => self::statusEnumAllows(self::STATUS_DONE)
                ? self::STATUS_DONE : $status,
            self::STATUS_ON_HOLD, self::STATUS_REVIEW => self::statusEnumAllows(self::STATUS_IN_PROGRESS)
                ? self::STATUS_IN_PROGRESS : $status,
            default => $status,
        };
    }

    public static function statusEnumAllows(string $value): bool
    {
        return in_array($value, self::enumValues('status'), true);
    }

    /** @return list<string> */
    public static function enumValues(string $column): array
    {
        static $cache = [];

        if (isset($cache[$column])) {
            return $cache[$column];
        }

        $cache[$column] = [];
        try {
            $type = (string) Database::fetchValue(
                "SELECT COLUMN_TYPE FROM information_schema.columns
                 WHERE table_schema = DATABASE() AND table_name = 'tasks' AND COLUMN_NAME = :col",
                ['col' => $column]
            );
            if (preg_match_all("/'((?:\\\\'|[^'])*)'/", $type, $matches)) {
                $cache[$column] = array_map(
                    static fn (string $v): string => str_replace("\\'", "'", $v),
                    $matches[1]
                );
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('Task enum values lookup failed', ['column' => $column, 'error' => $e->getMessage()]);
            $cache[$column] = [];
        }

        return $cache[$column];
    }

    public static function isDone(string $status): bool
    {
        return in_array(self::normalizeStatus($status), [self::STATUS_COMPLETED], true)
            || in_array($status, self::DONE_STATUSES, true);
    }

    public static function isClosed(string $status): bool
    {
        return in_array(self::normalizeStatus($status), self::CLOSED_STATUSES, true)
            || in_array($status, self::CLOSED_STATUSES, true);
    }

    public static function percentForStatus(string $status): int
    {
        return match (self::normalizeStatus($status)) {
            self::STATUS_TODO        => 0,
            self::STATUS_IN_PROGRESS => 40,
            self::STATUS_ON_HOLD     => 40,
            self::STATUS_REVIEW      => 80,
            self::STATUS_COMPLETED   => 100,
            self::STATUS_CANCELLED   => 0,
            default                  => 0,
        };
    }

    public static function statusCss(string $status): string
    {
        return match (self::normalizeStatus($status)) {
            self::STATUS_TODO        => 'planning',
            self::STATUS_IN_PROGRESS => 'active',
            self::STATUS_ON_HOLD     => 'hold',
            self::STATUS_REVIEW      => 'archived',
            self::STATUS_COMPLETED   => 'completed',
            self::STATUS_CANCELLED   => 'cancelled',
            default                  => 'planning',
        };
    }

    public static function priorityCss(string $priority): string
    {
        return match ($priority) {
            self::PRIORITY_LOW    => 'low',
            self::PRIORITY_HIGH   => 'high',
            self::PRIORITY_URGENT => 'urgent',
            default               => 'medium',
        };
    }

    /**
     * One task with project, assignee, creator, hours and assignees attached.
     *
     * @return array<string, mixed>|null
     */
    public function findDetailed(int $id): ?array
    {
        if ($id < 1 || !self::installed()) {
            return null;
        }

        $row = Database::fetchOne(
            $this->selectSql() . ' WHERE t.id = :id LIMIT 1',
            ['id' => $id]
        );

        if ($row === null) {
            return null;
        }

        $rows = $this->attachAssignees([$this->hydrate($row)]);

        return $rows[0] ?? null;
    }

    /**
     * Tasks of one project with their assignees attached.
     *
     * @param string $filter 'active' (not Completed/Cancelled), 'done' or 'all'
     * @return list<array<string, mixed>>
     */
    public function forProject(int $projectId, string $filter = 'active', string $search = '', string $dir = 'asc'): array
    {
        $where  = ['t.project_id = :project_id'];
        $params = ['project_id' => $projectId];

        if ($filter === 'active') {
            $where[] = $this->notClosedSql('t');
        } elseif ($filter === 'done') {
            $where[] = $this->doneSql('t');
        }

        $search = trim($search);
        if ($search !== '') {
            $where[]     = 't.name LIKE :q';
            $params['q'] = '%' . self::like($search) . '%';
        }

        $direction = $dir === 'desc' ? 'DESC' : 'ASC';
        $rows = Database::fetchAll(
            $this->selectSql() . '
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY ' . $this->closedOrderSql('t') . ', t.name ' . $direction,
            $params
        );

        return $this->attachAssignees(array_map([$this, 'hydrate'], $rows));
    }

    /**
     * Nested subtask tree for one project (roots first, children on `children`).
     *
     * @return list<array<string, mixed>>
     */
    public function treeForProject(int $projectId, string $filter = 'all', string $search = '', string $dir = 'asc'): array
    {
        return $this->nest($this->forProject($projectId, $filter, $search, $dir));
    }

    /**
     * Nested tree starting at one task (the task itself plus descendants).
     *
     * @param array<string, mixed> $task
     * @return array<string, mixed>
     */
    public function treeFrom(array $task): array
    {
        $all  = $this->forProject((int) $task['project_id'], 'all');
        $byId = [];
        foreach ($all as $row) {
            $byId[(int) $row['id']] = $row;
        }

        $nested = $this->nest($all, $this->parentId($task));
        foreach ($nested as $node) {
            if ((int) $node['id'] === (int) $task['id']) {
                return $node;
            }
        }

        $task['children'] = $this->nest($all, (int) $task['id']);

        return $task;
    }

    /**
     * Direct children of a task, ordered for the checklist.
     *
     * @return list<array<string, mixed>>
     */
    public function childrenOf(int $parentId): array
    {
        if ($parentId < 1 || !self::hasColumn('parent_task_id')) {
            return [];
        }

        $rows = Database::fetchAll(
            $this->selectSql() . '
             WHERE t.parent_task_id = :id
             ORDER BY ' . $this->closedOrderSql('t') . ', t.name ASC',
            ['id' => $parentId]
        );

        return $this->attachAssignees(array_map([$this, 'hydrate'], $rows));
    }

    /**
     * Possible parents for a task in a project (excludes self and descendants).
     *
     * @return list<array<string, mixed>>
     */
    public function parentOptions(int $projectId, ?int $excludeId = null): array
    {
        $rows = $this->forProject($projectId, 'all');
        if ($excludeId === null) {
            return $rows;
        }

        $blocked = array_fill_keys($this->descendantIds($excludeId, $rows), true);
        $blocked[$excludeId] = true;

        return array_values(array_filter(
            $rows,
            static fn (array $row): bool => !isset($blocked[(int) $row['id']])
        ));
    }

    /**
     * Flatten a nested tree into a depth-annotated list for dropdowns and tables.
     *
     * @param list<array<string, mixed>> $nodes
     * @return list<array<string, mixed>>
     */
    public function flatten(array $nodes, int $depth = 0): array
    {
        $out = [];
        foreach ($nodes as $node) {
            $children = $node['children'] ?? [];
            $node['depth'] = $depth;
            unset($node['children']);
            $out[] = $node;
            if ($children !== []) {
                foreach ($this->flatten($children, $depth + 1) as $child) {
                    $out[] = $child;
                }
            }
        }

        return $out;
    }

    /**
     * Filtered, paginated list for the standalone Tasks page.
     *
     * @param array{
     *     scope?: string,
     *     project_id?: int,
     *     assigned_to?: int,
     *     status?: string,
     *     priority?: string,
     *     due?: string,
     *     q?: string,
     *     sort?: string,
     *     dir?: string
     * } $filters
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, counts: array<string, int>}
     */
    public function listFiltered(array $filters, int $page, int $perPage, int $userId, bool $viewAll): array
    {
        $perPage = min(100, max(1, $perPage));
        [$whereSql, $params] = $this->filterClause($filters, $userId, $viewAll);

        $total = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM tasks t
             INNER JOIN projects p ON p.id = t.project_id' . $whereSql,
            $params
        );

        $pages = max(1, (int) ceil($total / $perPage));
        $page  = min(max(1, $page), $pages);

        $sort = (string) ($filters['sort'] ?? 'due');
        $dir  = strtolower((string) ($filters['dir'] ?? 'asc')) === 'desc' ? 'DESC' : 'ASC';
        $order = match ($sort) {
            'name'     => 't.name ' . $dir,
            'status'   => 't.status ' . $dir . ', t.name ASC',
            'priority' => "FIELD(t.priority, 'Urgent','High','Medium','Low') " . ($dir === 'DESC' ? 'DESC' : 'ASC') . ', t.name ASC',
            'project'  => 'p.name ' . $dir . ', t.name ASC',
            'assignee' => 'assignee.name ' . $dir . ', t.name ASC',
            default    => 't.due_date IS NULL, t.due_date ' . $dir . ', t.name ASC',
        };

        $params['limit']  = $perPage;
        $params['offset'] = ($page - 1) * $perPage;

        $rows = Database::fetchAll(
            $this->selectSql() . $whereSql . '
             ORDER BY ' . $order . '
             LIMIT :limit OFFSET :offset',
            $params
        );

        $items = $this->attachAssignees(array_map([$this, 'hydrate'], $rows));
        $items = $this->attachHours($items);

        return [
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => $pages,
            'counts'   => $this->scopeCounts($filters, $userId, $viewAll),
        ];
    }

    /**
     * Kanban columns for the current filters (no pagination).
     *
     * @param array<string, mixed> $filters
     * @return array<string, list<array<string, mixed>>>
     */
    public function kanbanColumns(array $filters, int $userId, bool $viewAll): array
    {
        $filters['status'] = '';
        [$whereSql, $params] = $this->filterClause($filters, $userId, $viewAll);

        $rows = Database::fetchAll(
            $this->selectSql() . $whereSql . '
             ORDER BY t.priority = \'Urgent\' DESC, t.priority = \'High\' DESC, t.due_date IS NULL, t.due_date ASC, t.name ASC
             LIMIT 400',
            $params
        );

        $items = $this->attachHours($this->attachAssignees(array_map([$this, 'hydrate'], $rows)));
        $columns = [];
        foreach (self::STATUSES as $status) {
            $columns[$status] = [];
        }
        foreach ($items as $item) {
            $status = self::normalizeStatus((string) $item['status']);
            if (!isset($columns[$status])) {
                $columns[$status] = [];
            }
            $columns[$status][] = $item;
        }

        return $columns;
    }

    /**
     * Tasks with tracked seconds, for the Status tab.
     *
     * @param string $filter all|active|done
     * @param string $sort   name|tracked
     * @return list<array<string, mixed>>
     */
    public function statusRows(int $projectId, string $filter = 'all', string $sort = 'name', string $dir = 'asc'): array
    {
        $where = ['t.project_id = :project_id'];
        if ($filter === 'active') {
            $where[] = $this->notClosedSql('t');
        } elseif ($filter === 'done') {
            $where[] = $this->doneSql('t');
        }

        $direction = $dir === 'desc' ? 'DESC' : 'ASC';
        $order     = $sort === 'tracked' ? 'tracked_seconds ' . $direction . ', t.name ASC' : 't.name ' . $direction;

        try {
            $rows = Database::fetchAll(
                'SELECT t.id, t.name, t.status, COALESCE(SUM(te.duration_seconds), 0) AS tracked_seconds
                 FROM tasks t
                 LEFT JOIN time_entries te ON te.task_id = t.id
                 WHERE ' . implode(' AND ', $where) . '
                 GROUP BY t.id, t.name, t.status
                 ORDER BY ' . $order,
                ['project_id' => $projectId]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Task list with tracked seconds failed', ['error' => $e->getMessage()]);
            $rows = Database::fetchAll(
                'SELECT t.id, t.name, t.status, 0 AS tracked_seconds
                 FROM tasks t WHERE ' . implode(' AND ', $where) . ' ORDER BY t.name ' . $direction,
                ['project_id' => $projectId]
            );
        }

        return $this->attachAssignees($rows);
    }

    /** Seconds tracked on the whole project (including entries without a task). */
    public function projectTrackedSeconds(int $projectId): int
    {
        try {
            return (int) Database::fetchValue(
                'SELECT COALESCE(SUM(duration_seconds), 0) FROM time_entries WHERE project_id = :id',
                ['id' => $projectId]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Task projectTrackedSeconds failed', ['error' => $e->getMessage()]);
            return 0;
        }
    }

    /**
     * Planned hours vs tracked actual hours for one task (includes descendants).
     *
     * @return array{planned_hours: float, tracked_seconds: int, tracked_hours: float}
     */
    public function hoursFor(int $taskId): array
    {
        $ids = $this->idWithDescendants($taskId);
        $marks = [];
        $params = [];
        foreach ($ids as $i => $id) {
            $marks[]           = ':h' . $i;
            $params['h' . $i]  = $id;
        }
        $in = implode(',', $marks);

        $planned = 0.0;
        try {
            $planned = (float) Database::fetchValue(
                "SELECT COALESCE(SUM(estimated_hours), 0) FROM tasks WHERE id IN ({$in})",
                $params
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Task planned hours lookup failed', ['error' => $e->getMessage()]);
            $planned = 0.0;
        }

        $tracked = 0;
        try {
            $tracked = (int) Database::fetchValue(
                "SELECT COALESCE(SUM(duration_seconds), 0) FROM time_entries WHERE task_id IN ({$in})",
                $params
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Task tracked hours lookup failed', ['error' => $e->getMessage()]);
            $tracked = 0;
        }

        return [
            'planned_hours'   => round($planned, 2),
            'tracked_seconds' => $tracked,
            'tracked_hours'   => round($tracked / 3600, 2),
        ];
    }

    /**
     * Time log history for a task (own entries only, newest first).
     *
     * @return list<array<string, mixed>>
     */
    public function timeLog(int $taskId, int $limit = 50): array
    {
        if ($taskId < 1 || !class_exists('TimeEntry') || !TimeEntry::installed()) {
            return [];
        }

        try {
            return Database::fetchAll(
                'SELECT te.id, te.user_id, te.started_at, te.ended_at, te.duration_seconds,
                        te.description, te.is_billable, u.name AS user_name
                 FROM time_entries te
                 INNER JOIN users u ON u.id = te.user_id
                 WHERE te.task_id = :id
                 ORDER BY te.started_at DESC, te.id DESC
                 LIMIT :limit',
                ['id' => $taskId, 'limit' => max(1, $limit)]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Task timeLog failed', ['error' => $e->getMessage()]);
            return [];
        }
    }

    /**
     * Planned schedule blocks linked to this task.
     *
     * @return list<array<string, mixed>>
     */
    public function scheduleHistory(int $taskId, int $limit = 40): array
    {
        if ($taskId < 1) {
            return [];
        }

        try {
            return Database::fetchAll(
                'SELECT s.id, s.user_id, s.start_datetime, s.end_datetime, s.estimated_hours,
                        s.status, s.notes, u.name AS user_name
                 FROM schedules s
                 INNER JOIN users u ON u.id = s.user_id
                 WHERE s.task_id = :id
                 ORDER BY s.start_datetime DESC, s.id DESC
                 LIMIT :limit',
                ['id' => $taskId, 'limit' => max(1, $limit)]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Task scheduleHistory failed', ['error' => $e->getMessage()]);
            return [];
        }
    }

    /** @return array{all: int, active: int, done: int} */
    public function counts(int $projectId): array
    {
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS total,
                    COALESCE(SUM(' . $this->notClosedSql() . '), 0) AS active,
                    COALESCE(SUM(' . $this->doneSql() . '), 0) AS done
             FROM tasks WHERE project_id = :id',
            ['id' => $projectId]
        );

        return [
            'all'    => (int) ($row['total'] ?? 0),
            'active' => (int) ($row['active'] ?? 0),
            'done'   => (int) ($row['done'] ?? 0),
        ];
    }

    public function nameTaken(int $projectId, string $name, ?int $ignoreId = null, ?int $parentId = null): bool
    {
        $sql    = 'SELECT COUNT(*) FROM tasks WHERE project_id = :project_id AND name = :name';
        $params = ['project_id' => $projectId, 'name' => $name];

        if ($ignoreId !== null) {
            $sql .= ' AND id <> :id';
            $params['id'] = $ignoreId;
        }

        if (self::hasColumn('parent_task_id')) {
            if ($parentId === null) {
                $sql .= ' AND parent_task_id IS NULL';
            } else {
                $sql .= ' AND parent_task_id = :parent_id';
                $params['parent_id'] = $parentId;
            }
        }

        return (int) Database::fetchValue($sql, $params) > 0;
    }

    public function create(array $data): int
    {
        return parent::create($this->prepareWrite($data));
    }

    public function update(int $id, array $data): int
    {
        return parent::update($id, $this->prepareWrite($data));
    }

    public function setStatus(int $id, string $status, ?int $percent = null): int
    {
        $status  = self::normalizeStatus($status);
        $percent = $percent !== null ? max(0, min(100, $percent)) : self::percentForStatus($status);

        $data = ['status' => $status];
        if (self::hasColumn('completion_percent')) {
            $data['completion_percent'] = $percent;
        }

        $changed = $this->update($id, $data);
        $this->recalculateAncestors($id);

        return $changed;
    }

    /**
     * Recalculate every ancestor of $taskId (its parent, grandparent, ...) from their children.
     */
    public function recalculateAncestors(int $taskId): void
    {
        if (!self::hasColumn('parent_task_id')) {
            return;
        }

        $task = $this->find($taskId);
        $parentId = $task !== null ? $this->parentId($task) : null;

        if ($parentId !== null) {
            $this->refreshFrom($parentId);
        }
    }

    /**
     * Recalculate $nodeId from its direct children, then keep walking up to the root.
     *
     * Rules:
     *  - Cancelled children are ignored (they neither help nor hurt progress).
     *  - Completion % is the average of the remaining children.
     *  - All remaining children Completed  -> parent Completed (100%).
     *  - Any remaining child started       -> parent In Progress.
     *  - Otherwise                         -> parent To Do.
     *  - A parent a person parked as On Hold / Review / Cancelled keeps that status until
     *    every child is done; only its percentage follows the children.
     *  - A parent with no children is left alone (its own status/percent are authoritative).
     */
    public function refreshFrom(int $nodeId): void
    {
        if (!self::hasColumn('parent_task_id')) {
            return;
        }

        $hasPct = self::hasColumn('completion_percent');
        $current = $nodeId;
        $guard = 0;

        while ($current > 0 && $guard < 32) {
            $node = $this->find($current);
            if ($node === null) {
                break;
            }

            $children = Database::fetchAll(
                'SELECT id, status' . ($hasPct ? ', completion_percent' : '') . '
                 FROM tasks WHERE parent_task_id = :id',
                ['id' => $current]
            );

            if ($children !== []) {
                $sum = 0;
                $counted = 0;
                $allDone = true;
                $anyStarted = false;

                foreach ($children as $child) {
                    $st = self::normalizeStatus((string) $child['status']);
                    if ($st === self::STATUS_CANCELLED) {
                        continue;
                    }

                    $counted++;
                    $pct = $hasPct
                        ? (int) ($child['completion_percent'] ?? self::percentForStatus($st))
                        : self::percentForStatus($st);
                    $sum += $pct;

                    if ($st !== self::STATUS_COMPLETED) {
                        $allDone = false;
                    }
                    if ($st !== self::STATUS_TODO) {
                        $anyStarted = true;
                    }
                }

                if ($counted > 0) {
                    $own = self::normalizeStatus((string) ($node['status'] ?? self::STATUS_TODO));
                    $parked = in_array($own, [self::STATUS_ON_HOLD, self::STATUS_REVIEW, self::STATUS_CANCELLED], true);

                    if ($allDone) {
                        $status = self::STATUS_COMPLETED;
                    } elseif ($parked) {
                        $status = $own;
                    } else {
                        $status = $anyStarted ? self::STATUS_IN_PROGRESS : self::STATUS_TODO;
                    }

                    $payload = ['status' => $status];
                    if ($hasPct) {
                        $payload['completion_percent'] = $allDone ? 100 : (int) round($sum / $counted);
                    }
                    $this->update($current, $payload);
                }
            }

            $next = $this->parentId($node);
            if ($next === null) {
                break;
            }
            $current = $next;
            $guard++;
        }
    }

    /**
     * Replace a task's assignees. Only users who belong to the project are kept.
     *
     * @param list<int> $userIds
     * @param list<int> $allowedUserIds project members (the only valid assignees)
     */
    public function syncAssignees(int $taskId, array $userIds, array $allowedUserIds): void
    {
        $userIds = array_values(array_unique(array_intersect(
            array_map('intval', $userIds),
            array_map('intval', $allowedUserIds)
        )));

        Database::transaction(function () use ($taskId, $userIds): void {
            Database::execute('DELETE FROM task_assignees WHERE task_id = :id', ['id' => $taskId]);

            foreach ($userIds as $userId) {
                Database::execute(
                    'INSERT INTO task_assignees (task_id, user_id) VALUES (:task_id, :user_id)',
                    ['task_id' => $taskId, 'user_id' => $userId]
                );
            }
        });
    }

    /** Delete a task and its subtasks; schedule blocks that pointed at them are kept but detached. */
    public function deleteWithLinks(int $id): void
    {
        $ids = $this->idWithDescendants($id);

        Database::transaction(static function () use ($ids): void {
            foreach ($ids as $taskId) {
                try {
                    Database::execute('UPDATE schedules SET task_id = NULL WHERE task_id = :id', ['id' => $taskId]);
                } catch (Throwable $e) {
                    LoggerHelper::debug('Task detach schedules failed', ['error' => $e->getMessage()]);
                }
                try {
                    Database::execute('UPDATE time_entries SET task_id = NULL WHERE task_id = :id', ['id' => $taskId]);
                } catch (Throwable $e) {
                    LoggerHelper::debug('Task detach time entries failed', ['error' => $e->getMessage()]);
                }
                Database::execute('DELETE FROM task_assignees WHERE task_id = :id', ['id' => $taskId]);
            }

            // Delete leaves first so parent_task_id FK does not block the row.
            foreach (array_reverse($ids) as $taskId) {
                Database::execute('DELETE FROM tasks WHERE id = :id', ['id' => $taskId]);
            }
        });
    }

    /**
     * @param list<array<string, mixed>> $tasks
     * @return list<array<string, mixed>>
     */
    public function nest(array $tasks, ?int $parentId = null): array
    {
        if (!self::hasColumn('parent_task_id')) {
            foreach ($tasks as &$task) {
                $task['children'] = [];
                $task['depth'] = 0;
            }
            unset($task);

            return $tasks;
        }

        $out = [];
        foreach ($tasks as $task) {
            if ($this->parentId($task) === $parentId) {
                $task['children'] = $this->nest($tasks, (int) $task['id']);
                $out[] = $task;
            }
        }

        return $out;
    }

    /**
     * @param list<array<string, mixed>> $tasks
     * @return list<int>
     */
    private function descendantIds(int $id, array $tasks): array
    {
        $ids = [];
        foreach ($tasks as $task) {
            if ($this->parentId($task) === $id) {
                $childId = (int) $task['id'];
                $ids[] = $childId;
                foreach ($this->descendantIds($childId, $tasks) as $nested) {
                    $ids[] = $nested;
                }
            }
        }

        return $ids;
    }

    /** @return list<int> */
    private function idWithDescendants(int $id): array
    {
        $ids = [$id];
        if (!self::hasColumn('parent_task_id')) {
            return $ids;
        }

        $task = $this->find($id);
        if ($task === null) {
            return $ids;
        }

        $all = Database::fetchAll(
            'SELECT id, parent_task_id FROM tasks WHERE project_id = :pid',
            ['pid' => (int) $task['project_id']]
        );

        return array_merge($ids, $this->descendantIds($id, $all));
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function filterClause(array $filters, int $userId, bool $viewAll): array
    {
        $where  = [];
        $params = [];

        if (!$viewAll) {
            $where[] = '(p.manager_id = :uid_mgr OR p.created_by = :uid_own
                OR EXISTS (SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = :uid_mem))';
            $params['uid_mgr'] = $userId;
            $params['uid_own'] = $userId;
            $params['uid_mem'] = $userId;
        }

        $scope = (string) ($filters['scope'] ?? 'mine');
        if ($scope !== 'all') {
            $where[] = 'EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id = t.id AND ta.user_id = :scope_uid)';
            $params['scope_uid'] = $userId;
        }

        $projectId = (int) ($filters['project_id'] ?? 0);
        if ($projectId > 0) {
            $where[]              = 't.project_id = :project_id';
            $params['project_id'] = $projectId;
        }

        $assigneeId = (int) ($filters['assigned_to'] ?? 0);
        if ($assigneeId > 0) {
            $where[] = 'EXISTS (SELECT 1 FROM task_assignees ta2 WHERE ta2.task_id = t.id AND ta2.user_id = :assignee)';
            $params['assignee'] = $assigneeId;
        }

        $status = self::normalizeStatus((string) ($filters['status'] ?? ''));
        if ($status !== '' && in_array($status, self::STATUSES, true)) {
            if ($status === self::STATUS_TODO) {
                $where[] = "(t.status IN ('To Do','Open'))";
            } elseif ($status === self::STATUS_COMPLETED) {
                $where[] = "(t.status IN ('Completed','Done'))";
            } else {
                $where[]          = 't.status = :status';
                $params['status'] = $status;
            }
        }

        $priority = (string) ($filters['priority'] ?? '');
        if ($priority !== '' && in_array($priority, self::PRIORITIES, true) && self::hasColumn('priority')) {
            $where[]            = 't.priority = :priority';
            $params['priority'] = $priority;
        }

        $due = (string) ($filters['due'] ?? '');
        if ($due === 'overdue') {
            $where[] = 't.due_date IS NOT NULL AND t.due_date < UTC_DATE() AND ' . $this->notClosedSql('t');
        } elseif ($due === 'today') {
            $where[] = 't.due_date = UTC_DATE()';
        } elseif ($due === 'week') {
            $where[] = 't.due_date IS NOT NULL AND t.due_date BETWEEN UTC_DATE() AND DATE_ADD(UTC_DATE(), INTERVAL 7 DAY)';
        } elseif ($due === 'none') {
            $where[] = 't.due_date IS NULL';
        } elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $due) === 1) {
            $where[]       = 't.due_date = :due_date';
            $params['due_date'] = $due;
        }

        $search = trim((string) ($filters['q'] ?? ''));
        if ($search !== '') {
            $term = '%' . self::like($search) . '%';
            $where[] = '(t.name LIKE :q_name OR t.description LIKE :q_desc OR p.name LIKE :q_project)';
            $params['q_name']    = $term;
            $params['q_desc']    = $term;
            $params['q_project'] = $term;
        }

        $sql = $where === [] ? '' : ' WHERE ' . implode(' AND ', $where);

        return [$sql, $params];
    }

    /**
     * @param array<string, mixed> $filters
     * @return array<string, int>
     */
    private function scopeCounts(array $filters, int $userId, bool $viewAll): array
    {
        $base = $filters;
        $base['scope'] = 'all';
        [$allSql, $allParams] = $this->filterClause($base, $userId, $viewAll);
        $all = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM tasks t INNER JOIN projects p ON p.id = t.project_id' . $allSql,
            $allParams
        );

        $mine = $filters;
        $mine['scope'] = 'mine';
        [$mineSql, $mineParams] = $this->filterClause($mine, $userId, $viewAll);
        $mineCount = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM tasks t INNER JOIN projects p ON p.id = t.project_id' . $mineSql,
            $mineParams
        );

        return ['all' => $all, 'mine' => $mineCount];
    }

    /**
     * Drop columns the live table does not have, and map status onto the live ENUM.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function prepareWrite(array $data): array
    {
        if (array_key_exists('status', $data) && $data['status'] !== null && $data['status'] !== '') {
            $data['status'] = self::persistStatus((string) $data['status']);
        }

        foreach (array_keys($data) as $column) {
            if (!self::hasColumn($column)) {
                unset($data[$column]);
            }
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function hydrate(array $row): array
    {
        $row['status'] = self::normalizeStatus((string) ($row['status'] ?? self::STATUS_TODO));
        if (!isset($row['priority']) || $row['priority'] === null || $row['priority'] === '') {
            $row['priority'] = self::PRIORITY_MEDIUM;
        }
        if (!isset($row['completion_percent']) || $row['completion_percent'] === null) {
            $row['completion_percent'] = self::percentForStatus((string) $row['status']);
        }
        $row['completion_percent'] = (int) $row['completion_percent'];
        $row['estimated_hours']    = (float) ($row['estimated_hours'] ?? 0);
        $row['is_billable']        = (int) ($row['is_billable'] ?? 0);
        $row['parent_task_id']     = isset($row['parent_task_id']) && $row['parent_task_id'] !== null
            ? (int) $row['parent_task_id'] : null;
        $row['children_count']     = (int) ($row['children_count'] ?? 0);

        return $row;
    }

    /**
     * @param array<string, mixed> $task
     */
    private function parentId(array $task): ?int
    {
        if (!isset($task['parent_task_id']) || $task['parent_task_id'] === null || $task['parent_task_id'] === '') {
            return null;
        }

        $id = (int) $task['parent_task_id'];

        return $id > 0 ? $id : null;
    }

    /**
     * @param list<array<string, mixed>> $tasks
     * @return list<array<string, mixed>>
     */
    private function attachHours(array $tasks): array
    {
        if ($tasks === []) {
            return $tasks;
        }

        $seconds = [];
        try {
            $placeholders = [];
            $params       = [];
            foreach ($tasks as $i => $task) {
                $placeholders[]   = ':h' . $i;
                $params['h' . $i] = (int) $task['id'];
            }
            $rows = Database::fetchAll(
                'SELECT task_id, COALESCE(SUM(duration_seconds), 0) AS seconds
                 FROM time_entries
                 WHERE task_id IN (' . implode(',', $placeholders) . ')
                 GROUP BY task_id',
                $params
            );
            foreach ($rows as $row) {
                $seconds[(int) $row['task_id']] = (int) $row['seconds'];
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('Task attach tracked seconds failed', ['error' => $e->getMessage()]);
            $seconds = [];
        }

        foreach ($tasks as &$task) {
            $sec = $seconds[(int) $task['id']] ?? 0;
            $task['tracked_seconds'] = $sec;
            $task['tracked_hours']   = round($sec / 3600, 2);
            $task['planned_hours']   = round((float) ($task['estimated_hours'] ?? 0), 2);
        }
        unset($task);

        return $tasks;
    }

    /**
     * @param list<array<string, mixed>> $tasks
     * @return list<array<string, mixed>>
     */
    private function attachAssignees(array $tasks): array
    {
        if ($tasks === []) {
            return $tasks;
        }

        $placeholders = [];
        $params       = [];
        foreach ($tasks as $i => $task) {
            $placeholders[]   = ':t' . $i;
            $params['t' . $i] = (int) $task['id'];
        }

        $rows = [];
        try {
            $rows = Database::fetchAll(
                'SELECT ta.task_id, u.id AS user_id, u.name
                 FROM task_assignees ta
                 INNER JOIN users u ON u.id = ta.user_id
                 WHERE ta.task_id IN (' . implode(',', $placeholders) . ')
                 ORDER BY u.name ASC',
                $params
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Task attachAssignees failed', ['error' => $e->getMessage()]);
            $rows = [];
        }

        $byTask = [];
        foreach ($rows as $row) {
            $byTask[(int) $row['task_id']][] = ['id' => (int) $row['user_id'], 'name' => (string) $row['name']];
        }

        foreach ($tasks as &$task) {
            $list = $byTask[(int) $task['id']] ?? [];
            $task['assignees']    = $list;
            $task['assignee_ids'] = array_map(static fn (array $a): int => $a['id'], $list);
        }
        unset($task);

        return $tasks;
    }

    private function selectSql(): string
    {
        $parent = self::hasColumn('parent_task_id')
            ? 't.parent_task_id'
            : 'NULL AS parent_task_id';
        $priority = self::hasColumn('priority')
            ? 't.priority'
            : "'Medium' AS priority";
        $percent = self::hasColumn('completion_percent')
            ? 't.completion_percent'
            : '0 AS completion_percent';
        $start = self::hasColumn('start_date')
            ? 't.start_date'
            : 'NULL AS start_date';
        $billable = self::hasColumn('is_billable')
            ? 't.is_billable'
            : '0 AS is_billable';
        $children = self::hasColumn('parent_task_id')
            ? '(SELECT COUNT(*) FROM tasks ch WHERE ch.parent_task_id = t.id) AS children_count'
            : '0 AS children_count';
        $parentName = self::hasColumn('parent_task_id')
            ? 'parent.name AS parent_name'
            : 'NULL AS parent_name';
        $parentJoin = self::hasColumn('parent_task_id')
            ? 'LEFT JOIN tasks parent ON parent.id = t.parent_task_id'
            : '';

        return "SELECT t.id, t.project_id, {$parent}, t.name, t.description, t.status,
                       {$priority}, t.estimated_hours, {$percent},
                       {$start}, t.due_date, {$billable}, t.created_by, t.created_at, t.updated_at,
                       {$children},
                       p.name AS project_name, p.project_code, p.status AS project_status,
                       p.color AS project_color, p.is_billable AS project_billable,
                       c.name AS client_name,
                       {$parentName},
                       creator.name AS created_by_name
                FROM tasks t
                INNER JOIN projects p ON p.id = t.project_id
                INNER JOIN clients c ON c.id = p.client_id
                {$parentJoin}
                LEFT JOIN users creator ON creator.id = t.created_by";
    }

    private function doneSql(string $alias = ''): string
    {
        $col = $alias === '' ? 'status' : $alias . '.status';

        return "({$col} IN ('Completed','Done'))";
    }

    private function notClosedSql(string $alias = ''): string
    {
        $col = $alias === '' ? 'status' : $alias . '.status';

        return "({$col} NOT IN ('Completed','Done','Cancelled'))";
    }

    private function closedOrderSql(string $alias): string
    {
        return '(' . $alias . ".status IN ('Completed','Done','Cancelled')) ASC";
    }

    private static function like(string $value): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value);
    }
}
