/*
 * TimeTrack front-end behaviour.
 *
 * The Content-Security-Policy forbids inline scripts and inline event handlers, so every
 * interaction is wired here through data- attributes:
 *
 *   data-toggle-password="#id"     button that shows/hides a password field
 *   data-password-meter="#id"      password input that feeds a strength meter
 *   data-single-submit             form whose submit button is disabled after the first submit
 *   data-confirm="Message"         form or button that asks for confirmation first
 *   data-auto-dismiss="ms"         alert that closes itself (0 = stay)
 *   data-timer-clock                live elapsed clock (driven by timer.js)
 *
 * It also makes every same-origin fetch()/XHR state-changing request carry the CSRF
 * token from <meta name="csrf-token"> as the X-CSRF-Token header.
 */
(function () {
    'use strict';

    var csrfMeta = document.querySelector('meta[name="csrf-token"]');
    var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

    window.TT = {
        csrf: csrfToken,
        baseUrl: document.body ? (document.body.getAttribute('data-base-url') || '') : ''
    };

    /* ---- CSRF header on fetch() ------------------------------------- */
    if (window.fetch) {
        var nativeFetch = window.fetch.bind(window);

        window.fetch = function (input, init) {
            init = init || {};
            var method = String(init.method || (input && input.method) || 'GET').toUpperCase();
            var target = typeof input === 'string' ? input : (input && input.url) || '';
            var sameOrigin = true;

            try {
                sameOrigin = new URL(target, window.location.href).origin === window.location.origin;
            } catch (e) {
                sameOrigin = true;
            }

            if (sameOrigin && method !== 'GET' && method !== 'HEAD' && method !== 'OPTIONS') {
                var headers = new Headers(init.headers || (input && input.headers) || {});
                if (!headers.has('X-CSRF-Token') && csrfToken) {
                    headers.set('X-CSRF-Token', csrfToken);
                }
                headers.set('X-Requested-With', 'XMLHttpRequest');
                init.headers = headers;
            }

            return nativeFetch(input, init);
        };
    }

    /* ---- CSRF header on XMLHttpRequest ------------------------------ */
    if (window.XMLHttpRequest && csrfToken) {
        var nativeOpen = XMLHttpRequest.prototype.open;
        var nativeSend = XMLHttpRequest.prototype.send;

        XMLHttpRequest.prototype.open = function (method, url) {
            this._ttMethod = String(method || 'GET').toUpperCase();
            this._ttUrl = url;
            return nativeOpen.apply(this, arguments);
        };

        XMLHttpRequest.prototype.send = function () {
            var unsafe = this._ttMethod !== 'GET' && this._ttMethod !== 'HEAD' && this._ttMethod !== 'OPTIONS';
            var same = true;

            try {
                same = new URL(this._ttUrl, window.location.href).origin === window.location.origin;
            } catch (e) {
                same = true;
            }

            if (unsafe && same) {
                this.setRequestHeader('X-CSRF-Token', csrfToken);
                this.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            }

            return nativeSend.apply(this, arguments);
        };
    }

    document.addEventListener('DOMContentLoaded', function () {
        initPasswordToggles();
        initPasswordMeters();
        initSingleSubmit();
        initWorkspaceGeneralForm();
        initConfirm();
        initAutoDismiss();
        initClientModal();
        initTaskModal();
        initTimesheetApproval();
        initNotifications();
        initProjectRows();
        initProjectList();
    });

    /* ---- chart colours follow the theme ------------------------------- */
    window.ttChartPalette = function () {
        var dark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
        return dark
            ? { tick: '#9aa8b2', tickStrong: '#b4c0c8', grid: 'rgba(255, 255, 255, .09)', axis: '#3a444c', slice: '#1b2024' }
            : { tick: '#8a96a0', tickStrong: '#5b6d6c', grid: '#edf0f1', axis: '#dfe5e9', slice: '#ffffff' };
    };

    (function watchThemeForCharts() {
        if (!window.MutationObserver) { return; }
        new MutationObserver(function () {
            if (!window.Chart || !window.Chart.instances) { return; }
            var c = window.ttChartPalette();
            Object.keys(window.Chart.instances).forEach(function (id) {
                var chart = window.Chart.instances[id];
                var scales = chart.options && chart.options.scales;
                if (scales) {
                    Object.keys(scales).forEach(function (key) {
                        var sc = scales[key];
                        if (sc.ticks) { sc.ticks.color = c.tick; }
                        if (sc.grid && sc.grid.display !== false) { sc.grid.color = c.grid; }
                        if (sc.border && sc.border.display !== false) { sc.border.color = c.axis; }
                    });
                }
                (chart.data.datasets || []).forEach(function (ds) {
                    if (ds.borderColor === '#ffffff' || ds.borderColor === '#1b2024') { ds.borderColor = c.slice; }
                });
                if (chart.options.plugins && chart.options.plugins.legend && chart.options.plugins.legend.labels) {
                    chart.options.plugins.legend.labels.color = c.tickStrong;
                }
                chart.update('none');
            });
        }).observe(document.documentElement, { attributes: true, attributeFilter: ['data-bs-theme'] });
    })();

    /* ---- clickable project rows ------------------------------------ */
    function initProjectRows() {
        document.querySelectorAll('[data-project-href]').forEach(function (row) {
            row.addEventListener('click', function (event) {
                if (event.target.closest('a, button, input, select, textarea, form, [data-bs-toggle]')) {
                    return;
                }
                var href = row.getAttribute('data-project-href');
                if (href) { window.location.href = href; }
            });
        });
    }

    /* ---- project list: select-all + CSV export ---------------------- */
    function initAccessFilter() {
        var box = document.querySelector('.cfl-access-filter');
        if (!box) { return; }
        var all = box.querySelector('[data-access-all]');
        var items = Array.prototype.slice.call(box.querySelectorAll('[data-access-item]'));
        var label = box.querySelector('[data-access-label]');
        var button = box.querySelector('.cfl-access-btn');

        function sync() {
            var n = items.filter(function (i) { return i.checked; }).length;
            if (all) { all.checked = items.length > 0 && n === items.length; }
            if (label) { label.textContent = 'Access' + (n ? ' (' + n + ')' : ''); }
            if (button) { button.classList.toggle('has-value', n > 0); }
        }
        if (all) {
            all.addEventListener('change', function () {
                items.forEach(function (i) { i.checked = all.checked; });
                sync();
            });
        }
        items.forEach(function (i) { i.addEventListener('change', sync); });
        sync();
    }

    function initProjectList() {
        initAccessFilter();
        var scope = document.querySelector('[data-export-scope]');
        if (!scope) { return; }

        var all = scope.querySelector('[data-select-all]');
        var rows = function () { return Array.prototype.slice.call(scope.querySelectorAll('[data-select-row]')); };

        if (all) {
            all.addEventListener('change', function () {
                rows().forEach(function (box) { box.checked = all.checked; });
            });
        }
        scope.addEventListener('change', function (event) {
            if (all && event.target.matches('[data-select-row]')) {
                var boxes = rows();
                all.checked = boxes.length > 0 && boxes.every(function (b) { return b.checked; });
            }
        });
        // Checkbox cells must not trigger the row link.
        scope.querySelectorAll('.cfl-col-check').forEach(function (cell) {
            cell.addEventListener('click', function (event) { event.stopPropagation(); });
        });

        var exportBtn = scope.querySelector('[data-export-csv]');
        if (!exportBtn) { return; }
        exportBtn.addEventListener('click', function () {
            var table = scope.querySelector('[data-export-table]');
            var headers = ['Name', 'Client', 'Tracked', 'Progress', 'Access'];
            var body = Array.prototype.slice.call(table.querySelectorAll('tbody tr.cfl-row'));
            var picked = body.filter(function (tr) {
                var box = tr.querySelector('[data-select-row]');
                return box && box.checked;
            });
            var source = picked.length ? picked : body;
            var cell = function (value) { return '"' + String(value).replace(/"/g, '""') + '"'; };
            var lines = [headers.map(cell).join(',')];
            source.forEach(function (tr) {
                var values = Array.prototype.slice.call(tr.querySelectorAll('[data-export]')).map(function (td) {
                    return td.getAttribute('data-export') || '';
                });
                lines.push(values.map(cell).join(','));
            });
            var blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
            var link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'projects.csv';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            setTimeout(function () { URL.revokeObjectURL(link.href); }, 1000);
        });
    }

    /* ---- show / hide password --------------------------------------- */
    function initPasswordToggles() {
        document.querySelectorAll('[data-toggle-password]').forEach(function (button) {
            var input = document.querySelector(button.getAttribute('data-toggle-password'));
            var icon = button.querySelector('i');
            if (!input) { return; }

            button.addEventListener('click', function () {
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                button.setAttribute('aria-pressed', show ? 'true' : 'false');
                button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
                if (icon) {
                    icon.className = show ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye';
                }
            });
        });
    }

    /* ---- password strength ------------------------------------------ */
    function initPasswordMeters() {
        document.querySelectorAll('[data-password-meter]').forEach(function (input) {
            var meter = document.querySelector(input.getAttribute('data-password-meter'));
            if (!meter) { return; }

            var bar = meter.querySelector('.strength-bar');
            var label = meter.querySelector('.strength-text');
            var levels = [
                { text: 'Too weak', color: '#c0392b', width: '20%' },
                { text: 'Weak', color: '#d9652b', width: '40%' },
                { text: 'Fair', color: '#d9a21b', width: '60%' },
                { text: 'Good', color: '#4f9d4a', width: '80%' },
                { text: 'Strong', color: '#1c7c3a', width: '100%' }
            ];

            input.addEventListener('input', function () {
                var value = input.value;

                if (value === '') {
                    meter.classList.remove('is-active');
                    return;
                }

                var score = 0;
                if (value.length >= 10) { score++; }
                if (value.length >= 14) { score++; }
                if (/[a-z]/.test(value) && /[A-Z]/.test(value)) { score++; }
                if (/\d/.test(value)) { score++; }
                if (/[^A-Za-z0-9]/.test(value)) { score++; }
                if (value.length < 10) { score = Math.min(score, 1); }

                var level = levels[Math.max(0, Math.min(score - 1, levels.length - 1))];
                if (score === 0) { level = levels[0]; }

                meter.classList.add('is-active');
                bar.style.setProperty('--score', level.width);
                bar.style.setProperty('--clr', level.color);
                label.textContent = level.text;
            });
        });
    }

    /* ---- prevent double submits ------------------------------------- */
    function initSingleSubmit() {
        document.querySelectorAll('form[data-single-submit]').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (event.defaultPrevented) { return; }

                if (form.getAttribute('data-submitting') === '1') {
                    event.preventDefault();
                    return;
                }

                form.setAttribute('data-submitting', '1');
                var buttons = form.querySelectorAll('button[type="submit"]');

                // Disable after the browser has collected the form data.
                window.setTimeout(function () {
                    buttons.forEach(function (button) {
                        button.disabled = true;
                        button.setAttribute('aria-busy', 'true');
                    });
                }, 0);
            });
        });

        // Coming back with the browser's Back button must not leave a dead form behind.
        window.addEventListener('pageshow', function (event) {
            if (!event.persisted) { return; }
            document.querySelectorAll('form[data-single-submit]').forEach(function (form) {
                form.removeAttribute('data-submitting');
                form.querySelectorAll('button[type="submit"]').forEach(function (button) {
                    button.disabled = false;
                    button.removeAttribute('aria-busy');
                });
            });
        });
    }

    function initWorkspaceGeneralForm() {
        document.querySelectorAll('form[data-workspace-general-form]').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (event.defaultPrevented) return;
                var file = form.querySelector('input[type=file][name=logo]');
                if (file && file.files && file.files[0]) {
                    var f = file.files[0];
                    if (f.size > 5 * 1024 * 1024) {
                        event.preventDefault();
                        window.alert('Logo must be 5 MB or smaller.');
                        return;
                    }
                    var button = form.querySelector('button[type=submit]');
                    if (button) {
                        button.disabled = true;
                        button.setAttribute('aria-busy', 'true');
                        button.dataset.originalText = button.textContent;
                        button.textContent = 'Uploading logo…';
                    }
                }
            });
        });
    }

    /* ---- confirmation prompts --------------------------------------- */
    function initConfirm() {
        document.addEventListener('submit', function (event) {
            var form = event.target;
            var message = form && form.getAttribute ? form.getAttribute('data-confirm') : null;
            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });

        document.addEventListener('click', function (event) {
            var trigger = event.target.closest ? event.target.closest('button[data-confirm], a[data-confirm]') : null;
            if (trigger && !trigger.form && !window.confirm(trigger.getAttribute('data-confirm'))) {
                event.preventDefault();
            }
        });
    }

    /* ---- self-closing alerts ---------------------------------------- */
    function initAutoDismiss() {
        document.querySelectorAll('.alert[data-auto-dismiss]').forEach(function (alert) {
            var delay = parseInt(alert.getAttribute('data-auto-dismiss'), 10);
            if (!delay || delay < 1) { return; }

            window.setTimeout(function () {
                if (!document.body.contains(alert)) { return; }
                if (window.bootstrap && window.bootstrap.Alert) {
                    window.bootstrap.Alert.getOrCreateInstance(alert).close();
                } else {
                    alert.remove();
                }
            }, delay);
        });
    }

    /* ---- client create/edit modal ----------------------------------- */
    function initClientModal() {
        var modalEl = document.getElementById('clientModal');
        if (!modalEl) { return; }

        var form = document.getElementById('clientForm');
        var title = document.getElementById('clientModalTitle');
        var submit = document.getElementById('clientSubmit');
        var fields = {
            name: document.getElementById('client_name'),
            company: document.getElementById('client_company'),
            email: document.getElementById('client_email'),
            phone: document.getElementById('client_phone'),
            address: document.getElementById('client_address'),
            status: document.getElementById('client_status')
        };

        function fill(data) {
            Object.keys(fields).forEach(function (key) {
                if (fields[key]) {
                    fields[key].value = data && data[key] != null ? String(data[key]) : (key === 'status' ? 'active' : '');
                }
            });
        }

        if (form && form.querySelector('.is-invalid') && window.bootstrap && window.bootstrap.Modal) {
            window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
        }

        modalEl.addEventListener('show.bs.modal', function (event) {
            var trigger = event.relatedTarget;
            if (!trigger || !form) { return; }

            var raw = trigger.getAttribute('data-client-edit');
            if (raw) {
                var payload = {};
                try { payload = JSON.parse(raw); } catch (e) { payload = {}; }
                fill(payload);
                form.setAttribute('action', trigger.getAttribute('data-client-action') || form.getAttribute('action'));
                if (title) { title.textContent = 'Edit client'; }
                if (submit) { submit.textContent = 'Save changes'; }
                return;
            }

            fill({ status: 'active' });
            form.setAttribute('action', form.getAttribute('data-create-action') || form.getAttribute('action'));
            if (title) { title.textContent = 'New client'; }
            if (submit) { submit.textContent = 'Save client'; }
        });

        if (form && !form.getAttribute('data-create-action')) {
            form.setAttribute('data-create-action', form.getAttribute('action'));
        }
    }

    /* ---- task modal: add / edit ------------------------------------- */
    function initTaskModal() {
        var modalEl = document.getElementById('taskModal');
        if (!modalEl) { return; }

        var form = document.getElementById('taskForm');
        var title = document.getElementById('taskModalTitle');
        var submit = document.getElementById('taskSubmit');
        if (!form) { return; }

        var fields = {
            name: document.getElementById('task_name'),
            description: document.getElementById('task_description'),
            status: document.getElementById('task_status'),
            estimated_hours: document.getElementById('task_estimated_hours'),
            due_date: document.getElementById('task_due_date')
        };

        function fill(data) {
            Object.keys(fields).forEach(function (key) {
                if (!fields[key]) { return; }
                var fallback = key === 'status' ? 'Open' : '';
                fields[key].value = data && data[key] != null ? String(data[key]) : fallback;
            });

            var chosen = (data && data.assignee_ids) ? data.assignee_ids.map(String) : [];
            form.querySelectorAll('.task-assignee').forEach(function (box) {
                box.checked = chosen.indexOf(box.value) !== -1;
            });
        }

        modalEl.addEventListener('show.bs.modal', function (event) {
            var trigger = event.relatedTarget;
            if (!trigger) { return; }

            var raw = trigger.getAttribute('data-task-edit');
            if (raw) {
                var payload = {};
                try { payload = JSON.parse(raw); } catch (e) { payload = {}; }
                fill(payload);
                form.setAttribute('action', trigger.getAttribute('data-task-action') || form.getAttribute('action'));
                if (fields.name) {
                    var completed = String(payload.status || '') === 'Completed';
                    fields.name.disabled = completed;
                    if (completed) {
                        fields.name.title = 'Completed tasks cannot be renamed. Mark the task active first.';
                    } else {
                        fields.name.removeAttribute('title');
                    }
                }
                if (title) { title.textContent = 'Edit task'; }
                if (submit) { submit.textContent = 'Save changes'; }
                return;
            }

            fill(null);
            if (fields.name) { fields.name.disabled = false; fields.name.removeAttribute('title'); }
            form.setAttribute('action', form.getAttribute('data-create-action') || form.getAttribute('action'));
            if (title) { title.textContent = 'Add task'; }
            if (submit) { submit.textContent = 'Add task'; }
        });

        modalEl.addEventListener('shown.bs.modal', function () {
            if (fields.name) { fields.name.focus(); }
        });
    }

    /* ---- timesheet reject modal + batch approve --------------------- */
    function initTimesheetApproval() {
        var rejectModal = document.getElementById('rejectTimesheetModal');
        var rejectForm = document.getElementById('rejectTimesheetForm');
        if (rejectModal && rejectForm) {
            var lead = document.getElementById('rejectTimesheetLead');
            var reason = document.getElementById('reject_reason');

            rejectModal.addEventListener('show.bs.modal', function (event) {
                var trigger = event.relatedTarget;
                if (!trigger) { return; }

                var id = trigger.getAttribute('data-reject-id');
                var name = trigger.getAttribute('data-reject-name') || 'this person';
                var week = trigger.getAttribute('data-reject-week') || 'this week';
                if (id) {
                    rejectForm.setAttribute('action', (window.TT && window.TT.baseUrl ? window.TT.baseUrl.replace(/\/$/, '') : '') + '/timesheets/' + id + '/reject');
                }
                if (lead) {
                    lead.textContent = 'Send ' + name + '\'s timesheet for ' + week + ' back with a note.';
                }
                if (reason) { reason.value = ''; }
            });

            rejectModal.addEventListener('shown.bs.modal', function () {
                if (reason) { reason.focus(); }
            });
        }

        var selectAll = document.querySelector('[data-check-all]');
        var rowChecks = document.querySelectorAll('[data-row-check]');
        if (selectAll && rowChecks.length) {
            selectAll.addEventListener('change', function () {
                rowChecks.forEach(function (box) { box.checked = selectAll.checked; });
                updateBatchCount();
            });
            rowChecks.forEach(function (box) {
                box.addEventListener('change', updateBatchCount);
            });
        }

        function selectedIds() {
            var ids = [];
            document.querySelectorAll('[data-row-check]:checked').forEach(function (box) {
                ids.push(box.value);
            });
            return ids;
        }

        function updateBatchCount() {
            var countEl = document.querySelector('[data-batch-count]');
            if (countEl) { countEl.textContent = String(selectedIds().length); }
        }

        var batchOpen = document.querySelector('[data-batch-open]');
        if (batchOpen) {
            batchOpen.addEventListener('click', function (event) {
                if (selectedIds().length < 1) {
                    event.preventDefault();
                    window.alert('Select at least one timesheet.');
                }
            });
        }

        var confirmBtn = document.querySelector('[data-batch-confirm]');
        var batchForm = document.getElementById('batchApproveForm');
        var batchIds = document.getElementById('batchApproveIds');
        if (confirmBtn && batchForm && batchIds) {
            confirmBtn.addEventListener('click', function () {
                var ids = selectedIds();
                if (!ids.length) { return; }
                batchIds.innerHTML = '';
                ids.forEach(function (id) {
                    var input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'ids[]';
                    input.value = id;
                    batchIds.appendChild(input);
                });
                if (typeof batchForm.requestSubmit === 'function') {
                    batchForm.requestSubmit();
                } else {
                    batchForm.submit();
                }
            });
        }

        updateBatchCount();
    }

    /* ---- notification bell (Phase 9) -------------------------------- */
    function initNotifications() {
        var toggle = document.querySelector('[data-notification-toggle]');
        var menu = document.querySelector('[data-notification-menu]');
        if (!toggle || !menu) { return; }

        var list = menu.querySelector('[data-notification-list]');
        var readAll = menu.querySelector('[data-notification-read-all]');

        toggle.addEventListener('click', function () {
            var url = toggle.getAttribute('data-url');
            if (!url || !window.fetch) { return; }

            fetch(url, { headers: { Accept: 'application/json' } })
                .then(function (response) { return response.ok ? response.json() : null; })
                .then(function (data) { if (data && data.ok) { render(data); } })
                .catch(function () { /* keep the server-rendered list on failure */ });
        });

        if (list) {
            list.addEventListener('click', function (event) {
                var item = event.target.closest('[data-notification-item]');
                if (!item) { return; }

                var url = item.getAttribute('data-read-url');
                var href = item.getAttribute('href');
                if (!url || !window.fetch) { return; }

                event.preventDefault();
                fetch(url, { method: 'POST', headers: { Accept: 'application/json' } })
                    .then(function (response) { return response.ok ? response.json() : null; })
                    .then(function (data) {
                        if (data && data.ok) {
                            item.classList.remove('is-unread');
                            setBadge(data.unread);
                        }
                    })
                    .catch(function () { /* ignore */ })
                    .then(function () { if (href) { window.location.href = href; } });
            });
        }

        if (readAll) {
            readAll.addEventListener('click', function (event) {
                var url = readAll.getAttribute('data-url');
                if (!url || !window.fetch) { return; }

                event.preventDefault();
                fetch(url, { method: 'POST', headers: { Accept: 'application/json' } })
                    .then(function (response) { return response.ok ? response.json() : null; })
                    .then(function (data) {
                        if (!data || !data.ok) { return; }
                        if (list) {
                            list.querySelectorAll('[data-notification-item]').forEach(function (item) {
                                item.classList.remove('is-unread');
                            });
                        }
                        setBadge(0);
                    })
                    .catch(function () { /* ignore */ });
            });
        }

        function render(data) {
            setBadge(typeof data.unread === 'number' ? data.unread : 0);
            if (!list) { return; }

            var items = data.items || [];
            if (!items.length) {
                list.innerHTML = '<div class="notification-empty" data-notification-empty>You are all caught up.</div>';
                return;
            }
            list.innerHTML = items.map(itemHtml).join('');
        }

        function itemHtml(note) {
            var type = String(note.type || 'info');
            var icon = type === 'success' ? 'fa-circle-check'
                : type === 'warning' ? 'fa-triangle-exclamation'
                : type === 'danger' ? 'fa-circle-exclamation'
                : 'fa-circle-info';
            var base = window.TT && window.TT.baseUrl ? String(window.TT.baseUrl).replace(/\/$/, '') : '';
            var rawLink = String(note.link || '');
            var link = rawLink ? (rawLink.charAt(0) === '/' ? base + rawLink : rawLink) : base + '/dashboard';

            return '<a class="notification-item' + (note.is_read ? '' : ' is-unread') + '"'
                + ' href="' + escapeHtml(link) + '"'
                + ' data-notification-item data-id="' + escapeHtml(note.id) + '"'
                + ' data-read-url="' + escapeHtml(base + '/notifications/' + encodeURIComponent(note.id) + '/read') + '">'
                + '<span class="feed-icon feed-' + escapeHtml(type) + '" aria-hidden="true"><i class="fa-solid ' + icon + '"></i></span>'
                + '<span class="notification-body">'
                + '<span class="notification-title">' + escapeHtml(note.title) + '</span>'
                + (note.message ? '<span class="notification-text">' + escapeHtml(note.message) + '</span>' : '')
                + '<span class="notification-time">' + escapeHtml(note.created) + '</span>'
                + '</span></a>';
        }

        function setBadge(count) {
            var badge = toggle.querySelector('[data-notification-badge]');
            if (!badge) { return; }
            count = parseInt(count, 10);
            if (isNaN(count) || count < 1) {
                badge.hidden = true;
                badge.textContent = '0';
                return;
            }
            badge.hidden = false;
            badge.textContent = count > 9 ? '9+' : String(count);
        }

        function escapeHtml(value) {
            return String(value === undefined || value === null ? '' : value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }
    }

})();
