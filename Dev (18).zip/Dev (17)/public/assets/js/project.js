/*
 * Project page (Clockify layout): inline task edit, assignee picker, visibility, note autosave,
 * settings helpers and the forecast chart. Loaded only on project pages (projectAssets flag).
 * CSP: no inline scripts, so everything is wired from data- attributes.
 */
(function () {
    'use strict';

    function post(url, params) {
        var body = new URLSearchParams();
        Object.keys(params || {}).forEach(function (key) {
            var value = params[key];
            if (Array.isArray(value)) {
                value.forEach(function (item) { body.append(key + '[]', item); });
            } else {
                body.append(key, value);
            }
        });

        return fetch(url, {
            method: 'POST',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
            body: body.toString(),
            credentials: 'same-origin'
        }).then(function (response) {
            return response.json().catch(function () { return { ok: false, message: 'Unexpected response.' }; })
                .then(function (json) { json.status = response.status; return json; });
        });
    }

    /* ---- selects that submit their form on change --------------------- */
    document.querySelectorAll('select[data-auto-submit]').forEach(function (select) {
        select.addEventListener('change', function () { if (select.form) { select.form.submit(); } });
    });

    /* ---- Tasks tab: inline rename -------------------------------------- */
    document.querySelectorAll('input[data-task-rename]').forEach(function (input) {
        var busy = false;

        function commit() {
            var original = input.getAttribute('data-original') || '';
            var value = input.value.trim();
            if (busy || value === original) { input.value = original; return; }
            if (value === '') { input.value = original; return; }

            busy = true;
            input.classList.add('is-saving');
            post(input.getAttribute('data-task-rename'), { name: value }).then(function (json) {
                input.classList.remove('is-saving');
                busy = false;
                if (json.ok) {
                    input.setAttribute('data-original', json.name);
                    input.value = json.name;
                } else {
                    input.value = original;
                    input.classList.add('is-error');
                    input.title = json.message || 'Could not rename the task.';
                    setTimeout(function () { input.classList.remove('is-error'); input.removeAttribute('title'); }, 3000);
                }
            }).catch(function () {
                busy = false;
                input.classList.remove('is-saving');
                input.value = original;
            });
        }

        input.addEventListener('blur', commit);
        input.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') { event.preventDefault(); input.blur(); }
            if (event.key === 'Escape') { input.value = input.getAttribute('data-original') || ''; input.blur(); }
        });
    });

    /* ---- Tasks tab: Mark as done / Mark as active (in place, no page change) ---- */
    document.querySelectorAll('form[data-task-toggle-status]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            if (form.getAttribute('data-busy') === '1') { return; }

            var statusInput = form.querySelector('input[name="status"]');
            var button = form.querySelector('button[type="submit"]');
            var row = form.closest('tr');
            var filter = form.getAttribute('data-task-filter') || 'active';
            var target = statusInput ? statusInput.value : '';
            if (!target) { return; }

            form.setAttribute('data-busy', '1');
            if (button) { button.disabled = true; }

            post(form.getAttribute('action'), { status: target }).then(function (json) {
                form.removeAttribute('data-busy');
                if (button) { button.disabled = false; }

                if (!json.ok) {
                    window.alert(json.message || 'Could not change the task status.');
                    return;
                }

                var nowDone = target === 'Completed'; // json.status is overwritten with the HTTP code by post()

                // The current filter no longer matches this row: reload so counts and list stay right.
                if ((filter === 'active' && nowDone) || (filter === 'done' && !nowDone)) {
                    window.location.reload();
                    return;
                }

                if (row) { row.classList.toggle('is-done', nowDone); }
                var statusBadge = row ? row.querySelector('[data-task-status]') : null;
                if (statusBadge) {
                    statusBadge.textContent = nowDone ? 'Done' : 'Active';
                    statusBadge.classList.toggle('is-done', nowDone);
                    statusBadge.classList.toggle('is-active', !nowDone);
                }
                var nameInput = row ? row.querySelector('[data-task-rename]') : null;
                if (nameInput) {
                    nameInput.disabled = nowDone;
                    if (nowDone) {
                        nameInput.title = 'Completed tasks cannot be renamed. Mark the task active first.';
                    } else {
                        nameInput.removeAttribute('title');
                    }
                }
                if (statusInput) { statusInput.value = nowDone ? 'To Do' : 'Completed'; }
                if (button) { button.textContent = nowDone ? 'Mark as active' : 'Mark as done'; }
            }).catch(function () {
                form.removeAttribute('data-busy');
                if (button) { button.disabled = false; }
                window.alert('Could not reach the server. Please try again.');
            });
        });
    });

    /* ---- Tasks tab: assignee picker ------------------------------------ */
    document.querySelectorAll('.cf-assignee[data-task-assignees]').forEach(function (box) {
        var label = box.querySelector('.cf-pill-label');

        box.addEventListener('change', function (event) {
            if (!event.target || event.target.type !== 'checkbox') { return; }

            var ids = [];
            var names = [];
            box.querySelectorAll('input[type="checkbox"]:checked').forEach(function (checkbox) {
                ids.push(checkbox.value);
                names.push(checkbox.getAttribute('data-name'));
            });

            label.textContent = names.length ? names.join(', ') : 'Anyone';
            post(box.getAttribute('data-task-assignees'), { assignee_ids: ids }).then(function (json) {
                if (json.ok) {
                    label.textContent = json.names.length ? json.names.join(', ') : 'Anyone';
                } else {
                    window.alert(json.message || 'Could not change the assignees.');
                    window.location.reload();
                }
            }).catch(function () { window.location.reload(); });
        });
    });

    /* ---- Access tab: visibility ---------------------------------------- */
    var visibility = document.querySelector('[data-visibility-url]');
    if (visibility) {
        var hint = document.getElementById('cf-visibility-hint');

        visibility.addEventListener('change', function (event) {
            var radio = event.target;
            if (!radio || radio.name !== 'visibility') { return; }

            post(visibility.getAttribute('data-visibility-url'), { visibility: radio.value }).then(function (json) {
                if (json.ok) {
                    if (hint) { hint.textContent = hint.getAttribute('data-' + json.visibility); }
                } else {
                    window.alert(json.message || 'Could not change the visibility.');
                    window.location.reload();
                }
            }).catch(function () { window.location.reload(); });
        });
    }

    /* ---- Access tab: filter people in the "Add members" modal ---------- */
    document.querySelectorAll('input[data-filter-list]').forEach(function (input) {
        var list = document.querySelector(input.getAttribute('data-filter-list'));
        if (!list) { return; }

        input.addEventListener('input', function () {
            var needle = input.value.trim().toLowerCase();
            list.querySelectorAll('[data-filter-text]').forEach(function (row) {
                row.style.display = row.getAttribute('data-filter-text').indexOf(needle) === -1 ? 'none' : '';
            });
        });
    });

    /* ---- Note tab: autosave -------------------------------------------- */
    var note = document.getElementById('cf-note');
    if (note && note.getAttribute('data-note-url')) {
        var status = document.getElementById('cf-note-status');
        var timer = null;
        var saved = note.value;

        function setStatus(text, isError) {
            if (!status) { return; }
            status.textContent = text;
            status.classList.toggle('is-error', !!isError);
        }

        function saveNote() {
            clearTimeout(timer);
            if (note.value === saved) { return; }
            var value = note.value;
            setStatus('Saving...');
            post(note.getAttribute('data-note-url'), { note: value }).then(function (json) {
                if (json.ok) { saved = value; setStatus('Saved'); } else { setStatus(json.message || 'Could not save the note.', true); }
            }).catch(function () { setStatus('Could not save the note.', true); });
        }

        note.addEventListener('input', function () { clearTimeout(timer); setStatus(''); timer = setTimeout(saveNote, 900); });
        note.addEventListener('blur', saveNote);
        window.addEventListener('beforeunload', function () {
            if (note.value !== saved && navigator.sendBeacon) {
                var body = new URLSearchParams();
                body.append('note', note.value);
                body.append('_csrf', window.TT ? window.TT.csrf : '');
                navigator.sendBeacon(note.getAttribute('data-note-url'), body);
            }
        });
    }

    /* ---- Settings tab --------------------------------------------------- */
    var colorInput = document.getElementById('cf-color-input');
    if (colorInput) {
        var swatch = document.getElementById('cf-color-swatch');
        document.querySelectorAll('.cf-swatch-pick').forEach(function (button) {
            button.addEventListener('click', function () {
                colorInput.value = button.getAttribute('data-color');
                if (swatch) { swatch.style.background = colorInput.value; }
                document.querySelectorAll('.cf-swatch-pick').forEach(function (other) { other.classList.toggle('is-on', other === button); });
            });
        });
    }

    var estimate = document.querySelector('[data-estimate-select]');
    if (estimate) {
        var syncEstimate = function () {
            document.querySelectorAll('[data-estimate-for]').forEach(function (box) {
                var active = box.getAttribute('data-estimate-for') === estimate.value;
                box.hidden = !active;
                box.querySelectorAll('input').forEach(function (input) { input.disabled = !active; });
            });
        };
        estimate.addEventListener('change', syncEstimate);
    }

    var addField = document.getElementById('cf-add-field');
    if (addField) {
        addField.addEventListener('change', function () {
            var key = addField.value;
            if (!key) { return; }

            var box = document.querySelector('.cf-extra[data-cf-field="' + key + '"]');
            if (box) {
                box.hidden = false;
                box.querySelectorAll('input, select').forEach(function (control) { control.disabled = false; });
                var first = box.querySelector('input:not([type="hidden"]), select');
                if (first) { first.focus(); }
            }

            var option = addField.querySelector('option[value="' + key + '"]');
            if (option) { option.remove(); }
            addField.value = '';
        });
    }

    /* ---- Forecast chart -------------------------------------------------- */
    var canvas = document.getElementById('cf-forecast-canvas');
    if (canvas && window.Chart) {
        var data = {};
        try { data = JSON.parse(canvas.getAttribute('data-forecast') || '{}'); } catch (e) { data = {}; }

        var palette = ['#03a9f4', '#8bc34a', '#ff9800', '#9c27b0', '#f44336', '#009688', '#795548', '#607d8b'];
        var empty = !!data.empty;
        var chartTheme = window.ttChartPalette ? window.ttChartPalette() : { tick: '#8a96a0', grid: '#eef2f4', axis: '#dfe5e9' };
        var tickColor = chartTheme.tick;

        var config = {
            type: 'bar',
            data: {
                labels: empty ? [data.startLabel, data.endLabel] : data.labels,
                datasets: empty ? [] : data.datasets.map(function (set, index) {
                    return {
                        label: set.label,
                        data: set.data,
                        backgroundColor: palette[index % palette.length],
                        maxBarThickness: 46
                    };
                })
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                plugins: {
                    legend: { display: !empty && data.datasets.length > 1, position: 'bottom' },
                    tooltip: {
                        callbacks: {
                            label: function (context) { return context.dataset.label + ': ' + context.parsed.y + ' h'; }
                        }
                    }
                },
                scales: {
                    x: {
                        stacked: true,
                        offset: false,
                        grid: { color: chartTheme.grid, drawTicks: false },
                        border: { color: chartTheme.axis, width: 2 },
                        ticks: {
                            color: tickColor,
                            autoSkip: !empty,
                            maxRotation: 0,
                            align: empty ? 'inner' : 'center',
                            padding: 10
                        }
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        display: !empty,
                        border: { color: chartTheme.axis, width: 2 },
                        grid: { color: chartTheme.grid },
                        ticks: { color: tickColor, callback: function (value) { return value + ' h'; } }
                    }
                }
            }
        };

        new window.Chart(canvas, config);
    }
})();
