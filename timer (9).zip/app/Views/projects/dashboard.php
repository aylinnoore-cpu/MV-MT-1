<?php
/**
 * Project dashboard: progress, budget, schedule vs actual, time by employee, gantt.
 *
 * @var array<string, mixed> $project
 * @var array<string, mixed> $totals
 * @var list<array<string, mixed>> $taskRows
 * @var list<array<string, mixed>> $people
 * @var array{items: list<array<string, mixed>>, start: string, end: string} $gantt
 * @var string $currency
 * @var bool $canEdit
 * @var bool $canTrack
 */

$usage = (int) $totals['usage_percent'];
$budgetPct = (int) $totals['budget_percent'];
$gaugeDeg = (int) round(($budgetPct / 100) * 180);

$statusClass = static fn (string $status): string => match ($status) {
    'Planning'    => 'planning',
    'Active'      => 'active',
    'On Hold'     => 'hold',
    'Completed'   => 'completed',
    'Cancelled'   => 'cancelled',
    'Archived'    => 'archived',
    'Open'        => 'planning',
    'In Progress' => 'active',
    'Done'        => 'completed',
    default       => 'planning',
};

$peopleLabels = [];
$peopleHours = [];
$peopleAmounts = [];
foreach ($people as $row) {
    $peopleLabels[]  = (string) $row['name'];
    $peopleHours[]   = round(((int) $row['seconds']) / 3600, 2);
    $peopleAmounts[] = round((float) $row['billable_amount'], 2);
}
?>
<?php
$activeProjectTab = '';
$tasksReady = Task::installed() && PermissionHelper::has('tasks.view');
$taskCounts = $tasksReady ? (new Task())->counts((int) $project['id']) : ['all' => 0, 'active' => 0, 'done' => 0];
?>
<div class="cf-page">
<?php require APP_PATH . '/Views/projects/_header.php'; ?>

<div class="d-flex flex-wrap align-items-center gap-2 mb-3">
    <h2 class="h5 mb-0 me-2">Project dashboard</h2>
    <span class="status-badge status-<?= e($statusClass((string) $project['status'])) ?>"><?= e($project['status']) ?></span>
    <span class="health-badge health-<?= e((string) $totals['health_class']) ?>"><?= e((string) $totals['health']) ?></span>
</div>

<div class="row g-4 mb-4">
    <div class="col-lg-8">
        <section class="panel h-100">
            <div class="panel-head">
                <h2 class="panel-title">Progress</h2>
            </div>
            <div class="panel-body">
                <div class="progress-label">
                    <span>Tracked vs estimated</span>
                    <span class="mono"><?= e(AnalyticsHelper::formatHours((float) $totals['actual_hours'])) ?>h / <?= e(AnalyticsHelper::formatHours((float) $totals['planned_hours'])) ?>h</span>
                </div>
                <div class="progress mb-3" role="progressbar" aria-valuenow="<?= $usage ?>" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar health-bar-<?= e((string) $totals['health_class']) ?>" style="width: <?= $usage ?>%"></div>
                </div>
                <dl class="facts facts-inline">
                    <div>
                        <dt>Variance</dt>
                        <dd class="variance-<?= ((float) $totals['variance_hours']) > 0 ? 'over' : (((float) $totals['variance_hours']) < 0 ? 'under' : 'even') ?>">
                            <?= e((string) $totals['variance_formatted']) ?>
                        </dd>
                    </div>
                    <div>
                        <dt>Billable amount</dt>
                        <dd><?= e(FormatHelper::money((float) $totals['billable_amount'], $currency)) ?></dd>
                    </div>
                    <div>
                        <dt>Billable hours</dt>
                        <dd><?= e(AnalyticsHelper::formatHours((float) $totals['billable_hours'])) ?>h</dd>
                    </div>
                </dl>
            </div>
        </section>
    </div>
    <div class="col-lg-4">
        <section class="panel h-100">
            <div class="panel-head">
                <h2 class="panel-title">Budget usage</h2>
            </div>
            <div class="panel-body text-center">
                <div class="budget-gauge" style="--gauge: <?= $gaugeDeg ?>deg" aria-label="Budget <?= $budgetPct ?> percent used">
                    <span class="budget-gauge-value"><?= $budgetPct ?>%</span>
                </div>
                <p class="mb-0 mt-2">
                    <?= e(FormatHelper::money((float) $totals['budget_used'], $currency)) ?>
                    of <?= e(FormatHelper::money((float) $totals['budget'], $currency)) ?>
                </p>
            </div>
        </section>
    </div>
</div>

<section class="panel mb-4" aria-labelledby="task-compare-title">
    <div class="panel-head">
        <h2 id="task-compare-title" class="panel-title">Schedule vs actual</h2>
    </div>
    <?php if ($taskRows === []): ?>
        <div class="empty-state">
            <i class="fa-solid fa-list-check" aria-hidden="true"></i>
            <p>No tasks on this project yet.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <th>Task</th>
                        <th>Status</th>
                        <th class="text-end">Planned</th>
                        <th class="text-end">Actual</th>
                        <th class="text-end">Variance</th>
                        <th>Health</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($taskRows as $row): ?>
                        <tr>
                            <td><?= e($row['name']) ?></td>
                            <td><span class="status-badge status-<?= e($statusClass((string) $row['status'])) ?>"><?= e($row['status']) ?></span></td>
                            <td class="text-end mono"><?= e(AnalyticsHelper::formatHours((float) $row['planned_hours'])) ?>h</td>
                            <td class="text-end mono"><?= e(AnalyticsHelper::formatHours((float) $row['actual_hours'])) ?>h</td>
                            <td class="text-end mono variance-<?= ((float) $row['variance_hours']) > 0 ? 'over' : (((float) $row['variance_hours']) < 0 ? 'under' : 'even') ?>">
                                <?= e((string) $row['variance_formatted']) ?>
                            </td>
                            <td>
                                <span class="health-badge health-<?= e((string) $row['health_class']) ?>"><?= e((string) $row['health']) ?></span>
                                <div class="progress mt-1" role="progressbar" aria-valuenow="<?= (int) $row['usage_percent'] ?>" aria-valuemin="0" aria-valuemax="100">
                                    <div class="progress-bar health-bar-<?= e((string) $row['health_class']) ?>" style="width: <?= (int) $row['usage_percent'] ?>%"></div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<div class="row g-4 mb-4">
    <div class="col-lg-7">
        <section class="panel h-100" aria-labelledby="people-title">
            <div class="panel-head">
                <h2 id="people-title" class="panel-title">Time by employee</h2>
            </div>
            <?php if ($people === []): ?>
                <div class="empty-state">
                    <i class="fa-regular fa-user" aria-hidden="true"></i>
                    <p>No time logged on this project yet.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table data-table mb-0">
                        <thead>
                            <tr>
                                <th>Person</th>
                                <th class="text-end">Hours</th>
                                <th class="text-end">Rate</th>
                                <th class="text-end">Billable</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($people as $row): ?>
                                <tr>
                                    <td>
                                        <strong><?= e($row['name']) ?></strong>
                                        <div class="small text-secondary"><?= e(AuthHelper::roleLabel((string) $row['role'])) ?></div>
                                    </td>
                                    <td class="text-end mono"><?= e(FormatHelper::hours((int) $row['seconds'])) ?></td>
                                    <td class="text-end mono"><?= e(FormatHelper::money((float) $row['hourly_rate'], $currency)) ?></td>
                                    <td class="text-end mono"><?= e(FormatHelper::money((float) $row['billable_amount'], $currency)) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="panel-body pt-0">
                    <canvas id="peopleTimeChart" height="140"
                            data-chart-labels="<?= e(json_encode($peopleLabels, JSON_UNESCAPED_UNICODE)) ?>"
                            data-chart-hours="<?= e(json_encode($peopleHours)) ?>"
                            data-chart-amounts="<?= e(json_encode($peopleAmounts)) ?>"></canvas>
                </div>
            <?php endif; ?>
        </section>
    </div>
    <div class="col-lg-5">
        <section class="panel h-100" aria-labelledby="gantt-title">
            <div class="panel-head">
                <h2 id="gantt-title" class="panel-title">Timeline</h2>
            </div>
            <?php if ($gantt['items'] === []): ?>
                <div class="empty-state">
                    <i class="fa-solid fa-bars-staggered" aria-hidden="true"></i>
                    <p>Add tasks with dates to see a timeline.</p>
                </div>
            <?php else: ?>
                <div class="gantt-wrap">
                    <div class="gantt-range small text-secondary px-3 pt-2">
                        <?= e(FormatHelper::date($gantt['start'] . ' 00:00:00', 'M j, Y')) ?>
                        –
                        <?= e(FormatHelper::date($gantt['end'] . ' 00:00:00', 'M j, Y')) ?>
                    </div>
                    <ul class="gantt-list">
                        <?php foreach ($gantt['items'] as $bar): ?>
                            <li>
                                <span class="gantt-label" title="<?= e($bar['name']) ?>"><?= e($bar['name']) ?></span>
                                <span class="gantt-track">
                                    <span class="gantt-bar gantt-<?= e($bar['done'] ? 'done' : $statusClass((string) $bar['status'])) ?>"
                                          style="left: <?= e((string) $bar['left']) ?>%; width: <?= e((string) $bar['width']) ?>%"
                                          title="<?= e($bar['start'] . ' to ' . $bar['end']) ?>"></span>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>
</div>
