<?php header('Location: deletion_log.php?entity=Asset');
