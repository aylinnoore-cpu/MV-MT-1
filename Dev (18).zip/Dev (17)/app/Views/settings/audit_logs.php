<?php
/**
 * Activity / audit log (Phase 9). Search and module filters over activity_logs.
 *
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int} $result
 * @var array{q: string, module: string, action: string, user_id: int} $filters
 * @var list<string> $modules
 */

$items = $result['items'];

$moduleClass = static fn (string $module): string => match ($module) {
    'project'   => 'role-manager',
    'task'      => 'role-employee',
    'schedule'  => 'role-client',
    'timesheet' => 'status-active',
    'time'      => 'status-hold',
    'user'      => 'role-admin',
    default     => 'status-planning',
};

$pretty = static function (string $raw): string {
    if ($raw === '') {
        return '';
    }
    $decoded = json_decode($raw, true);
    return json_last_error() === JSON_ERROR_NONE
        ? (string) json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
        : $raw;
};

$query = static function (array $extra = []) use ($filters): string {
    $params = array_filter([
        'q'      => $extra['q'] ?? $filters['q'],
        'module' => ($extra['module'] ?? $filters['module']) !== 'all' ? ($extra['module'] ?? $filters['module']) : null,
        'page'   => $extra['page'] ?? null,
    ], static fn ($v): bool => $v !== null && $v !== '');
    return $params === [] ? '' : '?' . http_build_query($params);
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Activity log</h2>
        <p class="page-lead">Who changed what, when and from where.</p>
    </div>
</div>

<form method="get" action="<?= e(url('/settings/audit-logs')) ?>" class="filter-bar">
    <div class="filter-search">
        <label for="log-q" class="visually-hidden">Search activity</label>
        <input type="search" id="log-q" name="q" class="form-control" placeholder="Search action, user, email or IP" value="<?= e($filters['q']) ?>">
    </div>
    <div>
        <label for="log-module" class="visually-hidden">Module</label>
        <select id="log-module" name="module" class="form-select">
            <option value="all">All modules</option>
            <?php foreach ($modules as $module): ?>
                <option value="<?= e($module) ?>"<?= $filters['module'] === $module ? ' selected' : '' ?>><?= e(ucfirst($module)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Events <span class="count-pill"><?= (int) $result['total'] ?></span></h2>
    </div>

    <?php if ($items === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-clipboard" aria-hidden="true"></i>
            <p>No activity matches these filters.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table table-stack mb-0">
                <thead>
                    <tr>
                        <th>When</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Module</th>
                        <th>Record</th>
                        <th>IP</th>
                        <th class="text-end">Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $row): ?>
                        <?php
                        $old = $pretty((string) ($row['old_value'] ?? ''));
                        $new = $pretty((string) ($row['new_value'] ?? ''));
                        $meta = $pretty((string) ($row['meta'] ?? ''));
                        ?>
                        <tr>
                            <td data-label="When" class="text-nowrap"><?= e(FormatHelper::datetime((string) $row['created_at'], 'M j, Y H:i:s')) ?></td>
                            <td data-label="User">
                                <?php if (!empty($row['user_name'])): ?>
                                    <strong><?= e($row['user_name']) ?></strong>
                                    <div class="text-secondary small"><?= e($row['user_email'] ?? '') ?></div>
                                <?php else: ?>
                                    <span class="text-secondary">System / deleted</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="Action"><code><?= e($row['action']) ?></code></td>
                            <td data-label="Module"><span class="role-pill <?= e($moduleClass((string) ($row['module'] ?? ''))) ?>"><?= e(ucfirst((string) ($row['module'] ?? '—'))) ?></span></td>
                            <td data-label="Record"><?= (int) ($row['entity_id'] ?? 0) > 0 ? '#' . (int) $row['entity_id'] : '—' ?></td>
                            <td data-label="IP" class="mono small"><?= e($row['ip_address'] ?? '') ?></td>
                            <td data-label="Details" class="text-end">
                                <?php if ($old !== '' || $new !== '' || $meta !== ''): ?>
                                    <details class="audit-details">
                                        <summary class="btn btn-sm btn-outline-secondary">View</summary>
                                        <div class="audit-values">
                                            <?php if ($old !== ''): ?><div><span class="audit-label">Before</span><pre><?= e($old) ?></pre></div><?php endif; ?>
                                            <?php if ($new !== ''): ?><div><span class="audit-label">After</span><pre><?= e($new) ?></pre></div><?php endif; ?>
                                            <?php if ($meta !== ''): ?><div><span class="audit-label">Meta</span><pre><?= e($meta) ?></pre></div><?php endif; ?>
                                        </div>
                                    </details>
                                <?php else: ?>
                                    <span class="text-secondary">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($result['pages'] > 1): ?>
            <nav class="pager" aria-label="Activity pages">
                <?php for ($p = 1; $p <= $result['pages']; $p++): ?>
                    <a class="btn btn-sm <?= $p === (int) $result['page'] ? 'btn-primary' : 'btn-outline-secondary' ?>" href="<?= e(url('/settings/audit-logs') . $query(['page' => $p])) ?>"><?= $p ?></a>
                <?php endfor; ?>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>
