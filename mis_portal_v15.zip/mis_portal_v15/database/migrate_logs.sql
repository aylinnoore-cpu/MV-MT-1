USE mis_portal;
CREATE TABLE IF NOT EXISTS deletion_log(id INT AUTO_INCREMENT PRIMARY KEY,entity VARCHAR(40),entity_id INT,label VARCHAR(255),snapshot MEDIUMTEXT,reason VARCHAR(500),
 deleted_by INT,deleted_by_name VARCHAR(100),client_ip VARCHAR(45),deleted_at DATETIME,prev_hash CHAR(64),row_hash CHAR(64),INDEX(entity),INDEX(deleted_at));
-- make the log tables permanent: nobody can change or delete rows, even from phpMyAdmin
CREATE TRIGGER IF NOT EXISTS deletion_log_no_update BEFORE UPDATE ON deletion_log FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Deletion log is permanent and cannot be changed';
CREATE TRIGGER IF NOT EXISTS deletion_log_no_delete BEFORE DELETE ON deletion_log FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Deletion log is permanent and cannot be deleted';
CREATE TRIGGER IF NOT EXISTS asset_deletions_no_update BEFORE UPDATE ON asset_deletions FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Deletion log is permanent and cannot be changed';
CREATE TRIGGER IF NOT EXISTS asset_deletions_no_delete BEFORE DELETE ON asset_deletions FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Deletion log is permanent and cannot be deleted';
CREATE TRIGGER IF NOT EXISTS activity_no_update BEFORE UPDATE ON activity FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Activity log is permanent and cannot be changed';
CREATE TRIGGER IF NOT EXISTS activity_no_delete BEFORE DELETE ON activity FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Activity log is permanent and cannot be deleted';
