<?php require __DIR__.'/includes/lib.php';need();head('Dashboard',"Welcome to MIS Portal. Here's an overview of the current system status.");
$r=role();$s=$r=='staff';$id=me()['id'];$F=in_array($r,['support','ed','finance']);$S=in_array($r,['support','ed']);
$c=fn($sql,$p=[])=>q($sql,$p)->fetch()['c'];$a=$s?[' WHERE assigned_to=?',[$id]]:['',[]];$ao=$s?' AND assigned_to=?':'';
$card=fn($ic,$l,$n,$cap,$href)=>'<a class="sc'.($n?'':' z').'" href="'.$href.'"><div class=t><div class=ico>'.ic($ic,28).'</div><div><div class=l>'.$l.'</div><div class=n>'.$n.'</div></div><span class=ar>'.ic('chev',16).'</span></div><hr><p>'.$cap.'</p></a>';
$M='modules/records.php?m=';
echo '<div class=stats>'.$card('box','Total assets',$c('SELECT COUNT(*) c FROM assets'.$a[0],$a[1]),'Total registered assets in system',$M.'assets')
 .$card('ticket','Open tickets',$c('SELECT COUNT(*) c FROM tickets WHERE status IN("open","in_progress")'.($s?' AND created_by=?':''),$a[1]),'Pending support tickets',$M.'tickets')
 .($F?$card('check','Pending approvals',$c('SELECT COUNT(*) c FROM procurement WHERE status IN("requested","ed_approved","finance_approved")'),'Awaiting management approval','modules/approvals.php'):'').$card('box',$S?'Item requests':'My item requests',$c('SELECT COUNT(*) c FROM item_requests WHERE status IN("pending","approved")'.($S?'':' AND user_id=?'),$S?[]:[$id]),$S?'IT item requests awaiting action':'Your requests in progress',$M.'item_requests').'</div>';
if($F)echo '<div class=stats>'.$card('doc','Quotations',$c('SELECT COUNT(*) c FROM documents WHERE kind="quotation"'),'Uploaded quotations','modules/quotes.php')
 .$card('cart','Purchase orders',$c('SELECT COUNT(*) c FROM generated WHERE kind="po"'),'Total purchase orders','modules/gen.php?k=po')
 .$card('file','Comparative statements',$c('SELECT COUNT(*) c FROM generated WHERE kind="cs"'),'Available comparative statements','modules/gen.php?k=cs')
 .($S?$card('users','Staff records',$c('SELECT COUNT(*) c FROM users'),'Total staff records',$M.'users'):'').'</div>';
$qa=[['ticket','Create support ticket',$M.'tickets&a=form',1],['box','Request IT item',$M.'item_requests&a=form',1]];
if($S)$qa[]=['cart','New procurement request',$M.'procurement&a=form',1];if($S)$qa[]=['tool','Log repair / maintenance',$M.'maintenance&a=form',1];if($F)$qa[]=['doc','View reports','modules/reports.php',1];
echo '<div class=qa><h3>'.ic('zap',22).'Quick actions</h3><p>Access commonly used features with one click.</p><div class=qb>';
foreach($qa as $i=>$x)echo '<a href="'.$x[2].'"'.($i?'':' class=p').'>'.ic($x[0],22).$x[1].ic('arr',16).'</a>';echo '</div></div>';
if(!$s){$all=isset($_GET['all']);echo '<div class=card><div class=rh><div class=ico>'.ic('clock',20).'</div><div><h3>Recent activity</h3><p>Saved and updated records from the system.</p></div>'.($all?'':'<a href="?all=1">View all activity &rarr;</a>').'</div>
 <table><tr><th style="width:40px">#<th>Activity<th>User<th>Date &amp; Time<th>Status';$i=0;
 foreach(q('SELECT a.*,u.name FROM activity a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT '.($all?100:6)) as $x){$m=$x['message'];$v=strtok($m,' ');
  $cl=['Saved'=>'g','Signed'=>'g','Created'=>'o','Updated'=>'b','Uploaded'=>'b','Deleted'=>'r','Revoked'=>'r'][$v]??'';$icn=stripos($m,'users')!==false?'user':(['Created'=>'plus','Uploaded'=>'up','Signed'=>'shield','Saved'=>'file'][$v]??'file');
  echo '<tr><td>'.(++$i).'<td><div class=ai>'.ic($icn,18).h($m).'</div><td>'.h($x['name']).'<td>'.h($x['created_at']).'<td><span class="pill '.$cl.'">'.h(in_array($v,['Saved','Signed','Created','Updated','Uploaded','Deleted','Revoked'])?$v:'Done').'</span>';}
 echo '</table></div>';}
foot();
