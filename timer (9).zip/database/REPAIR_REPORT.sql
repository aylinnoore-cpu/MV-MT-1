-- ============================================================================
-- TimeTrack: read-only hierarchy integrity report.
-- Run in phpMyAdmin (SQL tab). Prints the rows tools/repair_hierarchy.php would
-- fix. Does not write anything.
-- ============================================================================

SET NAMES utf8mb4;

-- Team people (manager, members) who have no project_members row.
-- Live dump must list at least user 13 (Hira Ali) on project 1.
SELECT 'team people missing from project_members' AS report,
       x.project_id,
       p.name AS project_name,
       x.user_id,
       u.name AS user_name,
       u.email
FROM (
    SELECT t.project_id, t.manager_id AS user_id FROM teams t WHERE t.manager_id IS NOT NULL
    UNION
    SELECT t.project_id, tm.user_id FROM team_members tm INNER JOIN teams t ON t.id = tm.team_id
) x
INNER JOIN projects p ON p.id = x.project_id
INNER JOIN users u ON u.id = x.user_id
LEFT JOIN project_members pm ON pm.project_id = x.project_id AND pm.user_id = x.user_id
WHERE pm.user_id IS NULL
ORDER BY x.project_id, u.name;

-- project_role = manager rows that are not projects.manager_id.
-- Live dump must list at least project 1 / user 15 and project 2 / user 3.
SELECT 'stray project_members.manager rows' AS report,
       pm.project_id,
       p.name AS project_name,
       p.manager_id AS true_manager_id,
       pm.user_id,
       u.name AS user_name,
       pm.project_role
FROM project_members pm
INNER JOIN projects p ON p.id = pm.project_id
INNER JOIN users u ON u.id = pm.user_id
WHERE pm.project_role = 'manager'
  AND (p.manager_id IS NULL OR p.manager_id <> pm.user_id)
ORDER BY pm.project_id, u.name;

-- True PMs who are missing a project_members row, or whose row is not manager.
SELECT 'project manager membership' AS report,
       p.id AS project_id,
       p.name AS project_name,
       p.manager_id,
       u.name AS manager_name,
       pm.project_role AS current_role
FROM projects p
INNER JOIN users u ON u.id = p.manager_id
LEFT JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = p.manager_id
WHERE p.manager_id IS NOT NULL
  AND (pm.user_id IS NULL OR pm.project_role <> 'manager')
ORDER BY p.id;

-- Tasks whose team belongs to a different project (should be 0; enforced in PHP).
SELECT 'tasks.team_id on another project' AS report,
       t.id AS task_id,
       t.name AS task_name,
       t.project_id,
       t.team_id,
       te.project_id AS team_project_id,
       te.name AS team_name
FROM tasks t
INNER JOIN teams te ON te.id = t.team_id
WHERE te.project_id <> t.project_id
ORDER BY t.id;

-- Assignees who are viewers or not on the project (PM counts as on the project).
SELECT 'task assignees not assignable' AS report,
       ta.task_id,
       t.name AS task_name,
       t.project_id,
       ta.user_id,
       u.name AS user_name,
       pm.project_role
FROM task_assignees ta
INNER JOIN tasks t ON t.id = ta.task_id
INNER JOIN users u ON u.id = ta.user_id
INNER JOIN projects p ON p.id = t.project_id
LEFT JOIN project_members pm ON pm.project_id = t.project_id AND pm.user_id = ta.user_id
WHERE (pm.user_id IS NULL AND (p.manager_id IS NULL OR p.manager_id <> ta.user_id))
   OR pm.project_role = 'viewer'
ORDER BY ta.task_id, u.name;
