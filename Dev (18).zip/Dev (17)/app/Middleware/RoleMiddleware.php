<?php
/**
 * Allows the request only for the listed roles (explicit allow-list, no implicit admin bypass).
 *
 * Runs in the Controller constructor AFTER AuthMiddleware, so the role it checks
 * has just been refreshed from the database.
 *
 *   parent::__construct(true, [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER]);
 */

declare(strict_types=1);

final class RoleMiddleware
{
    /** @param list<string> $allowedRoles */
    public function __construct(private readonly array $allowedRoles)
    {
        // A typo such as "manger" would silently lock everyone out or, worse, be copied around; fail loudly.
        foreach ($allowedRoles as $role) {
            if (!in_array($role, AuthHelper::ROLES, true)) {
                throw new InvalidArgumentException("Unknown role: {$role}");
            }
        }
    }

    public function handle(): void
    {
        $user = AuthHelper::user();

        if ($user === null) {
            throw new HttpException(401);
        }

        if (!in_array($user['role'], $this->allowedRoles, true)) {
            LoggerHelper::warning('RBAC denied', [
                'user_id' => $user['id'],
                'role'    => $user['role'],
                'path'    => Request::current()->path(),
            ]);

            throw new HttpException(403);
        }
    }
}
