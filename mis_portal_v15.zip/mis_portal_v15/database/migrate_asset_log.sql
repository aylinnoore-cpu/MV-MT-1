USE mis_portal;
CREATE TABLE IF NOT EXISTS asset_deletions(id INT AUTO_INCREMENT PRIMARY KEY,asset_id INT,asset_tag VARCHAR(60),name VARCHAR(150),category VARCHAR(80),serial_no VARCHAR(100),
 barcode VARCHAR(40),status VARCHAR(30),assigned_to_name VARCHAR(100),vendor_name VARCHAR(150),cost DECIMAL(12,2),mac_address VARCHAR(17),ip_address VARCHAR(45),
 maintenance_records INT DEFAULT 0,reason VARCHAR(500),snapshot MEDIUMTEXT,deleted_by INT,deleted_by_name VARCHAR(100),client_ip VARCHAR(45),
 deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(deleted_at));
