<?php require __DIR__.'/includes/lib.php';
$first=q('SELECT COUNT(*) c FROM users')->fetch()['c']==0;$e='';
if($_SERVER['REQUEST_METHOD']=='POST'){
 if($first){q('INSERT INTO users(name,email,password,role,department)VALUES(?,?,?,?,?)',[$_POST['name'],$_POST['email'],password_hash($_POST['password'],PASSWORD_DEFAULT),'ed','Management']);$first=false;}
 $u=q('SELECT * FROM users WHERE email=? AND status="active"',[$_POST['email']])->fetch();
 if($u&&password_verify($_POST['password'],$u['password'])){session_regenerate_id(true);unset($u['password']);$_SESSION['u']=$u;header('Location: index.php');exit;}
 $e='Email or password is incorrect.';}
?><!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Sign in</title>
<body style="font:15px system-ui;background:#14171c;display:grid;place-items:center;min-height:100vh;margin:0">
<form method=post style="background:#fff;padding:28px;border:1px solid #dcdfe4;border-radius:6px;width:320px">
<style>.lgx img{max-height:42px;max-width:100%}.lgx img.w{filter:brightness(0) invert(1)}.lgx em{color:#ff6a13;font-style:normal}</style><div class=lgx style="background:#14171c;margin:-28px -28px 18px;padding:18px;text-align:center;color:#fff;font:800 26px sans-serif;letter-spacing:2px;border-radius:6px 6px 0 0"><?=logo_html()?></div><h2 style="margin-top:0">MIS Portal</h2><?php if($first)echo '<p>No users yet. Create the first Executive Director account.</p><input name=name placeholder="Full name" required style="width:100%;margin-bottom:8px;padding:8px">'?>
<p class=err style="color:#a33"><?=h($e)?></p>
<input name=email type=email placeholder=Email required style="width:100%;margin-bottom:8px;padding:8px">
<input name=password type=password placeholder=Password required style="width:100%;margin-bottom:12px;padding:8px">
<button style="width:100%;padding:9px;background:#ff6a13;color:#fff;border:0;border-radius:4px"><?=$first?'Create account':'Sign in'?></button></form>
