USE mis_portal;
CREATE TABLE IF NOT EXISTS vendors(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150),category VARCHAR(60),contact_person VARCHAR(100),phone VARCHAR(50),
 email VARCHAR(120),address TEXT,city VARCHAR(80),ntn VARCHAR(60),website VARCHAR(150),payment_terms VARCHAR(120),bank_details TEXT,notes TEXT,
 status ENUM('active','inactive') DEFAULT 'active',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
ALTER TABLE assets ADD COLUMN IF NOT EXISTS vendor_id INT NULL, ADD COLUMN IF NOT EXISTS warranty_months INT NULL, ADD COLUMN IF NOT EXISTS warranty_start DATE NULL,
 ADD COLUMN IF NOT EXISTS warranty_end DATE NULL, ADD COLUMN IF NOT EXISTS warranty_notes TEXT NULL;
ALTER TABLE procurement ADD COLUMN IF NOT EXISTS vendor_id INT NULL;
-- bring existing free-text vendor names into the vendor list and link them
INSERT INTO vendors(name) SELECT DISTINCT TRIM(x.vendor) FROM (SELECT vendor FROM assets UNION SELECT vendor FROM procurement) x
 WHERE x.vendor IS NOT NULL AND TRIM(x.vendor)<>'' AND TRIM(x.vendor) NOT IN (SELECT name FROM vendors);
UPDATE assets a JOIN vendors v ON v.name=TRIM(a.vendor) SET a.vendor_id=v.id WHERE a.vendor_id IS NULL;
UPDATE procurement p JOIN vendors v ON v.name=TRIM(p.vendor) SET p.vendor_id=v.id WHERE p.vendor_id IS NULL;
