-- TimeTrack Phase 13 / Step 17
-- Remove role and schema duplicates. role_id is the source of truth;
-- tasks.assigned_to yields to task_assignees; activity_logs.entity_id
-- yields over record_id; project_members.project_role is lowercase.
-- Idempotent on MariaDB 11.8. Does not delete or rewrite user/task/log rows
-- beyond filling missing copies of already-known ids.

SET @db_name := DATABASE();

START TRANSACTION;

-- users.role is kept as a denormalized cache of roles.name for the user's role_id.
-- role_id wins when they disagree, so a stale enum cannot escalate privileges.
UPDATE users u
INNER JOIN roles r ON r.id = u.role_id
SET u.role = r.name
WHERE u.role <> r.name;

-- Copy any leftover tasks.assigned_to into task_assignees before the column is dropped.
INSERT IGNORE INTO task_assignees (task_id, user_id, created_at)
SELECT t.id, t.assigned_to, UTC_TIMESTAMP()
FROM tasks t
WHERE t.assigned_to IS NOT NULL
  AND NOT EXISTS (
      SELECT 1 FROM task_assignees ta
      WHERE ta.task_id = t.id AND ta.user_id = t.assigned_to
  );

-- Prefer entity_id. Fill gaps from the duplicate record_id so the audit trail is unchanged.
UPDATE activity_logs
SET entity_id = record_id
WHERE entity_id IS NULL AND record_id IS NOT NULL;

-- Canonical project roles are lowercase manager|member|viewer.
UPDATE project_members
SET project_role = CASE
    WHEN LOWER(project_role) = 'manager' THEN 'manager'
    WHEN LOWER(project_role) = 'viewer' THEN 'viewer'
    ELSE 'member'
END
WHERE project_role NOT IN ('manager', 'member', 'viewer');

COMMIT;

ALTER TABLE `project_members`
    MODIFY `project_role` varchar(60) NOT NULL DEFAULT 'member';

-- Recreate the audit view without record_id so the UI cannot prefer the duplicate.
CREATE OR REPLACE SQL SECURITY INVOKER VIEW `audit_logs` AS
    SELECT `id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`,
           `ip_address`, `user_agent`, `meta`, `old_value`, `new_value`, `created_at`
    FROM `activity_logs`;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name
          AND table_name = 'activity_logs'
          AND column_name = 'record_id'
    ),
    'ALTER TABLE `activity_logs` DROP COLUMN `record_id`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_schema = @db_name
          AND table_name = 'tasks'
          AND constraint_name = 'fk_tasks_assigned'
    ),
    'ALTER TABLE `tasks` DROP FOREIGN KEY `fk_tasks_assigned`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'tasks'
          AND index_name = 'idx_tasks_assigned'
    ),
    'ALTER TABLE `tasks` DROP INDEX `idx_tasks_assigned`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name
          AND table_name = 'tasks'
          AND column_name = 'assigned_to'
    ),
    'ALTER TABLE `tasks` DROP COLUMN `assigned_to`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
