/**
 * Department setup form: nested team blocks, live member filter,
 * and hide people already chosen as this team's managers.
 */
(function () {
    'use strict';

    var list = document.querySelector('[data-team-list]');
    var addBtn = document.querySelector('[data-add-team]');
    var template = document.getElementById('team-block-template');

    function nextIndex() {
        var max = -1;
        if (!list) { return 0; }
        Array.prototype.forEach.call(list.querySelectorAll('[data-team-block]'), function (block) {
            var input = block.querySelector('input[name*="[id]"]');
            if (!input) { return; }
            var match = (input.getAttribute('name') || '').match(/teams\[(\d+)\]/);
            if (match) { max = Math.max(max, parseInt(match[1], 10)); }
        });
        return max + 1;
    }

    function relabel() {
        if (!list) { return; }
        Array.prototype.forEach.call(list.querySelectorAll('[data-team-block]'), function (block, i) {
            var label = block.querySelector('[data-team-label]');
            if (label) { label.textContent = 'Team ' + (i + 1); }
        });
    }

    function applyBlock(block) {
        var filter = block.querySelector('[data-team-filter]');
        var rows = Array.prototype.slice.call(block.querySelectorAll('[data-team-person]'));
        var managers = Array.prototype.slice.call(block.querySelectorAll('[data-team-manager]'));
        var term = filter ? filter.value.trim().toLowerCase() : '';
        var skip = {};
        managers.forEach(function (box) {
            if (box.checked) { skip[box.value] = true; }
        });

        rows.forEach(function (row) {
            var matches = term === '' || (row.getAttribute('data-name') || '').indexOf(term) !== -1;
            var hidden = !!skip[row.getAttribute('data-user-id')];
            var box = row.querySelector('input[type="checkbox"]');
            if (hidden && box) { box.checked = false; }
            row.style.display = (matches && !hidden) ? '' : 'none';
        });
    }

    function applyAll() {
        if (!list) { return; }
        Array.prototype.forEach.call(list.querySelectorAll('[data-team-block]'), applyBlock);
    }

    function bindBlock(block) {
        var filter = block.querySelector('[data-team-filter]');
        var managers = Array.prototype.slice.call(block.querySelectorAll('[data-team-manager]'));
        var remove = block.querySelector('[data-remove-team]');
        if (filter) { filter.addEventListener('input', function () { applyBlock(block); }); }
        managers.forEach(function (box) {
            box.addEventListener('change', function () { applyBlock(block); });
        });
        if (remove) {
            remove.addEventListener('click', function () {
                block.parentNode.removeChild(block);
                relabel();
                applyAll();
            });
        }
        applyBlock(block);
    }

    if (list) {
        Array.prototype.forEach.call(list.querySelectorAll('[data-team-block]'), bindBlock);
    }

    if (addBtn && template && list) {
        addBtn.addEventListener('click', function () {
            var index = nextIndex();
            var html = template.innerHTML.split('__INDEX__').join(String(index));
            var wrap = document.createElement('div');
            wrap.innerHTML = html.trim();
            var block = wrap.firstElementChild;
            if (!block) { return; }
            list.appendChild(block);
            bindBlock(block);
            relabel();
            applyAll();
        });
    }

    applyAll();
})();
