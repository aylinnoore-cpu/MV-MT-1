-- =====================================================================
-- TimeTrack Phase 16: Windows desktop activity + workspace idle policy
-- Safe for an existing Phase 15 database. Run once.
-- =====================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `desktop_agent_devices` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `workspace_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `device_id` VARCHAR(120) NOT NULL,
    `device_name` VARCHAR(160) NOT NULL DEFAULT 'Windows PC',
    `token_hash` CHAR(64) NOT NULL,
    `last_seen_at` DATETIME NOT NULL,
    `last_activity_at` DATETIME NOT NULL,
    `is_locked` TINYINT(1) NOT NULL DEFAULT 0,
    `agent_version` VARCHAR(40) NOT NULL DEFAULT 'unknown',
    `status` ENUM('active','revoked') NOT NULL DEFAULT 'active',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_desktop_agent_token` (`token_hash`),
    UNIQUE KEY `uq_desktop_agent_user_device` (`user_id`,`device_id`),
    KEY `idx_desktop_agent_user_status` (`user_id`,`status`),
    KEY `idx_desktop_agent_seen` (`last_seen_at`),
    CONSTRAINT `fk_desktop_agent_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_desktop_agent_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `desktop_agent_pairing_codes` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `workspace_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `code_hash` CHAR(64) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `used_at` DATETIME NULL,
    `attempts` TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_agent_pair_expiry` (`expires_at`,`used_at`),
    KEY `idx_agent_pair_user` (`user_id`,`created_at`),
    CONSTRAINT `fk_agent_pair_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_agent_pair_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `timer_idle_events` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `timer_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `last_activity_at` DATETIME NOT NULL,
    `warning_at` DATETIME NOT NULL,
    `response` ENUM('continued','manual_pause','auto_paused') NULL,
    `responded_at` DATETIME NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_idle_timer_open` (`timer_id`,`response`,`id`),
    KEY `idx_idle_user_created` (`user_id`,`created_at`),
    CONSTRAINT `fk_idle_timer` FOREIGN KEY (`timer_id`) REFERENCES `active_timers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_idle_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`)
SELECT id, 'idle_detection_enabled', '0' FROM workspaces
WHERE NOT EXISTS (SELECT 1 FROM workspace_settings ws WHERE ws.workspace_id = workspaces.id AND ws.setting_key='idle_detection_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`)
SELECT id, 'idle_threshold_minutes', '10' FROM workspaces
WHERE NOT EXISTS (SELECT 1 FROM workspace_settings ws WHERE ws.workspace_id = workspaces.id AND ws.setting_key='idle_threshold_minutes');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`)
SELECT id, 'idle_warning_seconds', '60' FROM workspaces
WHERE NOT EXISTS (SELECT 1 FROM workspace_settings ws WHERE ws.workspace_id = workspaces.id AND ws.setting_key='idle_warning_seconds');

SET FOREIGN_KEY_CHECKS = 1;
