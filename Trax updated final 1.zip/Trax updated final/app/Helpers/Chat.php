<?php
/**
 * Chat policy, settings, mentions and file rules (Phase 21).
 *
 * Access is re-checked on every request from team_members / project_members
 * (custom and DM membership lives in conversation_members). Client-role users
 * never reach this helper: ChatController and ClientScopeMiddleware 403 first.
 */

declare(strict_types=1);

final class ChatHelper
{
    public const BODY_MAX = 4000;
    public const FILES_PER_MESSAGE = 10;
    public const NAME_MAX = 120;
    public const DEFAULT_MAX_MB = 25;
    public const SEND_LIMIT = 30;
    public const SEND_WINDOW_MINUTES = 1;
    public const UPLOAD_LIMIT = 20;
    public const UPLOAD_WINDOW_MINUTES = 10;
    public const GROUP_MENTION_LIMIT = 5;
    public const GROUP_MENTION_WINDOW_MINUTES = 60;

    public const GROUP_ALIASES = ['all', 'everyone', 'team', 'members'];

    public const DEFAULT_EXTENSIONS = [
        'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'ppt', 'pptx', 'txt', 'rtf', 'odt', 'ods',
        'jpg', 'jpeg', 'png', 'gif', 'webp',
        'dwg', 'dxf', 'skp', 'rvt', 'ifc', 'psd', 'ai',
        'zip',
        'mp3', 'm4a', 'wav', 'mp4',
    ];

    public const BLOCKED_EXTENSIONS = [
        'php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'phar', 'pht', 'phps',
        'html', 'htm', 'shtml', 'svg', 'js', 'mjs', 'cjs',
        'exe', 'bat', 'cmd', 'sh', 'bash', 'msi', 'jar', 'com', 'scr', 'pif',
        'cgi', 'asp', 'aspx', 'jsp', 'pl', 'py', 'rb', 'htaccess',
    ];

    public const INLINE_IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    public const PREVIEW_IMAGE_MIMES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    public const OPAQUE_EXTENSIONS = ['dwg', 'dxf', 'skp', 'rvt', 'ifc', 'psd', 'ai', 'zip'];

    /** @var array<string, list<string>> extension => accepted finfo MIME types */
    private const MIME_MAP = [
        'pdf'  => ['application/pdf'],
        'doc'  => ['application/msword', 'application/octet-stream'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
        'xls'  => ['application/vnd.ms-excel', 'application/octet-stream'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'],
        'csv'  => ['text/csv', 'text/plain', 'application/csv', 'application/vnd.ms-excel'],
        'ppt'  => ['application/vnd.ms-powerpoint', 'application/octet-stream'],
        'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip', 'application/octet-stream'],
        'txt'  => ['text/plain'],
        'rtf'  => ['application/rtf', 'text/rtf', 'text/plain'],
        'odt'  => ['application/vnd.oasis.opendocument.text', 'application/zip', 'application/octet-stream'],
        'ods'  => ['application/vnd.oasis.opendocument.spreadsheet', 'application/zip', 'application/octet-stream'],
        'jpg'  => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png'  => ['image/png'],
        'gif'  => ['image/gif'],
        'webp' => ['image/webp'],
        'dwg'  => ['application/acad', 'application/x-acad', 'application/x-dwg', 'image/vnd.dwg', 'application/dwg', 'application/octet-stream'],
        'dxf'  => ['application/dxf', 'application/x-dxf', 'image/vnd.dxf', 'application/octet-stream', 'text/plain'],
        'skp'  => ['application/vnd.sketchup.skp', 'application/octet-stream'],
        'rvt'  => ['application/octet-stream'],
        'ifc'  => ['application/x-step', 'text/plain', 'application/octet-stream'],
        'psd'  => ['image/vnd.adobe.photoshop', 'application/x-photoshop', 'application/octet-stream'],
        'ai'   => ['application/postscript', 'application/pdf', 'application/octet-stream'],
        'zip'  => ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'],
        'mp3'  => ['audio/mpeg', 'audio/mp3'],
        'm4a'  => ['audio/mp4', 'audio/x-m4a', 'audio/m4a', 'video/mp4'],
        'wav'  => ['audio/wav', 'audio/x-wav', 'audio/wave'],
        'mp4'  => ['video/mp4', 'audio/mp4'],
    ];

    public static function storageDir(): string
    {
        return STORAGE_PATH . '/chat';
    }

    public static function installed(): bool
    {
        return SchemaHelper::tableExists('conversations')
            && SchemaHelper::tableExists('conversation_members')
            && SchemaHelper::tableExists('messages');
    }

    public static function workspaceId(): int
    {
        return WorkspacePolicy::currentId();
    }

    /** @return array<string, string> */
    public static function settings(): array
    {
        $id = self::workspaceId();
        if ($id < 1) {
            return array_intersect_key(Workspace::DEFAULT_SETTINGS, array_flip(self::settingKeys()));
        }

        try {
            return SettingsService::workspace($id);
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat settings read failed', ['error' => $e->getMessage()]);

            return Workspace::DEFAULT_SETTINGS;
        }
    }

    /** @return list<string> */
    public static function settingKeys(): array
    {
        return [
            'chat_admin_read_dms',
            'chat_create_channel_manager',
            'chat_create_channel_member',
            'chat_create_task_from_message_manager',
            'chat_create_task_from_message_member',
            'chat_group_mention_manager',
            'chat_group_mention_member',
            'chat_max_file_mb',
            'chat_allowed_file_types',
            'chat_notice_enabled',
            'chat_notice_text',
        ];
    }

    public static function bool(string $key, bool $default = false): bool
    {
        $raw = strtolower(trim((string) (self::settings()[$key] ?? ($default ? '1' : '0'))));

        return in_array($raw, ['1', 'true', 'yes', 'on'], true);
    }

    public static function adminCanReadDms(): bool
    {
        return self::bool('chat_admin_read_dms', true);
    }

    public static function noticeEnabled(): bool
    {
        return self::bool('chat_notice_enabled', true);
    }

    public static function noticeText(): string
    {
        $text = trim((string) (self::settings()['chat_notice_text'] ?? ''));

        return $text !== '' ? mb_substr($text, 0, 240, 'UTF-8')
            : 'Messages are company records and may be reviewed by an admin.';
    }

    public static function canCreateChannel(?string $role = null): bool
    {
        $role = $role ?? AuthHelper::role();
        if ($role === AuthHelper::ROLE_ADMIN) {
            return true;
        }
        if ($role === AuthHelper::ROLE_MANAGER) {
            return self::bool('chat_create_channel_manager', false);
        }
        if ($role === AuthHelper::ROLE_EMPLOYEE) {
            return self::bool('chat_create_channel_member', false);
        }

        return false;
    }

    public static function canCreateTaskFromMessage(?string $role = null): bool
    {
        if (!WorkspacePolicy::canCreateTask()) {
            return false;
        }
        $role = $role ?? AuthHelper::role();
        if ($role === AuthHelper::ROLE_ADMIN) {
            return true;
        }
        if ($role === AuthHelper::ROLE_MANAGER) {
            return self::bool('chat_create_task_from_message_manager', false);
        }
        if ($role === AuthHelper::ROLE_EMPLOYEE) {
            return self::bool('chat_create_task_from_message_member', false);
        }

        return false;
    }

    public static function canUseGroupMentions(?string $role = null): bool
    {
        $role = $role ?? AuthHelper::role();
        if ($role === AuthHelper::ROLE_ADMIN) {
            return true;
        }
        if ($role === AuthHelper::ROLE_MANAGER) {
            return self::bool('chat_group_mention_manager', true);
        }
        if ($role === AuthHelper::ROLE_EMPLOYEE) {
            return self::bool('chat_group_mention_member', true);
        }

        return false;
    }

    public static function configuredMaxBytes(): int
    {
        $mb = (int) (self::settings()['chat_max_file_mb'] ?? self::DEFAULT_MAX_MB);
        $mb = max(1, min(512, $mb));

        return $mb * 1048576;
    }

    public static function iniBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '' || $value === '0') {
            return 0;
        }
        $unit = strtolower(substr($value, -1));
        $number = (float) $value;
        if ($unit === 'g') {
            $number *= 1024 * 1024 * 1024;
        } elseif ($unit === 'm') {
            $number *= 1024 * 1024;
        } elseif ($unit === 'k') {
            $number *= 1024;
        }

        return (int) round($number);
    }

    public static function serverUploadLimitBytes(): int
    {
        $candidates = [];
        foreach (['upload_max_filesize', 'post_max_size'] as $key) {
            $bytes = self::iniBytes((string) ini_get($key));
            if ($bytes > 0) {
                $candidates[] = $bytes;
            }
        }

        return $candidates === [] ? 0 : min($candidates);
    }

    public static function effectiveMaxBytes(): int
    {
        $configured = self::configuredMaxBytes();
        $server = self::serverUploadLimitBytes();
        if ($server > 0 && $server < $configured) {
            return $server;
        }

        return $configured;
    }

    public static function formatBytes(int $bytes): string
    {
        if ($bytes >= 1048576) {
            $mb = $bytes / 1048576;
            $label = $mb >= 10 ? (string) (int) round($mb) : rtrim(rtrim(number_format($mb, 1, '.', ''), '0'), '.');

            return $label . ' MB';
        }
        if ($bytes >= 1024) {
            return (string) (int) round($bytes / 1024) . ' KB';
        }

        return (string) $bytes . ' B';
    }

    /** @return list<string> */
    public static function allowedExtensions(): array
    {
        $raw = strtolower((string) (self::settings()['chat_allowed_file_types'] ?? ''));
        $parts = preg_split('/[\s,;]+/', $raw) ?: [];
        $out = [];
        foreach ($parts as $part) {
            $ext = ltrim(trim($part), '.');
            if ($ext === '' || !preg_match('/^[a-z0-9]{1,16}$/', $ext)) {
                continue;
            }
            if (in_array($ext, self::BLOCKED_EXTENSIONS, true)) {
                continue;
            }
            $out[] = $ext;
        }

        return $out === [] ? self::DEFAULT_EXTENSIONS : array_values(array_unique($out));
    }

    public static function isBlockedName(string $name): bool
    {
        $base = strtolower(basename(str_replace('\\', '/', $name)));
        $base = preg_replace('/\s+/', '', $base) ?? $base;
        $parts = explode('.', $base);
        array_shift($parts);
        foreach ($parts as $part) {
            if (in_array($part, self::BLOCKED_EXTENSIONS, true) || str_starts_with($part, 'php')) {
                return true;
            }
        }

        return false;
    }

    public static function extensionOf(string $name): string
    {
        $base = strtolower(basename(str_replace('\\', '/', $name)));
        $pos = strrpos($base, '.');
        if ($pos === false) {
            return '';
        }

        return substr($base, $pos + 1);
    }

    /**
     * @return array{ok: true, ext: string, mime: string}|array{ok: false, error: string}
     */
    public static function inspectUpload(array $file): array
    {
        $error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) {
            return ['ok' => false, 'error' => 'No file was selected.'];
        }
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            $limit = self::formatBytes(self::serverUploadLimitBytes() ?: self::effectiveMaxBytes());

            return ['ok' => false, 'error' => 'That file is larger than the server upload limit (' . $limit . ').'];
        }
        if ($error !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'error' => 'The file could not be uploaded. Please try again.'];
        }

        $name = (string) ($file['name'] ?? 'file');
        $tmp = (string) ($file['tmp_name'] ?? '');
        $size = (int) ($file['size'] ?? 0);
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            return ['ok' => false, 'error' => 'The uploaded file is invalid.'];
        }
        if (self::isBlockedName($name)) {
            return ['ok' => false, 'error' => 'That file type is not allowed.'];
        }

        $ext = self::extensionOf($name);
        $allowed = self::allowedExtensions();
        if ($ext === '' || !in_array($ext, $allowed, true)) {
            return ['ok' => false, 'error' => '“' . $ext . '” files are not allowed. Allowed types: ' . implode(', ', $allowed) . '.'];
        }

        $max = self::effectiveMaxBytes();
        if ($size < 1 || $size > $max) {
            $msg = 'Each file must be ' . self::formatBytes($max) . ' or smaller.';
            $server = self::serverUploadLimitBytes();
            if ($server > 0 && $server < self::configuredMaxBytes()) {
                $msg .= ' The server limit is ' . self::formatBytes($server) . '.';
            }

            return ['ok' => false, 'error' => $msg];
        }

        $mime = self::detectMime($tmp);
        $accepted = self::MIME_MAP[$ext] ?? [];
        if ($accepted === [] || !in_array($mime, $accepted, true)) {
            if (in_array($ext, self::OPAQUE_EXTENSIONS, true) && ($mime === 'application/octet-stream' || $mime === '')) {
                $mime = $mime !== '' ? $mime : 'application/octet-stream';
            } else {
                return ['ok' => false, 'error' => 'The contents of “' . $name . '” do not match a permitted file type.'];
            }
        }

        return ['ok' => true, 'ext' => $ext, 'mime' => $mime];
    }

    public static function detectMime(string $path): string
    {
        if (!is_file($path)) {
            return '';
        }
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = (string) $finfo->file($path);
        $mime = strtolower(trim(explode(';', $mime)[0]));

        return $mime;
    }

    public static function ensureStorage(): void
    {
        $dir = self::storageDir();
        if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('Could not create the chat file directory.');
        }
        $deny = $dir . '/.htaccess';
        if (!is_file($deny)) {
            @file_put_contents($deny, "Require all denied\n");
        }
    }

    /**
     * @return array{stored_name: string, original_name: string, size_bytes: int, mime: string, extension: string}
     */
    public static function storeUpload(array $file, string $ext, string $mime): array
    {
        self::ensureStorage();
        $original = mb_substr(basename((string) ($file['name'] ?? 'file')), 0, 255, 'UTF-8');
        $stored = bin2hex(random_bytes(16)) . '.' . $ext;
        $dest = self::storageDir() . '/' . $stored;
        if (!move_uploaded_file((string) $file['tmp_name'], $dest)) {
            throw new RuntimeException('The file could not be saved.');
        }
        @chmod($dest, 0640);

        return [
            'stored_name'    => $stored,
            'original_name'  => $original !== '' ? $original : 'file.' . $ext,
            'size_bytes'     => (int) ($file['size'] ?? 0),
            'mime'           => $mime,
            'extension'      => $ext,
        ];
    }

    public static function absoluteFile(string $storedName): ?string
    {
        if (!preg_match('/^[a-f0-9]{32}\.[a-z0-9]{1,16}$/', $storedName)) {
            return null;
        }
        $base = realpath(self::storageDir());
        $path = realpath(self::storageDir() . '/' . $storedName);
        if ($base === false || $path === false) {
            return null;
        }
        if (!str_starts_with($path, $base . DIRECTORY_SEPARATOR) || !is_file($path)) {
            return null;
        }

        return $path;
    }

    public static function handleFor(string $name, int $userId): string
    {
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '', $name) ?? '');
        if ($slug === '') {
            $slug = 'user';
        }

        return $slug . $userId;
    }

    /**
     * @param list<array{id: int, name: string, handle?: string}> $members
     * @return array{user_ids: list<int>, group: bool, unknown: list<string>}
     */
    public static function parseMentions(string $body, array $members): array
    {
        $byHandle = [];
        $byId = [];
        foreach ($members as $member) {
            $id = (int) $member['id'];
            if ($id < 1) {
                continue;
            }
            $handle = strtolower((string) ($member['handle'] ?? self::handleFor((string) $member['name'], $id)));
            $byHandle[$handle] = $id;
            $byId[$id] = true;
        }

        $userIds = [];
        $unknown = [];
        $group = false;

        if (preg_match_all('/@([A-Za-z0-9_]+)/', $body, $matches) < 1) {
            return ['user_ids' => [], 'group' => false, 'unknown' => []];
        }

        foreach ($matches[1] as $raw) {
            $token = strtolower((string) $raw);
            if (in_array($token, self::GROUP_ALIASES, true)) {
                $group = true;
                continue;
            }
            if (isset($byHandle[$token])) {
                $userIds[] = $byHandle[$token];
                continue;
            }
            $unknown[] = $token;
        }

        if ($group) {
            $userIds = array_keys($byId);
        }

        $userIds = array_values(array_unique(array_filter(
            array_map('intval', $userIds),
            static fn (int $id): bool => $id > 0
        )));

        return ['user_ids' => $userIds, 'group' => $group, 'unknown' => array_values(array_unique($unknown))];
    }

    public static function tooManySends(int $userId): bool
    {
        if ($userId < 1 || !self::installed()) {
            return false;
        }
        try {
            $count = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM messages
                 WHERE user_id = :uid AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL :mins MINUTE)',
                ['uid' => $userId, 'mins' => self::SEND_WINDOW_MINUTES]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat send rate lookup failed', ['error' => $e->getMessage()]);

            return false;
        }

        return $count >= self::SEND_LIMIT;
    }

    public static function tooManyUploads(int $userId): bool
    {
        if ($userId < 1 || !SchemaHelper::tableExists('message_attachments')) {
            return false;
        }
        try {
            $count = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM message_attachments a
                 INNER JOIN messages m ON m.id = a.message_id
                 WHERE m.user_id = :uid AND a.created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL :mins MINUTE)',
                ['uid' => $userId, 'mins' => self::UPLOAD_WINDOW_MINUTES]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat upload rate lookup failed', ['error' => $e->getMessage()]);

            return false;
        }

        return $count >= self::UPLOAD_LIMIT;
    }

    public static function tooManyGroupMentions(int $userId): bool
    {
        if ($userId < 1 || !SchemaHelper::tableExists('message_mentions')) {
            return false;
        }
        try {
            $count = (int) Database::fetchValue(
                'SELECT COUNT(DISTINCT mm.message_id) FROM message_mentions mm
                 INNER JOIN messages m ON m.id = mm.message_id
                 WHERE m.user_id = :uid AND mm.is_group = 1
                   AND m.created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL :mins MINUTE)',
                ['uid' => $userId, 'mins' => self::GROUP_MENTION_WINDOW_MINUTES]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat group-mention rate lookup failed', ['error' => $e->getMessage()]);

            return false;
        }

        return $count >= self::GROUP_MENTION_LIMIT;
    }

    public static function shareTeamOrProject(int $userA, int $userB): bool
    {
        if ($userA < 1 || $userB < 1 || $userA === $userB) {
            return false;
        }
        try {
            if (SchemaHelper::tableExists('team_members')) {
                $sharedTeam = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM team_members a
                     INNER JOIN team_members b ON b.team_id = a.team_id AND b.user_id = :b
                     WHERE a.user_id = :a LIMIT 1',
                    ['a' => $userA, 'b' => $userB]
                );
                if ($sharedTeam > 0) {
                    return true;
                }
            }
            if (SchemaHelper::tableExists('team_managers')) {
                $sharedMgr = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM (
                        SELECT team_id, user_id FROM team_managers
                        UNION
                        SELECT team_id, user_id FROM team_members
                     ) x
                     INNER JOIN (
                        SELECT team_id, user_id FROM team_managers
                        UNION
                        SELECT team_id, user_id FROM team_members
                     ) y ON y.team_id = x.team_id AND y.user_id = :b2
                     WHERE x.user_id = :a2 LIMIT 1',
                    ['a2' => $userA, 'b2' => $userB]
                );
                if ($sharedMgr > 0) {
                    return true;
                }
            }
            if (SchemaHelper::tableExists('project_members')) {
                $sharedProject = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM (
                        SELECT project_id, user_id FROM project_members
                        UNION
                        SELECT id AS project_id, manager_id AS user_id FROM projects WHERE manager_id IS NOT NULL AND manager_id > 0
                     ) x
                     INNER JOIN (
                        SELECT project_id, user_id FROM project_members
                        UNION
                        SELECT id AS project_id, manager_id AS user_id FROM projects WHERE manager_id IS NOT NULL AND manager_id > 0
                     ) y ON y.project_id = x.project_id AND y.user_id = :pb
                     WHERE x.user_id = :pa LIMIT 1',
                    ['pa' => $userA, 'pb' => $userB]
                );
                if ($sharedProject > 0) {
                    return true;
                }
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('Chat DM eligibility lookup failed', ['error' => $e->getMessage()]);
        }

        return false;
    }
}
