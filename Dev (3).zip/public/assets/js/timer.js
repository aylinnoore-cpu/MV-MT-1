/*
 * Server-authoritative timer.
 *
 * Fetches /time/status on load, ticks from the server-reported elapsed seconds
 * (not Date.parse of a client clock), and handles every [data-timer-start] /
 * [data-timer-stop] control on the page.
 */
/*
 * Live timer feed for the Time page.
 * The server is polled periodically for authoritative timer state; each row
 * then advances locally every second between polls. This avoids a database
 * request every second while still keeping different viewers synchronized.
 */
(function () {
    'use strict';

    var panel = document.querySelector('[data-live-timers-panel]');
    if (!panel) { return; }

    var url = panel.getAttribute('data-live-timers-url') || '';
    var userId = panel.getAttribute('data-live-user-id') || '0';
    var body = panel.querySelector('[data-live-timers-body]');
    var countEl = panel.querySelector('[data-live-timers-count]');
    var timers = Object.create(null);
    var pollTimer = null;
    var tickTimer = null;
    var polling = false;

    function pad(n) { return n < 10 ? '0' + n : String(n); }
    function duration(seconds) {
        seconds = Math.max(0, Math.floor(seconds || 0));
        var h = Math.floor(seconds / 3600);
        var m = Math.floor((seconds % 3600) / 60);
        var s = seconds % 60;
        return h + ':' + pad(m) + ':' + pad(s);
    }
    function text(value) {
        return value === null || value === undefined || value === '' ? '—' : String(value);
    }
    function formatStart(iso) {
        if (!iso) { return '—'; }
        try {
            return new Intl.DateTimeFormat('en-PK', {
                timeZone: 'Asia/Karachi', month: 'short', day: 'numeric',
                hour: 'numeric', minute: '2-digit', hour12: true
            }).format(new Date(iso));
        } catch (e) {
            return iso;
        }
    }
    function currentSeconds(item) {
        if (item.paused) { return item.elapsed; }
        return item.elapsed + Math.max(0, Math.floor((Date.now() - item.anchorAt) / 1000));
    }
    function makeCell(value, className) {
        var td = document.createElement('td');
        if (className) { td.className = className; }
        td.textContent = value;
        return td;
    }
    function render() {
        var ids = Object.keys(timers);
        panel.hidden = ids.length === 0;
        if (countEl) { countEl.textContent = String(ids.length); }
        if (!body) { return; }
        body.innerHTML = '';
        ids.forEach(function (id) {
            var item = timers[id];
            var tr = document.createElement('tr');
            tr.className = 'live-timer-row';
            tr.setAttribute('data-live-timer-id', id);
            if (window.__ttViewAllLiveTimers) {
                tr.appendChild(makeCell(text(item.user_name), 'fw-medium'));
            }
            tr.appendChild(makeCell(text(item.project_name)));
            tr.appendChild(makeCell(text(item.task_name)));
            tr.appendChild(makeCell(text(item.description)));
            tr.appendChild(makeCell(formatStart(item.started_at_iso), 'mono text-nowrap'));
            var durationCell = makeCell(duration(currentSeconds(item)), 'live-duration mono text-end');
            durationCell.setAttribute('data-live-duration', id);
            tr.appendChild(durationCell);
            body.appendChild(tr);
        });
    }
    function tick() {
        Object.keys(timers).forEach(function (id) {
            var el = body ? body.querySelector('[data-live-duration="' + id + '"]') : null;
            if (el) { el.textContent = duration(currentSeconds(timers[id])); }
        });
    }
    function parse(response) {
        return response.text().then(function (raw) {
            var data = {};
            try { data = raw ? JSON.parse(raw) : {}; } catch (e) { data = {}; }
            return data;
        });
    }
    function refresh() {
        if (!url || polling) { return; }
        polling = true;
        var requestUrl = url;
        if (userId && userId !== '0') {
            requestUrl += (requestUrl.indexOf('?') === -1 ? '?' : '&') + 'user_id=' + encodeURIComponent(userId);
        }
        fetch(requestUrl, {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            cache: 'no-store'
        }).then(parse).then(function (data) {
            if (!data.ok || !Array.isArray(data.timers)) { return; }
            var next = Object.create(null);
            data.timers.forEach(function (timer) {
                var id = String(timer.id);
                next[id] = {
                    id: id,
                    user_name: timer.user_name || '',
                    project_name: timer.project_name || '',
                    task_name: timer.task_name || '',
                    description: timer.description || '',
                    started_at_iso: timer.started_at_iso || '',
                    elapsed: parseInt(timer.elapsed_seconds, 10) || 0,
                    paused: !!timer.paused,
                    anchorAt: Date.now()
                };
            });
            timers = next;
            render();
            tick();
        }).catch(function () { /* keep the last good state visible */ })
          .finally(function () { polling = false; });
    }

    window.__ttViewAllLiveTimers = panel.querySelector('thead th:first-child') &&
        panel.querySelector('thead th:first-child').textContent.trim() === 'Person';

    refresh();
    pollTimer = window.setInterval(refresh, 5000);
    tickTimer = window.setInterval(tick, 1000);

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) { refresh(); }
    });
    window.addEventListener('tt:timer-changed', refresh);
})();

(function () {
    'use strict';

    var bar = document.querySelector('[data-timer-bar]');
    if (!bar) { return; }

    var statusUrl = bar.getAttribute('data-status-url') || '';
    var startUrl = bar.getAttribute('data-start-url') || '';
    var stopUrl = bar.getAttribute('data-stop-url') || '';
    var pauseUrl = bar.getAttribute('data-pause-url') || '';
    var resumeUrl = bar.getAttribute('data-resume-url') || '';
    var pingUrl = bar.getAttribute('data-ping-url') || '';
    var tasksUrl = bar.getAttribute('data-tasks-url') || '';

    var clockEl = bar.querySelector('[data-timer-clock]');
    var projectEl = bar.querySelector('[data-timer-project]');
    var taskEl = bar.querySelector('[data-timer-task]');
    var stopBtn = bar.querySelector('[data-timer-stop]');
    var toggleBtn = bar.querySelector('[data-timer-toggle]');
    var toggleLabel = bar.querySelector('[data-timer-toggle-label]');
    var toggleIcon = toggleBtn ? toggleBtn.querySelector('i') : null;
    var conflictModalEl = document.querySelector('[data-timer-stop-conflict-modal]');
    var conflictModal = null;
    var conflictDetails = conflictModalEl ? conflictModalEl.querySelector('[data-timer-conflict-details]') : null;
    var trimBtn = conflictModalEl ? conflictModalEl.querySelector('[data-timer-trim]') : null;
    var discardBtn = conflictModalEl ? conflictModalEl.querySelector('[data-timer-discard]') : null;

    if (conflictModalEl && window.bootstrap && window.bootstrap.Modal) {
        conflictModal = window.bootstrap.Modal.getOrCreateInstance(conflictModalEl);
    }

    var originElapsed = 0;
    var originAt = 0;
    var running = false;
    var paused = false;
    var tickTimer = null;
    var busy = false;

    function pad(n) { return n < 10 ? '0' + n : String(n); }

    function formatElapsed(seconds) {
        seconds = Math.max(0, Math.floor(seconds));
        var h = Math.floor(seconds / 3600);
        var m = Math.floor((seconds % 3600) / 60);
        var s = seconds % 60;
        return h + ':' + pad(m) + ':' + pad(s);
    }

    function currentElapsed() {
        if (!running) { return originElapsed; }
        return originElapsed + Math.max(0, Math.floor((Date.now() - originAt) / 1000));
    }

    function renderClock() {
        if (clockEl) {
            clockEl.textContent = formatElapsed(currentElapsed());
        }
    }

    function applyTimer(timer) {
        if (!timer) {
            running = false;
            paused = false;
            originElapsed = 0;
            originAt = Date.now();
            bar.hidden = true;
            bar.classList.add('is-idle');
            bar.setAttribute('data-started-at', '');
            bar.setAttribute('data-elapsed', '0');
            if (stopBtn) { stopBtn.disabled = true; }
            if (toggleBtn) { toggleBtn.disabled = true; }
            if (projectEl) { projectEl.textContent = 'Timer running'; }
            if (taskEl) {
                taskEl.textContent = '';
                taskEl.classList.add('d-none');
            }
            renderClock();
            return;
        }

        originElapsed = parseInt(timer.elapsed_seconds, 10) || 0;
        originAt = Date.now();
        paused = !!timer.paused;
        running = !paused;

        bar.hidden = false;
        bar.classList.remove('is-idle');
        bar.classList.toggle('is-paused', paused);
        bar.setAttribute('data-started-at', timer.started_at_iso || '');
        bar.setAttribute('data-elapsed', String(originElapsed));

        if (projectEl) { projectEl.textContent = timer.project_name || 'Timer running'; }
        if (taskEl) {
            if (timer.task_name) {
                taskEl.textContent = timer.task_name;
                taskEl.classList.remove('d-none');
            } else {
                taskEl.textContent = '';
                taskEl.classList.add('d-none');
            }
        }
        if (stopBtn) { stopBtn.disabled = false; }
        if (toggleBtn) {
            toggleBtn.disabled = false;
            if (toggleLabel) { toggleLabel.textContent = paused ? 'Resume' : 'Pause'; }
            if (toggleIcon) {
                toggleIcon.className = paused ? 'fa-solid fa-play' : 'fa-solid fa-pause';
            }
        }
        renderClock();
        window.dispatchEvent(new Event('tt:timer-changed'));
    }

    function tick() {
        if (!running) { return; }
        renderClock();
    }

    function ensureTicker() {
        if (tickTimer) { return; }
        tickTimer = window.setInterval(tick, 1000);
    }

    function parseJson(response) {
        return response.text().then(function (text) {
            var data = {};
            if (text) {
                try { data = JSON.parse(text); } catch (e) { data = {}; }
            }
            data._http = response.status;
            data._okHttp = response.ok;
            return data;
        });
    }

    function fail(message) {
        window.alert(message || 'The timer request failed.');
    }

    function startFrom(el) {
        if (busy) { return; }

        var form = el.closest ? el.closest('[data-timer-start-form], form') : null;
        var projectId = el.getAttribute('data-project-id')
            || (form && form.querySelector('[name="project_id"]') ? form.querySelector('[name="project_id"]').value : '')
            || '';
        var taskId = el.getAttribute('data-task-id')
            || (form && form.querySelector('[name="task_id"]') ? form.querySelector('[name="task_id"]').value : '')
            || '';
        var description = el.getAttribute('data-description')
            || (form && form.querySelector('[name="description"]') ? form.querySelector('[name="description"]').value : '')
            || '';
        var billable = el.getAttribute('data-billable');
        if (billable === null && form) {
            var billableField = form.querySelector('[name="is_billable"]');
            if (billableField) {
                billable = billableField.type === 'checkbox' ? (billableField.checked ? '1' : '0') : billableField.value;
            }
        }

        if (!projectId) {
            fail('Choose a project first.');
            return;
        }

        var body = {
            project_id: parseInt(projectId, 10),
            description: description
        };
        if (taskId) { body.task_id = parseInt(taskId, 10); }
        if (billable === '0' || billable === '1') { body.is_billable = parseInt(billable, 10); }

        busy = true;
        fetch(startUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(body)
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                fail(data.message || (data.error && data.error.message) || 'Could not start the timer.');
                return;
            }
            applyTimer(data.timer);
        }).catch(function () {
            busy = false;
            fail('Could not start the timer.');
        });
    }

    function formatConflictTime(value) {
        if (!value) { return '—'; }
        try {
            var normalized = String(value).replace(' ', 'T') + 'Z';
            return new Intl.DateTimeFormat('en-PK', {
                timeZone: 'Asia/Karachi',
                dateStyle: 'medium',
                timeStyle: 'short',
                hour12: true
            }).format(new Date(normalized));
        } catch (e) {
            return String(value) + ' UTC';
        }
    }

    function showStopConflict(data) {
        if (!conflictModalEl || !conflictModal) {
            fail((data && data.message) || 'The timer overlaps existing time. Open the Time page to resolve it.');
            return;
        }

        var conflict = data.conflict || {};
        if (conflictDetails) {
            conflictDetails.textContent = 'Existing entry: ' +
                formatConflictTime(conflict.start_time) + ' – ' +
                formatConflictTime(conflict.end_time) + '.';
        }
        if (trimBtn) {
            trimBtn.disabled = data.can_trim !== true;
            trimBtn.title = data.can_trim === true
                ? 'Save the timer only up to the start of the conflicting entry.'
                : 'The conflict begins at or before the timer start, so trimming is not possible.';
        }
        conflictModal.show();
    }

    function resolveStop(resolution) {
        if (busy) { return; }
        busy = true;

        fetch(stopUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ resolution: resolution })
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                fail(data.message || (data.error && data.error.message) || 'Could not resolve the timer conflict.');
                return;
            }
            if (conflictModal) { conflictModal.hide(); }
            applyTimer(null);
            window.dispatchEvent(new Event('tt:timer-changed'));
        }).catch(function () {
            busy = false;
            fail('Could not resolve the timer conflict.');
        });
    }

    function stopTimer() {
        if (busy) { return; }
        busy = true;

        fetch(stopUrl, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                if (data.resolution_required === true) {
                    showStopConflict(data);
                    return;
                }
                fail(data.message || (data.error && data.error.message) || 'Could not stop the timer.');
                return;
            }
            applyTimer(null);
        }).catch(function () {
            busy = false;
            fail('Could not stop the timer.');
        });
    }

    function togglePause() {
        if (busy || !pauseUrl || !resumeUrl) { return; }
        busy = true;
        var url = paused ? resumeUrl : pauseUrl;

        fetch(url, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                fail(data.message || (data.error && data.error.message) || 'Could not change the timer state.');
                return;
            }
            applyTimer(data.timer || null);
        }).catch(function () {
            busy = false;
            fail('Could not change the timer state.');
        });
    }

    function loadStatus() {
        if (!statusUrl) { return; }

        fetch(statusUrl, {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(parseJson).then(function (data) {
            if (data.ok) {
                applyTimer(data.timer || null);
            }
        }).catch(function () { /* keep server-rendered bar */ });
    }

    function ping() {
        if (!running || !pingUrl) { return; }
        fetch(pingUrl, {
            method: 'POST',
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).catch(function () { /* ignore */ });
    }

    function fillTasks(select, projectId, selectedId) {
        if (!select || !tasksUrl) { return; }
        select.innerHTML = '<option value="">No task</option>';
        if (!projectId) { return; }

        fetch(tasksUrl + (tasksUrl.indexOf('?') === -1 ? '?' : '&') + 'project_id=' + encodeURIComponent(projectId), {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(parseJson).then(function (data) {
            if (!data.ok || !data.tasks) { return; }
            data.tasks.forEach(function (task) {
                var opt = document.createElement('option');
                opt.value = String(task.id);
                opt.textContent = task.name;
                if (selectedId && String(selectedId) === String(task.id)) {
                    opt.selected = true;
                }
                select.appendChild(opt);
            });
        }).catch(function () { /* keep empty */ });
    }

    document.addEventListener('click', function (event) {
        var startEl = event.target.closest ? event.target.closest('[data-timer-start]') : null;
        if (startEl && startEl.tagName !== 'SPAN') {
            event.preventDefault();
            startFrom(startEl);
            return;
        }

        var toggleEl = event.target.closest ? event.target.closest('[data-timer-toggle]') : null;
        if (toggleEl) {
            event.preventDefault();
            togglePause();
            return;
        }

        var stopEl = event.target.closest ? event.target.closest('[data-timer-stop]') : null;
        if (stopEl) {
            event.preventDefault();
            stopTimer();
            return;
        }
        var trimEl = event.target.closest ? event.target.closest('[data-timer-trim]') : null;
        if (trimEl) {
            event.preventDefault();
            resolveStop('trim');
            return;
        }

        var discardEl = event.target.closest ? event.target.closest('[data-timer-discard]') : null;
        if (discardEl) {
            event.preventDefault();
            resolveStop('discard');
        }
    });

    document.querySelectorAll('[data-timer-project-select]').forEach(function (select) {
        var root = select.closest('form') || select.parentElement;
        var taskSelect = root ? root.querySelector('[data-timer-task-select]') : null;
        select.addEventListener('change', function () {
            var selected = taskSelect ? (taskSelect.getAttribute('data-selected-task') || '') : '';
            fillTasks(taskSelect, select.value, selected);
        });
        if (select.value) {
            var selected = taskSelect ? (taskSelect.getAttribute('data-selected-task') || '') : '';
            fillTasks(taskSelect, select.value, selected);
        }
    });

    var manualModal = document.getElementById('manualEntryModal');
    if (manualModal && manualModal.getAttribute('data-open') === '1' && window.bootstrap && window.bootstrap.Modal) {
        window.bootstrap.Modal.getOrCreateInstance(manualModal).show();
    }

    window.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') {
            loadStatus();
        }
    });

    applyTimer(bar.classList.contains('is-idle') ? null : {
        elapsed_seconds: parseInt(bar.getAttribute('data-elapsed') || '0', 10) || 0,
        started_at_iso: bar.getAttribute('data-started-at') || '',
        project_name: projectEl ? projectEl.textContent : '',
        task_name: taskEl && !taskEl.classList.contains('d-none') ? taskEl.textContent : ''
    });

    ensureTicker();
    loadStatus();
    window.setInterval(ping, 60000);
})();
