<?php
/**
 * Shared top of every report page (Clockify layout): report tabs, date range + export,
 * then the filter strip. Styles live in assets/css/reports.css.
 *
 * @var string $tab
 * @var array<string,mixed> $period
 * @var array<string,mixed> $filters
 * @var array<string,mixed> $query
 */
$isTime = in_array($tab, ['summary', 'detailed', 'weekly'], true);
$isClient = AuthHelper::hasRole(AuthHelper::ROLE_CLIENT);
$tabs = $isTime
    ? ['summary' => 'Summary', 'detailed' => 'Detailed', 'weekly' => 'Weekly']
    : ['attendance' => 'Attendance', 'assignments' => 'Assignments'];
$tabUrl = static function (string $name, array $extra = []) use ($query): string {
    $params = array_merge($query, $extra);
    unset($params['page']);
    $params = array_filter($params, static fn($v): bool => $v !== '' && $v !== null && $v !== 0 && $v !== '0');
    $qs = http_build_query($params);
    return url('/reports/' . $name) . ($qs !== '' ? '?' . $qs : '');
};
$visibleFilters = match ($tab) {
    'attendance' => ['user'],
    'assignments' => ['user', 'project'],
    default => ['user', 'client', 'project', 'task', 'billable'],
};
$carry = static function (array $skip = []) use ($filters, $query): string {
    $out = '';
    $pairs = ['from' => $filters['from'], 'to' => $filters['to'], 'user_id' => $filters['user_id'], 'client_id' => $filters['client_id'],
              'project_id' => $filters['project_id'], 'task_id' => $filters['task_id'], 'billable' => $filters['billable']];
    foreach (['group', 'then', 'all'] as $k) { if (!empty($query[$k])) { $pairs[$k] = $query[$k]; } }
    foreach ($pairs as $k => $v) {
        if (in_array($k, $skip, true) || $v === '' || $v === 0 || $v === '0') { continue; }
        $out .= '<input type="hidden" name="' . e($k) . '" value="' . e((string) $v) . '">';
    }
    return $out;
};
?>
<div class="rk">
<div class="rk-top">
    <div class="rk-tabs">
        <div class="dropdown">
            <button type="button" class="rk-kind" data-bs-toggle="dropdown" aria-expanded="false"><?= $isTime ? 'Time report' : 'Team report' ?></button>
            <ul class="dropdown-menu rk-menu">
                <li><a class="dropdown-item<?= $isTime ? ' is-active' : '' ?>" href="<?= e(url('/reports/summary')) ?>">Time report</a></li>
                <?php if (!$isClient): ?><li><a class="dropdown-item<?= !$isTime ? ' is-active' : '' ?>" href="<?= e(url('/reports/attendance')) ?>">Team report</a></li><?php endif; ?>
                <?php if ($isAdmin ?? false): ?><li><hr class="dropdown-divider"></li><li><a class="dropdown-item" href="<?= e(url('/reports/access')) ?>"><i class="fa-solid fa-user-lock me-2"></i>Who can see reports</a></li><?php endif; ?>
            </ul>
        </div>
        <?php foreach ($tabs as $key => $text): ?>
            <a href="<?= e($tabUrl($key)) ?>"<?= $tab === $key ? ' class="is-active" aria-current="page"' : '' ?>><?= e($text) ?></a>
        <?php endforeach; ?>
    </div>

    <div class="rk-right">
        <div class="rk-date">
            <div class="dropdown d-flex">
                <button type="button" class="rk-range" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false"><i class="fa-regular fa-calendar"></i><?= e($period['label']) ?></button>
                <div class="dropdown-menu rk-menu">
                    <?php foreach ($period['presets'] as $name => $range): ?><a class="dropdown-item<?= $period['label'] === $name ? ' is-active' : '' ?>" href="<?= e($tabUrl($tab, $range)) ?>"><?= e($name) ?></a><?php endforeach; ?>
                    <div class="dropdown-divider"></div>
                    <form class="rk-custom" method="get" action="<?= e(url('/reports/' . $tab)) ?>">
                        <?= $carry(['from', 'to']) ?>
                        <label for="rk-from">From</label><input class="form-control form-control-sm mb-2" id="rk-from" type="date" name="from" value="<?= e($filters['from']) ?>">
                        <label for="rk-to">To</label><input class="form-control form-control-sm mb-2" id="rk-to" type="date" name="to" value="<?= e($filters['to']) ?>">
                        <button class="rk-apply w-100" type="submit">Apply</button>
                    </form>
                </div>
            </div>
            <a class="rk-step" href="<?= e($tabUrl($tab, $period['prev'])) ?>" aria-label="Previous period"><i class="fa-solid fa-angle-left"></i></a>
            <a class="rk-step" href="<?= e($tabUrl($tab, $period['next'])) ?>" aria-label="Next period"><i class="fa-solid fa-angle-right"></i></a>
        </div>
        <?php if ($canExport): ?>
        <div class="dropdown">
            <button type="button" class="rk-btn-outline dropdown-toggle h-100" data-bs-toggle="dropdown" aria-expanded="false">Export</button>
            <ul class="dropdown-menu dropdown-menu-end rk-menu"><li><a class="dropdown-item" href="<?= e(url('/reports/export.csv') . '?' . http_build_query($filters)) ?>">Save as CSV</a></li></ul>
        </div>
        <?php endif; ?>
    </div>
</div>

<form method="get" action="<?= e(url('/reports/' . $tab)) ?>" class="rk-filter">
    <?= $carry(['user_id', 'client_id', 'project_id', 'task_id', 'billable']) ?>
    <span class="rk-filter-label">Filter</span>
    <?php if ($canViewAll && in_array('user', $visibleFilters, true)): ?>
    <div class="rk-filter-item<?= (int) $filters['user_id'] > 0 ? ' is-set' : '' ?>"><select name="user_id" aria-label="Team"><option value="0">Team</option><?php foreach ($people as $person): ?><option value="<?= (int) $person['id'] ?>"<?= (int) $filters['user_id'] === (int) $person['id'] ? ' selected' : '' ?>><?= e($person['name']) ?></option><?php endforeach; ?></select></div>
    <?php endif; ?>
    <?php if ($canViewAll && in_array('client', $visibleFilters, true)): ?>
    <div class="rk-filter-item<?= (int) $filters['client_id'] > 0 ? ' is-set' : '' ?>"><select name="client_id" aria-label="Client"><option value="0">Client</option><?php foreach ($clients as $client): ?><option value="<?= (int) $client['id'] ?>"<?= (int) $filters['client_id'] === (int) $client['id'] ? ' selected' : '' ?>><?= e($client['name']) ?></option><?php endforeach; ?></select></div>
    <?php endif; ?>
    <?php if (in_array('project', $visibleFilters, true)): ?>
    <div class="rk-filter-item<?= (int) $filters['project_id'] > 0 ? ' is-set' : '' ?>"><select name="project_id" aria-label="Project"><option value="0">Project</option><?php foreach ($projects as $project): ?><option value="<?= (int) $project['id'] ?>"<?= (int) $filters['project_id'] === (int) $project['id'] ? ' selected' : '' ?>><?= e($project['name']) ?></option><?php endforeach; ?></select></div>
    <?php endif; ?>
    <?php if (in_array('task', $visibleFilters, true)): ?>
    <div class="rk-filter-item<?= (int) $filters['task_id'] > 0 ? ' is-set' : '' ?>"><select name="task_id" aria-label="Task"><option value="0">Task</option><?php foreach ($tasks as $task): ?><option value="<?= (int) $task['id'] ?>"<?= (int) $filters['task_id'] === (int) $task['id'] ? ' selected' : '' ?>><?= e($task['name']) ?></option><?php endforeach; ?></select></div>
    <?php endif; ?>
    <?php if (in_array('billable', $visibleFilters, true)): ?>
    <div class="rk-filter-item<?= $filters['billable'] !== '' ? ' is-set' : '' ?>"><select name="billable" aria-label="Status"><option value="">Status</option><option value="1"<?= $filters['billable'] === '1' ? ' selected' : '' ?>>Billable</option><option value="0"<?= $filters['billable'] === '0' ? ' selected' : '' ?>>Non-billable</option></select></div>
    <?php endif; ?>
    <div class="rk-filter-actions"><a class="rk-reset" href="<?= e(url('/reports/' . $tab)) ?>">Reset</a><button class="rk-apply" type="submit">Apply filter</button></div>
</form>
