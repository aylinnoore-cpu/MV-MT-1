<?php
// ---- Database settings: edit for your server ----
const DB=['127.0.0.1','mis_portal','root',''];   // host, database, user, password
// ---- Paths (auto) ----
$d=str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']));
define('BASE',rtrim(basename($d)=='modules'?str_replace('\\','/',dirname($d)):$d,'/'));   // URL of project root
define('ROOT',dirname(__DIR__));
define('ST',ROOT.'/storage/');                    // private uploads (blocked from web by .htaccess)
// For PDF import: install Poppler and, if it is not on PATH, uncomment and set the full path to pdftotext:
// const PDFTOTEXT='C:\\poppler\\Library\\bin\\pdftotext.exe';
