<?php
/**
 * NOTE tab: one free-text note, saved automatically (assets/js/project.js).
 * The note is stored in projects.description.
 *
 * @var array<string, mixed> $project
 * @var bool $canEdit
 */
?>
<section class="cf-card cf-pad">
    <div class="cf-note">
        <textarea id="cf-note" class="cf-note-box" maxlength="5000" placeholder="Add note..." aria-label="Project note"
                  <?= $canEdit ? 'data-note-url="' . e(url('/projects/' . (int) $project['id'] . '/note')) . '"' : 'readonly' ?>><?= e((string) ($project['description'] ?? '')) ?></textarea>
        <span class="cf-note-status" id="cf-note-status" aria-live="polite"></span>
    </div>
</section>
