/*
 * Dashboard charts (Chart.js) and time-entry edit modal.
 * Wired through data- attributes; no inline scripts.
 */
(function () {
    'use strict';

    function parseJsonAttr(el, name) {
        if (!el) { return []; }
        var raw = el.getAttribute(name);
        if (!raw) { return []; }
        try { return JSON.parse(raw); } catch (e) { return []; }
    }

    function barChart(canvas, labels, datasets) {
        if (!canvas || !window.Chart || labels.length === 0) { return; }
        new window.Chart(canvas, {
            type: 'bar',
            data: { labels: labels, datasets: datasets },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: { legend: { position: 'bottom' } },
                scales: {
                    x: { ticks: { autoSkip: true, maxRotation: 0 } },
                    y: { beginAtZero: true }
                }
            }
        });
    }

    var health = document.getElementById('projectHealthChart');
    if (health) {
        barChart(health, parseJsonAttr(health, 'data-chart-labels'), [
            { label: 'Estimated hours', data: parseJsonAttr(health, 'data-chart-planned'), backgroundColor: '#12426f' },
            { label: 'Tracked hours', data: parseJsonAttr(health, 'data-chart-actual'), backgroundColor: '#0b7a75' }
        ]);
    }

    var people = document.getElementById('peopleTimeChart');
    if (people) {
        barChart(people, parseJsonAttr(people, 'data-chart-labels'), [
            { label: 'Hours', data: parseJsonAttr(people, 'data-chart-hours'), backgroundColor: '#0b7a75' },
            { label: 'Billable amount', data: parseJsonAttr(people, 'data-chart-amounts'), backgroundColor: '#e8a317' }
        ]);
    }

    /* ---- Weekly team dashboard: stacked day chart + project donut ---- */
    function pad2(n) { return n < 10 ? '0' + n : String(n); }
    function hms(totalSeconds) {
        var s = Math.max(0, Math.round(totalSeconds));
        return pad2(Math.floor(s / 3600)) + ':' + pad2(Math.floor((s % 3600) / 60)) + ':' + pad2(s % 60);
    }

    // Pin a chart's box to a fixed size with inline styles. A responsive Chart.js canvas whose
    // container is sized by its own content grows on every resize; this makes that impossible
    // no matter which stylesheet is (or is not) loaded.
    function lockBox(canvas, width, height) {
        var box = canvas.parentElement;
        if (!box) { return; }
        box.style.position = 'relative';
        box.style.height = height;
        box.style.minHeight = '0';
        box.style.maxHeight = height;
        box.style.overflow = 'hidden';
        if (width) { box.style.width = width; box.style.maxWidth = '100%'; }
        canvas.style.position = 'absolute';
        canvas.style.top = '0';
        canvas.style.left = '0';
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.maxWidth = '100%';
        canvas.style.maxHeight = '100%';
    }

    var weekStack = document.getElementById('weekStackChart');
    if (weekStack && window.Chart) {
        lockBox(weekStack, '', '21rem');
        var wkLabels = parseJsonAttr(weekStack, 'data-labels');
        var wkSets = parseJsonAttr(weekStack, 'data-datasets');
        var wkTotals = parseJsonAttr(weekStack, 'data-totals');
        var maxHours = 0;
        wkTotals.forEach(function (t) { maxHours = Math.max(maxHours, t / 3600); });

        // Draws "hh:mm:ss" above each stacked column (and on the baseline for empty days).
        var totalsPlugin = {
            id: 'weekTotals',
            afterDatasetsDraw: function (chart) {
                var ctx = chart.ctx;
                var yScale = chart.scales.y;
                ctx.save();
                ctx.font = '12px "IBM Plex Sans", system-ui, sans-serif';
                ctx.fillStyle = '#5b6d6c';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'bottom';
                wkLabels.forEach(function (_, i) {
                    var top = yScale.getPixelForValue(0);
                    var x = null;
                    chart.data.datasets.forEach(function (ds, di) {
                        var el = chart.getDatasetMeta(di).data[i];
                        if (!el) { return; }
                        if (x === null) { x = el.x; }
                        if ((ds.data[i] || 0) > 0) { top = Math.min(top, el.y); }
                    });
                    if (x === null) { x = chart.scales.x.getPixelForValue(i); }
                    ctx.fillText(hms(wkTotals[i] || 0), x, top - 5);
                });
                ctx.restore();
            }
        };

        new window.Chart(weekStack, {
            type: 'bar',
            data: {
                labels: wkLabels,
                datasets: wkSets.map(function (s) {
                    return {
                        label: s.label,
                        data: s.data,
                        backgroundColor: s.color,
                        borderWidth: 0,
                        barPercentage: 0.72,
                        categoryPercentage: 0.9
                    };
                })
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                layout: { padding: { top: 18 } },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        filter: function (item) { return item.parsed.y > 0; },
                        callbacks: {
                            label: function (ctx) { return ' ' + ctx.dataset.label + ': ' + hms(ctx.parsed.y * 3600); }
                        }
                    }
                },
                scales: {
                    x: { stacked: true, grid: { display: false }, ticks: { color: '#5b6d6c', maxRotation: 0 } },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        suggestedMax: Math.max(5, Math.ceil(maxHours * 1.12 / 5) * 5),
                        grid: { color: '#edf0f1' },
                        border: { display: false },
                        ticks: {
                            color: '#9aa7ac',
                            callback: function (v) { return Number(v).toFixed(1) + 'h'; }
                        }
                    }
                }
            },
            plugins: [totalsPlugin]
        });
    }

    var weekDonut = document.getElementById('weekDonutChart');
    if (weekDonut && window.Chart) {
        lockBox(weekDonut, '19rem', '19rem');
        var dn = {};
        try { dn = JSON.parse(weekDonut.getAttribute('data-donut') || '{}'); } catch (e) { dn = {}; }
        new window.Chart(weekDonut, {
            type: 'doughnut',
            data: {
                labels: dn.labels || [],
                datasets: [{ data: dn.data || [], backgroundColor: dn.colors || [], borderColor: '#ffffff', borderWidth: 1 }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '66%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function (ctx) { return ' ' + ctx.label + ': ' + hms(ctx.parsed); }
                        }
                    }
                }
            }
        });
    }

    var editModalEl = document.getElementById('editEntryModal');
    var editForm = document.getElementById('editEntryForm');
    if (!editModalEl || !editForm || !window.bootstrap) { return; }

    var modal = window.bootstrap.Modal.getOrCreateInstance(editModalEl);
    var baseUrl = (document.body && document.body.getAttribute('data-base-url')) || '/';
    if (baseUrl.slice(-1) !== '/') { baseUrl += '/'; }

    function fillEditTasks(projectId, selectedId) {
        var taskSelect = editForm.querySelector('[data-timer-task-select]');
        if (!taskSelect) { return; }
        taskSelect.innerHTML = '<option value="">No task</option>';
        if (!projectId) { return; }

        fetch(baseUrl + 'time/tasks?project_id=' + encodeURIComponent(projectId), {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(function (response) { return response.json(); }).then(function (data) {
            if (!data || !data.ok || !data.tasks) { return; }
            data.tasks.forEach(function (task) {
                var opt = document.createElement('option');
                opt.value = String(task.id);
                opt.textContent = task.name;
                if (selectedId && String(selectedId) === String(task.id)) {
                    opt.selected = true;
                }
                taskSelect.appendChild(opt);
            });
        }).catch(function () { /* keep empty */ });
    }

    document.addEventListener('click', function (event) {
        var btn = event.target.closest ? event.target.closest('[data-entry-edit]') : null;
        if (!btn) { return; }
        event.preventDefault();

        var id = btn.getAttribute('data-id') || '0';
        editForm.setAttribute('action', baseUrl + 'time/' + id);

        var project = editForm.querySelector('[name="project_id"]');
        var start = editForm.querySelector('[name="start_time"]');
        var end = editForm.querySelector('[name="end_time"]');
        var brk = editForm.querySelector('[name="break_minutes"]');
        var desc = editForm.querySelector('[name="description"]');
        var billable = editForm.querySelector('[name="is_billable"]');
        var projectId = btn.getAttribute('data-project-id') || '';
        var taskId = btn.getAttribute('data-task-id') || '';

        if (project) { project.value = projectId; }
        if (start) { start.value = btn.getAttribute('data-start') || ''; }
        if (end) { end.value = btn.getAttribute('data-end') || ''; }
        if (brk) { brk.value = btn.getAttribute('data-break') || '0'; }
        if (desc) { desc.value = btn.getAttribute('data-description') || ''; }
        if (billable) { billable.checked = btn.getAttribute('data-billable') === '1'; }
        fillEditTasks(projectId, taskId);

        modal.show();
    });
})();