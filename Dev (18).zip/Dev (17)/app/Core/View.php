<?php
/**
 * Template renderer.
 *
 * Layouts (see app/Views/layouts):
 *   app  : header + sidebar + timer_bar + page + footer   (authenticated screens)
 *   auth : header + page + footer                          (login and similar)
 *   none : the page only                                   (partials, print views)
 *
 * Templates are plain PHP. Escape EVERY dynamic value with e():
 *   <?= e($project['name']) ?>
 */

declare(strict_types=1);

final class View
{
    private const LAYOUTS = [
        'app'  => ['layouts/header', 'layouts/sidebar', 'layouts/timer_bar', '@page', 'layouts/footer'],
        'auth' => ['layouts/header', '@page', 'layouts/footer'],
        'none' => ['@page'],
    ];

    /**
     * @param array<string, mixed> $data Variables exposed to the template
     */
    public static function render(string $view, array $data = [], string $layout = 'app'): void
    {
        if (!isset(self::LAYOUTS[$layout])) {
            throw new InvalidArgumentException("Unknown layout: {$layout}");
        }

        // Layout files can read the page title and similar values from $data too.
        foreach (self::LAYOUTS[$layout] as $part) {
            echo $part === '@page' ? self::capture($view, $data) : self::capture($part, $data);
        }
    }

    /** Render a view to a string without layout (useful for AJAX HTML fragments). */
    public static function fragment(string $view, array $data = []): string
    {
        return self::capture($view, $data);
    }

    /** @param array<string, mixed> $data */
    private static function capture(string $view, array $data): string
    {
        $file = self::resolve($view);

        // Isolated scope: the template only sees $data, never this class's internals.
        $render = static function (string $__file, array $__data): string {
            extract($__data, EXTR_SKIP);
            ob_start();
            try {
                require $__file;
            } catch (Throwable $e) {
                ob_end_clean();
                throw $e;
            }
            return (string) ob_get_clean();
        };

        return $render($file, $data);
    }

    /** Map "projects/index" to app/Views/projects/index.php, refusing anything that could escape the folder. */
    private static function resolve(string $view): string
    {
        if (!preg_match('#^[a-z0-9_]+(/[a-z0-9_]+)*$#i', $view)) {
            throw new InvalidArgumentException('Invalid view name.');
        }

        $file = APP_PATH . '/Views/' . $view . '.php';

        if (!is_file($file)) {
            throw new RuntimeException("View not found: {$view}");
        }

        return $file;
    }
}
