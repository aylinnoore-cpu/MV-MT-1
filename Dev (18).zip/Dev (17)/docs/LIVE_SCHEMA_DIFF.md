# Live schema diff

Compared on 2026-10-04 against `u897128490_timetrack_fixed.sql` (dump date 2026-10-03, MariaDB 11.8) and `database/install.sql`.

## Still behind install.sql until `phase17_sync_live_schema.sql` is applied

- `time_entries.auto_stopped` missing
- `reports.view`, `reports.export`, `reports.billing` permission rows missing
- `tasks.assigned_to` still present (should copy into `task_assignees` then drop)
- `activity_logs.record_id` still present
- `agent_pair_attempts` table missing (added in this audit)

## Canonical `tasks.status`

Live enum is the source of truth:

`To Do / In Progress / On Hold / Review / Completed / Cancelled`

`database/install.sql` now matches that enum. Code maps legacy `Open`/`Done` via `Task::normalizeStatus()`.

## After applying phase 17

Re-run:

```sql
SHOW COLUMNS FROM time_entries LIKE 'auto_stopped';
SELECT name FROM permissions WHERE name LIKE 'reports.%';
SELECT r.name, p.name FROM role_permissions rp
  JOIN roles r ON r.id=rp.role_id JOIN permissions p ON p.id=rp.permission_id
  WHERE p.name LIKE 'reports.%';
```

Expect `auto_stopped` present and three `reports.*` permission rows assigned to admin and manager.
