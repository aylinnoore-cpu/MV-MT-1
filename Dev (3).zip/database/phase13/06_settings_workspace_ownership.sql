-- TimeTrack Phase 13 / Step 14
-- Canonical settings ownership.
-- Global/system values remain in settings; workspace policy values live in workspace_settings.
-- Safe to run more than once.

START TRANSACTION;

-- Preserve the existing workspace name when it is already meaningful. If an older
-- install only has the generic/default name, migrate the legacy company name into it.
UPDATE workspaces w
JOIN settings s ON s.setting_key = 'company_name'
SET w.name = s.setting_value,
    w.updated_at = UTC_TIMESTAMP()
WHERE TRIM(w.name) = '' OR w.name = 'TimeTrack';

-- Legacy week_start_day -> workspace week_start. Existing workspace value wins.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id,
       'week_start',
       CASE
           WHEN s.setting_value = '0' THEN 'sunday'
           ELSE 'monday'
       END,
       UTC_TIMESTAMP()
FROM workspaces w
LEFT JOIN settings s ON s.setting_key = 'week_start_day'
LEFT JOIN workspace_settings ws
       ON ws.workspace_id = w.id AND ws.setting_key = 'week_start'
WHERE ws.workspace_id IS NULL;

-- Legacy working_hours_per_day -> workspace daily_capacity. Existing workspace value wins.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id,
       'daily_capacity',
       CASE
           WHEN s.setting_value REGEXP '^[0-9]+(\\.[0-9]+)?$'
               THEN CAST(LEAST(24, GREATEST(1, CAST(s.setting_value AS DECIMAL(10,2)))) AS CHAR)
           ELSE '8'
       END,
       UTC_TIMESTAMP()
FROM workspaces w
LEFT JOIN settings s ON s.setting_key = 'working_hours_per_day'
LEFT JOIN workspace_settings ws
       ON ws.workspace_id = w.id AND ws.setting_key = 'daily_capacity'
WHERE ws.workspace_id IS NULL;

-- Legacy time_rounding_minutes -> workspace time_rounding_minutes.
-- Canonical workspace policy permits 1..60, so legacy 0/off is normalized to 1.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id,
       'time_rounding_minutes',
       CASE
           WHEN s.setting_value REGEXP '^[0-9]+$'
               THEN CAST(LEAST(60, GREATEST(1, CAST(s.setting_value AS UNSIGNED))) AS CHAR)
           ELSE '1'
       END,
       UTC_TIMESTAMP()
FROM workspaces w
LEFT JOIN settings s ON s.setting_key = 'time_rounding_minutes'
LEFT JOIN workspace_settings ws
       ON ws.workspace_id = w.id AND ws.setting_key = 'time_rounding_minutes'
WHERE ws.workspace_id IS NULL;

-- Legacy timesheet_approval -> workspace time_approval_enabled.
-- timesheet_enabled remains a separate workspace feature switch.
INSERT IGNORE INTO workspace_settings (workspace_id, setting_key, setting_value, updated_at)
SELECT w.id,
       'time_approval_enabled',
       CASE
           WHEN s.setting_value IN ('1','true','yes','on') THEN '1'
           ELSE '0'
       END,
       UTC_TIMESTAMP()
FROM workspaces w
LEFT JOIN settings s ON s.setting_key = 'timesheet_approval'
LEFT JOIN workspace_settings ws
       ON ws.workspace_id = w.id AND ws.setting_key = 'time_approval_enabled'
WHERE ws.workspace_id IS NULL;

-- Remove the legacy duplicates. These keys are no longer writable/read by Step 14.
DELETE FROM settings
WHERE setting_key IN (
    'company_name',
    'week_start_day',
    'working_hours_per_day',
    'time_rounding_minutes',
    'timesheet_approval'
);

COMMIT;
