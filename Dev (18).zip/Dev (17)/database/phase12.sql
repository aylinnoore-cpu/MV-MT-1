-- Phase 12: selectable work-entry submissions for timesheet approval.
-- Existing timesheets remain intact. A user can submit multiple batches from the same date range.
SET FOREIGN_KEY_CHECKS = 0;
ALTER TABLE timesheets ADD COLUMN IF NOT EXISTS submission_token varchar(64) DEFAULT NULL AFTER end_date;
ALTER TABLE timesheets DROP INDEX uq_timesheets_user_period;
UPDATE timesheets SET submission_token = CONCAT('legacy-', id) WHERE submission_token IS NULL OR submission_token = '';
ALTER TABLE timesheets ADD UNIQUE KEY uq_timesheets_submission_token (submission_token);
ALTER TABLE timesheets ADD KEY idx_timesheets_user_period (user_id, start_date, end_date);
SET FOREIGN_KEY_CHECKS = 1;
