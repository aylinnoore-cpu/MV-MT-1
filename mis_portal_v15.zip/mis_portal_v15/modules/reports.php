<?php require __DIR__.'/../includes/lib.php';need();if(role()=='staff')die('Access denied');
$R=['assets'=>['Asset inventory & status','SELECT a.asset_tag,a.name,a.category,a.serial_no,a.status,a.cost,COALESCE(vv.name,a.vendor) vendor,a.warranty_end,u.name assigned_to FROM assets a LEFT JOIN users u ON u.id=a.assigned_to LEFT JOIN vendors vv ON vv.id=a.vendor_id'],
'procurement'=>['Procurement','SELECT p.id,p.type,p.title,COALESCE(vv.name,p.vendor) vendor,p.amount,p.po_number,p.status,u.name requested_by,p.created_at FROM procurement p LEFT JOIN users u ON u.id=p.requested_by LEFT JOIN vendors vv ON vv.id=p.vendor_id'],
'tickets'=>['Support tickets','SELECT t.ticket_no,t.title,t.category,t.priority,t.status,u.name created_by,t.created_at,t.updated_at FROM tickets t LEFT JOIN users u ON u.id=t.created_by'],
'vendors'=>['Vendors','SELECT name,category,contact_person,phone,email,city,ntn,payment_terms,status FROM vendors ORDER BY name'],
'warranty'=>['Warranty status','SELECT a.asset_tag,a.name,COALESCE(v.name,a.vendor) vendor,a.warranty_end,DATEDIFF(a.warranty_end,CURDATE()) days_remaining,a.status FROM assets a LEFT JOIN vendors v ON v.id=a.vendor_id WHERE a.warranty_end IS NOT NULL ORDER BY a.warranty_end'],
'network'=>['Network / IP assignments','SELECT a.asset_tag,a.name,a.mac_address,a.ip_address,a.ip_type,u.name assigned_to FROM assets a LEFT JOIN users u ON u.id=a.assigned_to WHERE a.mac_address IS NOT NULL OR a.ip_address IS NOT NULL ORDER BY a.ip_address'],
'staff'=>['Staff asset allocation','SELECT u.name,u.department,u.location,a.asset_tag,a.name asset,a.assigned_date FROM users u LEFT JOIN assets a ON a.assigned_to=u.id ORDER BY u.name'],
'maintenance'=>['Maintenance','SELECT a.asset_tag,a.name asset,m.type,m.technician,m.cost,m.work_date,m.next_due,m.status FROM maintenance m LEFT JOIN assets a ON a.id=m.asset_id']];
if(role()=='finance')$R=array_intersect_key($R,['assets'=>1,'procurement'=>1,'vendors'=>1,'warranty'=>1]);
$k=$_GET['r']??array_key_first($R);$R[$k]??die('Unknown report');$rows=q($R[$k][1])->fetchAll();
if(isset($_GET['csv'])){header('Content-Type:text/csv');header("Content-Disposition:attachment;filename=$k.csv");$o=fopen('php://output','w');
 if($rows)csvput($o,array_keys($rows[0]));foreach($rows as $x)csvput($o,$x);exit;}
head('Reports');echo '<p class=noprint>';foreach($R as $i=>$v)echo "<a class='btn ".($i==$k?'':'g')."' href='?r=$i'>$v[0]</a> ";
echo "</p><p class=noprint><a class=btn href='?r=$k&csv=1'>Export Excel (CSV)</a> <button onclick=print() >Print / Save as PDF</button></p><div class=card><h3>".h($R[$k][0])."</h3><table>";
if($rows){echo '<tr>';foreach(array_keys($rows[0]) as $c)echo '<th>'.h(pretty($c));foreach($rows as $x){echo '<tr>';foreach($x as $v)echo '<td>'.h($v);}}
echo '</table></div>';foot();
