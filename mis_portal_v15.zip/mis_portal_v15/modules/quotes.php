<?php require __DIR__.'/../includes/lib.php';allow(['support','ed','finance']);$mis=role()=='support';$p=(int)($_GET['p']??0);
if($_SERVER['REQUEST_METHOD']=='POST'){chk();if(!$mis)die('Access denied');$p=(int)$_POST['p'];
 if(isset($_POST['del'])){$d=q('SELECT * FROM documents WHERE id=? AND kind="quotation"',[(int)$_POST['del']])->fetch();
  $rs=trim($_POST['reason']??'');if($d&&$rs===''){$_SESSION['err']='A reason is required to delete a quotation.';}elseif($d){log_delete('Quotation',$d['id'],$d['orig_name'],$d+['file_sha256'=>@hash_file('sha256',ST.$d['stored'])],$rs);@unlink(ST.$d['stored']);q('DELETE FROM documents WHERE id=?',[$d['id']]);logit("Deleted quotation {$d['orig_name']} (procurement #$p) - reason: ".mb_substr($rs,0,120));}}
 else foreach($_FILES['files']['name']??[] as $i=>$n){if($n==='')continue;$f=array_combine(['name','tmp_name','size'],[$n,$_FILES['files']['tmp_name'][$i],$_FILES['files']['size'][$i]]);
  $r=store($f,['pdf','jpg','jpeg','png']);if($r){adddoc('quotation',$p,$n,$r[0],$r[1]);logit("Uploaded quotation $n (procurement #$p)");}else $_SESSION['err']="Rejected $n: only PDF/JPG/PNG up to 8MB.";}
 header("Location: quotes.php?p=$p");exit;}
head('Quotations');if(!empty($_SESSION['err'])){echo '<p class=err>'.h($_SESSION['err']).'</p>';unset($_SESSION['err']);}
echo '<div class=card><form method=get>Procurement request: <select name=p onchange=form.submit()><option value=0>-- select --</option>';
foreach(q('SELECT id,title FROM procurement ORDER BY id DESC') as $x)echo "<option value=$x[id]".($x['id']==$p?' selected':'').'>#'.$x['id'].' '.h($x['title']).'</option>';echo '</select></form></div>';
if($p){if($mis)echo '<div class=card><form method=post enctype=multipart/form-data><input type=hidden name=c value="'.csrf().'"><input type=hidden name=p value='.$p.'>
 <label>Upload vendor quotations (PDF, JPG, PNG - multiple allowed)</label><input type=file name=files[] multiple required accept=.pdf,.jpg,.jpeg,.png><p><button>Upload</button></p></form></div>';
 echo '<div class=card><table><tr><th>File<th>Uploaded<th>By<th>';$us=array_column(q('SELECT id,name FROM users')->fetchAll(),'name','id');
 foreach(q('SELECT * FROM documents WHERE kind="quotation" AND ref_id=? ORDER BY id DESC',[$p]) as $d)
  echo '<tr><td>'.h($d['orig_name']).'<td>'.$d['created_at'].'<td>'.h($us[$d['uploaded_by']]??'').'<td><a href="file.php?id='.$d['id'].'" target=_blank>Preview</a> | <a href="file.php?id='.$d['id'].'&dl=1">Download</a>'
  .($mis?' | <form method=post style=display:inline onsubmit="return dl(this)"><input type=hidden name=reason><input type=hidden name=c value="'.csrf().'"><input type=hidden name=p value='.$p.'><button name=del value='.$d['id'].' class="btn r" style="padding:2px 8px">Delete</button></form>':'');
 echo '</table></div>';}
foot();
