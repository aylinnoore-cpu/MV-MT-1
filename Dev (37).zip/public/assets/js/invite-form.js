(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var projects = document.querySelector('[data-invite-projects]');
    var tasks = document.querySelector('[data-invite-tasks]');
    if (!projects || !tasks) return;

    var sync = function () {
      var selected = {};
      Array.prototype.forEach.call(projects.selectedOptions, function (opt) {
        selected[opt.value] = true;
      });
      var any = Object.keys(selected).length > 0;
      Array.prototype.forEach.call(tasks.options, function (opt) {
        var pid = opt.getAttribute('data-project-id');
        var show = !any || (pid !== null && selected[pid]);
        opt.hidden = !show;
        opt.disabled = !show;
        if (!show) {
          opt.selected = false;
        }
      });
    };

    projects.addEventListener('change', sync);
    sync();
  });
})();
